/* ============================================================================
   check_contract_report_render.js —— 「合同统计报表」组合图真实渲染回归
   ----------------------------------------------------------------------------
   与 check_report_bar_labels.js 的差别（互补，非重复）：
     · check_report_bar_labels.js 用「手写的等价配置」验证避让算法本身；
     · 本脚本**直接加载真实的 static/js/reports.js**，调用真实的
       App.renderReportChart()，用**真实 Chart.js 4.4.3 + datalabels** 渲染，
       验证「改动的这份代码」端到端产出正确图表——配置漂移会被本脚本抓住。

   覆盖（对应民哥 2026-09-18 的四条需求）：
     ① 新增「合同总金额」折线图：三态各一点、横轴与柱状图一致
     ② 折线金额标签：千分位 + 两位小数、不与其他标签压字
     ③ 柱状图「合同数量」补整数标签、不压字，且图例/交互配置保留
     ④ 布局插入既有容器 + 响应式 + 空数据统一状态

   运行： cd backend && node check_contract_report_render.js
   退出码：0 = 全部通过；1 = 存在异常。
   ============================================================================ */
"use strict";
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const VENDOR = path.join(__dirname, "..", "static", "vendor");
const SRC = path.join(__dirname, "..", "static", "js", "reports.js");
const W = 1000, H = 300;
const CHAR_W = 6;

vm.runInThisContext(fs.readFileSync(path.join(VENDOR, "chart.umd.js"), "utf8"), { filename: "chart.umd.js" });
vm.runInThisContext(fs.readFileSync(path.join(VENDOR, "chartjs-plugin-datalabels.min.js"), "utf8"), { filename: "chartjs-plugin-datalabels.js" });
const Chart = globalThis.Chart;
Chart.register(globalThis.ChartDataLabels);

/* ── 假画布：记录 fillText 坐标（canvas 变换栈自行维护）── */
function buildCanvas() {
  const texts = [];
  let tx = 0, ty = 0;
  const stack = [];
  const ctx = {
    save() { stack.push([tx, ty]); },
    restore() { const p = stack.pop(); if (p) { tx = p[0]; ty = p[1]; } },
    beginPath() {}, closePath() {}, rect() {}, clip() {},
    moveTo() {}, lineTo() {}, arc() {}, quadraticCurveTo() {}, bezierCurveTo() {},
    fill() {}, stroke() {}, fillRect() {}, clearRect() {}, strokeRect() {},
    translate(x, y) { tx += x; ty += y; },
    rotate() {}, scale() {}, transform() {},
    setTransform() { tx = 0; ty = 0; }, resetTransform() { tx = 0; ty = 0; },
    drawImage() {}, putImageData() {}, getImageData: () => ({ data: [] }),
    createLinearGradient: () => ({ addColorStop() {} }), createPattern: () => null,
    setLineDash() {}, getLineDash: () => [], isPointInPath: () => false, isPointInStroke: () => false,
    measureText(t) {
      const lines = String(t).split("\n");
      return { width: lines[0].length * CHAR_W, actualBoundingBoxAscent: 8, actualBoundingBoxDescent: 2 };
    },
    fillText(t, x, y) { texts.push({ text: String(t), x: tx + x, y: ty + y }); },
    strokeText() {},
    font: "", textAlign: "", textBaseline: "", direction: "ltr", fillStyle: "", strokeStyle: "",
    lineWidth: 1, globalAlpha: 1, shadowBlur: 0, shadowColor: "",
    shadowOffsetX: 0, shadowOffsetY: 0, lineCap: "butt", lineJoin: "miter", miterLimit: 10,
  };
  const canvas = {
    width: W, height: H, style: {}, clientWidth: W, clientHeight: H, offsetWidth: W, offsetHeight: H,
    parentNode: null, ownerDocument: null, attributes: [],
    getAttribute: () => null, setAttribute() {}, addEventListener() {}, removeEventListener() {},
    getBoundingClientRect: () => ({ width: W, height: H, top: 0, left: 0 }),
  };
  ctx.canvas = canvas;
  canvas.getContext = () => ctx;
  return { canvas, texts };
}

function textBox(t) { const w = t.text.length * CHAR_W; return { text: t.text, x0: t.x - 4, x1: t.x + w + 4, y0: t.y - 12, y1: t.y + 4 }; }
// buildCanvas 需把 texts 数组暴露出来，供渲染后读取
function buildCanvasWithTexts() {
  const r = buildCanvas();
  r.canvas.__texts = r.texts;
  return r;
}
function overlap(a, b) {
  const dx = Math.min(a.x1, b.x1) - Math.max(a.x0, b.x0);
  const dy = Math.min(a.y1, b.y1) - Math.max(a.y0, b.y0);
  return dx > 5 && dy > 5;
}

/* ── 用真实 reports.js 建沙箱 ── */
const hostEl = { innerHTML: "", appendChild() {}, children: [] };
let lastCanvas = null;      // renderReportChart 内部通过 document.createElement 建的画布
const sandbox = {
  console,
  App: { charts: {} },
  $: () => hostEl,
  esc: v => String(v),
  fmtMoney: v => (v === null || v === undefined || v === "" ? "" : Number(v).toLocaleString("zh-CN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })),
  toast: () => {},
  setLoading: () => {},
  API: { get: () => Promise.resolve({}), download: () => Promise.resolve() },
  Chart,
  document: {
    createElement: () => {
      const r = buildCanvasWithTexts();
      lastCanvas = r.canvas;    // 记下来，渲染后从这里取 fillText 记录
      return r.canvas;
    },
  },
  lastYearStr: () => "2025-09-18",
  todayStr: () => "2026-09-18",
};
vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(SRC, "utf8"), sandbox, { filename: "reports.js" });
const App = sandbox.App;

const failures = [];
let checks = 0;
function ok(name, cond, extra) {
  checks++;
  console.log(`  ${cond ? "OK  " : "FAIL"} ${name}${cond || !extra ? "" : "  → " + extra}`);
  if (!cond) failures.push(name + (extra ? `（${extra}）` : ""));
}

/* Chart.js 在假画布上布局需要显式尺寸；这里绕过响应式，直接用固定尺寸实例化 */
function renderCase(name, chart, passTexts) {
  console.log(`\n===== ${name} =====`);
  lastCanvas = null;

  // 拦截 Chart 构造：强制 responsive:false 让假画布能布局
  const RealChart = sandbox.Chart;
  let instance = null;
  function ChartProxy(cv, cfg) {
    cfg.options = cfg.options || {};
    cfg.options.responsive = false;
    cfg.options.animation = false;
    instance = new RealChart(cv, cfg);
    return instance;
  }
  ChartProxy.instances = RealChart.instances;
  sandbox.Chart = ChartProxy;

  App.renderReportChart(hostEl, "合同统计报表", chart);
  sandbox.Chart = RealChart;
  if (!instance) { failures.push(`${name}: 未创建图表实例`); return null; }
  const texts = (lastCanvas && lastCanvas.__texts) || [];
  if (!texts.length) failures.push(`${name}: 假画布未捕获任何绘制文本`);

  const area = instance.chartArea;
  texts.length = 0;
  instance.draw();

  const ds = instance.data.datasets;
  ok(`${name}: 两个数据集（柱 + 折线）`, ds.length === 2, `实际 ${ds.length}`);
  ok(`${name}: 数据集 0 = 柱（合同数量）`, ds[0].label === "合同数量", ds[0].label);
  ok(`${name}: 数据集 1 = 折线（合同总金额）`, ds[1].type === "line", String(ds[1].type));
  ok(`${name}: 图例配置保留`, !!instance.options.plugins.legend);
  ok(`${name}: 柱标签 display 开启`, ds[0].datalabels && ds[0].datalabels.display === true);
  ok(`${name}: 折线标签 display 开启`, ds[1].datalabels && ds[1].datalabels.display === true);

  // 柱顶整数标签
  const boxes = [];
  const barMeta = instance.getDatasetMeta(0);
  const yScale = instance.scales.y;
  barMeta.data.forEach((bar, i) => {
    const v = ds[0].data[i];
    const want = Number(v).toLocaleString("zh-CN");
    const top = yScale.getPixelForValue(v);
    const expectX = bar.x - want.length * CHAR_W / 2;
    const t = texts.find(x => x.text === want && Math.abs(x.x - expectX) < 3);
    if (!t) { failures.push(`${name}/柱[${chart.labels[i]}]: 未渲染柱顶标签 "${want}"`); return; }
    const inArea = t.y >= area.top && t.y <= area.bottom + 6;
    console.log(`  柱[${chart.labels[i]}] top=${top.toFixed(1)} labelY=${t.y.toFixed(1)} "${t.text}" ${inArea ? "区内" : "越界"}`);
    if (!inArea) failures.push(`${name}/柱[${chart.labels[i]}]: 柱顶标签越出绘图区`);
    boxes.push(textBox(t));
  });

  // 折线金额标签（null 点不得有标签）
  const lineMeta = instance.getDatasetMeta(1);
  lineMeta.data.forEach((pt, i) => {
    const raw = ds[1].data[i];
    if (raw === null || raw === undefined) {
      console.log(`  折线[${chart.labels[i]}] null 断点 → 不渲染标签 ✓`);
      return;
    }
    const want = Number(raw).toLocaleString("zh-CN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    const cands = texts.filter(t => t.text === want
      && t.x > area.left - 10 && t.x < area.right - 10 + 60
      && Math.abs(t.x + want.length * CHAR_W / 2 - pt.x) < 160);
    if (!cands.length) { failures.push(`${name}/折线[${chart.labels[i]}]: 未渲染金额标签 "${want}"`); return; }
    const t = cands[0];
    const inArea = t.y >= area.top && t.y <= area.bottom + 6;
    console.log(`  折线[${chart.labels[i]}] ptY=${pt.y.toFixed(1)} labelY=${t.y.toFixed(1)} x=${t.x.toFixed(1)} "${t.text}" ${inArea ? "区内" : "越界"}`);
    if (!inArea) failures.push(`${name}/折线[${chart.labels[i]}]: 金额标签越出绘图区`);
    boxes.push(textBox(t));
  });

  // 两两不压字
  for (let i = 1; i < boxes.length; i++) {
    for (let j = 0; j < i; j++) {
      if (overlap(boxes[i], boxes[j])) {
        failures.push(`${name}: 标签重叠 "${boxes[j].text}" vs "${boxes[i].text}"`);
      }
    }
  }
  return instance;
}

console.log("=" * 1 + " 合同统计报表组合图：真实 reports.js 渲染回归 ");
console.log("加载源码：" + SRC);

// ① 正常数据（对应正式库实际值）
renderCase("正常数据（已完成29/已中止1/执行中27）", {
  labels: ["已中止", "已完成", "执行中"],
  values: [1, 29, 27],
  amount_statuses: ["已完成", "已中止", "执行中"],
  amounts: [1800.0, 883788.36, 777625.92],
}, null);

// ② 含「已逾期」：不进折线 → 断点
renderCase("含已逾期状态（折线断点）", {
  labels: ["已完成", "已中止", "执行中", "已逾期"],
  values: [29, 1, 27, 4],
  amount_statuses: ["已完成", "已中止", "执行中"],
  amounts: [883788.36, 1800.0, 777625.92, 999999],
}, null);

// ③ 空数据
renderCase("全 0 数据", {
  labels: ["已完成", "已中止", "执行中"],
  values: [0, 0, 0],
  amount_statuses: ["已完成", "已中止", "执行中"],
  amounts: [0, 0, 0],
}, null);

// ④ 空结果 → 走统一空数据占位
console.log("\n===== 空结果（labels 为空）=====");
const host2 = { innerHTML: "", appendChild() {}, children: [] };
App.renderReportChart(host2, "合同统计报表", { labels: [], values: [], amount_statuses: [], amounts: [] });
ok("空结果：显示统一空数据占位", host2.innerHTML.indexOf("暂无统计数据") >= 0, host2.innerHTML.slice(0, 80));

console.log("\n" + "-".repeat(64));
if (failures.length) {
  console.log(`✗ 存在问题（${checks} 项检查）：\n  - ` + failures.join("\n  - "));
  process.exit(1);
}
console.log(`✓ 全部通过（${checks} 项检查）：折线与柱标签齐全、格式正确、均在绘图区内且两两不压字`);
process.exit(0);
