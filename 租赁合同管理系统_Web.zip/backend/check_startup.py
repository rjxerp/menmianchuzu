# -*- coding: utf-8 -*-
"""启动诊断脚本（2026-09-11）

用途：项目启动后「连不上数据库 / 登录失败 / 服务起不来」时，一键查清根因。
输出：解释器与依赖、配置文件解析、数据库路径与文件、实连测试、关键表与数据量、连接池状态、结论与下一步。

用法：python check_startup.py      （或双击项目根目录的「诊断启动.bat」）
"""
import os
import sys
import json
import time
import sqlite3

BASE = os.path.dirname(os.path.abspath(__file__))
PROJECT = os.path.dirname(BASE)
sys.path.insert(0, BASE)

# 与 main.py 保持一致的配置指向
os.environ.setdefault("LEASE_CONFIG_PATH", os.path.join(PROJECT, "config.json"))

OK, BAD, WARN = "[OK ]", "[!! ]", "[ ? ]"
_problems = []


def line(title):
    print("\n" + "=" * 66)
    print(title)
    print("=" * 66)


def item(name, value, ok=True):
    print(f"  {OK if ok else BAD} {name:<26} {value}")
    if not ok:
        _problems.append(f"{name}: {value}")


def warn(name, value):
    print(f"  {WARN} {name:<26} {value}")


# ---------------------------------------------------------------- 1. 解释器与依赖
line("1. 解释器与依赖")
item("Python 可执行文件", sys.executable)
item("Python 版本", sys.version.split()[0])
item("工作目录(cwd)", os.getcwd())
print(f"  {'':4} 项目根目录                 {PROJECT}")

DEPS = {
    "fastapi": "Web 框架",
    "uvicorn": "ASGI 服务器",
    "pydantic": "数据校验",
    "multipart": "文件上传(python-multipart)",
    "jwt": "认证(PyJWT)",
    "openpyxl": "Excel 导入导出",
    "reportlab": "PDF 导出",
}
missing = []
for mod, desc in DEPS.items():
    try:
        __import__(mod)
        item(f"{mod}", f"已安装（{desc}）")
    except Exception as e:
        missing.append(mod)
        item(f"{mod}", f"缺失（{desc}）→ {e}", ok=False)

# ---------------------------------------------------------------- 2. 配置
line("2. 配置文件解析")
env_cfg = os.environ.get("LEASE_CONFIG_PATH")
print(f"  {'':4} LEASE_CONFIG_PATH          {env_cfg}")
try:
    from config_utils import ConfigManager
    cfg_path = ConfigManager.get_config_path()
    item("配置文件实际读取路径", cfg_path, ok=os.path.isfile(cfg_path))
    if os.path.isfile(cfg_path):
        with open(cfg_path, "r", encoding="utf-8") as f:
            raw = json.load(f)
        keys = list(raw.keys())
        item("配置顶层键", ", ".join(keys))
        item("secret_key(JWT 密钥)", "已配置(已隐藏)" if raw.get("secret_key") else "缺失", ok=bool(raw.get("secret_key")))
        if "database_path" not in raw:
            warn("database_path", "配置中未设置（将回退扫描 Data/ 目录）")
    db_path = ConfigManager.get_database_path()
except Exception as e:
    item("加载配置", f"失败: {e}", ok=False)
    db_path = None

# ---------------------------------------------------------------- 3. 数据库文件
line("3. 数据库路径与文件")
if not db_path:
    item("解析出的数据库路径", "无（未配置）", ok=False)
    data_dir = os.path.join(PROJECT, "Data")
    cands = [f for f in os.listdir(data_dir) if f.lower().endswith(".db")] if os.path.isdir(data_dir) else []
    if cands:
        warn("回退候选(Data/)", ", ".join(cands) + "  ← 启动时会自动采用第一个")
        db_path = os.path.join(data_dir, sorted(cands, key=lambda n: (0 if n.upper().startswith("ZHMY") else 1, n))[0])
else:
    item("解析出的数据库路径", db_path)

if db_path:
    exists = os.path.isfile(db_path)
    item("数据库文件存在", "是" if exists else "否（启动时会自动新建空库）", ok=exists)
    if exists:
        st = os.stat(db_path)
        item("文件大小", f"{st.st_size:,} 字节")
        item("最后修改时间", time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(st.st_mtime)))
        item("父目录可写", "是" if os.access(os.path.dirname(db_path), os.W_OK) else "否", ok=os.access(os.path.dirname(db_path), os.W_OK))
        for suf in ("-wal", "-shm"):
            if os.path.exists(db_path + suf):
                warn(f"伴随文件 {suf}", f"{os.path.getsize(db_path + suf):,} 字节（正常，属 WAL 机制）")

# ---------------------------------------------------------------- 4. 实连测试
line("4. 数据库实连测试（走项目自身的连接层）")
tables = {}
connected = False
if db_path:
    try:
        import db_utils
        from db_utils import DatabaseUtils
        DatabaseUtils.set_db_path(db_path)
        DatabaseUtils._money_migrated = None
        conn = DatabaseUtils.get_connection()
        if conn is None:
            item("get_connection()", "返回 None（连接失败）", ok=False)
        else:
            try:
                v = conn.execute("SELECT sqlite_version()").fetchone()[0]
                item("建立连接", f"成功（SQLite {v}）")
                jm = conn.execute("PRAGMA journal_mode").fetchone()[0]
                item("journal_mode", jm)
                item("PRAGMA integrity_check", conn.execute("PRAGMA integrity_check").fetchone()[0])
                for t in ("contracts", "rent_records", "reminder_settings", "users", "houses"):
                    row = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (t,)).fetchone()
                    if row is None:
                        item(f"关键表 {t}", "缺失", ok=False)
                        tables[t] = None
                    else:
                        cnt = conn.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
                        tables[t] = cnt
                        item(f"关键表 {t}", f"存在，{cnt} 条记录")
                try:
                    row = conn.execute("SELECT value FROM schema_meta WHERE key='amount_cents_migrated'").fetchone()
                    item("金额迁移标记", row[0] if row else "无（金额按元处理）")
                except Exception:
                    warn("金额迁移标记", "schema_meta 表不存在")
                # 能否真正登录（users 表必须有记录）
                if tables.get("users") == 0:
                    item("可登录账号", "users 表为空 → 登录必然失败", ok=False)
                elif tables.get("users"):
                    unames = [r[0] for r in conn.execute("SELECT username FROM users").fetchall()]
                    item("可登录账号", ", ".join(unames))
                connected = True
            finally:
                DatabaseUtils.close_connection(conn)
        pool = len(getattr(DatabaseUtils, "_connection_pool", []) or [])
        active = len(getattr(DatabaseUtils, "_active_connections", {}) or {})
        item("连接池状态", f"空闲 {pool} / 使用中 {active}")
    except Exception as e:
        item("连接测试", f"异常: {type(e).__name__}: {e}", ok=False)

# ---------------------------------------------------------------- 5. 启动路径一致性
line("5. 常规启动路径一致性（start_web.bat 用 --app-dir backend，cwd=项目根）")
item("项目根/config.json", os.path.join(PROJECT, "config.json"), ok=os.path.isfile(os.path.join(PROJECT, "config.json")))
marker = os.path.join(BASE, ".python_exe.txt")
if os.path.isfile(marker):
    with open(marker, "r", encoding="utf-8") as f:
        item("记忆的解释器", f.read().strip())
else:
    warn("记忆的解释器", "无（下次启动自动探测并写入 backend/.python_exe.txt）")
item("backend 目录", BASE, ok=os.path.isdir(BASE))
item("static 目录", os.path.join(PROJECT, "static"), ok=os.path.isdir(os.path.join(PROJECT, "static")))

# ---------------------------------------------------------------- 6. 结论
line("6. 结论与下一步")
if missing:
    print(f"  ✗ 当前解释器缺少依赖: {', '.join(missing)}")
    print(f"     修复: {sys.executable} -m pip install -r {os.path.join(PROJECT, 'requirements.txt')}")
if _problems:
    for p in _problems:
        print(f"  ✗ {p}")
if not _problems and connected and not missing:
    print("  ✓ 启动链路全部正常：解释器/依赖/配置/数据库连接/关键表 均通过")
    print(f"     可正常启动：双击 start_web.bat（或 {sys.executable} -m uvicorn main:app --host 127.0.0.1 --port 8000 --app-dir backend）")
else:
    print("\n  常见处置：")
    print("   · 依赖缺失        → pip install -r requirements.txt")
    print("   · 数据库文件缺失  → 启动时自动新建空库（admin/admin），或改 config.json 的 database_path")
    print("   · 关键表缺失      → 登录后「系统设置 → 初始化数据」按表重建")
    print("   · 用户表为空      → 用「系统设置 → 数据初始化」重建默认 admin 账号")
    print("   · 解释器选错      → 删除 backend/.python_exe.txt 后重新双击 start_web.bat 自动重选")

print("\n" + "=" * 66)
sys.exit(1 if (_problems or missing) else 0)
