# -*- coding: utf-8 -*-
"""重置管理员密码（2026-09-11 新增）

用途：忘记密码 / 密码不是默认值导致登录失败时，把指定账号重置为已知密码。

用法：
  python reset_admin_password.py                 # 把 admin 重置为 admin（默认）
  python reset_admin_password.py admin 新密码     # 指定账号与新密码
  python reset_admin_password.py --list           # 只列出账号，不改动

安全说明：
  · 仅在本机运行，直接操作 config.json 指向的数据库；
  · 会先自动备份当前库到 backup/ 目录；
  · 重置后所有已登录设备的旧 token 立即失效（需重新登录）。
"""
import os
import sys
import sqlite3

BASE = os.path.dirname(os.path.abspath(__file__))
PROJECT = os.path.dirname(BASE)
sys.path.insert(0, BASE)
os.environ.setdefault("LEASE_CONFIG_PATH", os.path.join(PROJECT, "config.json"))

import db_utils
from db_utils import DatabaseUtils
from config_utils import ConfigManager
import auth
import services


def main():
    args = [a for a in sys.argv[1:]]
    db_path = ConfigManager.get_database_path()
    if not db_path:
        print("✗ 未配置数据库路径，请检查 config.json 的 database_path")
        return 1
    print("目标数据库:", db_path)
    if not os.path.isfile(db_path):
        print("✗ 数据库文件不存在")
        return 1
    DatabaseUtils.set_db_path(db_path)

    conn = sqlite3.connect(db_path)
    users = conn.execute("SELECT id, username, role FROM users ORDER BY id").fetchall()
    conn.close()
    print("现有账号:", users if users else "（无）")

    if "--list" in args or not users:
        return 0

    username = args[0] if args and not args[0].startswith("--") else "admin"
    new_password = args[1] if len(args) > 1 and not args[1].startswith("--") else "admin"
    if len(new_password) < 4:
        print("✗ 密码至少 4 位")
        return 1

    ok, msg, path = services.backup_database(username="admin")
    print("备份:", "成功 -> " + path if ok else "失败（继续重置）")

    ok, msg = auth.update_user(username, new_password=new_password)
    print(f"重置 {username} 密码:", ok, msg)
    if not ok:
        return 1

    conn = sqlite3.connect(db_path)
    row = conn.execute("SELECT password FROM users WHERE username=?", (username,)).fetchone()
    conn.close()
    verified = bool(row) and auth.PasswordUtils.verify_password(new_password, row[0])
    print("校验:", "✔ 新密码可用" if verified else "✗ 校验失败")
    print(f"\n请用 {username} / {new_password} 登录，登录后立刻在「系统设置 → 用户管理」改成你自己的密码。")
    return 0 if verified else 1


if __name__ == "__main__":
    sys.exit(main())
