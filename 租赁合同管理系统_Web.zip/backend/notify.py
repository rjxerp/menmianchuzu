# -*- coding: utf-8 -*-
"""租金调整事件通知：站内提醒（reminder_logs 留痕）+ 飞书推送 + 微信推送（ilinkai）。

凭证复用 Hermes 的 D:\\hermes\\.env：
  - 飞书：FEISHU_APP_ID / FEISHU_APP_SECRET，接收人 open_id（默认管理员）
  - 微信：WEIXIN_TOKEN / WEIXIN_HOME_CHANNEL（ilinkai 机器人，Home 频道=私聊）
接收人可用 config.json 的 notification 配置覆盖。
推送全部走异步线程，失败不影响租金调整主流程（静默降级为仅站内留痕）。
"""

import base64
import json
import os
import secrets
import struct
import threading
import time
import urllib.request
import uuid

# ---- 飞书 ----
FEISHU_OPEN_ID = "ou_d55cb50fb96610310c9c95d9c4502b3c"
FEISHU_TOKEN_URL = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
FEISHU_MSG_URL = "https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type=open_id"

# ---- 微信（ilinkai）----
WEIXIN_BASE_URL = "https://ilinkai.weixin.qq.com"
WEIXIN_SEND_EP = "ilink/bot/sendmessage"
WEIXIN_CHANNEL_VERSION = "2.2.0"
WEIXIN_APP_CLIENT_VERSION = "131584"  # (2<<16)|(2<<8)|0

_ENV_PATH = r"D:\hermes\.env"

_feishu_token_cache = {"token": None, "expire_ts": 0.0}


def _load_env():
    """读 D:\\hermes\\.env，回退环境变量。返回 dict（不缓存，读取开销小）。"""
    d = {}
    try:
        with open(_ENV_PATH, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if "=" in line and not line.startswith("#"):
                    k, v = line.split("=", 1)
                    d[k.strip()] = v.strip()
    except Exception:
        pass
    for k in ("FEISHU_APP_ID", "FEISHU_APP_SECRET", "WEIXIN_TOKEN", "WEIXIN_HOME_CHANNEL"):
        if not d.get(k):
            d[k] = os.environ.get(k, "")
    return d


def _load_notify_config():
    """读 config.json 的 notification 配置（覆盖默认接收人）。"""
    try:
        cfg_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "config.json")
        with open(cfg_path, encoding="utf-8") as f:
            cfg = json.load(f)
        return cfg.get("notification") or {}
    except Exception:
        return {}


# ================================ 飞书 ================================
def _get_feishu_token():
    global _feishu_token_cache
    if _feishu_token_cache["token"] and time.time() < _feishu_token_cache["expire_ts"]:
        return _feishu_token_cache["token"]
    d = _load_env()
    app_id, app_secret = d.get("FEISHU_APP_ID"), d.get("FEISHU_APP_SECRET")
    if not (app_id and app_secret):
        return None
    try:
        req = urllib.request.Request(
            FEISHU_TOKEN_URL,
            data=json.dumps({"app_id": app_id, "app_secret": app_secret}).encode("utf-8"),
            headers={"Content-Type": "application/json"},
        )
        resp = json.loads(urllib.request.urlopen(req, timeout=10).read().decode("utf-8"))
        token = resp.get("tenant_access_token")
        if token:
            _feishu_token_cache = {"token": token, "expire_ts": time.time() + 7000}
            return token
    except Exception:
        pass
    return None


def feishu_send_text(open_id, text):
    """飞书发文本消息。返回 (ok, errmsg)。"""
    token = _get_feishu_token()
    if not token:
        return False, "飞书凭证缺失或 token 获取失败"
    content = json.dumps({"text": text}, ensure_ascii=False)
    try:
        req = urllib.request.Request(
            FEISHU_MSG_URL,
            data=json.dumps({"receive_id": open_id, "msg_type": "text", "content": content}).encode("utf-8"),
            headers={"Content-Type": "application/json", "Authorization": "Bearer " + token},
        )
        resp = json.loads(urllib.request.urlopen(req, timeout=10).read().decode("utf-8"))
        if resp.get("code") == 0:
            return True, ""
        return False, "飞书推送失败: %s" % resp.get("msg", resp.get("code"))
    except Exception as e:
        return False, "飞书推送异常: %s" % str(e)


# ================================ 微信（ilinkai）========================
def _random_wechat_uin():
    value = struct.unpack(">I", secrets.token_bytes(4))[0]
    return base64.b64encode(str(value).encode("utf-8")).decode("ascii")


def wechat_send_text(to_user, text):
    """通过 ilinkai 机器人发微信文本消息。返回 (ok, errmsg)。"""
    token = _load_env().get("WEIXIN_TOKEN", "")
    if not token or not to_user:
        return False, "微信凭证或接收人缺失"
    body = {
        "msg": {
            "from_user_id": "",
            "to_user_id": to_user,
            "client_id": "hermes-weixin-%s" % uuid.uuid4().hex,
            "message_type": 2,     # MSG_TYPE_BOT
            "message_state": 2,    # MSG_STATE_FINISH
            "item_list": [{"type": 1, "text_item": {"text": text}}],  # ITEM_TEXT
        },
        "base_info": {"channel_version": WEIXIN_CHANNEL_VERSION},
    }
    body_str = json.dumps(body, ensure_ascii=False, separators=(",", ":"))
    headers = {
        "Content-Type": "application/json",
        "AuthorizationType": "ilink_bot_token",
        "Content-Length": str(len(body_str.encode("utf-8"))),
        "X-WECHAT-UIN": _random_wechat_uin(),
        "iLink-App-Id": "bot",
        "iLink-App-ClientVersion": WEIXIN_APP_CLIENT_VERSION,
        "Authorization": "Bearer " + token,
    }
    try:
        req = urllib.request.Request(
            WEIXIN_BASE_URL + "/" + WEIXIN_SEND_EP,
            data=body_str.encode("utf-8"), headers=headers, method="POST",
        )
        resp = json.loads(urllib.request.urlopen(req, timeout=10).read().decode("utf-8"))
        if "message_id" in resp:
            return True, ""
        return False, "微信推送响应异常: %s" % str(resp)[:120]
    except Exception as e:
        return False, "微信推送异常: %s" % str(e)


# ================================ 站内提醒 + 入口 ================================
def _insert_reminder(conn, reminder_type, related_info):
    """写站内提醒（reminder_logs）。失败静默，不影响主流程。"""
    try:
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO reminder_logs (reminder_type, related_info, reminder_date) VALUES (?, ?, ?)",
            (reminder_type, related_info, time.strftime("%Y-%m-%d")),
        )
        conn.commit()
    except Exception:
        pass


def _async_send(fn, *args):
    """异步线程执行推送，避免阻塞主请求。"""
    try:
        threading.Thread(target=fn, args=args, daemon=True).start()
    except Exception:
        pass


def notify_rent_adjustment(conn, event, feishu_text, reminder_text):
    """租金调整事件通知：站内提醒（同步留痕）+ 飞书/微信推送（异步）。

    参数：
      conn          主流程数据库连接（用于写 reminder_logs）
      event         事件标识（提交/通过/驳回/作废），仅语义化
      feishu_text   飞书/微信推送文案
      reminder_text 站内提醒文案
    """
    _insert_reminder(conn, "租金调整", reminder_text)

    cfg = _load_notify_config()
    env = _load_env()

    # 飞书推送
    feishu_oid = cfg.get("receive_open_id") or cfg.get("feishu_open_id") or FEISHU_OPEN_ID
    if feishu_oid and feishu_text:
        _async_send(feishu_send_text, feishu_oid, feishu_text)

    # 微信推送（可配置 wechat_to_user，默认 Home 频道=私聊）
    wechat_to = cfg.get("wechat_to_user") or env.get("WEIXIN_HOME_CHANNEL", "")
    if wechat_to and feishu_text:
        _async_send(wechat_send_text, wechat_to, feishu_text)
