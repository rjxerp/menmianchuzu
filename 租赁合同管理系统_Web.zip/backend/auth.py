# -*- coding: utf-8 -*-
"""
租赁合同管理系统 Web 版 - 认证模块

- JWT 登录认证（PyJWT）
- 密码哈希/验证（PBKDF2，兼容原桌面版存量格式）
- 用户管理（增删改查）
- 角色权限（管理员/操作员）
"""
import os
import re
import time
import hmac
import hashlib
import base64
from datetime import datetime, timedelta
from typing import Optional, Tuple

import jwt
from fastapi import Depends, HTTPException
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

from db_utils import DatabaseUtils
from operation_logger import record_operation

# ---------------------------------------------------------------- 配置
def _load_secret_key() -> str:
    """加载 JWT 签名密钥（安全整改 2026-09-02，移除硬编码默认值）。

    优先级：
      1. 环境变量 LEASE_WEB_SECRET（推荐，32+ 位随机字符串）
      2. config.json 的 secret_key 字段（首次启动自动生成 64 位随机 hex 并写回）
    两者均不可用时 fail-fast 拒绝启动，防止使用可预测默认密钥被伪造 token。
    """
    env_key = (os.environ.get("LEASE_WEB_SECRET") or "").strip()
    if env_key:
        return env_key

    cfg_path = os.environ.get("LEASE_CONFIG_PATH") or ""
    if cfg_path and os.path.isfile(cfg_path):
        import json as _json
        try:
            with open(cfg_path, "r", encoding="utf-8") as f:
                cfg = _json.load(f)
            cfg_key = str(cfg.get("secret_key") or "").strip()
            if cfg_key:
                return cfg_key
            # 首次启动：自动生成随机密钥并持久化到 config.json
            new_key = os.urandom(48).hex()  # 96 hex chars (~48 bytes entropy)
            cfg["secret_key"] = new_key
            with open(cfg_path, "w", encoding="utf-8") as f:
                _json.dump(cfg, f, ensure_ascii=False, indent=2)
            log_msg = f"auth: 已在 {cfg_path} 生成随机 JWT 密钥（重启后登录 token 将失效，需重新登录）"
            try:
                from logger_module import log_warning
                log_warning(log_msg)
            except Exception:
                pass
            return new_key
        except Exception as e:
            raise RuntimeError(
                "JWT 签名密钥未配置且无法自动生成：请设置环境变量 LEASE_WEB_SECRET "
                f"（32+ 位随机字符串）或检查 config.json 可写性。详情: {e}"
            )
    raise RuntimeError(
        "JWT 签名密钥未配置：请设置环境变量 LEASE_WEB_SECRET "
        "（32+ 位随机字符串），或确保 LEASE_CONFIG_PATH 指向项目 config.json。"
    )

SECRET_KEY = _load_secret_key()
ALGORITHM = "HS256"
TOKEN_EXPIRE_HOURS = 12

bearer_scheme = HTTPBearer(auto_error=False)

# 登录失败锁定（对齐原版 user_auth.py LoginDialog 行为：连续失败锁定 lockout_time 秒）
LOGIN_MAX_ATTEMPTS = 5
LOGIN_LOCKOUT_SECONDS = 60
_login_attempts = {}   # username -> {"count": n, "lock_until": ts}


def _check_login_locked(username: str) -> Optional[int]:
    """返回剩余锁定秒数；未锁定返回 None"""
    rec = _login_attempts.get(username)
    if not rec:
        return None
    if rec.get("lock_until") and time.time() < rec["lock_until"]:
        return int(rec["lock_until"] - time.time()) + 1
    return None


def _record_login_failure(username: str) -> Optional[int]:
    """记录一次失败，返回剩余锁定秒数（若触发锁定）"""
    now = time.time()
    rec = _login_attempts.get(username, {"count": 0, "lock_until": 0})
    rec["count"] = rec.get("count", 0) + 1
    if rec["count"] >= LOGIN_MAX_ATTEMPTS:
        rec["lock_until"] = now + LOGIN_LOCKOUT_SECONDS
        rec["count"] = 0
    _login_attempts[username] = rec
    if rec["lock_until"] and time.time() < rec["lock_until"]:
        return int(rec["lock_until"] - time.time()) + 1
    return None


def _clear_login_failures(username: str) -> None:
    _login_attempts.pop(username, None)


# ---------------------------------------------------------------- 密码工具
class PasswordUtils:
    """密码工具类 - PBKDF2-HMAC-SHA256（与原桌面版一致，兼容存量哈希）"""

    _PBKDF2_ITERATIONS = 210000
    _PREFIX = 'pbkdf2$'

    @staticmethod
    def hash_password(password):
        salt = os.urandom(16)
        dk = hashlib.pbkdf2_hmac(
            'sha256', str(password).encode('utf-8'), salt, PasswordUtils._PBKDF2_ITERATIONS
        )
        return (f"{PasswordUtils._PREFIX}{PasswordUtils._PBKDF2_ITERATIONS}$"
                f"{base64.b64encode(salt).decode('ascii')}$"
                f"{base64.b64encode(dk).decode('ascii')}")

    @staticmethod
    def verify_password(plain_password, hashed_password):
        if not hashed_password:
            return False
        if hashed_password.startswith(PasswordUtils._PREFIX):
            try:
                _, iterations_s, salt_b64, hash_b64 = hashed_password.split('$')
                iterations = int(iterations_s)
                salt = base64.b64decode(salt_b64)
                expected = base64.b64decode(hash_b64)
                dk = hashlib.pbkdf2_hmac(
                    'sha256', str(plain_password).encode('utf-8'), salt, iterations
                )
                return hmac.compare_digest(dk, expected)
            except Exception:
                return False
        if ':' in hashed_password:
            stored_hash, salt = hashed_password.split(':', 1)
            hash_obj = hashlib.md5((str(plain_password) + salt).encode('utf-8'))
            return hmac.compare_digest(hash_obj.hexdigest(), stored_hash)
        return hmac.compare_digest(str(plain_password), hashed_password)

    @staticmethod
    def needs_rehash(hashed_password):
        return not (hashed_password and hashed_password.startswith(PasswordUtils._PREFIX))


# ---------------------------------------------------------------- Token
def _password_signature(hashed_password: str) -> str:
    """密码哈希特征值：写入 token，改密后旧 token 立即失效（P1-1，2026-09-11）"""
    try:
        return hashlib.sha256(str(hashed_password or "").encode("utf-8")).hexdigest()[:16]
    except Exception:
        return ""


def create_token(user_id: int, username: str, role: str, password_hash: str = "") -> str:
    payload = {
        "sub": str(user_id),
        "username": username,
        "role": role,
        "pwd": _password_signature(password_hash),
        "exp": datetime.utcnow() + timedelta(hours=TOKEN_EXPIRE_HOURS),
        "iat": datetime.utcnow(),
    }
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)


def decode_token(token: str) -> Optional[dict]:
    try:
        return jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
    except Exception:
        return None


def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme),
) -> dict:
    """FastAPI 依赖：解析当前登录用户。

    P1-1（2026-09-11）：除验签外，还回查 users 表确认账号仍存在，
    并比对密码版本签名 —— 删除账号 / 改密码后旧 token 立即失效。
    """
    if credentials is None:
        raise HTTPException(status_code=401, detail="未登录")
    payload = decode_token(credentials.credentials)
    if payload is None:
        raise HTTPException(status_code=401, detail="登录已过期，请重新登录")
    try:
        user_id = int(payload.get("sub", 0))
    except (TypeError, ValueError):
        user_id = 0
    if user_id <= 0:
        raise HTTPException(status_code=401, detail="登录状态无效，请重新登录")
    user = _get_user_by_id(user_id)
    if user is None:
        raise HTTPException(status_code=401, detail="账号不存在或已被删除，请重新登录")
    if not hmac.compare_digest(str(payload.get("pwd", "")), _password_signature(user["password"])):
        raise HTTPException(status_code=401, detail="密码已变更，请重新登录")
    return {
        "user_id": user["id"],
        "username": user["username"],
        "role": user["role"],
    }


def require_admin(user: dict = Depends(get_current_user)) -> dict:
    """FastAPI 依赖：要求管理员权限"""
    if user["role"] != "管理员":
        raise HTTPException(status_code=403, detail="需要管理员权限")
    return user


# ---------------------------------------------------------------- 用户数据访问
def _get_user_by_username(username: str) -> Optional[dict]:
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return None
        cursor = DatabaseUtils.execute_query(
            conn, "SELECT id, username, password, role FROM users WHERE username = ?", (username,)
        )
        row = cursor.fetchone() if cursor else None
        if row is None:
            return None
        return {"id": row[0], "username": row[1], "password": row[2], "role": row[3]}
    except Exception:
        return None
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def _get_user_by_id(user_id: int) -> Optional[dict]:
    """按 id 查用户（token 校验用，P1-1：确认账号仍存在且密码未变更）"""
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return None
        cursor = DatabaseUtils.execute_query(
            conn, "SELECT id, username, password, role FROM users WHERE id = ?", (user_id,)
        )
        row = cursor.fetchone() if cursor else None
        if row is None:
            return None
        return {"id": row[0], "username": row[1], "password": row[2], "role": row[3]}
    except Exception:
        return None
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def _upgrade_password_hash(username: str, hashed: str) -> None:
    """登录成功后自动升级旧格式密码哈希为 PBKDF2"""
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return
        DatabaseUtils.execute_query(
            conn, "UPDATE users SET password = ? WHERE username = ?", (hashed, username)
        )
        conn.commit()
    except Exception as e:
        try:
            from logger_module import log_warning
            log_warning(f"账号 {username} 密码哈希升级写入失败（下次登录将重试）: {e}")
        except Exception:
            pass
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def verify_current_password(username: str, password: str) -> bool:
    """验证当前用户密码（系统设置访问用；不记录登录日志、不触发失败锁定）"""
    if not username or not password:
        return False
    user = _get_user_by_username(username)
    if user is None:
        return False
    return PasswordUtils.verify_password(password, user["password"])


# ---------------------------------------------------------------- 登录/登出
def do_login(username: str, password: str) -> Tuple[bool, dict]:
    """验证登录。返回 (是否成功, 结果字典)"""
    if not username or not password:
        return False, {"error": "用户名和密码不能为空"}

    # 登录失败锁定（对齐原版 LoginDialog.startLockTimer / isLocked）
    locked = _check_login_locked(username)
    if locked:
        return False, {"error": f"登录失败次数过多，请 {locked} 秒后再试"}

    user = _get_user_by_username(username)
    if user is None:
        _record_login_failure(username)
        record_operation(username=username, operation_module="登录", operation_content="用户登录",
                         operation_result="失败", detail="用户不存在")
        return False, {"error": "用户名或密码错误"}

    if not PasswordUtils.verify_password(password, user["password"]):
        remaining = _record_login_failure(username)
        record_operation(user_id=user["id"], username=username, operation_module="登录",
                         operation_content="用户登录", operation_result="失败", detail="密码错误")
        if remaining:
            return False, {"error": f"登录失败次数过多，请 {remaining} 秒后再试"}
        return False, {"error": "用户名或密码错误"}

    # 登录成功：清除失败计数
    _clear_login_failures(username)

    # 自动升级旧密码格式（升级后用新哈希生成 token 签名，避免刚登录即失效）
    current_hash = user["password"]
    if PasswordUtils.needs_rehash(current_hash):
        # R-10：检测到旧格式（md5/明文）密码，留审计告警——升级虽自动完成，但说明该账号
        # 自桌面版迁移后从未改过密码，建议提醒用户修改
        try:
            from logger_module import log_warning
            log_warning(f"账号 {username} 使用旧格式密码（md5/明文兼容分支），已自动升级为 PBKDF2；建议提醒其修改密码")
        except Exception:
            pass
        try:
            new_hash = PasswordUtils.hash_password(password)
            _upgrade_password_hash(username, new_hash)
            current_hash = new_hash
        except Exception as e:
            try:
                from logger_module import log_error
                log_error(f"账号 {username} 密码哈希升级失败: {e}")  # Q-01 抽查整改：不再静默吞掉
            except Exception:
                pass

    token = create_token(user["id"], username, user["role"], current_hash)
    record_operation(user_id=user["id"], username=username, operation_module="登录",
                     operation_content="用户登录", operation_result="成功", detail="登录成功")
    return True, {
        "token": token,
        "user": {"id": user["id"], "username": username, "role": user["role"]},
    }


def do_logout(user: dict) -> None:
    try:
        record_operation(user_id=user.get("user_id"), username=user.get("username"),
                         operation_module="登录", operation_content="用户退出",
                         operation_result="成功", detail="退出登录")
    except Exception:
        pass


# ---------------------------------------------------------------- 改密
def change_password(username: str, old_password: str, new_password: str) -> Tuple[bool, str]:
    user = _get_user_by_username(username)
    if user is None:
        return False, "用户不存在"
    if not PasswordUtils.verify_password(old_password, user["password"]):
        return False, "原密码错误"
    if not new_password:
        return False, "新密码不能为空"
    # 密码强度校验（对齐原版 PasswordChangeDialog.onChangeClick：≥8 字符且含字母和数字）
    if len(new_password) < 8:
        return False, "新密码长度至少为8个字符！"
    if not re.search(r'[A-Za-z]', new_password) or not re.search(r'[0-9]', new_password):
        return False, "新密码必须包含字母和数字！"
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return False, "数据库连接失败"
        cur = DatabaseUtils.execute_query(
            conn, "UPDATE users SET password = ? WHERE username = ?",
            (PasswordUtils.hash_password(new_password), username)
        )
        if cur is None:
            return False, "修改密码失败"
        conn.commit()
        record_operation(user_id=user["id"], username=username, operation_module="系统设置",
                         operation_content="修改密码", operation_result="成功")
        return True, "密码修改成功"
    except Exception as e:
        return False, f"修改密码失败: {str(e)}"
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


# ---------------------------------------------------------------- 用户管理（管理员）
def list_users() -> list:
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return []
        cursor = DatabaseUtils.execute_query(conn, "SELECT id, username, role FROM users ORDER BY id")
        rows = cursor.fetchall() if cursor else []
        return [{"id": r[0], "username": r[1], "role": r[2]} for r in rows]
    except Exception:
        return []
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def add_user(username: str, password: str, role: str) -> Tuple[bool, str]:
    if not username or not password:
        return False, "用户名和密码不能为空"
    if role not in ("管理员", "操作员"):
        return False, "角色无效"
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return False, "数据库连接失败"
        cur = DatabaseUtils.execute_query(
            conn, "INSERT INTO users (username, password, role) VALUES (?, ?, ?)",
            (username, PasswordUtils.hash_password(password), role)
        )
        if cur is None:
            return False, "添加用户失败（用户名可能已存在）"
        conn.commit()
        record_operation(username=username, operation_module="系统设置", operation_content="添加用户",
                         operation_result="成功", detail=f"用户名: {username}, 角色: {role}")
        return True, "用户添加成功"
    except Exception as e:
        try:
            from logger_module import log_error
            log_error(f"add_user 数据库异常: {e}")
        except Exception:
            pass
        return False, "添加用户失败（用户名可能已存在），详情见服务日志"
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def update_user(username: str, role: Optional[str] = None, new_password: Optional[str] = None) -> Tuple[bool, str]:
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return False, "数据库连接失败"
        if new_password:
            cur = DatabaseUtils.execute_query(
                conn, "UPDATE users SET password = ? WHERE username = ?",
                (PasswordUtils.hash_password(new_password), username)
            )
            if cur is None:
                return False, "更新用户失败"
        if role:
            cur = DatabaseUtils.execute_query(
                conn, "UPDATE users SET role = ? WHERE username = ?", (role, username)
            )
            if cur is None:
                return False, "更新用户失败"
        conn.commit()
        record_operation(username=username, operation_module="系统设置", operation_content="更新用户",
                         operation_result="成功")
        return True, "用户更新成功"
    except Exception as e:
        try:
            from logger_module import log_error
            log_error(f"update_user 数据库异常: {e}")
        except Exception:
            pass
        return False, "更新用户失败（数据库异常），详情见服务日志"
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def delete_user(username: str, current_username: str) -> Tuple[bool, str]:
    if username == current_username:
        return False, "不能删除当前登录用户"
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return False, "数据库连接失败"
        DatabaseUtils.execute_query(conn, "DELETE FROM users WHERE username = ?", (username,))
        conn.commit()
        record_operation(username=username, operation_module="系统设置", operation_content="删除用户",
                         operation_result="成功")
        return True, "用户删除成功"
    except Exception as e:
        return False, f"删除用户失败: {str(e)}"
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)
