# -*- coding: utf-8 -*-
"""user_auth 兼容模块（Web 版）

原版 db_utils.py 在「重建数据库/创建默认用户」路径中执行
`from user_auth import PasswordUtils`。Web 版认证逻辑已迁至 auth.py，
本模块保持 import 兼容，避免复用模块触发 ImportError。
"""
from auth import PasswordUtils  # noqa: F401

__all__ = ["PasswordUtils"]
