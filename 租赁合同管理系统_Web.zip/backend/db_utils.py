import os
import sqlite3
import time
import threading
import shutil
import gc
import traceback
import re as _re
from contextlib import contextmanager

# ============================================================ 金额单位换算配置
# 迁移后的金额列以「整数分」存储：读时 /100 返回元，写时 *100 存分。
# 判定一律以 (表名, 列名) 为准——历史实现按「列名跨表并集」猜测，
# 会把未迁移/存元的表列误除 100，是金额错值的根源，已废弃。
MONEY_COLUMNS = {
    'contracts': frozenset(['monthly_rent', 'quarterly_rent', 'total_rent', 'annual_rent',
                            'deposit', 'water_fee', 'electricity_fee']),
    'rent_records': frozenset(['amount']),
    'rent_adjustments': frozenset(['old_monthly_rent', 'new_monthly_rent']),
    'rent_schedule': frozenset(['monthly_rent']),
}
# 显式例外清单：列名与白名单同形但实际存「元」，或所属表未迁移，一律禁止换算。
#   rent_records.monthly_rent  → TEXT 列，存元（如 '5000'），不是分
#   utility_fee.*              → 该表未迁移，存元
NON_MONEY_COLUMNS = frozenset([
    ('rent_records', 'monthly_rent'),
    ('utility_fee', 'water_fee'),
    ('utility_fee', 'electricity_fee'),
])
# 兼容旧引用：跨表列名并集。仅供外部只读使用，MoneyCursor 已不再依赖它做判定。
ALL_MONEY_COLUMNS = frozenset().union(*MONEY_COLUMNS.values())


def _money_param_indices(query):
    """解析 INSERT/UPDATE 语句中金额列对应的参数位置（0-indexed）

    仅支持位置参数（?）。返回参数位置列表；解析失败或非金额操作返回 None（不转换）。
    """
    try:
        q = query.strip()
        m = _re.match(r"^\s*INSERT\s+INTO\s+[\"\']?([\w_]+)[\"\']?\s*\(([^)]*)\)\s*VALUES\s*\(([^)]*)\)", q, _re.I | _re.S)
        if m:
            tbl = m.group(1).strip()
            money_cols = MONEY_COLUMNS.get(tbl)
            if not money_cols:
                return None
            cols = [c.strip().strip('"').strip("'") for c in m.group(2).split(',')]
            vals = [v.strip() for v in m.group(3).split(',')]
            indices = []
            for i, (col, val) in enumerate(zip(cols, vals)):
                # 显式例外优先否决（如 rent_records.monthly_rent 存元，不参与 ×100）
                if col in money_cols and (tbl, col) not in NON_MONEY_COLUMNS and val.startswith('?'):
                    indices.append(i)
            return indices if indices else None
        m = _re.match(r"^\s*UPDATE\s+[\"\']?([\w_]+)[\"\']?\s+SET\s+(.*?)(?:\s+WHERE\s|\s*$)", q, _re.I | _re.S)
        if m:
            tbl = m.group(1).strip()
            money_cols = MONEY_COLUMNS.get(tbl)
            if not money_cols:
                return None
            set_part = m.group(2)
            indices = []
            pos = 0
            for assign in set_part.split(','):
                am = _re.match(r'^\s*["\']?([\w_]+)["\']?\s*=\s*(\?+)\s*$', assign)
                if (am and am.group(1) in money_cols
                        and (tbl, am.group(1)) not in NON_MONEY_COLUMNS):
                    for _ in range(len(am.group(2))):
                        indices.append(pos)
                        pos += 1
                else:
                    pos += len(_re.findall(r'\?', assign))
            return indices if indices else None
    except Exception:
        return None
    return None


def _convert_write_params(query, params):
    """INSERT/UPDATE 写参数：金额列参数 元→分（×100）"""
    if not params:
        return params
    indices = _money_param_indices(query)
    if not indices:
        return params
    if isinstance(params, (tuple, list)):
        lst = list(params)
        for i in indices:
            if i < len(lst) and lst[i] is not None and isinstance(lst[i], (int, float)):
                try:
                    lst[i] = int(round(float(lst[i]) * 100))
                except (ValueError, TypeError):
                    pass
        return tuple(lst) if isinstance(params, tuple) else lst
    # P1-8（2026-09-11）：金额列写入遇到 dict/不支持的参数类型 → 快速失败。
    # 旧逻辑对 dict 静默放行（不做元→分换算），会把「元」当「分」写库造成 100 倍错误，
    # 绝不能静默放过 —— 显式抛错，倒逼调用方改用位置参数。
    raise ValueError(
        f"金额列写入不支持参数类型 {type(params).__name__}（无法执行元→分换算），"
        f"请改为位置参数。SQL: {query.strip()[:120]}"
    )


# 日期列白名单（写路径校验 YYYY-MM-DD 格式，防非法日期写入）
DATE_COLUMNS = {
    'contracts': frozenset(['sign_date', 'start_date', 'end_date']),
    'rent_records': frozenset(['receipt_date', 'period_start', 'period_end']),
}
_DATE_RE = _re.compile(r'^\d{4}-\d{2}-\d{2}$')


def _write_column_param_indices(query):
    """解析 INSERT/UPDATE 语句中 (列名, 参数位置0-indexed) 列表；解析失败返回 []"""
    try:
        q = query.strip()
        m = _re.match(r"^\s*INSERT\s+INTO\s+[\"']?([\w_]+)[\"']?\s*\(([^)]*)\)\s*VALUES\s*\(([^)]*)\)", q, _re.I | _re.S)
        if m:
            cols = [c.strip().strip('"').strip("'") for c in m.group(2).split(',')]
            vals = [v.strip() for v in m.group(3).split(',')]
            result = []
            pos = 0
            for col, val in zip(cols, vals):
                if val.startswith('?'):
                    result.append((col, pos))
                    pos += 1
                else:
                    pos += len(_re.findall(r'\?', val))
            return result
        m = _re.match(r"^\s*UPDATE\s+[\"']?([\w_]+)[\"']?\s+SET\s+(.*?)(?:\s+WHERE\s|\s*$)", q, _re.I | _re.S)
        if m:
            set_part = m.group(2)
            result = []
            pos = 0
            for assign in set_part.split(','):
                am = _re.match(r'^\s*["\']?([\w_]+)["\']?\s*=\s*(.+?)\s*$', assign)
                if am:
                    col = am.group(1)
                    n_q = len(_re.findall(r'\?', am.group(2)))
                    if n_q:
                        for _ in range(n_q):
                            result.append((col, pos))
                    pos += n_q
                else:
                    pos += len(_re.findall(r'\?', assign))
            return result
    except Exception:
        return []
    return []


def _validate_write_params(query, params):
    """写路径参数校验（P2 数据层防非法输入）

    - 金额列（contracts 7 列 / rent_records.amount）：拒绝负数
    - 日期列（sign_date/start_date/end_date/receipt_date/period_start/period_end）：
      非空值必须匹配 YYYY-MM-DD 格式
    仅对 contracts / rent_records 表生效；解析失败或命名参数（dict）保守放行。
    非法输入抛 ValueError，由调用方（UI 层 try/except）拦截提示。
    """
    if not params or isinstance(params, dict):
        return
    try:
        m = _re.match(r"^\s*(?:INSERT\s+INTO|UPDATE)\s+[\"']?([\w_]+)[\"']?\s*", query, _re.I | _re.S)
        if not m:
            return
        tbl = m.group(1).strip()
        money_cols = MONEY_COLUMNS.get(tbl)
        date_cols = DATE_COLUMNS.get(tbl)
        if not money_cols and not date_cols:
            return
        col_indices = _write_column_param_indices(query)
        if not col_indices:
            return
        for col, idx in col_indices:
            if idx >= len(params):
                continue
            val = params[idx]
            if val is None:
                continue
            if money_cols and col in money_cols and isinstance(val, (int, float)) and not isinstance(val, bool):
                if val < 0:
                    raise ValueError(f"金额字段 {col} 不能为负数: {val}")
            if date_cols and col in date_cols and isinstance(val, str):
                s = val.strip()
                if s:
                    if not _DATE_RE.match(s):
                        raise ValueError(f"日期字段 {col} 格式必须为 YYYY-MM-DD，收到: {val}")
                    # 进一步校验真实日期（拒绝 2026-13-45 / 2026-08-32 等不存在日期）
                    try:
                        datetime.strptime(s, '%Y-%m-%d')
                    except (ValueError, TypeError):
                        raise ValueError(f"日期字段 {col} 不是有效日期，收到: {val}")
    except ValueError:
        raise
    except Exception:
        pass  # 解析异常保守放行，不阻塞正常写入


# ---- 结果列 → 所属表 解析（消除「按列名跨表猜测」）------------------------
# FROM / JOIN 后的「表名 别名」；子查询以 ( 开头，天然不匹配，自动跳过
_FROM_RE = _re.compile(
    r'\b(?:FROM|JOIN)\s+["\']?([\w_]+)["\']?(?:\s+(?:AS\s+)?(["\']?[\w_]+["\']?))?',
    _re.I | _re.S)
# 聚合表达式：SUM(col) / TOTAL(col) / SUM(alias.col)
_AGG_RE = _re.compile(r'^(?:SUM|TOTAL)\s*\(\s*(?:([\w_]+)\s*\.\s*)?([\w_]+)\s*\)$', _re.I)
# 外层 COALESCE(SUM(col), 0) 的剥离
_COALESCE_RE = _re.compile(r'^COALESCE\s*\((.+?)\s*,\s*[^()]*(?:\([^()]*\))?[^()]*\)$',
                           _re.I | _re.S)
# 别名位置可能误抓到的 SQL 关键字
_SQL_STOP_WORDS = frozenset(['where', 'on', 'group', 'order', 'having', 'limit', 'union',
                             'left', 'right', 'inner', 'outer', 'cross', 'full', 'join',
                             'using', 'set', 'values', 'select', 'and', 'or', 'as'])

_TABLE_COLUMNS_CACHE = {}
_TABLE_COLUMNS_LOCK = threading.Lock()


# 库路径解析带 2 秒短期记忆：get_db_path() 每次都会读盘解析 config.json，
# 而 _check_money_migrated / _table_columns 位于每条查询的热路径上。
_DB_PATH_MEMO = {'path': None, 'ts': 0.0}
_DB_PATH_MEMO_TTL = 2.0


def _fast_db_path():
    """带短期记忆的库路径读取；切换数据库时由 set_db_path 主动失效。

    注意：优先返回 set_db_path() 显式设置的 DatabaseUtils._db_path，
    只有其为空时才回落到 get_db_path()（后者会读 config.json 并回写 _db_path）。
    这样临时切到副本库的调用方不会被配置文件悄悄改回正式库。
    """
    now = time.time()
    if _DB_PATH_MEMO['path'] is not None and (now - _DB_PATH_MEMO['ts']) < _DB_PATH_MEMO_TTL:
        return _DB_PATH_MEMO['path']
    path = getattr(DatabaseUtils, '_db_path', None)
    if not path:
        try:
            path = DatabaseUtils.get_db_path()
        except Exception:
            path = None
    _DB_PATH_MEMO['path'] = path
    _DB_PATH_MEMO['ts'] = now
    return path


def invalidate_db_path_cache():
    """库路径/表结构相关缓存失效（切换数据库后调用）"""
    _DB_PATH_MEMO['path'] = None
    _DB_PATH_MEMO['ts'] = 0.0
    with _TABLE_COLUMNS_LOCK:
        _TABLE_COLUMNS_CACHE.clear()


def _resolve_query_tables(query):
    """按 FROM / JOIN 出现顺序返回被引用的基表名（小写、去重、跳过子查询）"""
    tables, seen = [], set()
    if not query:
        return tables
    try:
        stripped = _re.sub(r'/\*.*?\*/', ' ', query, flags=_re.S)
    except Exception:
        stripped = query
    for m in _FROM_RE.finditer(stripped):
        tbl = (m.group(1) or '').strip().strip('"').strip("'").lower()
        if not tbl or tbl in _SQL_STOP_WORDS or tbl in seen:
            continue
        seen.add(tbl)
        tables.append(tbl)
    return tables


def _table_columns(conn, table):
    """取表全部列名（PRAGMA table_info，结果按库路径缓存）"""
    try:
        db_path = _fast_db_path()
    except Exception:
        db_path = ''
    key = (db_path, table)
    cols = _TABLE_COLUMNS_CACHE.get(key)
    if cols is None:
        try:
            cols = frozenset(str(r[1]).lower()
                             for r in conn.execute('PRAGMA table_info("%s")' % table).fetchall())
        except Exception:
            cols = frozenset()
        with _TABLE_COLUMNS_LOCK:
            _TABLE_COLUMNS_CACHE[key] = cols
    return cols


def _is_money_col(table, col):
    """(表, 列) 是否为「存分」的金额列——显式例外优先否决"""
    if not table or not col:
        return False
    t, c = str(table).lower(), str(col).lower()
    if (t, c) in NON_MONEY_COLUMNS:
        return False
    return c in MONEY_COLUMNS.get(t, ())


def _resolve_money_column(conn, expr, tables):
    """判定结果列表达式是否为需换算的金额列。

    规则：先剥离 COALESCE/聚合外壳，去掉别名前缀，
    再按 FROM/JOIN 顺序找到第一个真正拥有该列的表，最后按 (表, 列) 判定。
    """
    e = (expr or '').strip()
    if not e:
        return False
    m = _COALESCE_RE.match(e)
    if m:
        e = m.group(1).strip()
    m = _AGG_RE.match(e)
    if m:
        prefix_tbl = (m.group(1) or '').lower()
        col = (m.group(2) or '').lower()
        if prefix_tbl:
            return _is_money_col(prefix_tbl, col)
    else:
        col = e.split('.')[-1].strip().strip('"').strip("'").lower()
    for t in tables:
        if col in _table_columns(conn, t):
            return _is_money_col(t, col)
    return False


class MoneyCursor:
    """游标包装器：SELECT 结果中金额列（存分）自动 /100 返回元。

    判定以 (表名, 列名) 为准：解析 SQL 的 FROM/JOIN 基表，
    结合 PRAGMA 表结构确定每列归属，再对照 MONEY_COLUMNS / NON_MONEY_COLUMNS。
    这样 utility_fee（未迁移）与 rent_records.monthly_rent（TEXT 存元）
    不会被误除 100。其余行为全部转发原游标。
    """

    def __init__(self, cursor, conn=None, query=None):
        self._cur = cursor
        self._conn = conn
        self._money_idx = None
        self._build_index(query)

    def _build_index(self, query):
        """根据当前 cursor.description 重建需换算的列下标"""
        self._money_idx = None
        try:
            desc = self._cur.description
        except Exception:
            desc = None
        if not desc or not query or self._conn is None:
            return
        tables = _resolve_query_tables(query)
        if not tables:
            return
        idxs = [i for i, d in enumerate(desc)
                if _resolve_money_column(self._conn, (d[0] if d else '') or '', tables)]
        self._money_idx = idxs or None

    def execute(self, *args, **kwargs):
        """复用游标再次执行时重建下标，避免沿用上一条 SQL 的列索引"""
        result = self._cur.execute(*args, **kwargs)
        self._build_index(args[0] if args else None)
        return result

    def _convert_row(self, row):
        if self._money_idx is None or row is None:
            return row
        lst = list(row)
        for i in self._money_idx:
            if i < len(lst) and lst[i] is not None:
                try:
                    lst[i] = float(lst[i]) / 100.0
                except (ValueError, TypeError):
                    pass
        return tuple(lst)

    def fetchall(self):
        rows = self._cur.fetchall()
        if self._money_idx is None:
            return rows
        return [self._convert_row(r) for r in rows]

    def fetchone(self):
        row = self._cur.fetchone()
        return self._convert_row(row) if self._money_idx is not None else row

    def fetchmany(self, size=None):
        rows = self._cur.fetchmany(size)
        if self._money_idx is None:
            return rows
        return [self._convert_row(r) for r in rows]

    def __iter__(self):
        return iter(self.fetchall())

    def __getattr__(self, name):
        return getattr(self._cur, name)

# 尝试导入fcntl模块，Windows系统可能不支持
try:
    import fcntl
except ImportError:
    # 在Windows上，fcntl不可用，创建一个空的模拟
    class MockFcntl:
        LOCK_EX = 2
        LOCK_NB = 4
        LOCK_UN = 8
    
    fcntl = MockFcntl()
from datetime import datetime
from logger_module import log_error, log_info, log_warning, log_debug

class DatabaseUtils:
    """数据库操作工具类，提供基本的数据库操作功能"""
    
    # 金额迁移标记缓存（None=未知, True=已迁移存分, False=未迁移存元）
    # 缓存与「所属库路径」绑定：切换数据库后自动失效，无需各调用方手工重置。
    _money_migrated = None
    _money_migrated_path = None
    
    # 连接池相关配置
    _connection_pool = []
    _pool_size = 5  # 最大连接池大小
    _pool_lock = threading.RLock()  # 使用可重入锁确保线程安全
    _pool_initialized = False  # 连接池初始化标志
    _pool_warned = False  # 空闲池容量告警状态（边沿触发，避免每个请求刷一条日志）
    _active_connections = {}  # 跟踪活跃连接的字典，用于调试
    
    # 连接对象 → 所属数据库路径映射（id(conn) → path）
    # 注意：sqlite3.Connection 是 C 类型，不允许设置实例属性，必须用外部字典
    _conn_db_paths = {}

    # 完整性检查结果缓存（db_path → (timestamp, result)），60 秒 TTL（2026-09-02 性能整改）
    _integrity_check_cache = {}
    # 关键表验证结果缓存（db_path → (timestamp, result)），60 秒 TTL
    _critical_tables_cache = {}
    # 索引补齐结果缓存（db_path → timestamp），60 秒 TTL（ensure_indexes 幂等，老库升级才需执行）
    _ensure_indexes_cache = {}
    # 建表模板缺列补齐结果缓存（db_path → timestamp），60 秒 TTL
    # （2026-09-11 修复：桌面版后期 ALTER 加的列不在建表模板里，新建库会缺列 → ensure_schema_columns 幂等补齐）
    _ensure_schema_cache = {}
    # close_connection 的 gc.collect 降频计数器（2026-09-02）
    _close_gc_counter = 0

    # 建表模板历史缺列清单：(表, 列, 类型定义, 是否需默认值)
    # 与 Data/ZHMY_Contract_SQLite_2026.db 的真实结构逐列比对得出（2026-09-11 体检 P0-1）
    SCHEMA_MISSING_COLUMNS = [
        ("contracts", "house_type", "TEXT", None),
        ("contracts", "attachment_path", "TEXT", None),
        ("contracts", "payment_status", "TEXT", "'未结清'"),
        ("contracts", "is_renewed", "TEXT", "'未续签'"),
        # Web 版专用：续签来源合同编号（续签预填保存新合同时写入；删除新合同时据此复位原合同 is_renewed）
        ("contracts", "renewed_from", "TEXT", None),
        ("rent_records", "house_no", "TEXT", None),
        ("rent_records", "payment_method", "TEXT", None),
        ("rent_records", "monthly_rent", "TEXT", None),
        ("reminder_settings", "reminder_frequency", "INTEGER", "60"),
        ("reminder_settings", "enabled_reminder_types", "TEXT", "'合同到期,租金到期,合同逾期'"),
        ("reminder_settings", "email_notification", "INTEGER", "0"),
        ("reminder_settings", "sms_notification", "INTEGER", "0"),
    ]

    @staticmethod
    def ensure_schema_columns(conn, db_path: str) -> int:
        """幂等补齐历史缺列：老库/恢复的旧备份若缺桌面版后期加的列，按清单 ALTER TABLE ADD COLUMN。

        Returns:
            int: 本次实际补上的列数（已齐则返回 0）
        """
        if not db_path or not conn:
            return 0
        now = time.time()
        cached = DatabaseUtils._ensure_schema_cache.get(db_path)
        if cached and (now - cached) < 60:
            return 0
        added = 0
        try:
            existing_tables = {
                r[0] for r in conn.execute(
                    "SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
            for table, column, col_type, default in DatabaseUtils.SCHEMA_MISSING_COLUMNS:
                if table not in existing_tables:
                    continue
                cols = {r[1] for r in conn.execute(f"PRAGMA table_info({table})").fetchall()}
                if column in cols:
                    continue
                ddl = f"ALTER TABLE {table} ADD COLUMN {column} {col_type}"
                if default is not None:
                    ddl += f" DEFAULT {default}"
                conn.execute(ddl)
                added += 1
                log_info(f"ensure_schema_columns: {table} 补齐缺失列 {column} {col_type}"
                         + (f" DEFAULT {default}" if default else ""))
            if added:
                conn.commit()
                log_info(f"ensure_schema_columns: 共补齐 {added} 个历史缺失列")
        except Exception as e:
            log_warning(f"ensure_schema_columns: 补列失败（不影响本次连接使用）: {str(e)}")
        finally:
            DatabaseUtils._ensure_schema_cache[db_path] = now
        return added

    # 数据库路径，支持动态更改
    _db_path = None
    
    @staticmethod
    def _read_migrated_flag(conn):
        """从给定连接读取迁移标记。返回 True/False，无法判定时返回 None"""
        try:
            row = conn.execute(
                "SELECT value FROM schema_meta WHERE key='amount_cents_migrated'"
            ).fetchone()
            return bool(row and str(row[0]) == '1')
        except sqlite3.OperationalError as e:
            if 'no such table' in str(e).lower():
                return False  # 确无 schema_meta：老库，未迁移
            return None        # locked / busy：无法判定
        except Exception:
            return None

    @staticmethod
    def _probe_money_migrated(db_path, conn=None):
        """实际探测库是否已完成金额迁移（存整数分）。

        返回 (结果, 是否可缓存)：
        - schema_meta 表不存在  → (False, True)  确属未迁移，可安全缓存
        - 库文件不存在          → (False, True)
        - 库被锁 / IO 等瞬时错  → (False, False) 不缓存，下次请求重新探测
          （历史实现在此静默吞异常并永久缓存 False，是金额被放大 100 倍的直接成因）

        优先用传入连接探测——连接池可能复用旧库连接，按配置路径探测会判错库。
        """
        if conn is not None:
            flag = DatabaseUtils._read_migrated_flag(conn)
            if flag is not None:
                return flag, True
        if not db_path or not os.path.exists(db_path):
            log_warning(f"_probe_money_migrated: 数据库文件不存在，按未迁移处理: {db_path}")
            return False, True
        last_err = None
        for attempt in range(3):
            check_conn = None
            try:
                check_conn = sqlite3.connect(db_path, timeout=5)
                flag = DatabaseUtils._read_migrated_flag(check_conn)
                if flag is not None:
                    return flag, True
                last_err = 'schema_meta 读取被阻塞'
            except sqlite3.DatabaseError as e:
                last_err = e
            except Exception as e:
                last_err = e
            finally:
                if check_conn is not None:
                    try:
                        check_conn.close()
                    except Exception:
                        pass
            if attempt < 2:
                time.sleep(0.2 * (attempt + 1))
        log_error(f"_probe_money_migrated: 探测失败，本次按未迁移处理且不缓存: {last_err}")
        return False, False

    @staticmethod
    def _check_money_migrated(conn=None):
        """检查数据库是否已完成金额迁移（存整数分）

        通过 schema_meta 表中的 amount_cents_migrated 标记判断，
        按当前配置库路径查询（不依赖传入连接，避免连接池复用旧库连接导致误判）。

        缓存与库路径绑定：路径变化自动重新探测，不再依赖调用方手工置 None。
        探测遇到瞬时错误时不缓存，避免一次抖动导致全进程长期错判。
        """
        try:
            db_path = _fast_db_path()
        except Exception:
            db_path = None
        if (DatabaseUtils._money_migrated is not None
                and DatabaseUtils._money_migrated_path == db_path):
            return DatabaseUtils._money_migrated
        migrated, cacheable = DatabaseUtils._probe_money_migrated(db_path, conn)
        if cacheable:
            DatabaseUtils._money_migrated = migrated
            DatabaseUtils._money_migrated_path = db_path
        else:
            # 不可缓存：清空缓存迫使下次重新探测
            DatabaseUtils._money_migrated = None
            DatabaseUtils._money_migrated_path = None
        return migrated

    @staticmethod
    def refresh_money_migrated():
        """强制刷新金额迁移标记缓存（切换/还原数据库后调用）"""
        DatabaseUtils._money_migrated = None
        DatabaseUtils._money_migrated_path = None
        return DatabaseUtils._check_money_migrated()

    @staticmethod
    def get_db_path():
        """获取数据库文件路径，优先从配置文件读取"""
        # 每次调用都尝试从配置文件获取最新路径，支持动态更新
        try:
            from config_utils import ConfigManager
            saved_path = ConfigManager.get_database_path()
            if saved_path:
                # 如果保存路径存在，使用它
                if os.path.exists(saved_path):
                    DatabaseUtils._db_path = saved_path
                # 如果保存路径不存在，创建目录并使用该路径
                else:
                    # 尝试创建目录（如果需要）
                    dir_path = os.path.dirname(saved_path)
                    if dir_path and not os.path.exists(dir_path):
                        try:
                            os.makedirs(dir_path)
                            log_info(f"创建数据库目录: {dir_path}")
                        except Exception as mkdir_error:
                            log_error(f"创建数据库目录失败: {str(mkdir_error)}")
                    DatabaseUtils._db_path = saved_path
                    return DatabaseUtils._db_path
        except ImportError as import_error:
            log_error(f"导入ConfigManager失败: {str(import_error)}")
        except AttributeError as attr_error:
            log_error(f"ConfigManager缺少get_database_path方法: {str(attr_error)}")
        except PermissionError as perm_error:
            log_error(f"无权限访问配置文件或目录: {str(perm_error)}")
        except Exception as e:
            log_error(f"从配置文件获取数据库路径失败: {str(e)}")
        
        # 如果没有配置路径或获取失败，使用默认路径
        try:
            if DatabaseUtils._db_path is None:
                base_dir = os.path.dirname(os.path.abspath(__file__))
                DatabaseUtils._db_path = os.path.join(base_dir, 'rental_contract.db')
        except Exception as path_error:
            log_error(f"构建默认数据库路径失败: {str(path_error)}")
            # 设置一个基本路径作为最后备选
            DatabaseUtils._db_path = 'rental_contract.db'
        
        # 确保在所有情况下都返回数据库路径
        return DatabaseUtils._db_path
    
    @staticmethod
    def set_db_path(db_path):
        """设置数据库文件路径
        
        Args:
            db_path: 数据库文件的绝对路径
        """
        if not db_path:
            log_error("set_db_path: 数据库路径不能为空")
            return False
        
        try:
            # 验证路径是否有效
            dir_path = os.path.dirname(db_path) or '.'
            if dir_path != '.' and not os.path.exists(dir_path):
                try:
                    os.makedirs(dir_path, exist_ok=True)
                    log_info(f"set_db_path: 创建数据库目录: {dir_path}")
                except Exception as mkdir_error:
                    log_error(f"set_db_path: 创建数据库目录失败: {str(mkdir_error)}")
                    return False
            
            DatabaseUtils._db_path = db_path
            log_info(f"set_db_path: 数据库路径已设置为: {db_path}")

            # 库路径变更：失效路径记忆、表结构缓存与金额迁移标记缓存
            # （标记缓存已按路径绑定，此处一并清理，保证换库后立刻重新探测）
            invalidate_db_path_cache()
            DatabaseUtils._money_migrated = None
            DatabaseUtils._money_migrated_path = None

            # 重置连接池，确保使用新的数据库路径
            with DatabaseUtils._pool_lock:
                for conn in DatabaseUtils._connection_pool:
                    try:
                        conn.close()
                    except Exception as close_error:
                        log_warning(f"set_db_path: 关闭连接时出错: {str(close_error)}")
                DatabaseUtils._connection_pool = []
                DatabaseUtils._conn_db_paths.clear()
                DatabaseUtils._integrity_check_cache.clear()
                DatabaseUtils._critical_tables_cache.clear()
                DatabaseUtils._ensure_indexes_cache.clear()
                DatabaseUtils._ensure_schema_cache.clear()
                DatabaseUtils._pool_warned = False  # 重置告警状态，换库后重新判断
                log_info("set_db_path: 连接池已重置")
            
            return True
        except Exception as e:
            log_error(f"set_db_path: 设置数据库路径失败: {str(e)}")
            return False
    
    @staticmethod
    def get_connection(connection_params=None):
        """
        获取数据库连接（从连接池或新建），提供完善的连接管理、错误恢复和参数配置
        
        Args:
            connection_params (dict, optional): 连接参数配置，支持以下键：
                - timeout: 连接超时时间（秒）
                - journal_mode: 日志模式（如 'WAL', 'DELETE'）
                - synchronous: 同步级别（如 'NORMAL', 'FULL'）
                - page_size: 页面大小
                - cache_size: 缓存大小
                
        Returns:
            sqlite3.Connection: 数据库连接对象，如果失败则返回None
        """# 记录连接池状态（DEBUG级别）
        with DatabaseUtils._pool_lock:
            active_size = len(DatabaseUtils._active_connections)# 默认连接参数
        default_params = {
            'timeout': 15,
            'journal_mode': 'WAL',
            'synchronous': 'NORMAL'
        }
        
        # 合并自定义参数
        if connection_params and isinstance(connection_params, dict):
            for key, value in connection_params.items():
                default_params[key] = value
        retry_count = 0
        max_retries = 3
        base_wait_time = 1.0  # 基础等待时间
        
        # 检查并清理连接池中的无效连接
        DatabaseUtils._cleanup_connection_pool()
        
        while retry_count < max_retries:
            try:
                # 获取数据库路径
                db_path = DatabaseUtils.get_db_path()
                if not db_path:
                    log_error("get_connection: 无法获取数据库路径")
                    return None
                
                # 验证数据库文件存在性
                file_exists = os.path.exists(db_path)
                # 将常规数据库路径检查降级为DEBUG级别# 检查数据库文件是否存在，如果不存在则创建
                if not file_exists:
                    log_info(f"get_connection: 数据库文件不存在，开始自动创建: {db_path}")
                    success, results = DatabaseUtils.create_empty_database(db_path)
                    for result in results:
                        log_info(f"get_connection: {result}")
                    if not success:
                        log_error("get_connection: 创建数据库失败")
                        # 增加重试次数
                        retry_count += 1
                        if retry_count < max_retries:
                            wait_time = base_wait_time * retry_count
                            log_info(f"get_connection: 尝试重新创建数据库 ({retry_count}/{max_retries})，等待 {wait_time} 秒")
                            time.sleep(wait_time)
                            continue
                        return None
                
                # 检查数据库文件是否损坏
                if file_exists and DatabaseUtils._is_database_corrupted(db_path):
                    log_error("get_connection: 检测到数据库文件可能已损坏，尝试修复")
                    # 尝试修复数据库
                    if not DatabaseUtils._attempt_database_repair(db_path):
                        log_error("get_connection: 数据库修复失败，尝试重建")
                        # 修复失败，尝试重建数据库
                        success, results = DatabaseUtils.create_empty_database(db_path)
                        for result in results:
                            log_info(f"get_connection: {result}")
                        if not success:
                            log_error("get_connection: 重建数据库失败")
                            retry_count += 1
                            if retry_count < max_retries:
                                wait_time = base_wait_time * retry_count
                                log_info(f"get_connection: 尝试重新连接 ({retry_count}/{max_retries})，等待 {wait_time} 秒")
                                time.sleep(wait_time)
                                continue
                            return None
                
                # 尝试从连接池获取连接
                conn = None
                with DatabaseUtils._pool_lock:
                    if DatabaseUtils._connection_pool:
                        try:
                            conn = DatabaseUtils._connection_pool.pop()
                            # 记录活跃连接（注意：_conn_db_paths 保持连接创建时登记的库路径，
                            # 用于归还时校验防混池，此处不能改写）
                            conn_id = id(conn)
                            DatabaseUtils._active_connections[conn_id] = time.time()
                            # log_info(f"获取连接成功，当前池大小: {len(DatabaseUtils._connection_pool)}")")
                        except Exception as pool_error:
                            log_error(f"从连接池获取连接时出错: {str(pool_error)}")
                            conn = None
                
                # 检查连接是否有效（在锁外执行以避免长时间持有锁）
                if conn:
                    try:
                        cursor = conn.cursor()
                        cursor.execute("SELECT 1")
                        cursor.close()# 验证关键表是否存在
                        if DatabaseUtils._validate_critical_tables(conn):
                            DatabaseUtils.ensure_schema_columns(conn, db_path)
                            # 保留连接成功的日志，但减少详细程度
                            log_debug("数据库连接获取成功")
                            return conn
                        else:
                            # 关键表不存在，需要重新创建数据库
                            log_error("检测到关键表缺失，需要重建数据库")
                            try:
                                conn.close()
                            except Exception as close_error:
                                log_warning(f"关闭无效连接时出错: {str(close_error)}")
                            # 从活跃连接记录中移除（防止计数膨胀泄漏）
                            with DatabaseUtils._pool_lock:
                                DatabaseUtils._active_connections.pop(id(conn), None)
                            conn = None
                        
                            # 重新创建数据库
                            success, results = DatabaseUtils.create_empty_database(db_path)
                            for result in results:
                                log_info(result)
                            if not success:
                                log_error("重建数据库失败")
                                return None
                    except Exception as e:
                        log_error(f"连接池中的连接无效: {str(e)}")
                        # 连接无效，关闭
                        try:
                            conn.close()
                        except Exception as close_error:
                            log_warning(f"关闭无效连接时出错: {str(close_error)}")
                        # 从活跃连接记录中移除（防止计数膨胀泄漏）
                        with DatabaseUtils._pool_lock:
                            DatabaseUtils._active_connections.pop(id(conn), None)
                        conn = None
                
                # 创建新连接前检查是否已达到最大连接数
                # 达到上限时有限等待池归还（轮询），超时后新建保底，避免连接无限膨胀
                if conn is None:
                    wait_start = time.time()
                    while True:
                        with DatabaseUtils._pool_lock:
                            active_size = len(DatabaseUtils._active_connections)
                            if active_size < DatabaseUtils._pool_size:
                                break  # 有新建额度
                            if DatabaseUtils._connection_pool:
                                # 池中有归还的连接，直接取用（下方验证后返回）
                                conn = DatabaseUtils._connection_pool.pop()
                                conn_id = id(conn)
                                DatabaseUtils._active_connections[conn_id] = time.time()
                                break
                        if time.time() - wait_start >= default_params['timeout']:
                            log_warning(f"get_connection: 等待连接归还超时({default_params['timeout']}s)，新建连接（活跃{active_size}）")
                            break
                        time.sleep(0.02)
                    
                    # 等待期间从池中取到连接，需验证后返回（与上方池取连接逻辑一致）
                    if conn is not None:
                        try:
                            cursor = conn.cursor()
                            cursor.execute("SELECT 1")
                            cursor.close()
                            if DatabaseUtils._validate_critical_tables(conn):
                                DatabaseUtils.ensure_schema_columns(conn, db_path)
                                log_debug("数据库连接获取成功")
                                return conn
                            else:
                                # 关键表缺失，关闭并从活跃表移除
                                log_error("检测到关键表缺失，需要重建数据库")
                                try:
                                    conn.close()
                                except Exception:
                                    pass
                                with DatabaseUtils._pool_lock:
                                    DatabaseUtils._active_connections.pop(id(conn), None)
                                conn = None
                        except Exception as e:
                            log_error(f"连接池中的连接无效: {str(e)}")
                            try:
                                conn.close()
                            except Exception:
                                pass
                            with DatabaseUtils._pool_lock:
                                DatabaseUtils._active_connections.pop(id(conn), None)
                            conn = None
                
                # 创建新连接
                log_debug(f"get_connection: 创建新的数据库连接: {db_path}")
                
                # 使用参数创建连接
                # check_same_thread=False：连接池的连接会被多线程复用（主线程+后台线程），
                # 显式关闭 sqlite3 的线程绑定检查（SQLite serialized 模式内部加锁）
                conn = sqlite3.connect(
                    db_path, 
                    timeout=default_params['timeout'],
                    check_same_thread=False
                )
                # 登记连接所属数据库路径（归还池时校验，防止切换数据库后旧库连接混入新池）
                DatabaseUtils._conn_db_paths[id(conn)] = db_path
                
                # 记录新创建的活跃连接
                conn_id = id(conn)
                with DatabaseUtils._pool_lock:
                    DatabaseUtils._active_connections[conn_id] = time.time()
                
                # 设置连接属性
                conn.row_factory = sqlite3.Row  # 使结果可以通过列名访问
                
                # 配置数据库参数
                try:
                    if 'journal_mode' in default_params:
                        conn.execute(f'PRAGMA journal_mode={default_params["journal_mode"]}')
                    if 'synchronous' in default_params:
                        conn.execute(f'PRAGMA synchronous={default_params["synchronous"]}')
                    if 'page_size' in default_params:
                        conn.execute(f'PRAGMA page_size={default_params["page_size"]}')
                    if 'cache_size' in default_params:
                        conn.execute(f'PRAGMA cache_size={default_params["cache_size"]}')
                    
                    # 启用外键约束
                    conn.execute('PRAGMA foreign_keys=ON')
                    
                    # 将参数配置完成日志降级为DEBUG级别
                except Exception as config_error:
                    log_warning(f"get_connection: 配置数据库参数时出错: {str(config_error)}")
                    # 配置错误不阻止连接使用
                
                # 验证关键表是否存在
                try:
                    if DatabaseUtils._validate_critical_tables(conn):
                        # 补齐历史缺失列（幂等，老库/旧备份自动升级）
                        DatabaseUtils.ensure_schema_columns(conn, db_path)
                        # 补齐常用查询索引（幂等，老库自动升级）
                        DatabaseUtils.ensure_indexes(conn)
                        # 统一连接成功的日志格式
                        log_debug(f"数据库连接获取成功 (ID:{conn_id})")
                        return conn
                    else:
                        # 关键表不存在，需要重新创建数据库
                        log_error("get_connection: 检测到关键表缺失，需要重建数据库")
                        # 关闭无效连接
                        try:
                            conn.close()
                        except Exception as close_error:
                            log_warning(f"get_connection: 关闭连接时出错: {str(close_error)}")
                        conn = None
                        
                        # 重新创建数据库
                        success, results = DatabaseUtils.create_empty_database(db_path)
                        for result in results:
                            log_info(f"get_connection: {result}")
                        if not success:
                            log_error("get_connection: 重建数据库失败")
                            retry_count += 1
                            if retry_count < max_retries:
                                wait_time = base_wait_time * retry_count
                                log_info(f"get_connection: 尝试重新创建数据库 ({retry_count}/{max_retries})，等待 {wait_time} 秒")
                                time.sleep(wait_time)
                                continue
                            return None
                        
                        # 重新创建连接
                        conn = sqlite3.connect(
                            db_path, 
                            timeout=default_params['timeout'],
                            check_same_thread=False
                        )
                        DatabaseUtils._conn_db_paths[id(conn)] = db_path
                        conn.row_factory = sqlite3.Row
                        conn.execute(f'PRAGMA journal_mode={default_params["journal_mode"]}')
                        conn.execute(f'PRAGMA synchronous={default_params["synchronous"]}')
                        conn.execute('PRAGMA foreign_keys=ON')
                        DatabaseUtils.ensure_indexes(conn)
                        
                        log_info("get_connection: 数据库连接获取成功")
                        return conn
                except Exception as validate_error:
                    log_warning(f"get_connection: 验证关键表时出错: {str(validate_error)}")
                    # 验证错误时仍返回连接，让上层处理
                except Exception as e:
                    log_error(f"get_connection: 验证表存在性时出错: {str(e)}")
                    try:
                        if conn:
                            conn.close()
                    except Exception as close_error:
                        log_warning(f"get_connection: 关闭连接时出错: {str(close_error)}")
                    
                    # 增加重试次数
                    retry_count += 1
                    if retry_count < max_retries:
                        wait_time = base_wait_time * retry_count
                        log_info(f"get_connection: 尝试重新连接 ({retry_count}/{max_retries})，等待 {wait_time} 秒")
                        time.sleep(wait_time)
                        continue
                    return None
                    
            except sqlite3.OperationalError as e:
                # 操作错误，可能是文件锁定或访问权限问题
                error_msg = str(e).lower()
                log_error(f"get_connection: 数据库操作错误: {str(e)}")
                
                # 针对特定错误类型的处理
                if 'locked' in error_msg or 'busy' in error_msg:
                    log_info("get_connection: 数据库文件被锁定，尝试释放锁")
                    # 尝试释放锁
                    DatabaseUtils.try_close_locks()
                elif 'permission' in error_msg or 'access denied' in error_msg:
                    log_error(f"get_connection: 权限错误，无法访问数据库文件: {db_path}")
                    # 权限错误通常不可重试
                    return None
                
                retry_count += 1
                wait_time = base_wait_time * retry_count
                log_info(f"get_connection: 尝试重试 ({retry_count}/{max_retries})，等待 {wait_time} 秒")
                time.sleep(wait_time)
                
            except sqlite3.DatabaseError as e:
                # 数据库错误，可能是文件格式问题
                log_error(f"get_connection: 数据库错误: {str(e)}")
                retry_count += 1
                wait_time = base_wait_time * retry_count
                log_info(f"get_connection: 尝试重试 ({retry_count}/{max_retries})，等待 {wait_time} 秒")
                time.sleep(wait_time)
                
            except Exception as e:
                # 其他未预期错误
                log_error(f"get_connection: 数据库连接失败: {str(e)}")
                retry_count += 1
                if retry_count < max_retries:
                    wait_time = base_wait_time * retry_count
                    log_info(f"get_connection: 尝试重试 ({retry_count}/{max_retries})，等待 {wait_time} 秒")
                    time.sleep(wait_time)
                else:
                    return None
        
        log_error("get_connection: 数据库连接重试次数用尽，连接失败")
        
        # 所有重试均失败时，尝试最后的应急措施
        log_info("get_connection: 执行最后的应急恢复措施")
        
        # 尝试清理并重建数据库
        try:
            # 强制清理锁定
            DatabaseUtils.try_close_locks()
            
            # 尝试重建数据库
            success, results = DatabaseUtils.force_initialize_database()
            if success:
                log_info("get_connection: 应急重建数据库成功，尝试重新连接")
                # 重建成功后再次尝试连接
                return DatabaseUtils.get_connection(connection_params)
        except Exception as emergency_error:
            log_error(f"get_connection: 应急恢复措施失败: {str(emergency_error)}")
        
        return None
    
    @staticmethod
    def _cleanup_connection_pool():
        """
        线程安全地清理连接池中的无效连接，并移除长时间未使用的活跃连接记录
        
        Returns:
            int: 清理的无效连接数量
        """# 使用线程锁保护连接池操作
        with DatabaseUtils._pool_lock:
            if not DatabaseUtils._connection_pool:return 0
                
            valid_connections = []
            cleaned_count = 0
            total_connections = len(DatabaseUtils._connection_pool)
            
            # 在锁内获取连接池副本，然后在锁外验证连接有效性
            # 这样可以减少锁的持有时间，提高并发性能
            connections_to_check = DatabaseUtils._connection_pool.copy()
            DatabaseUtils._connection_pool.clear()
        
        # 在锁外检查每个连接的有效性
        for conn in connections_to_check:
            is_valid = False
            try:
                # 检查连接是否有效
                cursor = conn.cursor()
                cursor.execute("SELECT 1")
                cursor.close()
                is_valid = True
            except Exception as e:
                log_info(f"清理无效连接: {str(e)}")
                try:
                    conn.close()
                except Exception as close_err:
                    log_warning(f"关闭无效连接时出错: {close_err}")
                cleaned_count += 1
            
            if is_valid:
                valid_connections.append(conn)
        
        # 使用线程锁更新连接池
        with DatabaseUtils._pool_lock:
            DatabaseUtils._connection_pool.extend(valid_connections)
            
            # 清理过期的活跃连接记录（避免内存泄漏）
            current_time = time.time()
            expired_connections = []
            for conn_id, last_used in DatabaseUtils._active_connections.items():
                # 如果连接记录超过30分钟未更新，视为过期
                if current_time - last_used > 1800:
                    expired_connections.append(conn_id)
            
            for conn_id in expired_connections:
                del DatabaseUtils._active_connections[conn_id]
            
            if expired_connections:
                log_info(f"已清理 {len(expired_connections)} 个过期的活跃连接记录")
            
        if cleaned_count > 0:
            log_info(f"已清理 {cleaned_count}/{total_connections} 个无效连接")
        return cleaned_count
    
    @staticmethod
    def _is_database_corrupted(db_path):
        """
        检测数据库文件是否损坏

        性能优化（2026-09-02）：完整 integrity_check 平均 ~33ms/次，
        原实现在 get_connection 每请求都会执行一次（小数据量 API 400ms+ 的主因之一）。
        现增加 60 秒结果缓存：同一 db_path 60 秒内只做一次完整检查，
        切换数据库路径（set_db_path）时自动按新路径重新检查。

        Args:
            db_path (str): 数据库文件路径

        Returns:
            bool: 如果数据库可能损坏返回True，否则返回False
        """
        if not os.path.exists(db_path):
            return False

        # 60 秒 TTL 缓存
        now = time.time()
        cached = DatabaseUtils._integrity_check_cache.get(db_path)
        if cached and (now - cached[0]) < 60:
            return cached[1]

        result = DatabaseUtils._do_check_database_corrupted(db_path)

        # 缓存结果（含失败结果，避免频繁重试风暴）
        DatabaseUtils._integrity_check_cache[db_path] = (now, result)
        return result

    @staticmethod
    def _do_check_database_corrupted(db_path):
        """实际的完整性检查（无缓存）"""
        # 检查文件大小是否为0
        if os.path.getsize(db_path) == 0:
            log_error(f"_is_database_corrupted: 数据库文件为空: {db_path}")
            return True

        # 尝试打开并执行简单查询来测试数据库完整性
        try:
            test_conn = sqlite3.connect(db_path, timeout=5)
            cursor = test_conn.cursor()

            # 执行完整性检查
            cursor.execute("PRAGMA integrity_check")
            result = cursor.fetchone()[0]

            if result != 'ok':
                log_error(f"_is_database_corrupted: 数据库完整性检查失败: {result}")
                test_conn.close()
                return True

            # 执行快速统计查询
            cursor.execute("SELECT count(*) FROM sqlite_master")
            cursor.fetchone()

            test_conn.close()
            # 将数据库完整性检查通过日志降级为DEBUG级别
            return False

        except Exception as e:
            log_error(f"_is_database_corrupted: 检测数据库完整性时出错: {str(e)}")
            try:
                if 'test_conn' in locals():
                    test_conn.close()
            except Exception as close_err:
                log_debug(f"关闭完整性检查连接时出错: {close_err}")
            return True
    
    @staticmethod
    def _attempt_database_repair(db_path):
        """
        尝试修复损坏的数据库
        
        Args:
            db_path (str): 数据库文件路径
            
        Returns:
            bool: 修复是否成功
        """
        log_info(f"_attempt_database_repair: 开始尝试修复数据库: {db_path}")
        
        # 备份原始数据库
        backup_path = f"{db_path}.backup_{int(time.time())}"
        try:
            shutil.copy2(db_path, backup_path)
            log_info(f"_attempt_database_repair: 创建数据库备份: {backup_path}")
        except Exception as backup_error:
            log_error(f"_attempt_database_repair: 创建备份失败: {str(backup_error)}")
            # 备份失败仍继续尝试修复
        
        # 尝试使用SQLite的修复命令
        try:
            repair_conn = sqlite3.connect(db_path, timeout=10)
            cursor = repair_conn.cursor()
            
            # 执行修复命令
            cursor.execute("PRAGMA writable_schema=ON")
            
            # 尝试重建数据库
            # 注意：这是一个基本的修复方法，对于严重损坏可能不起作用
            log_info("_attempt_database_repair: 执行数据库修复命令")
            
            # 执行VACUUM命令重建数据库
            repair_conn.execute("VACUUM")
            
            # 重置writable_schema
            cursor.execute("PRAGMA writable_schema=OFF")
            
            # 检查修复后的数据库
            cursor.execute("PRAGMA integrity_check")
            result = cursor.fetchone()[0]
            
            repair_conn.close()
            
            if result == 'ok':
                log_info("_attempt_database_repair: 数据库修复成功")
                return True
            else:
                log_error(f"_attempt_database_repair: 修复后数据库仍有问题: {result}")
                return False
                
        except Exception as repair_error:
            log_error(f"_attempt_database_repair: 修复数据库时出错: {str(repair_error)}")
            try:
                if 'repair_conn' in locals():
                    repair_conn.close()
            except Exception as close_err:
                log_debug(f"关闭修复连接时出错: {close_err}")
            return False
    
    @staticmethod
    def _validate_critical_tables(conn):
        """验证数据库中的关键表是否存在

        性能优化（2026-09-02）：sqlite_master 查询平均 ~27ms/次，
        原实现在 get_connection 每次取池连接都会执行。现按 db_path 缓存
        60 秒（表结构在运行期几乎不变；set_db_path 切库时按新路径重新检查）。
        """
        # 获取该连接所属的数据库路径作为缓存键
        db_path = DatabaseUtils._conn_db_paths.get(id(conn)) or "unknown"
        now = time.time()
        cached = DatabaseUtils._critical_tables_cache.get(db_path)
        if cached and (now - cached[0]) < 60:
            return cached[1]

        try:
            cursor = conn.cursor()
            critical_tables = ['contracts', 'reminder_settings', 'rent_records']
            table_missing = False

            for table in critical_tables:
                cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table,))
                exists = cursor.fetchone() is not None
                # 将表存在状态日志降级为DEBUG级别，减少日志冗余
                if not exists:
                    table_missing = True
                    log_error(f"检测到关键表 {table} 不存在")
                    break

            result = not table_missing
            DatabaseUtils._critical_tables_cache[db_path] = (now, result)
            return result
        except Exception as e:
            log_error(f"验证关键表时出错: {str(e)}")
            DatabaseUtils._critical_tables_cache[db_path] = (now, False)
            return False
    
    @staticmethod
    def ensure_indexes(conn):
        """为常用查询字段补齐索引（幂等，老库升级时自动生效）

        说明：正式库在早期版本创建时没有索引，此处按需补齐。
        使用 CREATE INDEX IF NOT EXISTS，已存在时跳过，可安全重复执行。

        性能优化（2026-09-02）：原实现每次新建连接都执行 11 次
        sqlite_master 查询 + 11 次 CREATE INDEX IF NOT EXISTS。
        索引补齐是幂等操作且运行期表结构不变，按 db_path 缓存 60 秒。

        Args:
            conn: 数据库连接对象
        """
        try:
            # 60 秒 TTL 缓存：同一库路径 60 秒内只做一次索引检查
            db_path = DatabaseUtils._conn_db_paths.get(id(conn)) or DatabaseUtils._db_path
            if db_path:
                now = time.time()
                last = DatabaseUtils._ensure_indexes_cache.get(db_path, 0)
                if now - last < 60:
                    return
            cursor = conn.cursor()
            index_operations = [
                ('rent_records', 'idx_rent_records_contract_no', 'contract_no'),
                ('rent_records', 'idx_rent_records_receipt_date', 'receipt_date'),
                ('rent_records', 'idx_rent_records_period_end', 'period_end'),
                ('contracts', 'idx_contracts_contract_no', 'contract_no'),
                ('contracts', 'idx_contracts_house_no', 'house_no'),
                ('contracts', 'idx_contracts_start_date', 'start_date'),
                ('contracts', 'idx_contracts_end_date', 'end_date'),
                ('houses', 'idx_houses_house_no', 'house_no'),
                ('tenants', 'idx_tenants_tenant_name', 'tenant_name'),
                ('operation_logs', 'idx_operation_logs_log_time', 'log_time'),
                ('operation_logs', 'idx_operation_logs_username', 'username')
            ]
            created = 0
            for table_name, index_name, column_name in index_operations:
                try:
                    # 表存在时才创建
                    cursor.execute(
                        "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
                        (table_name,)
                    )
                    if cursor.fetchone():
                        cursor.execute(
                            f"CREATE INDEX IF NOT EXISTS {index_name} ON {table_name}({column_name})"
                        )
                        created += 1
                except Exception as e:
                    log_warning(f"ensure_indexes: 创建索引 {index_name} 失败: {str(e)}")
            if created:
                conn.commit()
                log_info(f"ensure_indexes: 已补齐 {created} 个索引")
            # 检查完成（无论是否创建）记录缓存时间戳
            if db_path:
                DatabaseUtils._ensure_indexes_cache[db_path] = time.time()
        except Exception as e:
            log_error(f"ensure_indexes: 补齐索引失败: {str(e)}")
    
    @staticmethod
    def create_database_from_existing(source_db_path, target_db_path):
        """
        从现有数据库复制结构创建新数据库
        
        Args:
            source_db_path (str): 源数据库文件路径
            target_db_path (str): 目标数据库文件路径
            
        Returns:
            tuple: (success, results) - (是否成功, 结果信息列表)
        """
        results = []
        
        try:
            # 验证源数据库是否存在
            if not os.path.exists(source_db_path):
                results.append(f"❌ 源数据库不存在: {source_db_path}")
                log_error(f"源数据库不存在: {source_db_path}")
                return False, results
            
            # 防御：目标与源相同（GUI 层已拦截，这里双保险，避免误删当前库导致数据损坏）
            if os.path.normcase(os.path.abspath(source_db_path)) == os.path.normcase(os.path.abspath(target_db_path)):
                results.append("❌ 目标数据库与源数据库相同，已拒绝（不能覆盖当前正在使用的数据库）")
                log_error("目标数据库与源数据库相同，已拒绝")
                return False, results
            
            # 验证目标数据库目录
            target_dir = os.path.dirname(target_db_path)
            if target_dir and not os.path.exists(target_dir):
                try:
                    os.makedirs(target_dir)
                    results.append(f"✓ 创建目标目录: {target_dir}")
                except Exception as e:
                    results.append(f"❌ 创建目标目录失败: {str(e)}")
                    log_error(f"创建目标目录失败: {str(e)}")
                    return False, results
            
            # 如果目标数据库已存在，先删除（同时清理 WAL/SHM 残留，避免旧日志污染新库）
            if os.path.exists(target_db_path):
                try:
                    os.remove(target_db_path)
                    results.append("✓ 删除已存在的目标数据库")
                except Exception as e:
                    results.append(f"❌ 删除目标数据库失败: {str(e)}")
                    log_error(f"删除目标数据库失败: {str(e)}")
                    return False, results
            for residue_suffix in ("-wal", "-shm"):
                residue_path = target_db_path + residue_suffix
                if os.path.exists(residue_path):
                    try:
                        os.remove(residue_path)
                        results.append(f"✓ 清理残留文件: {os.path.basename(residue_path)}")
                    except Exception as e:
                        log_warning(f"清理残留文件失败 {residue_path}: {str(e)}")
            
            # 连接源数据库
            source_conn = sqlite3.connect(source_db_path, timeout=30)
            source_cursor = source_conn.cursor()
            
            # 连接目标数据库
            target_conn = sqlite3.connect(target_db_path, timeout=30)
            target_cursor = target_conn.cursor()
            
            # 设置目标数据库的性能参数
            target_conn.execute('PRAGMA journal_mode=WAL')
            target_conn.execute('PRAGMA synchronous=NORMAL')
            target_conn.execute('PRAGMA foreign_keys=OFF')  # 创建表时先关闭外键约束
            
            # 开始事务
            target_conn.execute('BEGIN TRANSACTION')
            transaction_started = True
            
            # 获取源数据库中的所有表结构
            source_cursor.execute("SELECT name, sql FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")
            tables = source_cursor.fetchall()
            
            if not tables:
                results.append("❌ 源数据库中未找到表")
                raise Exception("源数据库中未找到表结构")
            
            results.append(f"发现 {len(tables)} 个表，开始复制结构...")
            
            # 首先创建所有表（不包括外键约束，稍后添加）
            created_tables = []
            for table_name, create_sql in tables:
                try:
                    # 保存原始SQL用于后续完整性验证
                    original_create_sql = create_sql
                    
                    # 创建表
                    target_cursor.execute(create_sql)
                    created_tables.append(table_name)
                    results.append(f"✓ 创建表: {table_name}")
                    
                    # 获取表的详细结构信息
                    source_cursor.execute(f"PRAGMA table_info({table_name})")
                    columns_info = source_cursor.fetchall()
                    results.append(f"  - {table_name}表包含 {len(columns_info)} 个字段")
                    
                except sqlite3.Error as e:
                    results.append(f"❌ 创建表 {table_name} 失败: {str(e)}")
                    log_error(f"创建表 {table_name} 失败: {str(e)}")
                    raise
            
            # 获取并创建所有索引
            source_cursor.execute("SELECT name, sql FROM sqlite_master WHERE type='index' AND name NOT LIKE 'sqlite_%'")
            indexes = source_cursor.fetchall()
            
            if indexes:
                results.append(f"\n发现 {len(indexes)} 个索引，开始创建...")
                for index_name, create_sql in indexes:
                    try:
                        target_cursor.execute(create_sql)
                        results.append(f"✓ 创建索引: {index_name}")
                    except sqlite3.Error as e:
                        # 索引创建失败不影响主要功能，记录警告
                        results.append(f"⚠️ 创建索引 {index_name} 失败: {str(e)}")
                        log_warning(f"创建索引 {index_name} 失败: {str(e)}")
            
            # 获取并创建所有触发器
            source_cursor.execute("SELECT name, sql FROM sqlite_master WHERE type='trigger' AND name NOT LIKE 'sqlite_%'")
            triggers = source_cursor.fetchall()
            
            if triggers:
                results.append(f"\n发现 {len(triggers)} 个触发器，开始创建...")
                for trigger_name, create_sql in triggers:
                    try:
                        target_cursor.execute(create_sql)
                        results.append(f"✓ 创建触发器: {trigger_name}")
                    except sqlite3.Error as e:
                        results.append(f"⚠️ 创建触发器 {trigger_name} 失败: {str(e)}")
                        log_warning(f"创建触发器 {trigger_name} 失败: {str(e)}")
            
            # 提交事务
            target_conn.commit()
            transaction_started = False
            results.append("\n✓ 事务已成功提交")
            
            # 复制关键配置表数据（含金额迁移标记 schema_meta、自动备份设置、水电费单价、出租方）
            fatal_copy_error = None
            try:
                results.append("\n开始复制关键表数据...")
                tables_to_copy = ['reminder_settings', 'system_params', 'schema_meta', 'auto_backup_settings',
                                  'utility_fee', 'landlords']
                
                for table_name in tables_to_copy:
                    # 检查源数据库中是否存在该表
                    source_cursor.execute(f"SELECT name FROM sqlite_master WHERE type='table' AND name='{table_name}'")
                    if source_cursor.fetchone():
                        # 检查目标数据库中是否存在该表
                        target_cursor.execute(f"SELECT name FROM sqlite_master WHERE type='table' AND name='{table_name}'")
                        if target_cursor.fetchone():
                            # 获取表的列信息
                            source_cursor.execute(f"PRAGMA table_info({table_name})")
                            columns = source_cursor.fetchall()
                            column_names = [col[1] for col in columns]
                            
                            # 构建列名列表用于SQL查询
                            columns_str = ', '.join(column_names)
                            placeholders = ', '.join(['?' for _ in column_names])
                            
                            # 获取源表中的所有数据
                            source_cursor.execute(f"SELECT {columns_str} FROM {table_name}")
                            rows = source_cursor.fetchall()
                            
                            if rows:
                                # 开始事务以提高插入性能
                                target_conn.execute('BEGIN TRANSACTION')
                                try:
                                    # 批量插入数据
                                    insert_sql = f"INSERT INTO {table_name} ({columns_str}) VALUES ({placeholders})"
                                    target_cursor.executemany(insert_sql, rows)
                                    target_conn.commit()
                                    
                                    # 验证数据复制是否成功
                                    target_cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
                                    target_count = target_cursor.fetchone()[0]
                                    
                                    if target_count == len(rows):
                                        results.append(f"✓ 成功复制 {table_name} 表数据: {len(rows)} 条记录")
                                    else:
                                        results.append(f"⚠️ {table_name} 表数据计数不匹配: 源表({len(rows)}) vs 目标表({target_count})")
                                        log_warning(f"{table_name} 表数据计数不匹配: 源表({len(rows)}) vs 目标表({target_count})")
                                except Exception as insert_error:
                                    target_conn.rollback()
                                    results.append(f"❌ 插入 {table_name} 表数据失败: {str(insert_error)}")
                                    log_error(f"插入 {table_name} 表数据失败: {str(insert_error)}")
                                    # 行为标记表复制失败会让新库金额模式退化（历史 Bug 1），升级为致命错误
                                    if table_name == 'schema_meta':
                                        fatal_copy_error = (
                                            f"关键行为标记表 schema_meta 复制失败"
                                            f"（新库金额存储模式可能退化）: {str(insert_error)}"
                                        )
                            else:
                                results.append(f"✓ {table_name} 表中无数据")
                        else:
                            results.append(f"⚠️ 目标数据库中未找到 {table_name} 表")
                    else:
                        results.append(f"⚠️ 源数据库中未找到 {table_name} 表")
            except Exception as e:
                results.append(f"❌ 复制关键表数据时出错: {str(e)}")
                log_error(f"复制关键表数据失败: {str(e)}")
                if 'schema_meta' in str(e) and not fatal_copy_error:
                    fatal_copy_error = f"关键行为标记表 schema_meta 复制失败（新库金额存储模式可能退化）: {str(e)}"

            # 关键行为标记表复制失败 -> 中止创建（宁可失败重来，也不能交付金额模式退化的新库）
            if fatal_copy_error:
                results.append(f"❌ {fatal_copy_error}")
                raise Exception(fatal_copy_error)
            
            # 创建初始管理员账户
            try:
                # 检查用户表是否存在
                target_cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='users'")
                if target_cursor.fetchone():
                    # 检查是否已有admin用户
                    target_cursor.execute("SELECT * FROM users WHERE username='admin'")
                    if not target_cursor.fetchone():
                        # 插入初始管理员账户（密码使用哈希存储）
                        from user_auth import PasswordUtils
                        hashed_admin = PasswordUtils.hash_password('admin')
                        target_cursor.execute("INSERT INTO users (username, password, role) VALUES (?, ?, ?)", ('admin', hashed_admin, '管理员'))
                        results.append("✓ 已创建初始管理员账户: admin/admin")
                    else:
                        results.append("✓ 管理员账户已存在")
                else:
                    results.append("⚠️ 用户表不存在，无法创建管理员账户")
            except Exception as e:
                results.append(f"❌ 创建管理员账户失败（新库将无法登录，中止创建）: {str(e)}")
                log_error(f"创建管理员账户失败: {str(e)}")
                raise Exception(f"创建初始管理员账户失败，新库将无法登录: {str(e)}")
            
            # 重新启用外键约束
            target_conn.execute('PRAGMA foreign_keys=ON')
            results.append("✓ 已启用外键约束")
            
            # 显式提交可能存在的事务，确保在执行VACUUM前没有活动事务
            target_conn.commit()
            
            # 执行VACUUM优化新数据库
            target_conn.execute('VACUUM')
            results.append("✓ 数据库已优化")
            
            # 金额存储模式一致性校验（防止 schema_meta 丢失导致分模式库退化为元模式）
            try:
                src_migrated = source_cursor.execute(
                    "SELECT value FROM schema_meta WHERE key='amount_cents_migrated'"
                ).fetchone()
                tgt_migrated = target_cursor.execute(
                    "SELECT value FROM schema_meta WHERE key='amount_cents_migrated'"
                ).fetchone()
                src_is_cents = bool(src_migrated and str(src_migrated[0]) == "1")
                tgt_is_cents = bool(tgt_migrated and str(tgt_migrated[0]) == "1")
                if src_is_cents != tgt_is_cents:
                    raise Exception(
                        f"金额存储模式不一致：源库={'分' if src_is_cents else '元'}，"
                        f"新库={'分' if tgt_is_cents else '元'}"
                    )
                results.append(f"✓ 金额存储模式一致（{'分' if tgt_is_cents else '元'}）")
            except sqlite3.Error:
                results.append("✓ 金额存储模式一致（源库无 schema_meta，按元模式）")
            
            # 完整性校验：integrity + 外键
            target_cursor.execute("PRAGMA integrity_check")
            if target_cursor.fetchone()[0] != "ok":
                raise Exception("新数据库 integrity_check 未通过")
            results.append("✓ 完整性检查通过 (integrity_check=ok)")
            fk_issues = target_cursor.execute("PRAGMA foreign_key_check").fetchall()
            if fk_issues:
                results.append(f"⚠️ 外键检查发现 {len(fk_issues)} 条问题: {fk_issues[:3]}")
            else:
                results.append("✓ 外键检查通过")
            
            # 交付前 checkpoint，确保 -wal/-shm 不残留、文件干净
            target_conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
            results.append("✓ WAL 已 checkpoint (TRUNCATE)")
            
            # 验证新数据库结构
            results.append("\n开始验证新数据库结构...")
            target_cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")
            new_tables = [table[0] for table in target_cursor.fetchall()]
            
            # 检查表数量是否匹配
            if len(new_tables) != len(created_tables):
                results.append(f"⚠️ 表数量不匹配: 源数据库({len(created_tables)}) vs 新数据库({len(new_tables)})")
                log_warning(f"表数量不匹配: 源数据库({len(created_tables)}) vs 新数据库({len(new_tables)})")
            else:
                results.append(f"✓ 表数量验证成功: 共 {len(new_tables)} 个表")
            
            # 检查每个表的结构
            for table_name in new_tables:
                # 获取表结构信息
                target_cursor.execute(f"PRAGMA table_info({table_name})")
                columns = target_cursor.fetchall()
                results.append(f"✓ 表 {table_name} 包含 {len(columns)} 个字段")
            
            # 检查索引
            target_cursor.execute("SELECT name FROM sqlite_master WHERE type='index' AND name NOT LIKE 'sqlite_%'")
            new_indexes = [index[0] for index in target_cursor.fetchall()]
            results.append(f"✓ 索引数量: {len(new_indexes)} 个")
            
            # 关闭连接
            source_conn.close()
            target_conn.close()
            
            results.append("\n✅ 数据库结构复制完成！")
            results.append(f"源数据库: {source_db_path}")
            results.append(f"新数据库: {target_db_path}")
            
            return True, results
            
        except Exception as e:
            results.append(f"❌ 复制数据库结构时出错: {str(e)}")
            log_error(f"复制数据库结构失败: {str(e)}")
            
            # 回滚事务
            if 'transaction_started' in locals() and transaction_started:
                try:
                    target_conn.rollback()
                    results.append("✓ 事务已回滚")
                except Exception as rollback_error:
                    results.append(f"❌ 回滚事务失败: {str(rollback_error)}")
            
            # 关闭连接
            try:
                if 'source_conn' in locals():
                    source_conn.close()
                if 'target_conn' in locals():
                    try:
                        target_conn.close()
                    except Exception as close_err:
                        log_debug(f"关闭目标连接时出错: {close_err}")
            except Exception as e:
                log_error(f"备份数据库出错: {str(e)}")
            
            # 如果创建了部分数据库，尝试删除（同时清理 WAL/SHM 残留）
            if os.path.exists(target_db_path):
                try:
                    os.remove(target_db_path)
                    results.append("✓ 已删除损坏的目标数据库")
                except Exception as rm_err:
                    log_warning(f"删除损坏的目标数据库失败: {rm_err}")
            for residue_suffix in ("-wal", "-shm"):
                residue_path = target_db_path + residue_suffix
                if os.path.exists(residue_path):
                    try:
                        os.remove(residue_path)
                    except Exception as rm_err:
                        log_debug(f"删除残留文件失败: {rm_err}")
            
            return False, results
    
    @staticmethod
    def close_connection(conn):
        """
        安全关闭数据库连接或归还到连接池（线程安全实现）
        
        此方法会：
        1. 检查连接是否存在
        2. 回滚未提交的事务
        3. 验证连接有效性
        4. 如果有效且符合条件，线程安全地归还到连接池；否则关闭连接
        5. 执行必要的资源清理和垃圾回收
        
        Args:
            conn: 数据库连接对象
            
        Returns:
            bool: 操作是否成功
        """
        # 检查连接是否存在
        if conn is None: return True
            
        try:
            # 尝试重置连接状态（回滚可能的未提交事务）
            try:
                # P1-10（2026-09-11）：防御性回滚保留，但 in_transaction 为真说明
                # 调用方"写库后漏 commit"，数据会被静默丢弃 —— 打 WARNING 让其立刻暴露
                if getattr(conn, "in_transaction", False):
                    log_warning("close_connection: 连接存在未提交事务（调用方写库后漏 commit），"
                                "已防御性回滚 —— 请检查对应代码路径的 conn.commit() 是否遗漏")
                conn.rollback()
            except sqlite3.ProgrammingError:
                # 处理编程错误（如事务已结束）
                pass
            except sqlite3.OperationalError as op_error:
                if 'closed' in str(op_error).lower():
                    pass
                else:
                    log_error(f"回滚事务时发生操作错误: {str(op_error)}")
            except Exception as rollback_error:
                log_error(f"重置连接状态时出错: {str(rollback_error)}")
                # 回滚失败，但继续尝试关闭或归还连接
            
            # 验证连接是否仍然有效（在锁外执行）
            is_valid = False
            cursor = None
            try:
                cursor = conn.cursor()
                cursor.execute("SELECT 1")
                cursor.fetchone()  # 确保查询执行完成
                cursor.close()
                is_valid = True
            except sqlite3.ProgrammingError:
                # 处理编程错误
                pass
            except sqlite3.OperationalError as op_error:
                if 'closed' in str(op_error).lower():
                    # 连接已关闭
                    pass
                else:
                    log_error(f"连接验证时发生操作错误: {str(op_error)}")
            except Exception as validate_error:
                log_error(f"连接验证失败: {str(validate_error)}")
            finally:
                # 确保cursor被关闭
                if cursor:
                    try:
                        cursor.close()
                    except Exception as close_err:
                        log_debug(f"关闭游标时出错: {close_err}")
            
            if is_valid:
                # 校验连接所属库路径与当前配置库一致，防止切换数据库后旧库连接混入新池
                # （旧库连接直接关闭，不归还）
                conn_db_path = DatabaseUtils._conn_db_paths.get(id(conn))
                current_db_path = DatabaseUtils.get_db_path()
                if conn_db_path is not None and current_db_path and conn_db_path != current_db_path:
                    log_info("close_connection: 连接属于旧数据库路径，关闭而非归还连接池")
                    conn_id = id(conn)
                    with DatabaseUtils._pool_lock:
                        DatabaseUtils._active_connections.pop(conn_id, None)
                        DatabaseUtils._conn_db_paths.pop(conn_id, None)
                    try:
                        conn.close()
                    except Exception:
                        pass
                    return True
                
                # 获取连接池配置（在锁内执行）
                max_pool_size = DatabaseUtils._pool_size
                pool_size = 0
                
                # 检查是否可以归还到连接池
                with DatabaseUtils._pool_lock:
                    pool_size = len(DatabaseUtils._connection_pool)
                    if pool_size < max_pool_size:
                        # 连接有效且池未满，重置连接状态后归还到池
                        try:
                            conn.execute("PRAGMA journal_mode=WAL")
                            conn.execute("PRAGMA synchronous=NORMAL")
                            conn.execute("PRAGMA foreign_keys=ON")
                        except Exception as reset_error:
                            log_warning(f"重置连接状态时出错: {str(reset_error)}")
                            # 重置失败不阻止归还到连接池
                       
                        # 从活跃连接字典中移除
                        conn_id = id(conn)
                        if conn_id in DatabaseUtils._active_connections:
                            del DatabaseUtils._active_connections[conn_id]
                        
                        # 归还到连接池
                        DatabaseUtils._connection_pool.append(conn)
                        new_pool_size = len(DatabaseUtils._connection_pool)
                        log_debug(f"数据库连接(ID:{conn_id})已归还到连接池，当前池大小: {new_pool_size}")
                        
                        # 检查连接池健康状态
                        # 说明：new_pool_size 是「空闲」连接数（已归还），池满其实是正常状态，
                        # 不代表压力。原实现每次归还都判断，池达到 5 后每个请求都打一条 INFO，
                        # 导致该行占满日志（实测 1034/1551 行）。改为边沿触发：只在跨过警戒线
                        # 的那一次记录，回落到线下后再跨过才会再次记录。
                        if new_pool_size >= max_pool_size * 0.8:
                            if not DatabaseUtils._pool_warned:
                                DatabaseUtils._pool_warned = True
                                log_info(
                                    f"连接池空闲连接达到警戒线 ({new_pool_size}/{max_pool_size})，"
                                    f"当前活跃连接 {len(DatabaseUtils._active_connections)} 个"
                                    f"（空闲达到上限属正常；如需调整请调用 set_pool_size()）"
                                )
                        else:
                            DatabaseUtils._pool_warned = False
                        
                        return True
            else:  # 从活跃连接字典中移除
                conn_id = id(conn)
                with DatabaseUtils._pool_lock:
                    if conn_id in DatabaseUtils._active_connections:
                        del DatabaseUtils._active_connections[conn_id]
            
            # 关闭连接（未归还池的连接：关闭前必须清除活跃记录，防止泄漏）
            # 覆盖：连接验证失败、验证有效但池已满等所有未归还路径
            conn_id = id(conn)
            with DatabaseUtils._pool_lock:
                DatabaseUtils._active_connections.pop(conn_id, None)
                DatabaseUtils._conn_db_paths.pop(conn_id, None)
            conn.close()
            log_debug(f"数据库连接(ID:{conn_id})已成功关闭")
            return True
            
        except sqlite3.OperationalError as op_error:
            # 操作错误，可能是连接已经关闭或无效
            error_msg = str(op_error).lower()
            if 'closed' in error_msg:return True  # 连接已关闭，视为成功
            else:
                log_error(f"close_connection: 操作错误 - 无法关闭数据库连接: {str(op_error)}")
                
                # 尝试强制关闭
                try:
                    conn.close()
                    log_info("close_connection: 强制关闭连接成功")
                    return True
                except Exception as force_close_error:
                    log_warning(f"close_connection: 强制关闭连接失败: {str(force_close_error)}")
                    return False
                    
        except sqlite3.DatabaseError as db_error:
            # 数据库相关错误
            log_error(f"close_connection: 数据库错误 - 无法关闭连接: {str(db_error)}")
            
            # 尝试强制关闭
            try:
                conn.close()
                log_info("close_connection: 强制关闭连接成功")
                return True
            except Exception as force_close_error:
                log_warning(f"close_connection: 强制关闭连接失败: {str(force_close_error)}")
                return False
                
        except Exception as e:
            # 其他未预期错误
            log_error(f"close_connection: 关闭数据库连接失败: {str(e)}")
            
            # 尝试强制关闭
            try:
                conn.close()
                log_info("close_connection: 强制关闭连接成功")
                return True
            except Exception as force_close_error:
                log_warning(f"close_connection: 强制关闭连接失败: {str(force_close_error)}")
                return False
                
        finally:
                # 确保连接不再被引用
                conn = None
                
                # 执行垃圾回收以确保资源释放
                # 性能优化（2026-09-02）：原实现每次 close 都 gc.collect()，
                # 全局 GC 是 stop-the-world，5 并发下各线程互相冻结（p50 400ms+）。
                # 连接对象靠引用计数即时释放，无需每次 GC；降频到每 100 次一次。
                DatabaseUtils._close_gc_counter += 1
                if DatabaseUtils._close_gc_counter >= 100:
                    DatabaseUtils._close_gc_counter = 0
                    try:
                        gc.collect()
                    except Exception as gc_err:
                        log_debug(f"垃圾回收时出错: {gc_err}")
                    
        return False
        
    @staticmethod
    @contextmanager
    def connection(connection_params=None):
        """上下文管理器：自动获取并归还数据库连接

        用法::

            with DatabaseUtils.connection() as conn:
                cursor = conn.cursor()
                cursor.execute(...)

        无论正常结束还是抛出异常，连接都会归还到连接池，
        避免手动 close_connection 遗漏导致的连接泄漏。

        Args:
            connection_params (dict, optional): 连接参数，透传给 get_connection

        Yields:
            sqlite3.Connection: 可用的数据库连接

        Raises:
            RuntimeError: 无法获取数据库连接时
        """
        conn = DatabaseUtils.get_connection(connection_params)
        if conn is None:
            raise RuntimeError("无法获取数据库连接")
        try:
            yield conn
        finally:
            DatabaseUtils.close_connection(conn)

    @staticmethod
    def set_pool_size(size):
        """
        动态设置连接池大小
        
        Args:
            size (int): 连接池大小，必须大于0
        
        Returns:
            bool: 是否设置成功
        """
        try:
            size = int(size)
            if size > 0:
                with DatabaseUtils._pool_lock:
                    old_size = DatabaseUtils._pool_size
                    DatabaseUtils._pool_size = size
                    DatabaseUtils._pool_warned = False  # 池上限变化后重新判断警戒线
                    log_info(f"连接池大小已从 {old_size} 调整为 {size}")
                    
                    # 如果新大小小于当前池大小，移除多余连接
                    if size < len(DatabaseUtils._connection_pool):
                        excess = len(DatabaseUtils._connection_pool) - size
                        excess_connections = DatabaseUtils._connection_pool[:excess]
                        DatabaseUtils._connection_pool = DatabaseUtils._connection_pool[excess:]
                        
                        # 关闭多余连接
                        for conn in excess_connections:
                            try:
                                conn.close()
                            except Exception as e:
                                log_error(f"关闭多余连接时出错: {str(e)}")
                return True
            else:
                log_error(f"无效的连接池大小: {size}，必须大于0")
                return False
        except (ValueError, TypeError):
            log_error(f"无效的连接池大小参数: {size}")
            return False
            
    @staticmethod
    def get_pool_stats():
        """
        获取连接池统计信息
        
        Returns:
            dict: 包含连接池状态的字典
        """
        with DatabaseUtils._pool_lock:
            return {
                'pool_size': len(DatabaseUtils._connection_pool),
                'max_pool_size': DatabaseUtils._pool_size,
                'active_connections': len(DatabaseUtils._active_connections),
                'initialized': DatabaseUtils._pool_initialized
            }
    
    @staticmethod
    def execute_query(conn, query, params=None, timeout=None, max_retries=3):
        """
        执行SQL查询，提供完善的异常处理、参数验证、超时支持、智能重试和性能监控
        
        增强功能：
        - 全面的参数验证和连接状态检查
        - 针对临时性错误的智能重试机制
        - 详细的执行状态和性能监控
        - 完善的资源管理和清理
        - 支持命名参数和位置参数
        - 灵活的超时设置和恢复
        
        Args:
            conn: 数据库连接对象
            query (str): SQL查询语句
            params (tuple/list/dict, optional): 查询参数，默认为None
            timeout (float, optional): 查询超时时间（秒），默认为None（无超时）
            max_retries (int, optional): 最大重试次数，默认为3
            
        Returns:
            cursor: 查询游标对象，如果发生错误则返回None
        """
        # 记录执行开始时间
        start_time = time.time()
        
        # 参数验证
        if not conn:
            log_error("execute_query: 数据库连接为空，无法执行查询")
            return None
        
        if not query or not isinstance(query, str):
            log_error("execute_query: 查询语句无效")
            return None
        
        # 检查连接状态
        try:
            # 验证连接是否仍然有效
            test_cursor = conn.cursor()
            test_cursor.execute("SELECT 1")
            test_cursor.fetchone()  # 确保查询执行完成
            test_cursor.close()
        except sqlite3.ProgrammingError as prog_error:
            log_error(f"execute_query: 连接验证时发生编程错误: {str(prog_error)}")
            return None
        except sqlite3.OperationalError as op_error:
            if 'closed' in str(op_error).lower():
                log_error("execute_query: 连接已关闭")
            else:
                log_error(f"execute_query: 连接验证时发生操作错误: {str(op_error)}")
            return None
        except Exception as conn_error:
            log_error(f"execute_query: 连接已失效或不可用: {str(conn_error)}")
            return None
        
        # 设置查询超时（如果提供）
        old_timeout = None
        if timeout is not None:
            try:
                # 保存旧的超时设置
                old_timeout = conn.execute("PRAGMA busy_timeout").fetchone()[0]
                # 设置新的超时值（毫秒）
                conn.execute(f"PRAGMA busy_timeout = {int(timeout * 1000)}")
            except Exception as timeout_error:
                log_warning(f"execute_query: 无法设置查询超时: {str(timeout_error)}")
                # 超时设置失败不阻止查询执行
        
        retry_count = 0
        last_error = None
        query_type = "未知"
        
        # 金额写参数转换（元→分），循环外执行一次避免重试时二次转换
        # 仅当数据库已执行金额迁移（schema_meta 标记）时启用，未迁移库保持原行为
        converted_params = None
        if DatabaseUtils._check_money_migrated(conn):
            converted_params = _convert_write_params(query, params)
        # 写路径参数校验（P2：金额拒绝负数、日期校验 YYYY-MM-DD，防非法输入写入）
        _validate_write_params(query, converted_params if converted_params is not None else params)
        
        # 提取查询类型（用于日志记录）
        try:
            query_type = query.strip().upper().split()[0] if query.strip() else "未知"
        except Exception:
            query_type = "未知"
        
        while retry_count <= max_retries:
            cursor = None
            query_success = False
            try:
                # 记录查询信息（不记录敏感参数）
                log_debug(f"execute_query: 执行SQL查询: {query_type} (尝试: {retry_count+1}/{max_retries+1})")
                
                # 参数验证和预处理
                if params:
                    # 参数类型验证
                    if not isinstance(params, (tuple, list, dict)):
                        log_error("execute_query: 参数类型无效，必须是元组、列表或字典")
                        # 恢复超时设置
                        if old_timeout is not None:
                            try:
                                conn.execute(f"PRAGMA busy_timeout = {old_timeout}")
                            except Exception as restore_error:
                                log_warning(f"execute_query: 无法恢复原始超时设置: {str(restore_error)}")
                        return None
                    
                    # 对于字典类型参数，进行键名验证
                    if isinstance(params, dict):
                        for key in params.keys():
                            if not isinstance(key, str) or not key.isalnum() and ':' not in key:
                                log_error(f"execute_query: 无效的命名参数键: {key}")
                                # 恢复超时设置
                                if old_timeout is not None:
                                    try:
                                        conn.execute(f"PRAGMA busy_timeout = {old_timeout}")
                                    except Exception as restore_error:
                                        log_warning(f"execute_query: 无法恢复原始超时设置: {str(restore_error)}")
                                return None
                
                # 执行查询
                cursor = conn.cursor()
                
                if params:
                    try:
                        cursor.execute(query, converted_params if converted_params is not None else params)
                    except sqlite3.ProgrammingError as e:
                        # 参数错误，不需要重试
                        error_msg = f"SQL编程错误: {query[:100]}... {str(e)}"
                        log_error(f"execute_query: {error_msg}")
                        if cursor:
                            try:
                                cursor.close()
                            except Exception:
                                pass
                        # 恢复超时设置
                        if old_timeout is not None:
                            try:
                                conn.execute(f"PRAGMA busy_timeout = {old_timeout}")
                            except Exception as restore_error:
                                log_warning(f"execute_query: 无法恢复原始超时设置: {str(restore_error)}")
                        return None
                else:
                    cursor.execute(query)
                
                if old_timeout is not None:
                    try:
                        conn.execute(f"PRAGMA busy_timeout = {old_timeout}")
                    except Exception as restore_error:
                        log_warning(f"execute_query: 无法恢复原始超时设置: {str(restore_error)}")
                
                # 记录总执行时间
                total_time = time.time() - start_time
                log_debug(f"execute_query: 查询执行成功，总耗时: {total_time:.3f} 秒")
                query_success = True
                
                # 仅迁移库启用金额读转换（分→元）；按 (表, 列) 判定
                if DatabaseUtils._check_money_migrated(conn):
                    return MoneyCursor(cursor, conn=conn, query=query)
                return cursor
                
            except sqlite3.OperationalError as e:
                # 操作错误，可能是临时锁定等问题，尝试重试
                error_msg = str(e).lower()
                last_error = f"操作错误: {str(e)}"
                log_error(f"execute_query: {last_error}")
                
                # 检查是否是可重试的错误
                if any(keyword in error_msg for keyword in 
                       ['locked', 'busy', 'timeout', 'deadlock', 'database is locked']):
                    retry_count += 1
                    if retry_count <= max_retries:
                        wait_time = 0.5 * (1 + retry_count)  # 递增等待时间，从1秒开始
                        log_info(f"execute_query: 查询遇到临时性错误，{wait_time:.1f}秒后重试 ({retry_count}/{max_retries})")
                        # 释放资源
                        if cursor:
                            try:
                                cursor.close()
                            except Exception:
                                pass
                        time.sleep(wait_time)
                        continue
                    else:
                        last_error += " (已达到最大重试次数)"
                break
                
            except sqlite3.IntegrityError as e:
                # 完整性错误，通常不可重试
                last_error = f"数据完整性错误: {str(e)}"
                log_error(f"execute_query: {last_error}")
                break
                
            except sqlite3.ProgrammingError as e:
                # 编程错误，如SQL语法错误
                last_error = f"SQL错误: {str(e)}"
                log_error(f"execute_query: {last_error}")
                break
                
            except sqlite3.DatabaseError as e:
                # 数据库错误，可能是连接问题
                last_error = f"数据库错误: {str(e)}"
                log_error(f"execute_query: {last_error}")
                # 检查是否可以重试
                error_msg = str(e).lower()
                if any(keyword in error_msg for keyword in 
                       ['connection', 'timeout', 'locked']):
                    retry_count += 1
                    if retry_count <= max_retries:
                        wait_time = 0.5 * (1 + retry_count)  # 递增等待时间
                        log_info(f"execute_query: 数据库错误，可能是连接问题，{wait_time:.1f}秒后重试 ({retry_count}/{max_retries})")
                        # 释放资源
                        if cursor:
                            try:
                                cursor.close()
                            except Exception:
                                pass
                        time.sleep(wait_time)
                        continue
                    else:
                        last_error += " (已达到最大重试次数)"
                break
                
            except Exception as e:
                # 其他未知错误
                last_error = f"未知错误: {str(e)}"
                log_error(f"execute_query: {last_error}")
                break
            finally:
                # 仅在执行失败时关闭游标；成功时游标由调用方负责关闭与消费
                if cursor is not None and not query_success:
                    try:
                        cursor.close()
                    except Exception:
                        pass
        
        # 发生错误时尝试回滚
        try:
            conn.rollback()
            log_info("execute_query: 查询失败后执行回滚")
        except sqlite3.ProgrammingError:
            pass
        except sqlite3.OperationalError as op_error:
            if 'closed' in str(op_error).lower():
                pass
            else:
                  log_error(f"回滚事务时发生操作错误: {str(op_error)}")
        except Exception as rollback_error:
            log_error(f"execute_query: 回滚事务失败: {str(rollback_error)}")
        
        # 恢复超时设置（如果有错误发生）
        if old_timeout is not None:
            try:
                conn.execute(f"PRAGMA busy_timeout = {old_timeout}")
            except Exception:
                pass
        
        # 记录总执行时间和失败信息
        total_time = time.time() - start_time
        log_error(f"execute_query: 查询执行失败，所有重试均失败: {last_error}，总耗时: {total_time:.3f} 秒")
        return None
    
    @staticmethod
    def execute_batch(conn, query, params_list, batch_size=None, timeout=None, max_retries=3):
        """
        批量执行SQL语句，支持分批处理、事务管理、重试机制和错误处理
        
        增强功能：
        - 分批处理大数据量，防止内存溢出
        - 智能重试机制，针对临时性错误进行重试
        - 详细的执行状态日志和性能监控
        - 完善的事务管理和资源释放
        - 支持命名参数和位置参数
        - 灵活的超时设置和恢复
        
        Args:
            conn: 数据库连接对象
            query (str): SQL查询语句
            params_list (list): 参数列表，每个元素是一个元组/列表/字典
            batch_size (int, optional): 每批处理的记录数，默认None（自动调整）
            timeout (float, optional): 查询超时时间（秒），默认为None（无超时）
            max_retries (int, optional): 最大重试次数，默认为3
            
        Returns:
            tuple: (是否成功, 处理记录数)
        """
        # 参数验证
        if not conn:
            log_error("execute_batch: 数据库连接为空，无法执行批量查询")
            return False, 0
        
        if not query or not isinstance(query, str):
            log_error("execute_batch: 查询语句无效")
            return False, 0
        
        if params_list is None:
            log_error("execute_batch: 参数列表不能为空")
            return False, 0
        
        if not isinstance(params_list, list):
            log_error("execute_batch: 参数列表必须是列表类型")
            return False, 0
        
        # 空列表的快速处理
        if not params_list:
            log_info("execute_batch: 参数列表为空，无需执行操作")
            return True, 0
        
        # 检查连接状态
        try:
            # 验证连接是否仍然有效
            test_cursor = conn.cursor()
            test_cursor.execute("SELECT 1")
            test_cursor.fetchone()  # 确保查询执行完成
            test_cursor.close()
        except sqlite3.ProgrammingError as prog_error:
            log_error(f"execute_batch: 连接验证时发生编程错误: {str(prog_error)}")
            return False, 0
        except sqlite3.OperationalError as op_error:
            if 'closed' in str(op_error).lower():
                log_error("execute_batch: 连接已关闭")
                return False, 0
            else:
                log_error(f"execute_batch: 连接验证时发生操作错误: {str(op_error)}")
                return False, 0
        except sqlite3.DatabaseError as db_error:
            log_error(f"execute_batch: 连接验证时发生数据库错误: {str(db_error)}")
            return False, 0
        except Exception as conn_error:
            log_error(f"execute_batch: 连接已失效或不可用: {str(conn_error)}")
            return False, 0
        
        # 数据验证与预处理
        validated_params = []
        invalid_count = 0
        
        for i, params in enumerate(params_list):
            if params is None:
                invalid_count += 1
                continue  # 跳过None参数
            
            # 验证和转换参数格式
            try:
                if isinstance(params, (list, tuple)):
                    # 检查是否包含None值（根据SQLite规则处理）
                    if any(item is None for item in params):
                        # 允许None值，会自动转换为NULL
                        pass
                    validated_params.append(params)
                elif isinstance(params, dict):
                    # 支持命名参数，验证键名格式
                    for key in params.keys():
                        if not isinstance(key, str) or not key.isalnum() and ':' not in key:
                            raise ValueError(f"无效的命名参数键: {key}")
                    validated_params.append(params)
                else:validated_params.append((params,))
            except Exception as val_error:
                log_warning(f"execute_batch: 参数{i+1}验证失败，跳过: {str(val_error)}")
                invalid_count += 1
        
        # 金额写参数转换（元→分），仅对金额表 INSERT/UPDATE 生效且数据库已迁移
        money_indices = None
        if DatabaseUtils._check_money_migrated(conn):
            money_indices = _money_param_indices(query)
        if money_indices:
            converted = []
            for p in validated_params:
                if isinstance(p, (tuple, list)):
                    lst = list(p)
                    for i in money_indices:
                        if i < len(lst) and lst[i] is not None and isinstance(lst[i], (int, float)):
                            try:
                                lst[i] = int(round(float(lst[i]) * 100))
                            except (ValueError, TypeError):
                                pass
                    converted.append(tuple(lst) if isinstance(p, tuple) else lst)
                else:
                    converted.append(p)
            validated_params = converted
        
        # 写路径参数校验（P2：金额拒绝负数、日期校验 YYYY-MM-DD）
        # 非法参数整条跳过并计数，避免坏数据入库
        batch_invalid = 0
        final_params = []
        for p in validated_params:
            try:
                _validate_write_params(query, p)
                final_params.append(p)
            except ValueError as ve:
                batch_invalid += 1
                log_warning(f"execute_batch: 跳过非法参数: {ve}")
        validated_params = final_params
        invalid_count += batch_invalid
        
        # 记录验证结果
        total_records = len(validated_params)
        log_info(f"execute_batch: 参数验证完成 - 有效: {total_records}, 无效: {invalid_count}, 原始总数: {len(params_list)}")
        
        # 如果所有参数都被跳过，直接返回成功
        if not validated_params:
            log_info("execute_batch: 所有参数均为无效，无需执行操作")
            return True, 0
        
        # 自动确定批处理大小（如果未指定）
        if batch_size is None:
            # 根据记录总数自动调整批处理大小
            if total_records < 100:
                batch_size = total_records  # 小批量一次性处理
            elif total_records < 1000:
                batch_size = 100  # 中批量
            else:
                batch_size = 500  # 大批量
            
            log_info(f"execute_batch: 自动设置批处理大小为 {batch_size}")
        elif not isinstance(batch_size, int) or batch_size <= 0:
            log_warning(f"execute_batch: 无效的批处理大小 {batch_size}，使用默认值 100")
            batch_size = 100
        
        # 设置查询超时（如果提供）
        old_timeout = None
        if timeout is not None:
            try:
                # 保存旧的超时设置
                old_timeout = conn.execute("PRAGMA busy_timeout").fetchone()[0]
                # 设置新的超时值（毫秒）
                conn.execute(f"PRAGMA busy_timeout = {int(timeout * 1000)}")
            except Exception as timeout_error:
                log_warning(f"execute_batch: 无法设置查询超时: {str(timeout_error)}")
                # 超时设置失败不阻止查询执行
        
        cursor = None
        processed_count = 0
        start_time = time.time()
        
        try:
            # 如果记录数小于批处理大小，一次性处理
            if total_records <= batch_size:
                log_info(f"execute_batch: 记录数 {total_records} 小于等于批处理大小 {batch_size}，采用一次性处理模式")
                
                # 开始事务
                conn.execute("BEGIN TRANSACTION")
                
                # 重试机制
                retry_count = 0
                while retry_count <= max_retries:
                    try:
                        cursor = conn.cursor()
                        cursor.executemany(query, validated_params)
                        conn.commit()
                        processed_count = total_records
                        log_info(f"execute_batch: 批量操作成功执行，处理 {processed_count} 条记录")
                        return True, processed_count
                    except sqlite3.OperationalError as op_error:
                        # 操作错误，可能是临时锁定等问题
                        error_msg = str(op_error).lower()
                        if any(keyword in error_msg for keyword in 
                              ['locked', 'busy', 'timeout', 'deadlock']):
                            # 可重试的错误
                            retry_count += 1
                            if retry_count <= max_retries:
                                wait_time = 0.5 * retry_count  # 递增等待时间
                                log_info(f"execute_batch: 查询遇到临时性错误，{wait_time}秒后重试 ({retry_count}/{max_retries})")
                                time.sleep(wait_time)
                                continue
                            else:
                                log_error(f"execute_batch: 达到最大重试次数，操作失败: {str(op_error)}")
                        else:
                            # 不可重试的操作错误
                            log_error(f"execute_batch: 操作错误（不可重试）: {str(op_error)}")
                        raise
                    except Exception:
                        # 其他错误，回滚并重新抛出
                        try:
                            conn.rollback()
                        except Exception as rollback_error:
                            log_error(f"execute_batch: 一次性处理模式下回滚失败: {str(rollback_error)}")
                        raise
            else:
                # 分批处理模式
                log_info(f"execute_batch: 使用分批处理模式，每批 {batch_size} 条记录，共 {total_records} 条记录")
                
                # 开始事务
                conn.execute("BEGIN TRANSACTION")
                
                # 分批处理循环
                for i in range(0, total_records, batch_size):
                    batch_params = validated_params[i:i+batch_size]
                    batch_num = i // batch_size + 1
                    batch_count = len(batch_params)
                    log_info(f"execute_batch: 执行批处理 {batch_num}/{(total_records + batch_size - 1) // batch_size}，{batch_count} 条记录")
                    
                    # 批处理重试机制
                    batch_retry_count = 0
                    while batch_retry_count <= max_retries:
                        try:
                            cursor = conn.cursor()
                            cursor.executemany(query, batch_params)
                            cursor.close()
                            cursor = None
                            processed_count += batch_count
                            
                            # 日志记录详细执行信息
                            elapsed = time.time() - start_time
                            rate = processed_count / elapsed if elapsed > 0 else 0
                            log_info(f"execute_batch: 批处理 {batch_num} 完成，累计成功 {processed_count}/{total_records} 条记录，处理速率: {rate:.1f} 条/秒")
                            
                            break  # 批处理成功，继续下一批
                        except sqlite3.OperationalError as op_error:
                            # 操作错误，可能是临时锁定等问题
                            error_msg = str(op_error).lower()
                            if any(keyword in error_msg for keyword in 
                                  ['locked', 'busy', 'timeout', 'deadlock']):
                                # 可重试的错误
                                batch_retry_count += 1
                                if batch_retry_count <= max_retries:
                                    wait_time = 0.5 * batch_retry_count  # 递增等待时间
                                    log_info(f"execute_batch: 批处理 {batch_num} 遇到临时性错误，{wait_time}秒后重试 ({batch_retry_count}/{max_retries})")
                                    time.sleep(wait_time)
                                    continue
                                else:
                                    log_error(f"execute_batch: 批处理 {batch_num} 达到最大重试次数，操作失败: {str(op_error)}")
                            else:
                                # 不可重试的操作错误
                                log_error(f"execute_batch: 批处理 {batch_num} 操作错误（不可重试）: {str(op_error)}")
                            conn.rollback()
                            raise
                        except Exception:
                            # 其他错误，回滚并重新抛出
                            try:
                                conn.rollback()
                            except Exception as rollback_error:
                                log_error(f"execute_batch: 批处理 {batch_num} 回滚失败: {str(rollback_error)}")
                            raise
                
                # 提交事务
                conn.commit()
                log_info(f"execute_batch: 所有批处理成功完成，共处理 {total_records} 条记录，耗时: {time.time() - start_time:.2f} 秒")
                return True, processed_count
                
        except sqlite3.ProgrammingError as e:
            # SQL语法或参数错误
            error_msg = f"SQL编程错误: {query[:100]}... {str(e)}"
            log_error(f"execute_batch: {error_msg}")
            try:
                conn.rollback()
                log_info("execute_batch: 编程错误后成功回滚事务")
            except sqlite3.ProgrammingError:
                pass
            except sqlite3.OperationalError as rollback_op_error:
                if 'closed' in str(rollback_op_error).lower():
                    pass
                else:
                    log_error(f"execute_batch: 回滚事务时发生操作错误: {str(rollback_op_error)}")
            except Exception as rollback_error:
                log_error(f"execute_batch: 回滚事务失败: {str(rollback_error)}")
            return False, processed_count
            
        except sqlite3.IntegrityError as e:
            # 数据完整性错误
            error_msg = f"数据完整性错误: {query[:100]}... {str(e)}"
            log_error(f"execute_batch: {error_msg}")
            try:
                conn.rollback()
                log_info("execute_batch: 完整性错误后成功回滚事务")
            except sqlite3.ProgrammingError:
                pass
            except sqlite3.OperationalError as rollback_op_error:
                if 'closed' in str(rollback_op_error).lower():
                    pass
                else:
                    log_error(f"execute_batch: 回滚事务时发生操作错误: {str(rollback_op_error)}")
            except Exception as rollback_error:
                log_error(f"execute_batch: 回滚事务失败: {str(rollback_error)}")
            return False, processed_count
            
        except sqlite3.OperationalError as e:
            # 操作错误
            error_msg = f"数据库操作错误: {query[:100]}... {str(e)}"
            log_error(f"execute_batch: {error_msg}")
            try:
                conn.rollback()
                log_info("execute_batch: 操作错误后成功回滚事务")
            except sqlite3.ProgrammingError:
                pass
            except sqlite3.OperationalError as rollback_op_error:
                if 'closed' in str(rollback_op_error).lower():
                    pass
                else:
                    log_error(f"execute_batch: 回滚事务时发生操作错误: {str(rollback_op_error)}")
            except Exception as rollback_error:
                log_error(f"execute_batch: 回滚事务失败: {str(rollback_error)}")
            return False, processed_count
            
        except sqlite3.DatabaseError as e:
            # 数据库错误
            error_msg = f"数据库错误: {query[:100]}... {str(e)}"
            log_error(f"execute_batch: {error_msg}")
            try:
                conn.rollback()
                log_info("execute_batch: 数据库错误后成功回滚事务")
            except sqlite3.ProgrammingError:
                pass
            except sqlite3.OperationalError as rollback_op_error:
                if 'closed' in str(rollback_op_error).lower():
                    pass
                else:
                    log_error(f"execute_batch: 回滚事务时发生操作错误: {str(rollback_op_error)}")
            except Exception as rollback_error:
                log_error(f"execute_batch: 回滚事务失败: {str(rollback_error)}")
            return False, processed_count
            
        except Exception as e:
            # 其他未知错误
            error_msg = f"批量查询执行失败: {query[:100]}... {str(e)}"
            log_error(f"execute_batch: {error_msg}")
            try:
                conn.rollback()
                log_info("execute_batch: 未知错误后成功回滚事务")
            except sqlite3.ProgrammingError:
                pass
            except sqlite3.OperationalError as rollback_op_error:
                if 'closed' in str(rollback_op_error).lower():
                    pass
                else:
                    log_error(f"execute_batch: 回滚事务时发生操作错误: {str(rollback_op_error)}")
            except Exception as rollback_error:
                log_error(f"execute_batch: 回滚事务失败: {str(rollback_error)}")
            return False, processed_count
            
        finally:
            # 关闭游标
            if cursor is not None:
                try:
                    cursor.close()
                except Exception as close_error:
                    log_warning(f"execute_batch: 关闭游标失败: {str(close_error)}")
            
            # 恢复超时设置（如果之前有设置）
            if old_timeout is not None:
                try:
                    conn.execute(f"PRAGMA busy_timeout = {old_timeout}")
                except Exception as restore_error:
                    log_warning(f"execute_batch: 无法恢复原始超时设置: {str(restore_error)}")
        
    @staticmethod
    def create_empty_database(db_path=None, allow_existing=False):
        """创建一个空的数据库文件，包含所有必要的表，添加完善的异常处理和健壮性保障

        增强功能：
        - 高级数据库性能优化配置
        - 完善的文件系统安全检查
        - 智能的表结构验证和优化
        - 增强的事务管理和并发控制
        - 详细的性能监控和资源管理

        ⚠️ 销毁性语义（2026-09-18 加固）：
            本函数对已存在的数据库是**破坏性**的 —— 它会 DROP 并重建 contracts /
            rent_records / tenants 等关键表，原有业务数据会被清空；随后因默认数据
            「已存在」被跳过，还会误报初始化失败。历史上「系统设置 → 创建数据库」
            对已有库误调用本函数，导致用户数据被静默清空。

            因此新增 allow_existing 开关：**默认 False**，发现目标库已存在即直接
            返回失败（带清晰中文提示），不做任何破坏。只有「数据初始化」这类用户
            已明确确认要重建库的场景才传 allow_existing=True。

        Args:
            db_path: 数据库文件路径，如不提供则使用默认路径
            allow_existing: 是否允许对「已存在的数据库」执行销毁性重建，默认 False

        Returns:
            tuple: (是否成功, 操作结果列表)
        """
        results = []
        conn = None
        transaction_started = False
        start_time = time.time()
        
        # 输入参数验证
        if db_path is None:
            try:
                db_path = DatabaseUtils.get_db_path()
                if not db_path:
                    results.append("❌ 无法获取默认数据库路径")
                    log_error("create_empty_database: 无法获取默认数据库路径")
                    return False, results
            except Exception as e:
                results.append(f"❌ 获取默认数据库路径失败: {str(e)}")
                log_error(f"create_empty_database: 获取默认数据库路径失败: {str(e)}")
                return False, results
        
        # 路径安全检查和规范化
        try:
            # 确保路径是绝对路径并规范化
            db_path = os.path.abspath(db_path)
            # 检查路径是否包含非法字符
            if any(char in db_path for char in '<>"|?*'):
                results.append(f"❌ 数据库路径包含非法字符: {db_path}")
                log_error(f"create_empty_database: 数据库路径包含非法字符: {db_path}")
                return False, results
        except Exception as path_error:
            results.append(f"❌ 数据库路径处理失败: {str(path_error)}")
            log_error(f"create_empty_database: 数据库路径处理失败: {str(path_error)}")
            return False, results
        
        # 确保目录存在，添加重试机制
        dir_path = os.path.dirname(db_path)
        if dir_path and not os.path.exists(dir_path):
            retry_count = 0
            max_retries = 3
            while retry_count < max_retries:
                try:
                    # 使用exist_ok=True避免竞态条件
                    os.makedirs(dir_path, exist_ok=True)
                    # 验证目录是否真的创建成功
                    if os.path.exists(dir_path):
                        # 验证目录是否可写
                        if not os.access(dir_path, os.W_OK):
                            results.append(f"❌ 目录创建成功但无写入权限: {dir_path}")
                            log_error(f"create_empty_database: 目录创建成功但无写入权限: {dir_path}")
                            return False, results
                        results.append(f"✓ 创建数据库目录: {dir_path}")
                        log_info(f"create_empty_database: 创建数据库目录成功: {dir_path}")
                        break
                    else:
                        results.append("⚠️ 目录创建报告成功，但验证失败")
                        log_warning("create_empty_database: 目录创建报告成功，但验证失败")
                except PermissionError as e:
                    results.append(f"❌ 权限错误 - 创建目录失败: {str(e)}")
                    log_error(f"create_empty_database: 权限错误 - 创建目录失败: {str(e)}")
                    return False, results  # 权限错误无需重试
                except Exception as e:
                    results.append(f"⚠️ 创建目录尝试{retry_count+1}失败: {str(e)}")
                    log_warning(f"create_empty_database: 创建目录尝试{retry_count+1}失败: {str(e)}")
                retry_count += 1
                time.sleep(1)
            
            if retry_count >= max_retries:
                results.append("❌ 目录创建失败，重试次数用尽")
                log_error("create_empty_database: 目录创建失败，重试次数用尽")
                return False, results
        
        try:
            # 已存在库的守卫（2026-09-18 加固）：默认拒绝覆盖任何已存在的数据库文件，
            # 除非调用方显式传入 allow_existing=True（仅「数据初始化」全量重建走这条路）。
            # 此判断必须放在「损坏文件删除重建」之前，否则损坏库会被静默删除。
            file_existed = os.path.isfile(db_path)
            if file_existed and not allow_existing:
                results.append(f"❌ 数据库文件已存在: {db_path}")
                results.append("已存在的数据库不会被覆盖，本次操作没有修改任何数据。")
                results.append("如要使用该库，请点「选择数据库」；如要新建，请换一个未被占用的文件名。")
                log_warning(f"create_empty_database: 目标库已存在，拒绝覆盖（未做任何修改）: {db_path}")
                return False, results

            # 检查数据库文件是否已存在且损坏
            if file_existed:
                try:
                    # 尝试只读模式连接验证数据库是否有效
                    test_conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
                    test_conn.close()
                except sqlite3.OperationalError as op_error:
                    if 'damaged' in str(op_error).lower() or 'corrupt' in str(op_error).lower() or 'unable to open database file' in str(op_error):
                        results.append(f"⚠️ 检测到损坏的数据库文件，将重新创建: {str(op_error)}")
                        log_warning(f"create_empty_database: 检测到损坏的数据库文件: {str(op_error)}")
                        try:
                            os.remove(db_path)
                            results.append("✓ 已删除损坏的数据库文件")
                            log_info("create_empty_database: 已删除损坏的数据库文件")
                        except PermissionError as perm_error:
                            results.append(f"❌ 权限错误 - 删除损坏的数据库文件失败: {str(perm_error)}")
                            log_error(f"create_empty_database: 权限错误 - 删除损坏的数据库文件失败: {str(perm_error)}")
                            # 尝试获取文件锁定信息
                            if hasattr(DatabaseUtils, 'is_file_locked') and DatabaseUtils.is_file_locked(db_path):
                                results.append("⚠️ 数据库文件可能被其他进程锁定")
                        except OSError as os_error:
                            results.append(f"❌ 系统错误 - 删除损坏的数据库文件失败: {str(os_error)}")
                            log_error(f"create_empty_database: 系统错误 - 删除损坏的数据库文件失败: {str(os_error)}")
                        except Exception as remove_error:
                            results.append(f"❌ 删除损坏的数据库文件失败: {str(remove_error)}")
                            log_error(f"create_empty_database: 删除损坏的数据库文件失败: {str(remove_error)}")
                    else:
                        # 其他操作错误，记录但继续
                        results.append(f"⚠️ 数据库文件验证失败，但非损坏错误: {str(op_error)}")
                        log_warning(f"create_empty_database: 数据库文件验证失败: {str(op_error)}")
                except sqlite3.DatabaseError as db_error:
                    results.append(f"⚠️ 数据库错误 - 验证数据库文件失败: {str(db_error)}")
                    log_warning(f"create_empty_database: 数据库错误 - 验证数据库文件失败: {str(db_error)}")
                except Exception as verify_error:
                    results.append(f"⚠️ 验证数据库文件失败: {str(verify_error)}")
                    log_warning(f"create_empty_database: 验证数据库文件失败: {str(verify_error)}")
            
            # 创建或连接到数据库
            log_info(f"正在初始化数据库: {db_path}")
            results.append(f"初始化数据库: {db_path}")
            
            # 尝试打开数据库连接，增加超时设置
            try:
                conn = sqlite3.connect(db_path, timeout=30)
            except sqlite3.OperationalError as op_error:
                results.append(f"❌ 操作错误 - 无法创建数据库连接: {str(op_error)}")
                log_error(f"create_empty_database: 操作错误 - 无法创建数据库连接: {str(op_error)}")
                # 检查是否是权限错误
                if 'access' in str(op_error).lower() or 'permission' in str(op_error).lower():
                    results.append("⚠️ 请检查文件系统权限")
                elif 'locked' in str(op_error).lower() or 'busy' in str(op_error).lower():
                    results.append("⚠️ 数据库文件可能被锁定，请关闭其他可能正在使用该文件的程序")
                return False, results
            except sqlite3.DatabaseError as db_error:
                results.append(f"❌ 数据库错误 - 无法创建数据库连接: {str(db_error)}")
                log_error(f"create_empty_database: 数据库错误 - 无法创建数据库连接: {str(db_error)}")
                return False, results
            except Exception as conn_error:
                results.append(f"❌ 创建数据库连接失败: {str(conn_error)}")
                log_error(f"create_empty_database: 创建数据库连接失败: {str(conn_error)}")
                return False, results
            
            # 高级性能优化配置
            try:
                # 分别配置每个优化参数，确保每个参数都能单独处理失败
                pragma_configs = [
                    ('journal_mode=WAL', '启用WAL模式'),
                    ('synchronous=NORMAL', '优化同步级别'),
                    ('cache_size = -8192', '设置8MB缓存'),
                    ('foreign_keys = ON', '启用外键约束'),
                    ('temp_store = MEMORY', '临时表使用内存'),
                    ('mmap_size = 30000000000', '启用内存映射'),
                    ('busy_timeout = 30000', '设置30秒忙等待超时')
                ]
                
                pragma_success_count = 0
                for pragma_stmt, desc in pragma_configs:
                    try:
                        conn.execute(f'PRAGMA {pragma_stmt}')
                        pragma_success_count += 1
                    except Exception as pragma_error:
                        log_warning(f"create_empty_database: {desc} 失败: {str(pragma_error)}")
                        # 继续尝试其他优化参数
                
                if pragma_success_count > 0:
                    log_info(f"create_empty_database: 成功应用{pragma_success_count}/{len(pragma_configs)}个性能优化配置")
            except Exception as config_error:
                log_error(f"create_empty_database: 数据库配置失败: {str(config_error)}")
                # 继续执行，因为配置失败不应阻止数据库创建
            
            cursor = conn.cursor()# 开启事务
            try:
                conn.execute('BEGIN TRANSACTION')
                transaction_started = True
                results.append("✓ 事务已开始")
            except Exception as e:
                results.append(f"❌ 开始事务失败: {str(e)}")
                raise  # 重新抛出异常，进入外层异常处理
            
            # 创建所有必要的表，增加验证逻辑
            results.append("开始创建数据库表结构...")
            
            # 表创建语句列表，减少重复代码
            tables = [
                (
                    "reminder_settings",
                    '''CREATE TABLE IF NOT EXISTS reminder_settings (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        contract_reminder_days INTEGER DEFAULT 30,
                        rent_reminder_days INTEGER DEFAULT 7,
                        reminder_frequency INTEGER DEFAULT 60,
                        enabled_reminder_types TEXT DEFAULT '合同到期,租金到期,合同逾期',
                        email_notification INTEGER DEFAULT 0,
                        sms_notification INTEGER DEFAULT 0,
                        screen_timeout_minutes INTEGER DEFAULT 30
                    )'''
                ),
                ("houses",
                    '''CREATE TABLE IF NOT EXISTS houses (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        house_no TEXT NOT NULL UNIQUE,
                        house_location TEXT NOT NULL,
                        house_area REAL NOT NULL,
                        house_type TEXT,
                        usage TEXT NOT NULL,
                        status TEXT NOT NULL DEFAULT '空闲'
                    )'''
                ),
                ("tenants",
                    '''CREATE TABLE IF NOT EXISTS tenants (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        tenant_name TEXT NOT NULL,
                        contact_person TEXT NOT NULL,
                        contact_id TEXT NOT NULL,
                        contact_phone TEXT NOT NULL
                    )'''
                ),
                (
                    "users",
                    '''CREATE TABLE IF NOT EXISTS users (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        username TEXT NOT NULL UNIQUE,
                        password TEXT NOT NULL,
                        role TEXT NOT NULL
                    )'''
                ),
                (
                    "landlords",
                    '''CREATE TABLE IF NOT EXISTS landlords (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        landlord_name TEXT NOT NULL,
                        legal_representative TEXT,
                        person_in_charge TEXT,
                        contact_phone TEXT,
                        address TEXT,
                        is_default INTEGER DEFAULT 0
                    )'''
                ),
                (
                    "contracts",
                    '''CREATE TABLE IF NOT EXISTS contracts (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        contract_no TEXT NOT NULL UNIQUE,
                        sign_date TEXT NOT NULL,
                        sign_year_month TEXT NOT NULL,
                        house_no TEXT NOT NULL,
                        house_location TEXT NOT NULL,
                        house_area REAL NOT NULL,
                        lessor TEXT NOT NULL,
                        legal_representative TEXT,
                        person_in_charge TEXT,
                        contact_phone TEXT,
                        lessee TEXT NOT NULL,
                        tenant TEXT NOT NULL,
                        tenant_id TEXT NOT NULL,
                        tenant_phone TEXT NOT NULL,
                        start_date TEXT NOT NULL,
                        end_date TEXT NOT NULL,
                        status TEXT NOT NULL,
                        payment_method TEXT NOT NULL,
                        monthly_rent REAL NOT NULL,
                        quarterly_rent REAL,
                        total_rent REAL NOT NULL,
                        annual_rent REAL NOT NULL,
                        deposit REAL NOT NULL,
                        usage TEXT NOT NULL,
                        utility_method TEXT NOT NULL,
                        water_fee REAL,
                        electricity_fee REAL,
                        remarks TEXT,
                        house_type TEXT,
                        attachment_path TEXT,
                        payment_status TEXT DEFAULT '未结清',
                        is_renewed TEXT DEFAULT '未续签',
                        renewed_from TEXT
                    )'''
                ),
                (
                    "rent_records",
                    '''CREATE TABLE IF NOT EXISTS rent_records (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        contract_no TEXT NOT NULL,
                        lessee TEXT NOT NULL,
                        tenant TEXT NOT NULL,
                        receipt_date TEXT NOT NULL,
                        amount REAL NOT NULL,
                        period_start TEXT NOT NULL,
                        period_end TEXT NOT NULL,
                        account TEXT,
                        invoice_date TEXT,
                        description TEXT,
                        house_no TEXT,
                        payment_method TEXT,
                        monthly_rent TEXT,
                        payment_status TEXT DEFAULT '未结清'
                    )'''
                ),
                (
                    "notes",
                    '''CREATE TABLE IF NOT EXISTS notes (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        note_name TEXT NOT NULL UNIQUE,
                        content TEXT,
                        created_at TEXT NOT NULL,
                        updated_at TEXT NOT NULL
                    )'''
                ),
                (
                    "system_params",
                    '''CREATE TABLE IF NOT EXISTS system_params (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        key TEXT NOT NULL UNIQUE,
                        value TEXT
                    )'''
                ),
                (
                    "operation_logs",
                    '''CREATE TABLE IF NOT EXISTS operation_logs (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        log_time TEXT NOT NULL,
                        user_id INTEGER,
                        username TEXT,
                        operation_module TEXT,
                        operation_content TEXT,
                        operation_result TEXT,
                        ip_address TEXT,
                        detail TEXT
                    )'''
                ),
                (
                    "utility_fee",
                    '''CREATE TABLE IF NOT EXISTS utility_fee (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        house_type TEXT NOT NULL UNIQUE,
                        water_fee REAL NOT NULL,
                        electricity_fee REAL NOT NULL
                    )'''
                ),
                (
                    "auto_backup_settings",
                    '''CREATE TABLE IF NOT EXISTS auto_backup_settings (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        enabled INTEGER DEFAULT 0,
                        frequency TEXT DEFAULT '每天',
                        backup_time TEXT DEFAULT '00:00',
                        backup_path TEXT DEFAULT ''
                    )'''
                ),
                (
                    "rent_adjustments",
                    '''CREATE TABLE IF NOT EXISTS rent_adjustments (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        adjust_no TEXT NOT NULL UNIQUE,
                        contract_no TEXT NOT NULL,
                        adjust_type TEXT NOT NULL,
                        old_monthly_rent REAL,
                        new_monthly_rent REAL,
                        adjust_ratio REAL,
                        effective_date TEXT NOT NULL,
                        reason TEXT,
                        clause_basis TEXT,
                        attachment_path TEXT,
                        status TEXT NOT NULL DEFAULT '待审批',
                        applicant TEXT,
                        approver TEXT,
                        reject_reason TEXT,
                        apply_time TEXT,
                        approve_time TEXT,
                        created_at TEXT
                    )'''
                ),
                (
                    "rent_schedule",
                    '''CREATE TABLE IF NOT EXISTS rent_schedule (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        contract_no TEXT NOT NULL,
                        segment_no INTEGER NOT NULL,
                        start_date TEXT NOT NULL,
                        end_date TEXT NOT NULL,
                        monthly_rent REAL NOT NULL,
                        source TEXT NOT NULL DEFAULT 'initial',
                        adjust_id INTEGER,
                        created_at TEXT
                    )'''
                )
            ]
            
            # 批量创建表并验证，添加重试机制
            created_tables = []
            critical_tables = ['contracts', 'rent_records', 'tenants']
            retry_count = 0
            max_retries = 2
            
            while retry_count <= max_retries:
                tables_to_create = tables.copy()
                current_created = []
                
                for table_name, create_sql in tables_to_create:
                    try:
                        # 先检查表是否存在
                        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table_name,))
                        exists = cursor.fetchone() is not None
                        
                        if exists:
                            # 对于关键表，如果是第一次尝试或重试时仍存在问题，则删除重建
                            if table_name in critical_tables and (retry_count == 0 or retry_count < max_retries):
                                results.append(f"⚠️ {table_name}表已存在，尝试删除重建以确保结构正确...")
                                try:
                                    cursor.execute(f"DROP TABLE IF EXISTS {table_name}")
                                    exists = False  # 标记为需要重新创建
                                    results.append(f"  - {table_name}表已删除")
                                except Exception as drop_error:
                                    results.append(f"⚠️ 删除{table_name}表失败: {str(drop_error)}")
                                    # 即使删除失败，也继续尝试创建（可能使用IF NOT EXISTS）
                        
                        if not exists:
                            # 创建表，添加详细的异常处理
                            try:
                                cursor.execute(create_sql)
                                # 验证表是否成功创建
                                cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table_name,))
                                if cursor.fetchone():
                                    current_created.append(table_name)
                                    created_tables.append(table_name)
                                    results.append(f"✓ {table_name}表已成功创建")
                                    
                                    # 特别验证关键表的结构
                                    if table_name in critical_tables:
                                        cursor.execute(f"PRAGMA table_info({table_name})")
                                        columns = [row[1] for row in cursor.fetchall()]
                                        results.append(f"  - {table_name}表结构验证: {len(columns)}个字段")
                                else:
                                    results.append(f"❌ {table_name}表创建报告成功，但验证失败")
                            except sqlite3.OperationalError as op_error:
                                # 操作错误，可能是锁定或其他临时问题
                                results.append(f"⚠️ 操作错误 - 创建{table_name}表: {str(op_error)}")
                            except sqlite3.IntegrityError as int_error:
                                # 完整性错误，可能是表结构问题
                                results.append(f"❌ 完整性错误 - 创建{table_name}表: {str(int_error)}")
                            except Exception as e:
                                results.append(f"❌ 创建{table_name}表时出错: {str(e)}")
                        else:
                            current_created.append(table_name)
                            created_tables.append(table_name)
                            results.append(f"⚠️ {table_name}表已存在且跳过重建")
                    except Exception as e:
                        results.append(f"❌ 处理{table_name}表时发生异常: {str(e)}")
                
                # 检查关键表是否都已创建
                all_critical_created = all(table in created_tables for table in critical_tables)
                # 确保utility_fee表也被创建
                utility_fee_created = 'utility_fee' in created_tables
                
                if all_critical_created and utility_fee_created:
                    break
                
                retry_count += 1
                if retry_count <= max_retries:
                    results.append(f"⚠️ 关键表创建不完整，进行第{retry_count}次重试...")
                    # 重置已创建表列表，重新尝试
                    created_tables = []
                else:
                    results.append("❌ 关键表创建失败，重试次数用尽")
            
            # 为多个表添加索引以提高查询性能
            index_operations = [
                ('rent_records', 'idx_rent_records_contract_no', 'contract_no'),
                ('rent_records', 'idx_rent_records_receipt_date', 'receipt_date'),
                ('contracts', 'idx_contracts_contract_no', 'contract_no'),
                ('contracts', 'idx_contracts_house_no', 'house_no'),
                ('contracts', 'idx_contracts_start_date', 'start_date'),
                ('contracts', 'idx_contracts_end_date', 'end_date'),
                ('houses', 'idx_houses_house_no', 'house_no'),
                ('tenants', 'idx_tenants_tenant_name', 'tenant_name')
            ]
            
            index_success_count = 0
            for table_name, index_name, column_name in index_operations:
                if table_name in created_tables:
                    try:
                        cursor.execute(f"CREATE INDEX IF NOT EXISTS {index_name} ON {table_name}({column_name})")
                        index_success_count += 1
                    except Exception as e:
                        log_warning(f"create_empty_database: 为{table_name}表添加索引{index_name}失败: {str(e)}")
                        # 索引创建失败不记录到结果中，避免干扰主流程反馈
            
            if index_success_count > 0:
                results.append(f"✓ 成功创建{index_success_count}个索引，优化查询性能")

            # 幂等补齐历史缺列（双保险：模板已补齐，此处兜底防止模板再次漂移）
            try:
                schema_added = DatabaseUtils.ensure_schema_columns(conn, db_path)
                if schema_added:
                    results.append(f"✓ 补齐 {schema_added} 个历史缺失列")
            except Exception as schema_error:
                log_warning(f"create_empty_database: 补齐历史缺列失败: {str(schema_error)}")

            # 关键：新库与正式库统一为「分」存储模式（2026-09-11 体检 P0-1 配套修复）
            # 不写迁移标记时，金额换算层会把新库判定为「未迁移」而按「元」存取；
            # 一旦之后切回/恢复「分」模式的正式库或备份，金额会整体错 100 倍。
            try:
                cursor.execute("CREATE TABLE IF NOT EXISTS schema_meta (key TEXT PRIMARY KEY, value TEXT)")
                cursor.execute("INSERT OR REPLACE INTO schema_meta (key, value) VALUES ('amount_cents_migrated', '1')")
                results.append("✓ 已写入金额迁移标记 amount_cents_migrated=1（与正式库一致的「分」模式）")
            except Exception as meta_error:
                results.append(f"⚠️ 写入金额迁移标记失败: {str(meta_error)}")
                log_warning(f"create_empty_database: 写入 schema_meta 失败: {str(meta_error)}")

            # 最终验证所有关键表和utility_fee表
            missing_critical = [table for table in critical_tables if table not in created_tables]
            utility_fee_missing = 'utility_fee' not in created_tables
            
            if missing_critical:
                results.append(f"❌ 关键表缺失: {', '.join(missing_critical)}")
            elif utility_fee_missing:
                results.append("❌ utility_fee表创建失败")
            else:
                results.append("✓ 所有关键表和utility_fee表创建成功")
            
            # 插入默认数据，添加完善的异常处理
            results.append("开始插入默认数据...")
            
            # 定义默认数据插入函数，提高代码可维护性
            # 返回值语义（2026-09-18 修正）：True = 默认数据「已就绪」（新插入 或 本就存在），
            # 只有真正的异常（完整性错误 / 插入失败）才返回 False。
            # 旧实现把「已存在，跳过插入」也返回 False，导致对已初始化过的库重建时报出
            # 「默认提醒设置插入失败；默认管理员用户插入失败」这类与事实相反的误导性错误。
            def insert_default_data_if_not_exists(table, count_query, insert_query, params, success_msg):
                try:
                    # 检查count_query是否包含参数占位符
                    if '?' in count_query and params:
                        # 如果包含参数占位符且有参数，则使用第一个参数作为查询条件
                        cursor.execute(count_query, params[:1])
                    else:
                        # 如果不包含参数占位符，则不传递参数
                        cursor.execute(count_query)
                    
                    if cursor.fetchone()[0] == 0:
                        cursor.execute(insert_query, params)
                        results.append(success_msg)
                        return True
                    else:
                        results.append(f"✓ {table}表默认数据已存在（无需插入）")
                        return True
                except sqlite3.IntegrityError as int_error:
                    results.append(f"❌ 完整性错误 - 插入{table}表默认数据: {str(int_error)}")
                    return False
                except Exception as e:
                    results.append(f"❌ 插入{table}表默认数据失败: {str(e)}")
                    return False
            
            # 插入默认提醒设置
            reminder_success = insert_default_data_if_not_exists(
                "reminder_settings",
                "SELECT COUNT(*) FROM reminder_settings",
                "INSERT INTO reminder_settings (contract_reminder_days, rent_reminder_days, screen_timeout_minutes) VALUES (?, ?, ?)",
                (30, 7, 30),
                "✓ 默认提醒设置已插入"
            )
            
            # 导入密码工具类
            from user_auth import PasswordUtils
            
            # 插入默认管理员用户，使用哈希后的密码
            hashed_password = PasswordUtils.hash_password('admin')
            admin_success = insert_default_data_if_not_exists(
                "users",
                "SELECT COUNT(*) FROM users WHERE username = ?",
                "INSERT INTO users (username, password, role) VALUES (?, ?, ?)",
                ('admin', hashed_password, '管理员'),
                "✓ 默认管理员用户已插入"
            )
            
            # 插入默认系统参数（如果表存在）
            if 'system_params' in created_tables:
                system_params = [
                    ('db_version', '1.8.1'),
                    ('last_backup', ''),
                    ('system_name', '租赁合同管理系统')
                ]
                
                for key, value in system_params:
                    insert_default_data_if_not_exists(
                        "system_params",
                        "SELECT COUNT(*) FROM system_params WHERE key = ?",
                        "INSERT INTO system_params (key, value) VALUES (?, ?)",
                        (key, value),
                        f"✓ 默认系统参数 '{key}' 已插入"
                    )
            
            # 提交事务，添加完善的异常处理
            try:
                if transaction_started:
                    # 提交前执行VACUUM优化数据库结构（在创建大量索引后特别有用）
                    try:
                        cursor.execute("VACUUM")
                        log_info("create_empty_database: 数据库VACUUM操作成功")
                    except Exception as vacuum_error:
                        log_warning(f"create_empty_database: VACUUM操作失败（不会影响核心功能）: {str(vacuum_error)}")
                    
                    conn.commit()
                    results.append("✓ 事务提交成功")
                else:
                    results.append("⚠️ 事务未开始，跳过提交")
            except sqlite3.OperationalError as op_error:
                results.append(f"❌ 操作错误 - 提交事务失败: {str(op_error)}")
                # 提交失败，尝试回滚
                if transaction_started:
                    try:
                        conn.rollback()
                        results.append("✓ 事务已回滚")
                        log_info("create_empty_database: 事务回滚成功")
                    except sqlite3.ProgrammingError:
                        # 可能事务已结束或连接已关闭}")
                        results.append("⚠️ 回滚操作可能已完成或不必要")
                    except sqlite3.OperationalError as op_error:
                        if 'closed' in str(op_error).lower():results.append("⚠️ 连接已关闭，无法回滚")
                        else:
                            log_error(f"create_empty_database: 回滚事务时发生操作错误: {str(op_error)}")
                            results.append(f"❌ 回滚事务时发生操作错误: {str(op_error)}")
                    except Exception as rollback_error:
                        log_error(f"create_empty_database: 回滚事务失败: {str(rollback_error)}")
                        results.append(f"❌ 回滚事务失败: {str(rollback_error)}")
                        raise  # 重新抛出异常，进入外层异常处理
            except Exception as e:
                results.append(f"❌ 提交事务失败: {str(e)}")
                # 提交失败，尝试回滚
                if transaction_started:
                    try:
                        conn.rollback()
                        results.append("✓ 事务已回滚")
                    except Exception as rollback_error:
                        results.append(f"❌ 回滚事务失败: {str(rollback_error)}")
                raise  # 重新抛出异常，进入外层异常处理
            
            # 最终验证所有表是否存在
            try:
                cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
                db_tables = [table[0] for table in cursor.fetchall()]
                results.append(f"\n数据库中存在的表 ({len(db_tables)}个): {', '.join(sorted(db_tables))}")
                
                # 验证表的完整性和一致性
                for table_name in critical_tables:
                    if table_name in db_tables:
                        cursor.execute(f"PRAGMA table_info({table_name})")
                        columns = cursor.fetchall()
                        results.append(f"  - {table_name}表结构验证: {len(columns)}个字段")
            except Exception as e:
                results.append(f"⚠️ 验证表存在性时出错: {str(e)}")
                log_error(f"create_empty_database: 验证表存在性时出错: {str(e)}")
                db_tables = []
            
            # 验证关键表、utility_fee表和默认数据
            critical_tables = ['contracts', 'rent_records', 'tenants']
            all_critical_created = all(table in db_tables for table in critical_tables)
            utility_fee_created = 'utility_fee' in db_tables
            
            # 综合评估数据库创建是否成功
            success = all_critical_created and utility_fee_created and reminder_success and admin_success
            
            # 记录总执行时间
            total_time = time.time() - start_time
            
            if success:
                results.append(f"\n✅ 数据库已成功创建: {db_path}")
                results.append(f"⏱️  操作耗时: {total_time:.2f} 秒")
                results.append("系统现在应该可以正常运行了。")
                log_info(f"create_empty_database: 数据库创建成功，耗时: {total_time:.2f} 秒")
                return True, results
            else:
                issues = []
                if not all_critical_created:
                    missing_tables = [table for table in critical_tables if table not in db_tables]
                    issues.append(f"关键表创建失败: {', '.join(missing_tables)}")
                if not utility_fee_created:
                    issues.append("utility_fee表创建失败")
                if not reminder_success:
                    issues.append("默认提醒设置插入失败")
                if not admin_success:
                    issues.append("默认管理员用户插入失败")
                
                results.append(f"\n⚠️ 警告: 数据库初始化存在问题: {'; '.join(issues)}")
                results.append(f"⏱️  操作耗时: {total_time:.2f} 秒")
                results.append("数据库可能无法正常工作。")
                log_error(f"create_empty_database: 数据库初始化存在问题: {'; '.join(issues)}")
                return False, results
                
        except Exception as e:
            # 捕获所有异常并进行处理
            results.append(f"❌ 创建数据库时出错: {str(e)}")
            log_error(f"create_empty_database: 创建数据库时出错: {str(e)}")
            
            # 尝试回滚事务
            if conn and transaction_started:
                try:
                    conn.rollback()
                    results.append("✓ 事务已回滚")
                    log_info("create_empty_database: 事务已回滚")
                except Exception as rollback_error:
                    results.append(f"❌ 回滚事务失败: {str(rollback_error)}")
                    log_error(f"create_empty_database: 回滚事务失败: {str(rollback_error)}")
            
            # 尝试关闭连接
            if conn is not None:
                try:
                    # 先尝试确认连接状态
                    try:
                        test_cursor = conn.cursor()
                        test_cursor.execute("SELECT 1")
                        test_cursor.close()
                    except Exception:
                        # 连接可能已关闭，不处理
                        pass
                    
                    # 尝试优雅关闭
                    conn.close()
                    results.append("✓ 数据库连接已关闭")
                    log_info("create_empty_database: 数据库连接已关闭")
                except sqlite3.ProgrammingError:
                    results.append("⚠️ 连接可能已关闭")
                except sqlite3.OperationalError as op_error:
                    log_error(f"create_empty_database: 关闭连接时发生操作错误: {str(op_error)}")
                    results.append(f"❌ 关闭数据库连接时发生操作错误: {str(op_error)}")
                except Exception as close_error:
                    log_error(f"create_empty_database: 关闭数据库连接失败: {str(close_error)}")
                    results.append(f"❌ 关闭数据库连接失败: {str(close_error)}")
            
            # 尝试清理可能创建的损坏文件
            try:
                if os.path.exists(db_path) and os.path.getsize(db_path) == 0:
                    os.remove(db_path)
                    results.append("✓ 已删除空的数据库文件")
                    log_info("create_empty_database: 已删除空的数据库文件")
            except Exception:
                pass
            
            return False, results
    
    @staticmethod
    def ensure_operation_logs_table_exists(conn):
        """确保operation_logs表存在于数据库中"""
        try:
            cursor = conn.cursor()
            # 创建表（如果不存在），使用IF NOT EXISTS避免查询操作
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS operation_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                log_time TEXT NOT NULL,
                user_id INTEGER,
                username TEXT,
                operation_module TEXT,
                operation_content TEXT,
                operation_result TEXT,
                ip_address TEXT,
                detail TEXT
            )
            ''')
            conn.commit()
            return True
        except Exception as e:
            log_error(f"确保操作日志表存在时出错: {str(e)}")
            return False
    
    @staticmethod
    def force_initialize_database():
        """
        强制初始化数据库，处理各种锁定情况，提供重试机制和完善的异常处理
        
        Returns:
            tuple: (success_flag, results_list)
                - success_flag: 布尔值，表示初始化是否成功
                - results_list: 字符串列表，包含详细的操作结果日志
        """
        results = []
        db_path = None
        max_retries = 3
        
        try:
            # 获取数据库路径并进行验证
            try:
                db_path = DatabaseUtils.get_db_path()
                if not db_path:
                    results.append("❌ 无法获取数据库路径")
                    log_error("获取数据库路径失败")
                    return False, results
            except Exception as e:
                results.append(f"❌ 获取数据库路径时出错: {str(e)}")
                log_error(f"获取数据库路径异常: {str(e)}")
                return False, results
            
            results.append("=== 强制初始化数据库 ===")
            results.append(f"目标数据库路径: {db_path}")
            log_info(f"开始强制初始化数据库: {db_path}")
            
            # 检查并尝试关闭可能的锁定进程
            try:
                if os.path.exists(db_path):
                    try:
                        is_locked = DatabaseUtils.is_file_locked(db_path)
                        if is_locked:
                            results.append("⚠️ 检测到数据库文件被锁定！")
                            log_error(f"数据库文件被锁定: {db_path}")
                            
                            # 尝试关闭锁定进程，最多重试2次
                            retry_count = 0
                            while retry_count < 2:
                                # 再次检查锁定状态，避免不必要的尝试
                                if not DatabaseUtils.is_file_locked(db_path):
                                    results.append("✓ 文件锁已自动释放")
                                    break
                                
                                results.append(f"尝试第 {retry_count + 1} 次释放数据库锁...")
                                try:
                                    close_results = DatabaseUtils.try_close_locks()
                                    results.extend(close_results)
                                except Exception as close_error:
                                    results.append(f"❌ 释放锁时发生错误: {str(close_error)}")
                                    log_error(f"强制初始化时释放锁异常: {str(close_error)}")
                                
                                # 等待一段时间让进程有机会关闭
                                wait_time = 2 + retry_count  # 递增等待时间
                                results.append(f"等待 {wait_time} 秒让进程关闭...")
                                time.sleep(wait_time)
                                retry_count += 1
                    except Exception as lock_check_error:
                        results.append(f"⚠️ 检查文件锁定状态时出错: {str(lock_check_error)}")
                        log_error(f"检查数据库锁定状态异常: {str(lock_check_error)}")
                        # 继续执行，不因锁定检查失败而中断
            except Exception as file_check_error:
                results.append(f"⚠️ 检查文件状态时出错: {str(file_check_error)}")
                log_error(f"检查数据库文件状态异常: {str(file_check_error)}")
            
            # 尝试删除现有数据库文件，支持重试
            delete_success = False
            delete_attempts = 0
            while delete_attempts < max_retries and not delete_success:
                if delete_attempts > 0:
                    results.append(f"\n重试删除数据库文件（尝试 {delete_attempts + 1}/{max_retries}）")
                    time.sleep(1)  # 等待1秒后重试
                
                try:
                    delete_success, delete_results = DatabaseUtils.safe_delete_file(db_path)
                    results.extend(delete_results)
                    
                    # 如果删除失败，尝试直接使用os.remove（作为备选方案）
                    if not delete_success and os.path.exists(db_path):
                        try:
                            results.append("⚠️ 尝试使用备选方法删除文件...")
                            os.remove(db_path)
                            delete_success = True
                            results.append("✓ 备选方法成功删除数据库文件")
                            log_info("强制初始化时使用备选方法成功删除数据库文件")
                        except PermissionError as perm_error:
                            results.append(f"❌ 权限错误 - 备选删除方法失败: {str(perm_error)}")
                            log_error(f"强制初始化时备选删除方法权限错误: {str(perm_error)}")
                        except OSError as os_error:
                            results.append(f"❌ 系统错误 - 备选删除方法失败: {str(os_error)}")
                            log_error(f"强制初始化时备选删除方法系统错误: {str(os_error)}")
                except Exception as delete_error:
                    results.append(f"❌ 删除文件过程中发生异常: {str(delete_error)}")
                    log_error(f"强制初始化时删除文件异常: {str(delete_error)}")
                    delete_results = [f"删除文件异常: {str(delete_error)}"]
                    results.extend(delete_results)
                
                delete_attempts += 1
            
            # 无论是否成功删除，都尝试创建新的数据库
            create_success = False
            create_attempts = 0
            while create_attempts < max_retries and not create_success:
                if create_attempts > 0:
                    results.append(f"\n重试创建数据库（尝试 {create_attempts + 1}/{max_retries}）")
                    time.sleep(1)  # 等待1秒后重试
                
                try:
                    # 显式传递db_path参数以确保使用正确的路径
                    # allow_existing=True：本函数已在上面用 safe_delete_file 删掉旧库文件，
                    # 此处的「重建」是「数据初始化」用户已确认过的高危操作，是唯一允许
                    # 覆盖已有库的调用方，需显式放行 create_empty_database 的已存在守卫。
                    create_success, create_results = DatabaseUtils.create_empty_database(
                        db_path, allow_existing=True)
                    results.extend(create_results)
                except sqlite3.OperationalError as op_error:
                    results.append(f"❌ 操作错误 - 创建数据库失败: {str(op_error)}")
                    log_error(f"强制初始化时创建数据库操作错误: {str(op_error)}")
                    if 'locked' in str(op_error).lower() or 'busy' in str(op_error).lower():
                        results.append("⚠️ 数据库文件仍然被锁定，请关闭所有可能使用该数据库的程序")
                except sqlite3.DatabaseError as db_error:
                    results.append(f"❌ 数据库错误 - 创建数据库失败: {str(db_error)}")
                    log_error(f"强制初始化时创建数据库错误: {str(db_error)}")
                except PermissionError as perm_error:
                    results.append(f"❌ 权限错误 - 创建数据库失败: {str(perm_error)}")
                    log_error(f"强制初始化时创建数据库权限错误: {str(perm_error)}")
                    results.append("⚠️ 请检查文件夹权限设置")
                except Exception as create_error:
                    results.append(f"❌ 创建数据库时发生异常: {str(create_error)}")
                    log_error(f"强制初始化时创建数据库异常: {str(create_error)}")
                    create_results = [f"创建数据库异常: {str(create_error)}"]
                    results.extend(create_results)
                    
                create_attempts += 1
                
                # 在每次尝试后验证数据库文件是否存在且有效
                if create_attempts < max_retries and not create_success and os.path.exists(db_path):
                    try:
                        # 简单验证数据库文件是否有效
                        temp_conn = sqlite3.connect(db_path)
                        temp_conn.close()
                        results.append("⚠️ 数据库文件已创建但可能不完整，将重试")
                    except Exception as verify_error:
                        results.append(f"⚠️ 数据库文件验证失败: {str(verify_error)}")
            
            # 生成综合结果
            # 即使删除失败，如果创建成功，整体也视为成功
            overall_success = create_success
            results.append("\n=== 操作结果 ===")
            
            if overall_success:
                results.append("✅ 数据库初始化成功！")
                results.append("您可以重新启动应用程序了。")
                log_info("数据库强制初始化成功完成")
            else:
                results.append("❌ 数据库初始化失败！")
                results.append("请检查错误信息并尝试手动解决。")
                results.append("建议操作：")
                results.append("1. 关闭所有可能正在使用数据库的应用程序")
                results.append("2. 手动删除数据库文件后重试")
                results.append("3. 检查文件系统权限")
                log_error("数据库强制初始化失败")
            
            return overall_success, results
            
        except sqlite3.OperationalError as op_error:
            # 捕获SQLite操作错误
            error_msg = f"❌ SQLite操作错误: {str(op_error)}"
            results.append(error_msg)
            log_error(f"强制初始化数据库SQLite操作错误: {str(op_error)}")
            
            # 根据错误内容提供更具体的建议
            if 'locked' in str(op_error).lower() or 'busy' in str(op_error).lower():
                results.append("⚠️ 数据库文件被锁定，请确保没有其他程序正在使用该数据库")
                results.append("  - 关闭所有可能使用该数据库的应用程序")
                results.append("  - 重启计算机后重试")
            elif 'permission' in str(op_error).lower() or 'access' in str(op_error).lower():
                results.append("⚠️ 权限错误，请检查文件系统权限设置")
                results.append("  - 以管理员权限运行应用程序")
                results.append("  - 检查数据库文件和文件夹的权限")
            
            results.append("\n=== 操作结果 ===")
            results.append("❌ 数据库初始化失败！")
            results.append("发生SQLite操作错误，请查看日志获取更多信息。")
            
            return False, results
            
        except PermissionError as perm_error:
            # 捕获权限错误
            error_msg = f"❌ 权限错误: {str(perm_error)}"
            results.append(error_msg)
            log_error(f"强制初始化数据库权限错误: {str(perm_error)}")
            
            results.append("⚠️ 权限问题导致初始化失败")
            results.append("  - 请以管理员权限运行应用程序")
            results.append("  - 检查数据库文件和文件夹的访问权限")
            results.append("  - 确保目标路径存在且可写")
            
            results.append("\n=== 操作结果 ===")
            results.append("❌ 数据库初始化失败！")
            results.append("权限不足，请检查文件系统权限设置。")
            
            return False, results
            
        except OSError as os_error:
            # 捕获系统错误
            error_msg = f"❌ 系统错误: {str(os_error)}"
            results.append(error_msg)
            log_error(f"强制初始化数据库系统错误: {str(os_error)}")
            
            results.append("⚠️ 系统错误导致初始化失败")
            results.append("  - 检查磁盘空间是否充足")
            results.append("  - 确保数据库文件未被其他进程锁定")
            results.append("  - 验证文件系统是否正常")
            
            results.append("\n=== 操作结果 ===")
            results.append("❌ 数据库初始化失败！")
            results.append("发生系统错误，请检查系统状态。")
            
            return False, results
            
        except Exception as e:
            # 捕获所有其他未预期的异常
            error_msg = f"❌ 强制初始化数据库时发生未预期的错误: {str(e)}"
            results.append(error_msg)
            log_error(f"强制初始化数据库未预期异常: {str(e)}")
            
            # 添加异常堆栈信息到日志（如果可能）
            log_error(f"异常堆栈: {traceback.format_exc()}")
            
            results.append("\n=== 操作结果 ===")
            results.append("❌ 数据库初始化失败！")
            results.append("发生未预期的错误，请查看日志获取更多信息。")
            results.append("如果问题持续，请联系技术支持并提供完整的错误日志。")
            
            return False, results
            
        finally:
            # 清理工作
            log_info("强制初始化数据库操作结束")
            
            # 如果初始化失败，尝试清理可能的部分创建的文件
            if 'db_path' in locals() and os.path.exists(db_path):
                try:
                    # 尝试验证文件是否有效
                    temp_conn = sqlite3.connect(db_path)
                    # 简单检查必要的表是否存在
                    cursor = temp_conn.cursor()
                    cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
                    tables = [table[0] for table in cursor.fetchall()]
                    required_tables = ['contracts', 'rent_records', 'users']
                    temp_conn.close()
                    
                    # 如果关键表缺失，考虑删除损坏的文件
                    if not all(table in tables for table in required_tables):
                        # 只有在外部变量显示失败时才删除
                        if 'overall_success' in locals() and not overall_success:
                            os.remove(db_path)
                            log_info(f"强制初始化失败后删除了不完整的数据库文件: {db_path}")
                except Exception:
                    # 验证失败，可能是损坏的文件，尝试删除
                    try:
                        os.remove(db_path)
                        log_info(f"强制初始化失败后删除了可能损坏的数据库文件: {db_path}")
                    except Exception:
                        # 无法删除，记录日志但不阻止程序继续
                        log_warning(f"无法删除可能损坏的数据库文件: {db_path}")
    
    @staticmethod
    def is_file_locked(file_path):
        """
        检查文件是否被锁定，使用更准确的方法验证文件锁定状态
        
        Args:
            file_path (str): 要检查的文件路径
            
        Returns:
            bool: True表示文件被锁定，False表示文件未被锁定或不存在
        """
        # 首先验证参数
        if not isinstance(file_path, str) or not file_path:
            log_error("is_file_locked: 无效的文件路径参数")
            return False
            
        # 检查文件是否存在
        if not os.path.exists(file_path):
            log_info(f"is_file_locked: 文件不存在，无需检查锁定: {file_path}")
            return False
            
        # 检查是否是目录而非文件
        if os.path.isdir(file_path):
            log_error(f"is_file_locked: 指定路径是目录而非文件: {file_path}")
            return False
            
        try:
            # 尝试以读写模式打开文件（非追加模式）
            # 使用二进制模式以避免行尾转换问题
            with open(file_path, 'r+b') as f:
                # 尝试读写一小段数据
                original_position = f.tell()
                f.seek(0, os.SEEK_END)
                file_size = f.tell()
                
                # 如果文件不为空，尝试读取第一个字节然后写回
                if file_size > 0:
                    f.seek(0)
                    byte_data = f.read(1)
                    f.seek(0)
                    f.write(byte_data)
                
                # 恢复到原始位置
                f.seek(original_position)
                
            # 尝试获取文件排他锁作为额外验证
            try:
                with open(file_path, 'r+b') as f:
                    fcntl.lockf(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                    fcntl.lockf(f.fileno(), fcntl.LOCK_UN)
            except (NameError, AttributeError):
                # Windows系统可能不支持fcntl模块，忽略此错误
                pass
                
            log_info(f"is_file_locked: 文件可访问，未被锁定: {file_path}")
            return False
            
        except (IOError, PermissionError) as e:
            # IOError通常表示文件被锁定或无法访问
            # PermissionError表示权限问题
            log_error(f"is_file_locked: 文件可能被锁定或权限不足: {file_path}, 错误: {str(e)}")
            return True
        except Exception as e:
            # 捕获其他异常
            log_error(f"is_file_locked: 检查文件锁定状态时发生意外错误: {file_path}, 错误: {str(e)}")
            # 安全起见，当发生未知错误时假设文件被锁定
            return True
    
    @staticmethod
    def try_close_locks():
        """
        尝试关闭锁定数据库的进程，提供针对不同操作系统的实现
        
        Returns:
            list: 操作结果信息列表
        """
        results = []
        results.append("尝试释放数据库锁...")
        log_info("开始尝试释放数据库锁定")
        
        try:
            # Windows系统特定的锁定释放方法
            if os.name == 'nt':  # Windows系统
                try:
                    # 导入Windows特定模块
                    import psutil
                    
                    results.append("在Windows系统上寻找并尝试关闭锁定进程...")
                    db_processes = []
                    
                    # 查找可能正在使用SQLite数据库的Python进程
                    for proc in psutil.process_iter(['pid', 'name', 'exe']):
                        try:
                            proc_info = proc.info
                            # 查找Python进程或名称中包含SQLite的进程
                            if ('python' in proc_info['name'].lower() or 
                                'sqlite' in proc_info['name'].lower()):
                                # 检查进程是否打开了数据库相关文件
                                for file in proc.open_files():
                                    # 检查是否有.db文件或SQLite相关文件
                                    if file.path.endswith('.db') or 'sqlite' in file.path.lower():
                                        db_processes.append((proc_info['pid'], proc_info['name'], file.path))
                        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                            # 忽略无法访问的进程
                            pass
                    
                    if db_processes:
                        results.append(f"发现 {len(db_processes)} 个可能锁定数据库的进程:")
                        for pid, name, path in db_processes:
                            results.append(f"  - PID: {pid}, 名称: {name}, 文件: {path}")
                        
                        results.append("提示: 您可能需要手动关闭这些进程。")
                        results.append("注意: 强制终止进程可能导致数据丢失。")
                    else:
                        results.append("未找到明显的锁定进程。")
                        
                except ImportError:
                    results.append("psutil模块未安装，无法自动检测锁定进程。")
                    results.append("建议: 安装psutil以启用进程检测功能。")
                    results.append("命令: pip install psutil")
                except Exception as e:
                    results.append(f"检测锁定进程时出错: {str(e)}")
            else:
                # 非Windows系统的处理逻辑
                results.append("在非Windows系统上尝试释放锁...")
                # 这里可以添加针对Linux/Unix系统的特定实现
                results.append("已尝试释放锁，可能需要手动干预。")
            
            # 通用的锁定释放方法：尝试删除可能存在的锁定文件
            db_path = DatabaseUtils.get_db_path()
            if db_path and os.path.exists(db_path):
                # 检查并删除可能存在的SQLite临时锁定文件
                lock_file_path = db_path + '-journal'  # SQLite事务日志文件
                wal_file_path = db_path + '-wal'  # SQLite WAL模式文件
                
                for file_path in [lock_file_path, wal_file_path]:
                    if os.path.exists(file_path):
                        try:
                            os.remove(file_path)
                            results.append(f"已删除临时锁定文件: {os.path.basename(file_path)}")
                            log_info(f"删除SQLite临时文件: {file_path}")
                        except Exception as e:
                            results.append(f"无法删除临时文件 {os.path.basename(file_path)}: {str(e)}")
                            log_error(f"删除临时文件失败: {file_path}, 错误: {str(e)}")
            
            results.append("锁定释放尝试完成。")
            return results
            
        except Exception as e:
            error_msg = f"尝试释放锁定时发生错误: {str(e)}"
            results.append(error_msg)
            log_error(f"尝试释放锁定异常: {str(e)}")
            return results
    
    @staticmethod
    def safe_delete_file(file_path, backup_before_delete=False):
        """
        安全删除文件，提供完善的异常处理和可选的备份功能
        
        Args:
            file_path (str): 要删除的文件路径
            backup_before_delete (bool): 是否在删除前创建备份（默认为False）
            
        Returns:
            tuple: (success_flag, results_list)
                - success_flag: 布尔值，表示删除是否成功
                - results_list: 字符串列表，包含详细的操作结果日志
        """
        results = []
        
        # 参数验证
        if not isinstance(file_path, str) or not file_path:
            results.append("❌ 无效的文件路径参数")
            log_error("safe_delete_file: 无效的文件路径参数")
            return False, results
        
        # 检查文件是否存在
        if not os.path.exists(file_path):
            results.append(f"ℹ️ 文件不存在，跳过删除: {file_path}")
            log_info(f"文件不存在，跳过删除: {file_path}")
            return True, results
        
        # 检查是否是目录而非文件
        if os.path.isdir(file_path):
            results.append(f"❌ 指定路径是目录而非文件: {file_path}")
            log_error(f"尝试删除目录而非常文件: {file_path}")
            return False, results
        
        # 检查文件权限
        try:
            if not os.access(file_path, os.W_OK):
                results.append(f"⚠️ 警告: 没有写入权限: {file_path}")
                log_warning(f"删除文件前检测到权限问题: {file_path}")
        except Exception as perm_error:
            results.append(f"⚠️ 检查文件权限时出错: {str(perm_error)}")
            log_error(f"检查文件权限时异常: {str(perm_error)}")
        
        # 可选的备份功能
        backup_path = None
        if backup_before_delete:
            try:
                # 创建备份文件路径（添加时间戳）
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                backup_path = f"{file_path}.bak_{timestamp}"
                
                # 复制文件到备份位置
                shutil.copy2(file_path, backup_path)
                results.append(f"✅ 文件已备份到: {os.path.basename(backup_path)}")
                log_info(f"安全删除前备份文件: {file_path} -> {backup_path}")
                
            except ImportError:
                results.append("⚠️ shutil模块不可用，跳过备份")
                log_error("shutil模块不可用，无法创建备份")
            except Exception as backup_error:
                results.append(f"⚠️ 创建备份失败: {str(backup_error)}")
                log_error(f"创建文件备份失败: {str(backup_error)}")
                # 备份失败不阻止删除操作，继续执行
        
        # 尝试删除文件，使用重试机制
        max_retries = 3
        delete_success = False
        
        for attempt in range(max_retries):
            try:
                os.remove(file_path)
                delete_success = True
                results.append(f"✅ 成功删除文件: {file_path}")
                log_info(f"成功删除文件: {file_path}")
                break
            except PermissionError as perm_error:
                results.append(f"❌ 删除失败 - 权限错误: {str(perm_error)}")
                log_error(f"删除文件权限错误: {file_path}, 错误: {str(perm_error)}")
                # 权限错误不再重试，直接返回失败
                delete_success = False
                break
            except OSError as os_error:
                if attempt < max_retries - 1:
                    wait_time = 0.5 * (attempt + 1)
                    results.append(f"⚠️ 删除失败，{wait_time}秒后重试 ({attempt + 1}/{max_retries}): {str(os_error)}")
                    time.sleep(wait_time)
                else:
                    results.append(f"❌ 删除失败 - 操作系统错误: {str(os_error)}")
                    log_error(f"删除文件操作系统错误: {file_path}, 错误: {str(os_error)}")
            except Exception as e:
                results.append(f"❌ 删除失败 - 未知错误: {str(e)}")
                log_error(f"删除文件未知错误: {file_path}, 错误: {str(e)}")
                delete_success = False
                break
        
        # 如果删除成功且有备份，可以考虑删除备份（可选）
        # 这里选择保留备份，让用户自行决定
        
        return delete_success, results
    
    @staticmethod
    def begin_transaction(conn):
        """开始事务，增加连接有效性检查和重试机制
        
        增强功能：
        - 高级连接健康检查
        - 智能重试策略与指数退避
        - 事务嵌套管理
        - 详细的性能监控
        - 完善的错误分类处理
        
        Args:
            conn: 数据库连接对象
            
        Returns:
            bool: 事务是否成功开始
        """
        
        # 检查连接是否有效
        if not conn:
            log_error("begin_transaction: 连接无效或为None，无法开始事务")
            return False
            
        try:
            # 检查是否已在事务中（支持嵌套事务）
            transaction_depth = getattr(conn, '_transaction_depth', 0)
            if hasattr(conn, 'in_transaction') and conn.in_transaction and transaction_depth > 0:
                # 支持嵌套事务，使用SAVEPOINT
                savepoint_name = f"savepoint_{transaction_depth}"
                try:
                    conn.execute(f"SAVEPOINT {savepoint_name}")
                    # 更新事务深度
                    conn._transaction_depth = transaction_depth + 1
                    return True
                except Exception as e:
                    log_error(f"begin_transaction: 创建保存点失败: {str(e)}")
                    return False
                
            # 首次事务或没有嵌套支持时，创建新事务
            retry_count = 0
            max_retries = 3  # 增加重试次数
            max_wait_time = 2.0  # 最大等待时间
            
            while retry_count < max_retries:
                try:
                    # 高级连接健康检查
                    cursor = conn.cursor()
                    cursor.execute("SELECT 1")
                    cursor.fetchone()  # 确保执行完成
                    cursor.close()
                    
                    # 开始事务
                    conn.execute('BEGIN TRANSACTION')
                    
                    # 初始化事务深度跟踪
                    conn._transaction_depth = 1
                    return True
                    
                except sqlite3.OperationalError as e:
                    # 操作错误，可能需要重试
                    retry_count += 1
                    error_msg = f"操作错误: {str(e)}"
                    
                    # 根据错误类型决定是否重试
                    if any(keyword in str(e).lower() for keyword in ['locked', 'busy', 'timeout']):
                        # 使用指数退避策略
                        wait_time = min(0.1 * (2 ** retry_count), max_wait_time)
                        log_warning(f"begin_transaction: 开始事务失败 {error_msg}, 尝试重试 ({retry_count}/{max_retries}), 等待 {wait_time:.2f}秒")
                        time.sleep(wait_time)
                    else:
                        # 其他操作错误，不重试
                        log_error(f"begin_transaction: 开始事务失败 {error_msg}, 不重试")
                        return False
                        
                except sqlite3.ProgrammingError as e:
                    # 编程错误，通常不需要重试
                    log_error(f"begin_transaction: 开始事务失败（编程错误）: {str(e)}")
                    return False
                    
                except sqlite3.DatabaseError as e:
                    # 数据库错误，可能是连接问题
                    retry_count += 1
                    wait_time = min(0.1 * (2 ** retry_count), max_wait_time)
                    log_error(f"begin_transaction: 开始事务失败（数据库错误）: {str(e)}, 尝试重试 ({retry_count}/{max_retries}), 等待 {wait_time:.2f}秒")
                    time.sleep(wait_time)
                    
                except Exception as e:
                    # 其他未预期错误
                    retry_count += 1
                    wait_time = min(0.1 * (2 ** retry_count), max_wait_time)
                    log_error(f"begin_transaction: 开始事务失败: {str(e)}, 尝试重试 ({retry_count}/{max_retries}), 等待 {wait_time:.2f}秒")
                    time.sleep(wait_time)
            
            log_error("begin_transaction: 开始事务重试次数用尽，事务启动失败")
            return False
            
        except Exception as e:
            log_error(f"begin_transaction: 检查事务状态时出错: {str(e)}")
            
            # 继续尝试开始事务作为最后的备选方案
            try:
                conn.execute('BEGIN TRANSACTION')
                conn._transaction_depth = 1
                log_info("begin_transaction: 事务成功开始（备选方案）")
                return True
            except Exception as start_error:
                log_error(f"begin_transaction: 开始事务失败: {str(start_error)}")
                return False

    @staticmethod
    def commit_transaction(conn):
        """提交事务，增加连接有效性检查和异常分类处理
        
        增强功能：
        - 嵌套事务支持
        - 智能错误恢复
        - 事务完整性验证
        - 详细的性能监控
        - 完善的错误分类处理
        
        Args:
            conn: 数据库连接对象
            
        Returns:
            bool: 事务是否成功提交
        """
        start_time = time.time()
        
        # 检查连接是否有效
        if not conn:
            log_error("commit_transaction: 连接无效或为None，无法提交事务")
            return False
        
        try:
            # 检查是否在事务中
            if hasattr(conn, 'in_transaction') and not conn.in_transaction:return True
                
            # 处理嵌套事务
            transaction_depth = getattr(conn, '_transaction_depth', 1)
            if transaction_depth > 1:
                # 回滚到保存点（嵌套事务）
                savepoint_name = f"savepoint_{transaction_depth - 1}"
                try:
                    conn.execute(f"RELEASE {savepoint_name}")
                    # 更新事务深度
                    conn._transaction_depth = transaction_depth - 1
                    
                    elapsed_time = time.time() - start_time
                    return True
                except Exception as e:
                    log_error(f"commit_transaction: 释放保存点失败: {str(e)}")
                    return False
            
            # 验证连接有效性
            cursor = None
            try:
                cursor = conn.cursor()
                cursor.execute("SELECT 1")
                cursor.fetchone()  # 确保执行完成
            except Exception as health_check_error:
                log_warning(f"commit_transaction: 连接健康检查失败: {str(health_check_error)}，但仍尝试提交事务")
            finally:
                if cursor:
                    cursor.close()
            
            # 提交事务
            retry_count = 0
            max_retries = 2
            
            while retry_count <= max_retries:
                try:
                    conn.commit()
                    
                    # 重置事务深度
                    if hasattr(conn, '_transaction_depth'):
                        delattr(conn, '_transaction_depth')
                    
                    # 记录性能指标
                    elapsed_time = time.time() - start_time
                    log_info(f"commit_transaction: 事务成功提交，耗时: {elapsed_time:.3f}秒")
                    return True
                    
                except sqlite3.OperationalError as e:
                    # 操作错误，可能需要重试
                    if retry_count < max_retries:
                        retry_count += 1
                        wait_time = 0.5 * retry_count
                        log_warning(f"commit_transaction: 提交事务失败（操作错误）: {str(e)}, 尝试重试 ({retry_count}/{max_retries}), 等待 {wait_time}秒")
                        time.sleep(wait_time)
                    else:
                        log_error(f"commit_transaction: 提交事务失败（操作错误，重试次数用尽）: {str(e)}")
                        return False
                        
                except Exception as e:
                    log_error(f"commit_transaction: 提交事务失败: {str(e)}")
                    return False
        except sqlite3.OperationalError as op_error:
            # 操作错误，可能是磁盘空间不足或I/O错误
            error_msg = str(op_error)
            log_error(f"rollback_transaction: 回滚时操作错误: {error_msg}")
            
            # 根据错误类型提供更详细的诊断
            if 'disk full' in error_msg.lower() or 'no space' in error_msg.lower():
                log_error("rollback_transaction: 检测到磁盘空间不足，可能导致数据损坏！")
                log_error("rollback_transaction: 建议: 立即释放磁盘空间并备份数据库")
            elif 'locked' in error_msg.lower() or 'busy' in error_msg.lower():
                log_error("rollback_transaction: 数据库文件被锁定，无法执行回滚")
            
            # 尝试重置连接状态
            try:
                if hasattr(conn, '_transaction_depth'):
                    delattr(conn, '_transaction_depth')
                conn.close()
                log_info("rollback_transaction: 操作错误后关闭连接")
            except Exception as close_error:
                log_error(f"rollback_transaction: 操作错误后关闭连接失败: {str(close_error)}")
            
            return False
            
        except sqlite3.ProgrammingError as prog_error:
            # 编程错误，通常是事务状态问题
            log_error(f"rollback_transaction: 回滚时编程错误: {str(prog_error)}")
            
            # 尝试重置连接状态
            try:
                if hasattr(conn, '_transaction_depth'):
                    delattr(conn, '_transaction_depth')
                conn.close()
                log_info("rollback_transaction: 编程错误后关闭连接")
            except Exception as close_error:
                log_error(f"rollback_transaction: 编程错误后关闭连接失败: {str(close_error)}")
            
            return False
            
        except AttributeError as attr_error:
            # 连接对象属性错误，可能连接已损坏
            log_error(f"rollback_transaction: 连接对象属性错误: {str(attr_error)}")
            
            # 尝试重置连接状态
            try:
                if hasattr(conn, '_transaction_depth'):
                    delattr(conn, '_transaction_depth')
            except Exception as del_err:
                log_debug(f"清理事务深度标记时出错: {del_err}")
                
            return False
            
        except Exception as e:
            # 其他未预期错误
            log_error(f"rollback_transaction: 回滚时未预期错误: {str(e)}")
            
            # 添加异常堆栈信息到日志（如果可能）
            try:
                log_error(f"rollback_transaction: 异常堆栈: {traceback.format_exc()}")
            except Exception:
                # 日志系统不可用时静默（避免递归）
                pass
            
            # 尝试重置连接状态
            try:
                if hasattr(conn, '_transaction_depth'):
                    delattr(conn, '_transaction_depth')
                conn.close()
                log_info("rollback_transaction: 未预期错误后关闭连接")
            except Exception as close_error:
                log_error(f"rollback_transaction: 未预期错误后关闭连接失败: {str(close_error)}")
            
            return False
            

    @staticmethod
    def rollback_transaction(conn):
        """回滚事务，增加连接有效性检查和错误恢复机制
        
        增强功能：
        - 嵌套事务支持
        - 智能错误恢复
        - 事务状态清理
        - 详细的性能监控
        - 完善的错误分类处理
        - 增强的异常捕获和资源释放
        
        Args:
            conn: 数据库连接对象
            
        Returns:
            bool: 事务是否成功回滚
        """
        start_time = time.time()
        
        # 检查连接是否有效
        if not conn:
            log_error("rollback_transaction: 连接无效或为None，无法回滚事务")
            return False
            
        try:
            # 检查是否在事务中
            if hasattr(conn, 'in_transaction'):
                try:
                    if not conn.in_transaction:# 清理事务深度属性
                        if hasattr(conn, '_transaction_depth'):
                            delattr(conn, '_transaction_depth')
                        return True
                except Exception as state_check_error:
                    log_warning(f"rollback_transaction: 检查事务状态时出错: {str(state_check_error)}")
                    # 即使无法检查状态，也尝试回滚以确保安全
            
            # 处理嵌套事务
            transaction_depth = getattr(conn, '_transaction_depth', 1)
            if transaction_depth > 1:
                # 回滚到保存点（嵌套事务）
                savepoint_name = f"savepoint_{transaction_depth - 1}"
                try:
                    conn.execute(f"ROLLBACK TO {savepoint_name}")
                    # 更新事务深度
                    conn._transaction_depth = transaction_depth - 1
                    
                    elapsed_time = time.time() - start_time
                    return True
                except sqlite3.OperationalError as op_error:
                    log_error(f"rollback_transaction: 回滚到保存点操作错误: {str(op_error)}")
                    # 尝试完全回滚作为备选方案
                    log_warning("rollback_transaction: 尝试完全回滚事务")
                except sqlite3.ProgrammingError as prog_error:
                    log_error(f"rollback_transaction: 回滚到保存点编程错误: {str(prog_error)}")
                    # 保存点可能已被释放，尝试完全回滚
                    log_warning("rollback_transaction: 保存点可能已失效，尝试完全回滚事务")
                except Exception as e:
                    log_error(f"rollback_transaction: 回滚到保存点失败: {str(e)}")
                    # 尝试完全回滚作为备选方案
                    log_warning("rollback_transaction: 尝试完全回滚事务")
                
            # 验证连接有效性
            cursor = None
            try:
                cursor = conn.cursor()
                cursor.execute("SELECT 1")
                cursor.fetchone()  # 确保执行完成
            except sqlite3.OperationalError as op_error:
                log_warning(f"rollback_transaction: 连接健康检查操作错误: {str(op_error)}，尝试强制回滚")
            except sqlite3.DatabaseError as db_error:
                log_warning(f"rollback_transaction: 连接健康检查数据库错误: {str(db_error)}，尝试强制回滚")
            except AttributeError as attr_error:
                log_warning(f"rollback_transaction: 连接对象缺少必要属性: {str(attr_error)}，连接可能已损坏")
            except Exception as health_check_error:
                log_warning(f"rollback_transaction: 连接健康检查失败: {str(health_check_error)}，尝试强制回滚")
            finally:
                if cursor:
                    try:
                        cursor.close()
                    except Exception as close_error:
                        log_error(f"rollback_transaction: 关闭健康检查游标失败: {str(close_error)}")
            
            # 回滚事务
            retry_count = 0
            max_retries = 3  # 增加重试次数
            max_wait_time = 2.0
            
            while retry_count <= max_retries:
                try:
                    conn.rollback()
                    
                    # 重置事务深度
                    if hasattr(conn, '_transaction_depth'):
                        delattr(conn, '_transaction_depth')
                    
                    # 记录性能指标
                    elapsed_time = time.time() - start_time
                    log_info(f"rollback_transaction: 事务成功回滚，耗时: {elapsed_time:.3f}秒")
                    return True
                    
                except sqlite3.OperationalError as e:
                    # 操作错误，可能需要重试
                    error_msg = str(e)
                    if retry_count < max_retries:
                        retry_count += 1
                        wait_time = min(0.1 * (2 ** retry_count), max_wait_time)
                        
                        # 针对特定操作错误提供更详细的日志
                        if 'locked' in error_msg.lower() or 'busy' in error_msg.lower():
                            log_warning(f"rollback_transaction: 数据库被锁定，无法回滚: {error_msg}, 尝试重试 ({retry_count}/{max_retries}), 等待 {wait_time:.2f}秒")
                        elif 'disk full' in error_msg.lower() or 'no space' in error_msg.lower():
                            log_error(f"rollback_transaction: 磁盘空间不足，无法回滚: {error_msg}")
                            # 磁盘空间不足不再重试，直接返回失败
                            if hasattr(conn, '_transaction_depth'):
                                delattr(conn, '_transaction_depth')
                            return False
                        else:
                            log_warning(f"rollback_transaction: 回滚事务失败（操作错误）: {error_msg}, 尝试重试 ({retry_count}/{max_retries}), 等待 {wait_time:.2f}秒")
                        
                        time.sleep(wait_time)
                    else:
                        log_error(f"rollback_transaction: 回滚事务失败（操作错误，重试次数用尽）: {error_msg}")
                        # 尝试重置连接状态
                        if hasattr(conn, '_transaction_depth'):
                            delattr(conn, '_transaction_depth')
                        return False
                        
                except sqlite3.DatabaseError as e:
                    # 数据库错误，可能是连接问题
                    if retry_count < max_retries:
                        retry_count += 1
                        wait_time = min(0.1 * (2 ** retry_count), max_wait_time)
                        log_error(f"rollback_transaction: 回滚事务失败（数据库错误）: {str(e)}, 尝试重试 ({retry_count}/{max_retries}), 等待 {wait_time:.2f}秒")
                        time.sleep(wait_time)
                    else:
                        log_error(f"rollback_transaction: 回滚事务失败（数据库错误，重试次数用尽）: {str(e)}")
                        # 尝试重置连接状态
                        if hasattr(conn, '_transaction_depth'):
                            delattr(conn, '_transaction_depth')
                        return False
                except AttributeError as attr_error:
                    # 连接对象可能已损坏
                    log_error(f"rollback_transaction: 连接对象已损坏: {str(attr_error)}")
                    # 尝试重置连接状态
                    if hasattr(conn, '_transaction_depth'):
                        delattr(conn, '_transaction_depth')
                    return False
                except Exception as e:
                    log_error(f"rollback_transaction: 回滚事务失败: {str(e)}")
                    # 尝试重置连接状态
                    if hasattr(conn, '_transaction_depth'):
                        delattr(conn, '_transaction_depth')
                    return False
            
            log_error("rollback_transaction: 回滚事务重试次数用尽，事务回滚失败")
            
            # 即使回滚失败，也尝试重置连接状态并清理资源
            try:
                # 尝试重置事务深度
                if hasattr(conn, '_transaction_depth'):
                    delattr(conn, '_transaction_depth')
                
                # 尝试关闭连接以防止资源泄漏
                try:
                    conn.close()
                    log_info("rollback_transaction: 回滚失败后尝试关闭连接")
                except sqlite3.ProgrammingError as prog_error:
                    log_error(f"rollback_transaction: 回滚失败后关闭连接编程错误: {str(prog_error)}")
                except Exception as close_error:
                    log_error(f"rollback_transaction: 回滚失败后关闭连接失败: {str(close_error)}")
                    
                # 记录详细的失败信息
                elapsed_time = time.time() - start_time
                log_error(f"rollback_transaction: 事务回滚完全失败，耗时: {elapsed_time:.3f}秒")
                
            except Exception as cleanup_error:
                log_error(f"rollback_transaction: 清理资源时出错: {str(cleanup_error)}")
            
            return False
        except Exception as outer_error:
            log_error(f"rollback_transaction: 外层异常: {str(outer_error)}")
            # 确保清理事务状态
            if hasattr(conn, '_transaction_depth'):
                try:
                    delattr(conn, '_transaction_depth')
                except Exception:
                    pass
            return False

# 命令行工具函数

def main():
    """主函数，用于测试数据库工具类，包含增强的异常处理机制"""
    db_path = 'rental_contract.db'
    
    try:
        log_info("开始测试数据库工具类")
        
        # 尝试关闭可能锁定数据库的进程
        log_info("尝试关闭可能锁定数据库的进程...")
        try:
            results = DatabaseUtils.try_close_locks()
            log_info(f"关闭锁定进程结果: {results}")
        except sqlite3.OperationalError as op_error:
            log_error(f"关闭锁定进程操作错误: {str(op_error)}")
        except sqlite3.DatabaseError as db_error:
            log_error(f"关闭锁定进程数据库错误: {str(db_error)}")
        except Exception as lock_error:
            log_error(f"关闭锁定进程时出错: {str(lock_error)}")
        
        # 尝试安全删除文件
        log_info(f"尝试安全删除数据库文件: {db_path}")
        try:
            success, results = DatabaseUtils.safe_delete_file(db_path)
            if success:
                log_info(f"成功删除数据库文件: {db_path}")
            else:
                log_warning(f"删除数据库文件失败: {results}")
        except PermissionError as perm_error:
            log_error(f"删除文件权限错误: {str(perm_error)}")
            success = False
        except OSError as os_error:
            log_error(f"删除文件操作系统错误: {str(os_error)}")
            success = False
        except Exception as delete_error:
            log_error(f"删除文件时未预期错误: {str(delete_error)}")
            success = False
        
        # 无论是否删除成功，都尝试创建数据库
        if os.path.exists(db_path) and not success:
            # 文件被锁定，创建临时数据库文件
            temp_db_path = db_path + '.temp'
            log_warning(f"原数据库文件被锁定，尝试创建临时数据库文件: {temp_db_path}")
            try:
                create_success, create_results = DatabaseUtils.create_empty_database(temp_db_path)
                if create_success:
                    log_info(f"成功创建临时数据库文件: {temp_db_path}")
                    # 尝试通知用户
                    log_warning(f"原数据库文件被锁定，已创建临时数据库: {temp_db_path}")
                else:
                    log_error(f"创建临时数据库失败: {create_results}")
                    log_error(f"创建临时数据库失败: {create_results}")
            except sqlite3.OperationalError as op_error:
                log_error(f"创建临时数据库操作错误: {str(op_error)}")
                log_error(f"创建临时数据库失败: {str(op_error)}")
            except sqlite3.DatabaseError as db_error:
                log_error(f"创建临时数据库数据库错误: {str(db_error)}")
                log_error(f"创建临时数据库失败: {str(db_error)}")
            except Exception as create_error:
                log_error(f"创建临时数据库时未预期错误: {str(create_error)}")
                log_error(f"创建临时数据库失败: {str(create_error)}")
        else:
            # 成功删除或文件不存在，直接创建数据库
            log_info(f"尝试创建数据库: {db_path}")
            try:
                create_success, create_results = DatabaseUtils.create_empty_database(db_path)
                if create_success:
                    log_info(f"成功创建数据库: {db_path}")
                    log_info(f"数据库已创建: {db_path}")
                else:
                    log_error(f"创建数据库失败: {create_results}")
                    log_error(f"创建数据库失败: {create_results}")
            except sqlite3.OperationalError as op_error:
                log_error(f"创建数据库操作错误: {str(op_error)}")
                log_error(f"创建数据库失败: {str(op_error)}")
            except sqlite3.DatabaseError as db_error:
                log_error(f"创建数据库数据库错误: {str(db_error)}")
                log_error(f"创建数据库失败: {str(db_error)}")
            except Exception as create_error:
                log_error(f"创建数据库时未预期错误: {str(create_error)}")
                log_error(f"创建数据库失败: {str(create_error)}")
        
        log_info("数据库工具类测试完成")
        
    except KeyboardInterrupt:
        log_info("用户中断操作")
        log_warning("操作已中断")
    except Exception as e:
        log_error(f"main函数执行时发生未捕获异常: {str(e)}")
        # 尝试记录异常堆栈
        try:
            log_error(f"main函数异常堆栈: {traceback.format_exc()}")
        except Exception:
            # 日志系统不可用时静默（避免递归）
            pass
        log_error(f"严重错误: {str(e)}")
        log_error("请检查日志文件获取详细信息")
    # finally语句需要正确对应到main函数的try块
    log_info("main函数执行完毕")

if __name__ == '__main__':
    main()