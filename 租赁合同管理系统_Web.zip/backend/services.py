# -*- coding: utf-8 -*-
"""
租赁合同管理系统 Web 版 - 业务服务层

所有金额参数/返回均为「元」（execute_query 自动 元↔分 转换，迁移库生效）。
"""
import os
import time
import shutil
import sqlite3
import datetime
from typing import Optional, List, Tuple

from db_utils import DatabaseUtils
from operation_logger import record_operation
from config_utils import ConfigManager
from logger_module import log_warning
from notify import notify_rent_adjustment

# ================================================================ 工具
def _rows(cursor):
    """安全取行：cursor 可能为 None"""
    if cursor is None:
        return []
    return cursor.fetchall()


def _fmt_date(d):
    return d.isoformat() if isinstance(d, (datetime.date, datetime.datetime)) else (str(d) if d else "")


def _now_str():
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# ================================================================ 收款状态（三态）
# 历史缺陷：原实现只有「已结清 / 未结清」二值，且判据是「本次收款金额 >= 当前欠款余额」。
# 编辑保存时合同「已收」已包含本笔，导致 本次金额 == 余额 时被误判为「已结清」
# （典型：应收 48000、已收 36000、本次收 12000 → 余额 12000 → 误判已结清）。
# 现统一为按「累计已收 vs 合同应收总租」判定，并支持「部分收款」中间态。
PAYMENT_STATUS_SETTLED = "已结清"      # 累计已收 >= 合同应收
PAYMENT_STATUS_PARTIAL = "部分收款"    # 0 < 累计已收 < 合同应收
PAYMENT_STATUS_UNSETTLED = "未结清"    # 累计已收 = 0
VALID_PAYMENT_STATUSES = (PAYMENT_STATUS_SETTLED, PAYMENT_STATUS_PARTIAL, PAYMENT_STATUS_UNSETTLED)

# 分→元换算与四舍五入产生的尾差容忍值（50 分 = 0.5 元）
_PAYMENT_TOLERANCE_CENTS = 50


def normalize_payment_status(value) -> str:
    """把外部传入的收款状态收敛到合法取值，非法值一律回退「未结清」"""
    v = (value or "").strip()
    return v if v in VALID_PAYMENT_STATUSES else PAYMENT_STATUS_UNSETTLED


def compute_payment_status(received_cents, total_cents) -> str:
    """按「累计已收 vs 合同应收总租」判定收款状态。

    入参单位为「分」（与库内金额列一致）：
      应收 <= 0                → 已结清（无应收可收）
      已收 <= 0                → 未结清
      已收 >= 应收 - 0.5 元     → 已结清（容忍分→元换算尾差）
      其余                     → 部分收款
    """
    try:
        total = float(total_cents or 0)
        received = float(received_cents or 0)
    except (TypeError, ValueError):
        return PAYMENT_STATUS_UNSETTLED
    if total <= 0:
        return PAYMENT_STATUS_SETTLED
    if received <= 0:
        return PAYMENT_STATUS_UNSETTLED
    if received >= total - _PAYMENT_TOLERANCE_CENTS:
        return PAYMENT_STATUS_SETTLED
    return PAYMENT_STATUS_PARTIAL


def recalc_contract_payment_status(conn, contract_no) -> Optional[str]:
    """收款状态的唯一真源：按累计已收重算合同表 + 该合同全部收款记录，保证两处一致。

    替代旧的 _sync_payment_status（后者只是把外部传入的状态无差别广播，会把单条
    记录的错误状态扩散到整个合同）。返回重算后的状态；合同不存在时返回 None。
    """
    if not contract_no:
        return None
    cursor = conn.cursor()
    cursor.execute("SELECT total_rent, annual_rent FROM contracts WHERE contract_no = ?", (contract_no,))
    row = cursor.fetchone()
    if not row:
        return None
    total = row[0]
    if total is None or float(total or 0) == 0:
        total = row[1]
    cursor.execute("SELECT COALESCE(SUM(amount), 0) FROM rent_records WHERE contract_no = ?", (contract_no,))
    received = cursor.fetchone()[0] or 0
    status = compute_payment_status(received, total)
    cursor.execute("UPDATE contracts SET payment_status = ? WHERE contract_no = ?", (status, contract_no))
    cursor.execute("UPDATE rent_records SET payment_status = ? WHERE contract_no = ?", (status, contract_no))
    return status


def auto_update_contract_statuses(username: str = "") -> dict:
    """自动更新合同状态（对齐原版 main.py checkAndUpdateExpiredContracts / checkAndUpdateOverdueContracts）

    原版行为（main.py:1818-1964）：
    1. 执行中 且 end_date <= 今天 且 payment_status='已结清' → status 改为 '已完成'
    2. 执行中 且 end_date <= 今天 且 payment_status <> '已结清'（未结清/部分收款）→ status 改为 '已逾期'
    返回 {'expired': [...], 'overdue': [...]} 供前端提示。
    """
    result = {"expired": [], "overdue": []}
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if conn is None:
            return result
        cursor = conn.cursor()
        today = datetime.date.today().isoformat()

        # 1) 到期且已结清 → 已完成
        cursor.execute("""
            SELECT contract_no, house_no FROM contracts
            WHERE status = '执行中' AND end_date <= ? AND payment_status = '已结清'
            ORDER BY end_date ASC
        """, (today,))
        expired = cursor.fetchall()
        if expired:
            cursor.execute("""
                UPDATE contracts SET status = '已完成'
                WHERE status = '执行中' AND end_date <= ? AND payment_status = '已结清'
            """, (today,))
            result["expired"] = [{"contract_no": r[0], "house_no": r[1]} for r in expired]

        # 2) 到期且未结清（含「部分收款」）→ 已逾期
        cursor.execute("""
            SELECT contract_no, house_no FROM contracts
            WHERE status = '执行中' AND end_date <= ? AND payment_status != '已结清'
            ORDER BY end_date ASC
        """, (today,))
        overdue = cursor.fetchall()
        if overdue:
            cursor.execute("""
                UPDATE contracts SET status = '已逾期'
                WHERE status = '执行中' AND end_date <= ? AND payment_status != '已结清'
            """, (today,))
            result["overdue"] = [{"contract_no": r[0], "house_no": r[1]} for r in overdue]

        conn.commit()
        if (result["expired"] or result["overdue"]) and username:
            detail = []
            if result["expired"]:
                detail.append(f"已完成 {len(result['expired'])} 个到期已结清合同")
            if result["overdue"]:
                detail.append(f"已逾期 {len(result['overdue'])} 个到期未结清合同")
            _log_op(username, "合同管理", "自动更新合同状态", "成功", "; ".join(detail))
        return result
    except Exception:
        try:
            if conn:
                conn.rollback()
        except Exception:
            pass
        return result
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def _log_op(username, module, content, result="成功", detail=None):
    try:
        record_operation(username=username, operation_module=module,
                         operation_content=content, operation_result=result, detail=detail)
    except Exception:
        pass


# ================================================================ 合同管理
CONTRACT_LIST_SQL = """
SELECT c.contract_no, c.sign_date, c.house_no, h.house_type, c.house_location, c.lessee, c.tenant,
       c.start_date, c.end_date,
       COALESCE(rp.period_end, '') as rent_period_end,
       c.status, c.payment_method, c.monthly_rent, c.quarterly_rent, c.total_rent, c.annual_rent, c.deposit,
       COALESCE(rr.received_rent, 0) as received_rent,
       c.payment_status, c.remarks
 FROM contracts c
LEFT JOIN houses h ON c.house_no = h.house_no
LEFT JOIN (SELECT contract_no, SUM(amount) AS received_rent FROM rent_records GROUP BY contract_no) rr ON rr.contract_no = c.contract_no
LEFT JOIN (SELECT contract_no, period_end,
                  ROW_NUMBER() OVER (PARTITION BY contract_no ORDER BY receipt_date DESC, id DESC) AS rn
           FROM rent_records) rp
       ON rp.contract_no = c.contract_no AND rp.rn = 1
"""

CONTRACT_SEARCH_COLS = [
    "c.contract_no", "c.sign_date", "c.sign_year_month", "c.house_location",
    "h.house_type", "c.lessor", "c.legal_representative", "c.person_in_charge",
    "c.contact_phone", "c.lessee", "c.tenant", "c.tenant_id", "c.tenant_phone",
    "c.start_date", "c.end_date", "c.status", "c.payment_method", "c.usage",
    "c.utility_method", "c.remarks", "c.payment_status",
]

# received_rent 列（别名非白名单列）在迁移库需手动 /100
def _fix_received_rent(cursor, rows):
    try:
        if rows and DatabaseUtils._check_money_migrated():
            desc = cursor.description
            idx = None
            if desc:
                for i, d in enumerate(desc):
                    if d and d[0] == 'received_rent':
                        idx = i
                        break
            if idx is not None:
                return [row[:idx] + (row[idx] / 100.0 if row[idx] is not None else 0,) + row[idx+1:] for row in rows]
    except Exception:
        pass
    return rows


def _contract_filter_clause(search: str = "", statuses: Optional[List[str]] = None,
                            payment_statuses: Optional[List[str]] = None,
                            start_date_from: str = "", end_date_to: str = "") -> tuple:
    """合同列表 / 统计共用的 WHERE 条件（一处定义，保证列表与底部统计口径一致）

    日期条件（均为可选，空值表示不限制；库内日期为 YYYY-MM-DD 文本，可直接比大小）：
      语义 = 「合同租期 与 查询区间 有交集」，即
          合同到期日期 >= start_date_from  且  合同起租日期 <= end_date_to
      这样跨年合同（如 2025-10-25 ~ 2026-10-24）也能被「2026 年度」查到；
      参数名与页面「起租日期 / 到期日期」两个输入框一一对应（取的是框里的值，不是被比较的列）。
      若需改成「合同完全落在区间内」，把下面两个比较符换成 c.start_date >= ? / c.end_date <= ?。
    """
    conds, params = [], []
    if search:
        like = f"%{search}%"
        conds.append("(" + " OR ".join([f"{c} LIKE ?" for c in CONTRACT_SEARCH_COLS]) + ")")
        params.extend([like] * len(CONTRACT_SEARCH_COLS))
    if statuses:
        conds.append("c.status IN (%s)" % ",".join("?" * len(statuses)))
        params.extend(statuses)
    if payment_statuses:
        conds.append("c.payment_status IN (%s)" % ",".join("?" * len(payment_statuses)))
        params.extend(payment_statuses)
    if start_date_from:
        conds.append("c.end_date >= ?")   # 合同到期不早于区间起点
        params.append(start_date_from)
    if end_date_to:
        conds.append("c.start_date <= ?")  # 合同起租不晚于区间终点
        params.append(end_date_to)
    return (" WHERE " + " AND ".join(conds)) if conds else "", params


def list_contracts(search: str = "", statuses: Optional[List[str]] = None,
                   payment_statuses: Optional[List[str]] = None,
                   start_date_from: str = "", end_date_to: str = "") -> List[dict]:
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return []
        where, params = _contract_filter_clause(search, statuses, payment_statuses,
                                                start_date_from, end_date_to)
        cursor = DatabaseUtils.execute_query(conn, CONTRACT_LIST_SQL + where + " ORDER BY c.contract_no", params)
        rows = _fix_received_rent(cursor, _rows(cursor))
        keys = ["contract_no", "sign_date", "house_no", "house_type", "house_location", "lessee", "tenant",
                "start_date", "end_date", "rent_period_end", "status", "payment_method",
                "monthly_rent", "quarterly_rent", "total_rent", "annual_rent", "deposit", "received_rent",
                "payment_status", "remarks"]
        result = []
        for r in rows:
            d = dict(zip(keys, list(r) + [None] * (len(keys) - len(r))))
            # 应收总租金 = 合同总租 - 已收（租金调整后 total_rent 为含首尾分段累加口径）
            try:
                d["receivable_rent"] = max(0.0, float(d.get("total_rent") or 0) - float(d.get("received_rent") or 0))
            except Exception:
                d["receivable_rent"] = 0.0
            result.append(d)
        return result
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def get_contract(contract_no: str) -> Optional[dict]:
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return None
        cursor = DatabaseUtils.execute_query(conn, "SELECT * FROM contracts WHERE contract_no = ?", (contract_no,))
        row = cursor.fetchone() if cursor else None
        if row is None:
            return None
        keys = [d[0] for d in cursor.description] if cursor.description else []
        return dict(zip(keys, row))
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def next_contract_no() -> str:
    """生成合同编号: HT + 4位年份 + 3位序号（对齐桌面版 generateContractNo）"""
    current_year = str(datetime.date.today().year)
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return f"HT{current_year}001"
        cursor = conn.cursor()
        cursor.execute("SELECT MAX(contract_no) FROM contracts WHERE contract_no LIKE ?", (f"HT{current_year}%",))
        row = cursor.fetchone()
        max_no = row[0] if row else None
        if max_no:
            try:
                seq = int(str(max_no)[6:]) + 1
            except ValueError:
                seq = 1
        else:
            seq = 1
        return f"HT{current_year}{seq:03d}"
    except Exception:
        return f"HT{current_year}001"
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def _calc_rents(sign_date, start_date, end_date, monthly_rent):
    """按原桌面版规则计算派生租金字段（total_rent 用含首尾整月数，与租金调整分段口径一致）"""
    annual_rent = float(monthly_rent or 0) * 12
    try:
        s = datetime.datetime.strptime(start_date, "%Y-%m-%d")
        e = datetime.datetime.strptime(end_date, "%Y-%m-%d")
        months = (e.year - s.year) * 12 + (e.month - s.month)
        if e.day >= s.day:
            months += 1  # 含首尾整月数（对齐 _segment_month_count，修复月初~月末型少算1个月）
        total_rent = float(monthly_rent or 0) * months
    except Exception:
        total_rent = annual_rent
    try:
        sd = datetime.datetime.strptime(sign_date, "%Y-%m-%d")
        sign_year_month = f"{sd.year}-{sd.month:02d}"
    except Exception:
        sign_year_month = datetime.datetime.now().strftime("%Y-%m")
    return sign_year_month, annual_rent, total_rent


def add_contract(data: dict, username: str) -> Tuple[bool, str]:
    contract_no = (data.get("contract_no") or "").strip()
    if not contract_no:
        return False, "合同编号不能为空"
    monthly_rent = float(data.get("monthly_rent") or 0)
    sign_year_month, annual_rent, total_rent = _calc_rents(
        data.get("sign_date"), data.get("start_date"), data.get("end_date"), monthly_rent
    )
    # 续签来源合同编号（续签预填保存新合同时由前端传入）：
    # 仅当原合同真实存在且不是自己时才记录，避免悬空链接（原合同不存在时静默忽略，不影响新增）
    renewed_from = (data.get("renewed_from") or "").strip() or None
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return False, "无法获取数据库连接"
        if renewed_from:
            if renewed_from == contract_no:
                renewed_from = None
            else:
                _cur = DatabaseUtils.execute_query(
                    conn, "SELECT 1 FROM contracts WHERE contract_no = ?", (renewed_from,))
                if _cur is None or not _cur.fetchone():
                    renewed_from = None
        cur = DatabaseUtils.execute_query(conn, """INSERT INTO contracts (
            contract_no, sign_date, sign_year_month, house_no, house_location, house_area,
            lessor, legal_representative, person_in_charge, contact_phone,
            lessee, tenant, tenant_id, tenant_phone,
            start_date, end_date, status, payment_method, monthly_rent,
            total_rent, annual_rent, deposit, usage, utility_method, water_fee, electricity_fee,
            remarks, quarterly_rent, house_type, attachment_path, payment_status, renewed_from
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (contract_no, data.get("sign_date"), sign_year_month,
         data.get("house_no"), data.get("house_location"), data.get("house_area"),
         data.get("lessor"), data.get("legal_representative"), data.get("person_in_charge"), data.get("contact_phone"),
         data.get("lessee"), data.get("tenant"), data.get("tenant_id"), data.get("tenant_phone"),
         data.get("start_date"), data.get("end_date"), data.get("status") or "执行中", data.get("payment_method"),
         monthly_rent, total_rent, annual_rent, data.get("deposit") or 0,
         data.get("usage"), data.get("utility_method"), data.get("water_fee"), data.get("electricity_fee"),
         data.get("remarks"), data.get("quarterly_rent"), data.get("house_type"), data.get("attachment_path"),
         normalize_payment_status(data.get("payment_status")), renewed_from))
        if cur is None:
            return False, "合同编号已存在或数据不完整"
        conn.commit()
        _log_op(username, "合同管理", "添加合同", "成功",
                f"合同编号: {contract_no}, 承租方: {data.get('lessee')}"
                + (f", 续签自: {renewed_from}" if renewed_from else ""))
        return True, "合同添加成功"
    except Exception as e:
        return False, f"添加合同失败: {str(e)}"
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def update_contract(contract_no: str, data: dict, username: str) -> Tuple[bool, str]:
    monthly_rent = float(data.get("monthly_rent") or 0)
    sign_year_month, annual_rent, total_rent = _calc_rents(
        data.get("sign_date"), data.get("start_date"), data.get("end_date"), monthly_rent
    )
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return False, "无法获取数据库连接"
        cur = DatabaseUtils.execute_query(conn, """UPDATE contracts SET
            sign_date = ?, sign_year_month = ?, house_no = ?, house_location = ?, house_area = ?,
            lessor = ?, legal_representative = ?, person_in_charge = ?, contact_phone = ?,
            lessee = ?, tenant = ?, tenant_id = ?, tenant_phone = ?,
            start_date = ?, end_date = ?, status = ?, payment_method = ?, monthly_rent = ?, total_rent = ?, annual_rent = ?, deposit = ?,
            usage = ?, utility_method = ?, water_fee = ?, electricity_fee = ?, remarks = ?, attachment_path = ?
            WHERE contract_no = ?""",
        (data.get("sign_date"), sign_year_month,
         data.get("house_no"), data.get("house_location"), data.get("house_area"),
         data.get("lessor"), data.get("legal_representative"), data.get("person_in_charge"), data.get("contact_phone"),
         data.get("lessee"), data.get("tenant"), data.get("tenant_id"), data.get("tenant_phone"),
         data.get("start_date"), data.get("end_date"), data.get("status") or "执行中", data.get("payment_method"),
         monthly_rent, total_rent, annual_rent, data.get("deposit") or 0,
         data.get("usage"), data.get("utility_method"), data.get("water_fee"), data.get("electricity_fee"),
         data.get("remarks"), data.get("attachment_path"), contract_no))
        if cur is None:
            return False, "更新合同失败（数据可能不合法）"
        conn.commit()
        _log_op(username, "合同管理", "编辑合同", "成功", f"合同编号: {contract_no}")
        return True, "合同更新成功"
    except Exception as e:
        return False, f"更新合同失败: {str(e)}"
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def delete_contract(contract_no: str, username: str) -> Tuple[bool, str, int]:
    """删除合同：若已发生收款行为则禁止删除。返回 (是否成功, 消息, 收款次数)

    续签联动（2026-09-17）：若被删合同是「续签产生的新合同」（renewed_from 有值；
    历史数据无该值时按同房屋前序已续签合同兜底定位），则在同一事务内把原合同
    is_renewed 复位为「未续签」——删除与状态复位要么同时成功、要么同时回滚，保证数据一致。
    """
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return False, "无法获取数据库连接", 0
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM rent_records WHERE contract_no = ?", (contract_no,))
        payment_count = cursor.fetchone()[0] or 0
        if payment_count > 0:
            return False, f"该合同已发生 {payment_count} 次收款，不能删除", payment_count
        # 删除前读取续签来源信息（旧数据可能没有 renewed_from 值，需按同房屋前序合同兜底）
        cursor.execute("SELECT renewed_from, house_no, sign_date FROM contracts WHERE contract_no = ?",
                       (contract_no,))
        row = cursor.fetchone()
        if row is None:
            return False, "找不到该合同，可能已被删除", 0
        renewed_from, house_no, sign_date = row[0], row[1], row[2]
        conn.execute("BEGIN TRANSACTION")
        try:
            cursor.execute("DELETE FROM rent_records WHERE contract_no = ?", (contract_no,))
            cursor.execute("DELETE FROM contracts WHERE contract_no = ?", (contract_no,))
            if cursor.rowcount == 0:
                conn.rollback()
                return False, "找不到该合同，可能已被删除", 0
            # 同步复位原合同「续签状态」（与删除同事务，保证数据一致）
            reset_target, reset_note = None, ""
            if renewed_from:
                cursor.execute("SELECT 1 FROM contracts WHERE contract_no = ?", (renewed_from,))
                if cursor.fetchone():
                    reset_target = renewed_from
                    reset_note = f"续签来源合同 {renewed_from}"
                else:
                    # 原合同已不存在（可能已被先行删除）：不阻塞本次删除，仅记录
                    reset_note = f"续签来源合同 {renewed_from} 已不存在，跳过复位"
            elif house_no:
                # 兜底（历史数据无 renewed_from）：同房屋、已标记已续签、签约日期早于被删合同的最近一张
                cursor.execute(
                    """SELECT contract_no FROM contracts
                       WHERE is_renewed = '已续签' AND house_no = ? AND sign_date < ?
                       ORDER BY sign_date DESC LIMIT 1""", (house_no, sign_date or ""))
                r2 = cursor.fetchone()
                if r2:
                    reset_target = r2[0]
                    reset_note = f"按同房屋前序合同兜底定位 {r2[0]}"
            if reset_target:
                cursor.execute(
                    "UPDATE contracts SET is_renewed = '未续签' WHERE contract_no = ? AND is_renewed = '已续签'",
                    (reset_target,))
                if cursor.rowcount:
                    _log_op(username, "合同管理", "删除合同", "成功",
                            f"合同编号: {contract_no}；已同步复位{reset_note}的续签状态为未续签")
                else:
                    # 原合同存在但未处于已续签状态（可能已被人工复位）：不阻塞删除，仅记录
                    _log_op(username, "合同管理", "删除合同", "成功",
                            f"合同编号: {contract_no}；{reset_note}未处于已续签状态，无需复位")
            else:
                _log_op(username, "合同管理", "删除合同", "成功",
                        f"合同编号: {contract_no}；{reset_note or '未找到续签来源合同，仅删除本合同'}")
            conn.commit()
            if reset_target:
                return True, f"合同删除成功，原合同（{reset_target}）续签状态已恢复为未续签", 0
            return True, "合同删除成功", 0
        except sqlite3.Error as e:
            conn.rollback()
            return False, f"删除数据失败: {str(e)}", 0
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def get_contract_payments(contract_no: str) -> List[dict]:
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return []
        cursor = DatabaseUtils.execute_query(conn, """SELECT contract_no, lessee, tenant, receipt_date, amount,
            period_start, period_end, account, invoice_date, description, house_no, payment_method, payment_status
            FROM rent_records WHERE contract_no = ? ORDER BY receipt_date""", (contract_no,))
        rows = _rows(cursor)
        keys = ["contract_no", "lessee", "tenant", "receipt_date", "amount", "period_start", "period_end",
                "account", "invoice_date", "description", "house_no", "payment_method", "payment_status"]
        return [dict(zip(keys, r)) for r in rows]
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def renew_contract(contract_no: str, username: str) -> Tuple[bool, str]:
    """续签：将原合同标记已完成/已续签"""
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return False, "无法获取数据库连接"
        cursor = conn.cursor()
        cursor.execute("SELECT is_renewed FROM contracts WHERE contract_no = ?", (contract_no,))
        row = cursor.fetchone()
        if row is None:
            return False, "找不到该合同"
        if row[0] == "已续签":
            return False, f"该合同（{contract_no}）已续签，不能重复续签"
        cursor.execute("UPDATE contracts SET status = '已完成', is_renewed = '已续签' WHERE contract_no = ?", (contract_no,))
        conn.commit()
        _log_op(username, "合同管理", "续签合同", "成功", f"将合同 {contract_no} 状态更新为已完成并标记为已续签")
        return True, "合同状态已更新为已完成（已续签），请创建新合同"
    except Exception as e:
        return False, f"续签失败: {str(e)}"
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def contract_statistics(search: str = "", statuses: Optional[List[str]] = None,
                        payment_statuses: Optional[List[str]] = None,
                        start_date_from: str = "", end_date_to: str = "") -> dict:
    """合同列表底部统计信息（对齐原版 ui_contract_tab.updateStatistics 口径）
    支持按搜索词、状态、收款情况、起租/到期日期过滤，使统计值反映当前筛选结果"""
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return {}
        # 构建 WHERE 子句（与 list_contracts 共用同一函数，口径必然一致）
        where, params = _contract_filter_clause(search, statuses, payment_statuses,
                                                start_date_from, end_date_to)
        conds = bool(where)

        # 合同总数 / 状态分布 / 收款情况分布 / 租金合计 / 押金合计
        base_sql = "FROM contracts c LEFT JOIN houses h ON c.house_no = h.house_no"
        cursor = DatabaseUtils.execute_query(conn, f"SELECT COUNT(*) {base_sql}{where}", params)
        total = _rows(cursor)[0][0] if cursor else 0
        cursor = DatabaseUtils.execute_query(conn, f"SELECT c.status, COUNT(*) {base_sql}{where} GROUP BY c.status", params)
        status_counts = {r[0]: r[1] for r in _rows(cursor)}
        cursor = DatabaseUtils.execute_query(conn, f"SELECT c.payment_status, COUNT(*) {base_sql}{where} GROUP BY c.payment_status", params)
        pay_counts = {r[0]: r[1] for r in _rows(cursor)}
        cursor = DatabaseUtils.execute_query(conn,
            f"SELECT SUM(monthly_rent), SUM(quarterly_rent), SUM(annual_rent), SUM(deposit) {base_sql}{where}",
            params)
        sums = _rows(cursor)[0] if cursor else (0, 0, 0, 0)
        # 合同总租合计（含首尾分段累加口径，供应收总租金计算）
        cursor = DatabaseUtils.execute_query(conn,
            f"SELECT SUM(total_rent) {base_sql}{where}", params)
        total_sum = _rows(cursor)[0][0] if cursor else 0
        # 已收租金：仅统计当前过滤合同关联的 rent_records（与列表口径一致）
        if conds:
            contract_nos_sub = f"SELECT c.contract_no {base_sql}{where}"
            cursor = DatabaseUtils.execute_query(
                conn,
                f"SELECT SUM(amount) FROM rent_records r WHERE r.contract_no IN ({contract_nos_sub})",
                params)
        else:
            cursor = DatabaseUtils.execute_query(conn, "SELECT SUM(amount) FROM rent_records")
        received = _rows(cursor)[0][0] if cursor else 0
        # 应收总租金 = 合同总租合计 - 已收（对齐列表「应收总租金」口径，含首尾分段累加）
        try:
            receivable = max(0.0, float(total_sum or 0) - float(received or 0))
        except Exception:
            receivable = 0.0
        return {
            "total": total,
            "status_counts": status_counts,
            "monthly_rent_total": sums[0] or 0,
            "quarterly_rent_total": sums[1] or 0,
            "annual_rent_total": sums[2] or 0,
            "deposit_total": sums[3] or 0,
            "received_rent": received,
            "receivable_rent": receivable,
            "payment_counts": pay_counts,
            "settled_count": pay_counts.get(PAYMENT_STATUS_SETTLED, 0),
            "partial_count": pay_counts.get(PAYMENT_STATUS_PARTIAL, 0),
            "unsettled_count": pay_counts.get(PAYMENT_STATUS_UNSETTLED, 0),
        }
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


# ================================================================ 租金管理
def _rent_filter_clause(statuses: Optional[List[str]] = None, search: str = "",
                        receipt_date_from: str = "", receipt_date_to: str = "") -> tuple:
    """租金列表 / 统计共用的 WHERE 条件（一处定义，保证列表与底部统计口径一致）

    收款日期为「时点」而非区间，故直接按闭区间过滤（均可选，空值表示不限制）：
      receipt_date_from —— 收款日期不早于该值（r.receipt_date >= ?）
      receipt_date_to   —— 收款日期不晚于该值（r.receipt_date <= ?）
    """
    conds, params = [], []
    if statuses:
        conds.append("r.payment_status IN (%s)" % ",".join("?" * len(statuses)))
        params.extend(statuses)
    if search:
        like = f"%{search}%"
        conds.append("(r.contract_no LIKE ? OR r.lessee LIKE ? OR r.tenant LIKE ? OR c.house_no LIKE ?)")
        params.extend([like] * 4)
    if receipt_date_from:
        conds.append("r.receipt_date >= ?")
        params.append(receipt_date_from)
    if receipt_date_to:
        conds.append("r.receipt_date <= ?")
        params.append(receipt_date_to)
    return (" WHERE " + " AND ".join(conds)) if conds else "", params


def list_rent_records(statuses: Optional[List[str]] = None, search: str = "",
                      receipt_date_from: str = "", receipt_date_to: str = "") -> List[dict]:
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return []
        sql = """SELECT r.id, r.contract_no, c.house_no, r.lessee, r.tenant, r.receipt_date,
                 r.amount, r.period_start, r.period_end, r.account, r.invoice_date, r.description,
                 r.payment_method, r.payment_status, r.monthly_rent
            FROM rent_records r
            LEFT JOIN contracts c ON r.contract_no = c.contract_no"""
        where, params = _rent_filter_clause(statuses, search, receipt_date_from, receipt_date_to)
        if where:
            sql += where
        sql += " ORDER BY r.receipt_date DESC, r.id DESC"
        cursor = DatabaseUtils.execute_query(conn, sql, params)
        rows = _rows(cursor)
        keys = ["id", "contract_no", "house_no", "lessee", "tenant", "receipt_date", "amount",
                "period_start", "period_end", "account", "invoice_date", "description",
                "payment_method", "payment_status", "monthly_rent"]
        return [dict(zip(keys, list(r) + [None] * (len(keys) - len(r)))) for r in rows]
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def get_rent_record(record_id: int) -> Optional[dict]:
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return None
        cursor = DatabaseUtils.execute_query(conn, "SELECT * FROM rent_records WHERE id = ?", (record_id,))
        row = cursor.fetchone() if cursor else None
        if row is None:
            return None
        keys = [d[0] for d in cursor.description] if cursor.description else []
        return dict(zip(keys, row))
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def recalc_all_payment_statuses(username: str = "") -> Tuple[bool, str, dict]:
    """按「累计已收 vs 合同应收」全量重算收款状态，使合同管理与租金管理两个页面完全一致。

    用于修复历史脏数据（如误判「已结清」的部分收款合同），也可作为日常校准入口。
    返回 (是否成功, 消息, {"changed": [变更明细], "contracts": 处理合同数})
    """
    conn = None
    changed = []
    count = 0
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return False, "无法获取数据库连接", {"changed": changed, "contracts": 0}
        cursor = conn.cursor()
        cursor.execute("SELECT contract_no, lessee, total_rent, annual_rent, payment_status FROM contracts ORDER BY contract_no")
        contracts = cursor.fetchall()
        conn.execute("BEGIN TRANSACTION")
        try:
            for contract_no, lessee, total_rent, annual_rent, old_status in contracts:
                count += 1
                cursor.execute("SELECT COALESCE(SUM(amount), 0) FROM rent_records WHERE contract_no = ?", (contract_no,))
                received = cursor.fetchone()[0] or 0
                total = total_rent if (total_rent is not None and float(total_rent or 0) != 0) else annual_rent
                new_status = compute_payment_status(received, total)
                if new_status != old_status:
                    # 记录变更前该合同名下的收款记录条数，便于报告影响面
                    cursor.execute("SELECT COUNT(*) FROM rent_records WHERE contract_no = ?", (contract_no,))
                    rcnt = cursor.fetchone()[0] or 0
                    changed.append({
                        "contract_no": contract_no, "lessee": lessee,
                        "old_status": old_status, "new_status": new_status,
                        "total_rent": (float(total or 0)) / 100.0,
                        "received": float(received) / 100.0,
                        "rent_records": rcnt,
                    })
                cursor.execute("UPDATE contracts SET payment_status = ? WHERE contract_no = ?", (new_status, contract_no))
                cursor.execute("UPDATE rent_records SET payment_status = ? WHERE contract_no = ?", (new_status, contract_no))
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        msg = f"已重算 {count} 个合同的收款状态，修正 {len(changed)} 处"
        if username:
            _log_op(username, "系统维护", "重算收款状态", "成功", msg)
        return True, msg, {"changed": changed, "contracts": count}
    except Exception as e:
        return False, f"重算收款状态失败: {str(e)}", {"changed": [], "contracts": 0}
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def add_rent_record(data: dict, username: str) -> Tuple[bool, str]:
    contract_no = (data.get("contract_no") or "").strip()
    if not contract_no:
        return False, "合同编号不能为空"
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return False, "无法获取数据库连接"
        conn.execute("BEGIN TRANSACTION")
        try:
            cur = DatabaseUtils.execute_query(conn, """INSERT INTO rent_records (
                contract_no, lessee, tenant, receipt_date, amount, period_start, period_end,
                account, invoice_date, description, payment_status, house_no, payment_method, monthly_rent
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (contract_no, data.get("lessee"), data.get("tenant"),
             data.get("receipt_date"), data.get("amount"),
             data.get("period_start"), data.get("period_end"),
             data.get("account"), data.get("invoice_date"),
             data.get("description"), normalize_payment_status(data.get("payment_status")),
             data.get("house_no"), data.get("payment_method"), data.get("monthly_rent")))
            if cur is None:
                conn.rollback()
                return False, "租金记录数据不完整或违反完整性约束"
            # 收款状态一律由「累计已收 vs 合同应收」重算，不采信前端传入值
            new_status = recalc_contract_payment_status(conn, contract_no)
            # 若重算后已结清且期间截止 ≤ 今天，合同状态改为已完成
            if new_status == PAYMENT_STATUS_SETTLED:
                try:
                    period_end = datetime.datetime.strptime(data.get("period_end", ""), "%Y-%m-%d").date()
                    if period_end <= datetime.date.today():
                        conn.cursor().execute("UPDATE contracts SET status = '已完成' WHERE contract_no = ?", (contract_no,))
                except Exception:
                    pass
            conn.commit()
            _log_op(username, "租金管理", "添加租金记录", "成功",
                    f"合同编号: {contract_no}, 收款日期: {data.get('receipt_date')}, 金额: {data.get('amount')}")
            return True, "租金记录添加成功"
        except sqlite3.IntegrityError as e:
            conn.rollback()
            return False, f"租金记录数据不完整或违反完整性约束: {str(e)}"
        except sqlite3.Error as e:
            conn.rollback()
            return False, f"数据库错误: {str(e)}"
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def update_rent_record(record_id: int, data: dict, username: str) -> Tuple[bool, str]:
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return False, "无法获取数据库连接"
        conn.execute("BEGIN TRANSACTION")
        try:
            # 记录可能改挂到别的合同 → 需同时重算新旧两个合同
            old_no = None
            q = DatabaseUtils.execute_query(conn, "SELECT contract_no FROM rent_records WHERE id = ?", (record_id,))
            qrows = _rows(q) if q else []
            if qrows:
                old_no = qrows[0][0]
            cur = DatabaseUtils.execute_query(conn, """UPDATE rent_records SET
                contract_no=?, lessee=?, tenant=?, receipt_date=?, amount=?, period_start=?, period_end=?,
                account=?, invoice_date=?, description=?, payment_status=?, house_no=?, payment_method=?, monthly_rent=?
                WHERE id=?""",
            (data.get("contract_no"), data.get("lessee"), data.get("tenant"),
             data.get("receipt_date"), data.get("amount"),
             data.get("period_start"), data.get("period_end"),
             data.get("account"), data.get("invoice_date"),
             data.get("description"), normalize_payment_status(data.get("payment_status")),
             data.get("house_no"), data.get("payment_method"), data.get("monthly_rent"), record_id))
            if cur is None:
                conn.rollback()
                return False, "更新失败（数据可能不合法）"
            new_no = data.get("contract_no")
            new_status = recalc_contract_payment_status(conn, new_no)
            if old_no and old_no != new_no:
                recalc_contract_payment_status(conn, old_no)
            if new_status == PAYMENT_STATUS_SETTLED:
                try:
                    period_end = datetime.datetime.strptime(data.get("period_end", ""), "%Y-%m-%d").date()
                    if period_end <= datetime.date.today():
                        conn.cursor().execute("UPDATE contracts SET status = '已完成' WHERE contract_no = ?", (data.get("contract_no"),))
                except Exception:
                    pass
            conn.commit()
            _log_op(username, "租金管理", "编辑租金记录", "成功", f"记录ID: {record_id}")
            return True, "租金记录更新成功"
        except sqlite3.Error as e:
            conn.rollback()
            return False, f"更新失败: {str(e)}"
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def delete_rent_record(record_id: int, username: str) -> Tuple[bool, str]:
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return False, "无法获取数据库连接"
        # 先取被删记录的合同编号（删除后需重算合同收款状态）
        q = DatabaseUtils.execute_query(conn, "SELECT contract_no FROM rent_records WHERE id = ?", (record_id,))
        qrows = _rows(q) if q else []
        DatabaseUtils.execute_query(conn, "DELETE FROM rent_records WHERE id = ?", (record_id,))
        # 删除后重算该合同及其剩余收款记录的收款状态，避免合同列表仍显示旧状态
        if qrows:
            recalc_contract_payment_status(conn, qrows[0][0])
        conn.commit()
        _log_op(username, "租金管理", "删除租金记录", "成功", f"记录ID: {record_id}")
        return True, "租金记录删除成功"
    except Exception as e:
        return False, f"删除失败: {str(e)}"
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def rent_statistics(statuses: Optional[List[str]] = None, search: str = "",
                    receipt_date_from: str = "", receipt_date_to: str = "") -> dict:
    """租金列表底部统计信息（对齐原版 ui_rent_tab.updateStatistics 口径）
    支持按状态、搜索词、收款日期区间过滤，使统计值反映当前筛选结果
    
    关键实现细节：
    - SUM(amount) 不使用 r. 前缀或 COALESCE 包裹，确保 MoneyCursor 能通过
      r'^(SUM|TOTAL)\\(([\\w]+)\\)$' 检测列名并做分→元转换
    """
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return {}
        # 构建 WHERE 子句（与 list_rent_records 共用同一函数，口径必然一致）
        where, params = _rent_filter_clause(statuses, search, receipt_date_from, receipt_date_to)
        base_sql = "FROM rent_records r LEFT JOIN contracts c ON r.contract_no = c.contract_no"

        # 记录总数
        cursor = DatabaseUtils.execute_query(conn, f"SELECT COUNT(*) {base_sql}{where}", params)
        total = _rows(cursor)[0][0] if cursor else 0
        # 收款情况分布
        cursor = DatabaseUtils.execute_query(conn, f"SELECT r.payment_status, COUNT(*) {base_sql}{where} GROUP BY r.payment_status", params)
        pay_counts = {r[0]: r[1] for r in _rows(cursor)}
        # 收款金额合计
        # SUM(amount) 不带表前缀，MoneyCursor 通过列名 SUM(amount) 检测分→元
        cursor = DatabaseUtils.execute_query(conn, f"SELECT SUM(amount) {base_sql}{where}", params)
        amount_rows = _rows(cursor)
        total_amount = amount_rows[0][0] if amount_rows and amount_rows[0][0] is not None else 0.0

        return {
            "count": total,
            "total_amount": total_amount,
            "settled_count": pay_counts.get(PAYMENT_STATUS_SETTLED, 0),
            "partial_count": pay_counts.get(PAYMENT_STATUS_PARTIAL, 0),
            "unsettled_count": pay_counts.get(PAYMENT_STATUS_UNSETTLED, 0),
        }
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


# ================================================================ 基础资料
def list_houses(search: str = "") -> List[dict]:
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return []
        sql = "SELECT id, house_no, house_type, house_location, house_area, usage FROM houses"
        params = []
        if search:
            like = f"%{search}%"
            sql += " WHERE house_no LIKE ? OR house_type LIKE ? OR house_location LIKE ? OR usage LIKE ?"
            params = [like] * 4
        sql += " ORDER BY house_no"
        cursor = DatabaseUtils.execute_query(conn, sql, params)
        rows = _rows(cursor)
        keys = ["id", "house_no", "house_type", "house_location", "house_area", "usage"]
        return [dict(zip(keys, list(r) + [None] * (len(keys) - len(r)))) for r in rows]
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def add_house(data: dict, username: str) -> Tuple[bool, str]:
    house_no = (data.get("house_no") or "").strip()
    if not house_no:
        return False, "房屋编号不能为空"
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return False, "无法获取数据库连接"
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM houses WHERE house_no = ?", (house_no,))
        if cursor.fetchone():
            return False, "房屋编号已存在，请使用其他编号"
        usage = data.get("usage") or "商用"
        if usage == "全部":
            usage = "商用"
        cur = DatabaseUtils.execute_query(conn, "INSERT INTO houses (house_no, house_type, house_location, house_area, usage) VALUES (?, ?, ?, ?, ?)",
            (house_no, data.get("house_type"), data.get("house_location"), data.get("house_area"), usage))
        if cur is None:
            return False, "房屋编号已存在或数据不合法"
        conn.commit()
        _log_op(username, "基础资料", "添加房屋", "成功", f"编号: {house_no}")
        return True, "房屋资料添加成功"
    except Exception as e:
        return False, f"保存失败: {str(e)}"
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def update_house(house_id: int, data: dict, username: str) -> Tuple[bool, str]:
    house_no = (data.get("house_no") or "").strip()
    if not house_no:
        return False, "房屋编号不能为空"
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return False, "无法获取数据库连接"
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM houses WHERE house_no = ? AND id != ?", (house_no, house_id))
        if cursor.fetchone():
            return False, "房屋编号已存在，请使用其他编号"
        usage = data.get("usage") or "商用"
        if usage == "全部":
            usage = "商用"
        cur = DatabaseUtils.execute_query(conn, "UPDATE houses SET house_no=?, house_type=?, house_location=?, house_area=?, usage=? WHERE id=?",
            (house_no, data.get("house_type"), data.get("house_location"), data.get("house_area"), usage, house_id))
        if cur is None:
            return False, "房屋编号已存在或数据不合法"
        conn.commit()
        _log_op(username, "基础资料", "编辑房屋", "成功", f"ID: {house_id}")
        return True, "房屋资料编辑成功"
    except Exception as e:
        return False, f"保存失败: {str(e)}"
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def delete_house(house_id: int, username: str) -> Tuple[bool, str]:
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return False, "无法获取数据库连接"
        DatabaseUtils.execute_query(conn, "DELETE FROM houses WHERE id = ?", (house_id,))
        conn.commit()
        _log_op(username, "基础资料", "删除房屋", "成功", f"ID: {house_id}")
        return True, "房屋资料删除成功"
    except Exception as e:
        return False, f"删除失败: {str(e)}"
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def list_tenants(search: str = "") -> List[dict]:
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return []
        sql = "SELECT id, tenant_name, contact_person, contact_id, contact_phone FROM tenants"
        params = []
        if search:
            like = f"%{search}%"
            sql += " WHERE tenant_name LIKE ? OR contact_person LIKE ? OR contact_phone LIKE ?"
            params = [like] * 3
        sql += " ORDER BY tenant_name"
        cursor = DatabaseUtils.execute_query(conn, sql, params)
        rows = _rows(cursor)
        keys = ["id", "tenant_name", "contact_person", "contact_id", "contact_phone"]
        return [dict(zip(keys, r)) for r in rows]
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def add_tenant(data: dict, username: str) -> Tuple[bool, str]:
    name = (data.get("tenant_name") or "").strip()
    if not name:
        return False, "承租人名称不能为空"
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return False, "无法获取数据库连接"
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM tenants WHERE tenant_name = ?", (name,))
        if cursor.fetchone():
            return False, "承租人名称已存在，请使用其他名称"
        cur = DatabaseUtils.execute_query(conn, "INSERT INTO tenants (tenant_name, contact_person, contact_id, contact_phone) VALUES (?, ?, ?, ?)",
            (name, data.get("contact_person"), data.get("contact_id"), data.get("contact_phone")))
        if cur is None:
            return False, "承租人名称已存在或数据不合法"
        conn.commit()
        _log_op(username, "基础资料", "添加承租人", "成功", f"名称: {name}")
        return True, "承租人资料添加成功"
    except Exception as e:
        return False, f"保存失败: {str(e)}"
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def update_tenant(tenant_id: int, data: dict, username: str) -> Tuple[bool, str]:
    name = (data.get("tenant_name") or "").strip()
    if not name:
        return False, "承租人名称不能为空"
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return False, "无法获取数据库连接"
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM tenants WHERE tenant_name = ? AND id != ?", (name, tenant_id))
        if cursor.fetchone():
            return False, "承租人名称已存在，请使用其他名称"
        cur = DatabaseUtils.execute_query(conn, "UPDATE tenants SET tenant_name=?, contact_person=?, contact_id=?, contact_phone=? WHERE id=?",
            (name, data.get("contact_person"), data.get("contact_id"), data.get("contact_phone"), tenant_id))
        if cur is None:
            return False, "承租人名称已存在或数据不合法"
        conn.commit()
        _log_op(username, "基础资料", "编辑承租人", "成功", f"ID: {tenant_id}")
        return True, "承租人资料编辑成功"
    except Exception as e:
        return False, f"保存失败: {str(e)}"
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def delete_tenant(tenant_id: int, username: str) -> Tuple[bool, str]:
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return False, "无法获取数据库连接"
        DatabaseUtils.execute_query(conn, "DELETE FROM tenants WHERE id = ?", (tenant_id,))
        conn.commit()
        _log_op(username, "基础资料", "删除承租人", "成功", f"ID: {tenant_id}")
        return True, "承租人资料删除成功"
    except Exception as e:
        return False, f"删除失败: {str(e)}"
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def list_landlords() -> List[dict]:
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return []
        cursor = DatabaseUtils.execute_query(conn, "SELECT id, landlord_name, legal_representative, person_in_charge, contact_phone, is_default FROM landlords ORDER BY id")
        rows = _rows(cursor)
        keys = ["id", "landlord_name", "legal_representative", "person_in_charge", "contact_phone", "is_default"]
        return [dict(zip(keys, r)) for r in rows]
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def add_landlord(data: dict, username: str) -> Tuple[bool, str]:
    name = (data.get("landlord_name") or "").strip()
    if not name:
        return False, "出租方（甲方）不能为空"
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return False, "无法获取数据库连接"
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM landlords WHERE landlord_name = ?", (name,))
        if cursor.fetchone():
            return False, "出租方名称已存在，请使用其他名称"
        is_default = 1 if data.get("is_default") else 0
        if is_default:
            cursor.execute("UPDATE landlords SET is_default = 0")
        cur = DatabaseUtils.execute_query(conn, "INSERT INTO landlords (landlord_name, legal_representative, person_in_charge, contact_phone, is_default) VALUES (?, ?, ?, ?, ?)",
            (name, data.get("legal_representative"), data.get("person_in_charge"), data.get("contact_phone"), is_default))
        if cur is None:
            return False, "出租方名称已存在或数据不合法"
        conn.commit()
        _log_op(username, "基础资料", "添加出租人", "成功", f"名称: {name}")
        return True, "出租人资料添加成功"
    except Exception as e:
        return False, f"保存失败: {str(e)}"
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def update_landlord(landlord_id: int, data: dict, username: str) -> Tuple[bool, str]:
    name = (data.get("landlord_name") or "").strip()
    if not name:
        return False, "出租方（甲方）不能为空"
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return False, "无法获取数据库连接"
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM landlords WHERE landlord_name = ? AND id != ?", (name, landlord_id))
        if cursor.fetchone():
            return False, "出租方名称已存在，请使用其他名称"
        is_default = 1 if data.get("is_default") else 0
        if is_default:
            cursor.execute("UPDATE landlords SET is_default = 0")
        cur = DatabaseUtils.execute_query(conn, "UPDATE landlords SET landlord_name=?, legal_representative=?, person_in_charge=?, contact_phone=?, is_default=? WHERE id=?",
            (name, data.get("legal_representative"), data.get("person_in_charge"), data.get("contact_phone"), is_default, landlord_id))
        if cur is None:
            return False, "出租方名称已存在或数据不合法"
        conn.commit()
        _log_op(username, "基础资料", "编辑出租人", "成功", f"ID: {landlord_id}")
        return True, "出租人资料编辑成功"
    except Exception as e:
        return False, f"保存失败: {str(e)}"
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def delete_landlord(landlord_id: int, username: str) -> Tuple[bool, str]:
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return False, "无法获取数据库连接"
        DatabaseUtils.execute_query(conn, "DELETE FROM landlords WHERE id = ?", (landlord_id,))
        conn.commit()
        _log_op(username, "基础资料", "删除出租人", "成功", f"ID: {landlord_id}")
        return True, "出租人资料删除成功"
    except Exception as e:
        return False, f"删除失败: {str(e)}"
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def list_utility_fees() -> List[dict]:
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return []
        # 注意：必须用普通游标而非 execute_query（MoneyCursor 按列名跨表转换金额，
        # utility_fee 表未迁移（存元），若走 MoneyCursor 会被误 /100 显示为 0.06 等错误值。
        # 原版 basic_data_modules.py:2022 也是使用 self.conn.cursor() 普通游标读取。
        cursor = conn.cursor()
        cursor.execute("SELECT id, house_type, water_fee, electricity_fee FROM utility_fee ORDER BY house_type")
        rows = cursor.fetchall()
        keys = ["id", "house_type", "water_fee", "electricity_fee"]
        return [dict(zip(keys, r)) for r in rows]
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def add_utility_fee(data: dict, username: str) -> Tuple[bool, str]:
    house_type = (data.get("house_type") or "").strip()
    if not house_type:
        return False, "房屋类型不能为空"
    if house_type == "全部":
        return False, "不能选择'全部'作为房屋类型"
    try:
        water_fee = float(data.get("water_fee") or 0)
        electricity_fee = float(data.get("electricity_fee") or 0)
        if water_fee < 0 or electricity_fee < 0:
            return False, "水费和电费标准不能为负数"
    except ValueError:
        return False, "水费和电费标准必须是数字"
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return False, "无法获取数据库连接"
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM utility_fee WHERE house_type = ?", (house_type,))
        if cursor.fetchone():
            return False, f"{house_type}的水电费标准已存在，请使用其他房屋类型"
        cur = DatabaseUtils.execute_query(conn, "INSERT INTO utility_fee (house_type, water_fee, electricity_fee) VALUES (?, ?, ?)",
            (house_type, water_fee, electricity_fee))
        if cur is None:
            return False, "该房屋类型的水电费标准已存在"
        conn.commit()
        _log_op(username, "基础资料", "添加水电费标准", "成功", f"房屋类型: {house_type}")
        return True, "水电费标准添加成功"
    except Exception as e:
        return False, f"保存失败: {str(e)}"
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def update_utility_fee(fee_id: int, data: dict, username: str) -> Tuple[bool, str]:
    try:
        water_fee = float(data.get("water_fee") or 0)
        electricity_fee = float(data.get("electricity_fee") or 0)
        if water_fee < 0 or electricity_fee < 0:
            return False, "水费和电费标准不能为负数"
    except ValueError:
        return False, "水费和电费标准必须是数字"
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return False, "无法获取数据库连接"
        cur = DatabaseUtils.execute_query(conn, "UPDATE utility_fee SET water_fee=?, electricity_fee=? WHERE id=?",
            (water_fee, electricity_fee, fee_id))
        if cur is None:
            return False, "水电费标准保存失败（数据不合法）"
        conn.commit()
        _log_op(username, "基础资料", "编辑水电费标准", "成功", f"ID: {fee_id}")
        return True, "水电费标准编辑成功"
    except Exception as e:
        return False, f"保存失败: {str(e)}"
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def delete_utility_fee(fee_id: int, username: str) -> Tuple[bool, str]:
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return False, "无法获取数据库连接"
        DatabaseUtils.execute_query(conn, "DELETE FROM utility_fee WHERE id = ?", (fee_id,))
        conn.commit()
        _log_op(username, "基础资料", "删除水电费标准", "成功", f"ID: {fee_id}")
        return True, "水电费标准删除成功"
    except Exception as e:
        return False, f"删除失败: {str(e)}"
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def get_house_types() -> List[str]:
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return []
        cursor = DatabaseUtils.execute_query(conn, "SELECT DISTINCT house_type FROM houses WHERE house_type IS NOT NULL AND house_type != '' ORDER BY house_type")
        return [r[0] for r in _rows(cursor)]
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


# ================================================================ 笔记
def list_notes() -> List[dict]:
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return []
        cursor = DatabaseUtils.execute_query(conn, "SELECT id, note_name, content, created_at, updated_at FROM notes ORDER BY updated_at DESC")
        rows = _rows(cursor)
        keys = ["id", "note_name", "content", "created_at", "updated_at"]
        return [dict(zip(keys, r)) for r in rows]
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def get_note(note_id: int) -> Optional[dict]:
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return None
        cursor = DatabaseUtils.execute_query(conn, "SELECT id, note_name, content, created_at, updated_at FROM notes WHERE id = ?", (note_id,))
        row = cursor.fetchone() if cursor else None
        if row is None:
            return None
        keys = ["id", "note_name", "content", "created_at", "updated_at"]
        return dict(zip(keys, row))
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def save_note(note_id: Optional[int], note_name: str, content: str, username: str) -> Tuple[bool, str, Optional[int]]:
    note_name = (note_name or "").strip()
    if not note_name:
        return False, "笔记名称不能为空", None
    now = _now_str()
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return False, "无法获取数据库连接", None
        if note_id:
            cur = DatabaseUtils.execute_query(conn, "UPDATE notes SET note_name=?, content=?, updated_at=? WHERE id=?",
                (note_name, content, now, note_id))
            if cur is None:
                return False, "笔记保存失败（名称可能已存在）", None
            conn.commit()
            _log_op(username, "笔记", "保存笔记", "成功", f"笔记: {note_name}")
            return True, "笔记保存成功", note_id
        else:
            cursor = conn.cursor()
            cursor.execute("SELECT id FROM notes WHERE note_name = ?", (note_name,))
            if cursor.fetchone():
                return False, "笔记名称已存在", None
            cur = DatabaseUtils.execute_query(conn, "INSERT INTO notes (note_name, content, created_at, updated_at) VALUES (?, ?, ?, ?)",
                (note_name, content, now, now))
            if cur is None:
                return False, "笔记创建失败", None
            conn.commit()
            try:
                new_id = cur.lastrowid
            except Exception:
                new_id = conn.cursor().lastrowid
            _log_op(username, "笔记", "新建笔记", "成功", f"笔记: {note_name}")
            return True, "笔记创建成功", new_id
    except Exception as e:
        return False, f"保存失败: {str(e)}", None
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def delete_note(note_id: int, username: str) -> Tuple[bool, str]:
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return False, "无法获取数据库连接"
        DatabaseUtils.execute_query(conn, "DELETE FROM notes WHERE id = ?", (note_id,))
        conn.commit()
        _log_op(username, "笔记", "删除笔记", "成功", f"ID: {note_id}")
        return True, "笔记删除成功"
    except Exception as e:
        return False, f"删除失败: {str(e)}"
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


# ================================================================ 系统设置
def get_software_info() -> dict:
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return {}
        cursor = DatabaseUtils.execute_query(conn, "SELECT key, value FROM system_params")
        rows = _rows(cursor)
        d = {r[0]: r[1] for r in rows}
        return {
            "brand": d.get("brand", "综合贸易"),
            "software_name": d.get("software_name", "门面租赁管理系统"),
            "version": d.get("version", "v2.2.6"),
            "dev_time": d.get("dev_time", "2026-08-12 11:46"),
        }
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def save_software_info(info: dict, username: str) -> Tuple[bool, str]:
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return False, "无法获取数据库连接"
        for key in ("brand", "software_name", "version", "dev_time"):
            val = info.get(key)
            if val is not None:
                cur = DatabaseUtils.execute_query(conn, "INSERT OR REPLACE INTO system_params (key, value) VALUES (?, ?)", (key, str(val)))
                if cur is None:
                    return False, "保存软件信息失败"
        conn.commit()
        _log_op(username, "系统设置", "保存软件信息", "成功")
        return True, "软件信息保存成功"
    except Exception as e:
        return False, f"保存失败: {str(e)}"
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def get_reminder_settings() -> dict:
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return {}
        cursor = DatabaseUtils.execute_query(conn,
            "SELECT contract_reminder_days, rent_reminder_days, screen_timeout_minutes, reminder_frequency FROM reminder_settings LIMIT 1")
        row = _rows(cursor)
        if not row:
            return {"contract_reminder_days": 30, "rent_reminder_days": 7,
                    "screen_timeout_minutes": 30, "reminder_frequency": 60}
        return {"contract_reminder_days": row[0][0] or 30, "rent_reminder_days": row[0][1] or 7,
                "screen_timeout_minutes": row[0][2] or 30, "reminder_frequency": row[0][3] or 60}
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def save_reminder_settings(data: dict, username: str) -> Tuple[bool, str]:
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return False, "无法获取数据库连接"
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM reminder_settings LIMIT 1")
        row = cursor.fetchone()
        vals = (int(data.get("contract_reminder_days") or 30), int(data.get("rent_reminder_days") or 7),
                int(data.get("screen_timeout_minutes") or 30), int(data.get("reminder_frequency") or 60))
        if row:
            cur = DatabaseUtils.execute_query(conn,
                "UPDATE reminder_settings SET contract_reminder_days=?, rent_reminder_days=?, screen_timeout_minutes=?, reminder_frequency=? WHERE id=?",
                vals + (row[0],))
            if cur is None:
                return False, "保存提醒设置失败"
        else:
            cur = DatabaseUtils.execute_query(conn,
                "INSERT INTO reminder_settings (contract_reminder_days, rent_reminder_days, screen_timeout_minutes, reminder_frequency) VALUES (?, ?, ?, ?)",
                vals)
            if cur is None:
                return False, "保存提醒设置失败"
        conn.commit()
        _log_op(username, "系统设置", "保存提醒设置", "成功")
        return True, "提醒设置保存成功"
    except Exception as e:
        return False, f"保存失败: {str(e)}"
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def get_auto_backup_settings() -> dict:
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return {}
        # 自动备份设置表不存在时自动创建（老库升级自愈）
        conn.execute('''CREATE TABLE IF NOT EXISTS auto_backup_settings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            enabled INTEGER DEFAULT 0,
            frequency TEXT DEFAULT '每天',
            backup_time TEXT DEFAULT '00:00',
            backup_path TEXT DEFAULT ''
        )''')
        conn.commit()
        cursor = DatabaseUtils.execute_query(conn, "SELECT id, enabled, frequency, backup_time, backup_path FROM auto_backup_settings LIMIT 1")
        row = _rows(cursor)
        if not row:
            return {"enabled": False, "frequency": "每天", "backup_time": "00:00", "backup_path": ""}
        r = row[0]
        return {"enabled": bool(r[1]), "frequency": r[2] or "每天", "backup_time": r[3] or "00:00", "backup_path": r[4] or ""}
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def save_auto_backup_settings(data: dict, username: str) -> Tuple[bool, str]:
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return False, "无法获取数据库连接"
        # 自动备份设置表不存在时自动创建（老库升级自愈）
        conn.execute('''CREATE TABLE IF NOT EXISTS auto_backup_settings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            enabled INTEGER DEFAULT 0,
            frequency TEXT DEFAULT '每天',
            backup_time TEXT DEFAULT '00:00',
            backup_path TEXT DEFAULT ''
        )''')
        conn.commit()
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM auto_backup_settings LIMIT 1")
        row = cursor.fetchone()
        backup_path = data.get("backup_path") or ""
        if not backup_path.strip():
            # 2026-09-01 修改：路径留空则使用项目根 auto_backup/ 文件夹，不存在自动创建
            default_ab_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "auto_backup")
            try:
                os.makedirs(default_ab_dir, exist_ok=True)
            except Exception:
                pass
        vals = (1 if data.get("enabled") else 0, data.get("frequency") or "每天",
                data.get("backup_time") or "00:00", backup_path)
        if row:
            cur = DatabaseUtils.execute_query(conn, "UPDATE auto_backup_settings SET enabled=?, frequency=?, backup_time=?, backup_path=? WHERE id=?",
                vals + (row[0],))
            if cur is None:
                return False, "保存自动备份设置失败"
        else:
            cur = DatabaseUtils.execute_query(conn, "INSERT INTO auto_backup_settings (enabled, frequency, backup_time, backup_path) VALUES (?, ?, ?, ?)", vals)
            if cur is None:
                return False, "保存自动备份设置失败"
        conn.commit()
        _log_op(username, "系统设置", "保存自动备份设置", "成功")
        return True, "自动备份设置保存成功"
    except Exception as e:
        return False, f"保存失败: {str(e)}"
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def get_db_path() -> str:
    return DatabaseUtils.get_db_path()


# 自动备份保留份数（P1-8，2026-09-11）：超过则删除最旧的
BACKUP_KEEP_COUNT = 30


def _prune_old_backups(target_dir: str, keep: int = BACKUP_KEEP_COUNT) -> int:
    """按文件名时间戳保留最新 keep 份 *_backup_*.db，返回删除数量（失败不阻塞备份）"""
    try:
        import re as _re2
        files = [f for f in os.listdir(target_dir)
                 if _re2.match(r".*_backup_\d{8}_\d{6}\.db$", f)]
        if len(files) <= keep:
            return 0
        files.sort()  # 文件名含 YYYYMMDD_HHMMSS，字典序即时间序
        removed = 0
        for old in files[:-keep]:
            try:
                os.remove(os.path.join(target_dir, old))
                removed += 1
            except OSError:
                pass
        return removed
    except Exception:
        return 0


def _get_offsite_backup_dir() -> str:
    """异地备份目录：优先环境变量 LEASE_OFFSITE_BACKUP_DIR，其次 config.json app_settings.offsite_backup_dir"""
    env = (os.environ.get("LEASE_OFFSITE_BACKUP_DIR") or "").strip()
    if env:
        return env
    try:
        from config_utils import ConfigManager
        cfg = ConfigManager.load_config() or {}
        return str((cfg.get("app_settings") or {}).get("offsite_backup_dir") or "").strip()
    except Exception:
        return ""


def backup_database(target_dir: Optional[str] = None, username: str = "") -> Tuple[bool, str, str]:
    """一致性备份数据库（sqlite3.backup API）"""
    try:
        db_path = DatabaseUtils.get_db_path()
        if not db_path or not os.path.exists(db_path):
            return False, "数据库文件不存在", ""
        if not target_dir:
            # 2026-09-01 修改：手动备份默认目录改为项目根 backup/（原 auto_backup/），目录不存在自动创建
            target_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "backup")
        os.makedirs(target_dir, exist_ok=True)
        db_name = os.path.splitext(os.path.basename(db_path))[0]
        backup_filename = f"{db_name}_backup_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
        backup_path = os.path.join(target_dir, backup_filename)
        src = sqlite3.connect(db_path)
        try:
            dst = sqlite3.connect(backup_path)
            try:
                src.backup(dst)
            finally:
                dst.close()
        finally:
            src.close()
        verify_conn = sqlite3.connect(backup_path)
        try:
            integrity = verify_conn.execute("PRAGMA integrity_check").fetchone()[0]
        finally:
            verify_conn.close()
        if integrity != "ok":
            return False, f"备份文件完整性校验失败: {integrity}", ""
        # 保留策略（P1-8）：只保留最新 BACKUP_KEEP_COUNT 份，防止备份无限增长
        _prune_old_backups(target_dir)
        # 异地备份（P1-8）：配置了 offsite_backup_dir 时拷贝一份，失败仅告警不阻塞
        offsite_dir = _get_offsite_backup_dir()
        if offsite_dir:
            try:
                os.makedirs(offsite_dir, exist_ok=True)
                offsite_path = os.path.join(offsite_dir, backup_filename)
                shutil.copy2(backup_path, offsite_path)
                _prune_old_backups(offsite_dir)
                _log_op(username, "系统设置", "异地备份", "成功", f"异地副本: {offsite_path}")
            except Exception as off_err:
                _log_op(username, "系统设置", "异地备份", "失败", f"拷贝到 {offsite_dir} 失败: {off_err}")
        if username:
            _log_op(username, "系统设置", "备份数据", "成功", f"备份文件: {backup_path}")
        return True, "数据备份成功（含最新数据）", backup_path
    except Exception as e:
        return False, f"数据备份失败: {str(e)}", ""


def restore_database(backup_path: str, username: str) -> Tuple[bool, str]:
    """从备份文件恢复（覆盖当前库）"""
    try:
        if not backup_path or not os.path.exists(backup_path):
            return False, "备份文件不存在"
        check_conn = sqlite3.connect(backup_path)
        try:
            integrity = check_conn.execute("PRAGMA integrity_check").fetchone()[0]
        finally:
            check_conn.close()
        if integrity != "ok":
            return False, f"备份文件不完整（integrity={integrity}），拒绝恢复！"
        db_path = DatabaseUtils.get_db_path()
        DatabaseUtils.set_db_path(db_path)  # 重置连接池
        DatabaseUtils._money_migrated = None
        shutil.copy2(backup_path, db_path)
        for suffix in ("-wal", "-shm"):
            stale = db_path + suffix
            if os.path.exists(stale):
                try:
                    os.remove(stale)
                except Exception:
                    pass
        _log_op(username, "系统设置", "恢复数据", "成功", f"恢复来源: {backup_path}")
        return True, "数据恢复成功，请刷新页面加载新数据"
    except Exception as e:
        return False, f"数据恢复失败: {str(e)}"


def initialize_database(username: str, tables: Optional[List[str]] = None) -> Tuple[bool, str]:
    """数据初始化

    对齐原版 ui_system_settings_tab.initData：
    - 传入 tables 时：仅清空所选表 + 重建默认 admin（初始密码 admin）与 reminder_settings(30/7)
    - 未传 tables 时：沿用 force_initialize_database 全量重建（兼容旧行为）

    F-03（2026-09-17 交付整改）：初始化不可逆，执行前先自动做一次一致性备份；
    备份失败则中止初始化（宁可不做，不可无退路）。
    """
    try:
        ok_bk, msg_bk, _path = backup_database(username=username)
        if not ok_bk:
            return False, f"初始化中止：自动备份失败（{msg_bk}），请先排查备份能力再初始化"
        _log_op(username, "系统设置", "数据初始化", "成功", f"初始化前自动备份: {_path}")
        if tables:
            allowed = {"contracts", "rent_records", "users", "houses", "landlords",
                       "tenants", "notes", "operation_logs", "utility_fee"}
            sel = [t for t in tables if t in allowed]
            if not sel:
                return False, "未选择有效的初始化表"
            conn = None
            try:
                conn = DatabaseUtils.get_connection()
                if not conn:
                    return False, "无法获取数据库连接"
                cursor = conn.cursor()
                # 连接默认开启外键约束（get_connection 执行 PRAGMA foreign_keys=ON），
                # 逐表 DELETE 会被外键拦截（如 rent_records.contract_no 引用 contracts.contract_no）。
                # 故先临时关闭外键再清表，完成后恢复；PRAGMA 须在事务外执行（首条 DML 前）。
                cursor.execute("PRAGMA foreign_keys=OFF")
                try:
                    results = []
                    for t in sel:
                        cursor.execute(f"DELETE FROM {t}")
                        results.append(f"已清空表: {t}")
                    # 重建默认数据（对齐原版：提醒设置 + 管理员初始密码 admin）
                    if "reminder_settings" in sel:
                        cursor.execute("SELECT COUNT(*) FROM reminder_settings")
                        if cursor.fetchone()[0] == 0:
                            cursor.execute("INSERT INTO reminder_settings (contract_reminder_days, rent_reminder_days) VALUES (?, ?)", (30, 7))
                            results.append("已插入默认提醒设置")
                    if "users" in sel:
                        cursor.execute("SELECT COUNT(*) FROM users WHERE username = ?", ("admin",))
                        if cursor.fetchone()[0] == 0:
                            default_hash = auth_hash_password("admin")
                            cursor.execute("INSERT INTO users (username, password, role) VALUES (?, ?, ?)", ("admin", default_hash, "管理员"))
                            results.append("已插入默认管理员用户（初始密码 admin）")
                    conn.commit()
                    _log_op(username, "系统设置", "数据初始化", "成功", "; ".join(results))
                    return True, "数据初始化完成：" + "；".join(results)
                finally:
                    # 无论成功失败都恢复外键约束（连接回池前必须恢复）
                    try:
                        cursor.execute("PRAGMA foreign_keys=ON")
                    except Exception:
                        pass
            finally:
                if conn:
                    DatabaseUtils.close_connection(conn)
        ok, results = DatabaseUtils.force_initialize_database()
        _log_op(username, "系统设置", "数据初始化", "成功" if ok else "失败")
        if ok:
            return True, "数据初始化完成"
        return False, "数据初始化失败: " + "；".join(str(r) for r in results[-5:])
    except Exception as e:
        return False, f"数据初始化失败: {str(e)}"


def auth_hash_password(password: str) -> str:
    """生成 PBKDF2 密码哈希（与 auth.PasswordUtils 一致，避免循环导入）"""
    import hashlib, base64, os as _os
    salt = _os.urandom(16)
    dk = hashlib.pbkdf2_hmac('sha256', str(password).encode('utf-8'), salt, 210000)
    return (f"pbkdf2$210000$"
            f"{base64.b64encode(salt).decode('ascii')}$"
            f"{base64.b64encode(dk).decode('ascii')}")


def optimize_database(username: str) -> Tuple[bool, str]:
    """数据库优化（VACUUM + 重建索引）"""
    try:
        from database_optimization.core import DatabaseOptimizer
        from database_optimization.config import OptimizerConfig
        cfg = OptimizerConfig.get_default_config()
        optimizer = DatabaseOptimizer(cfg)
        result = optimizer.optimize()
        ok = result.success
        _log_op(username, "系统设置", "数据库优化", "成功" if ok else "失败",
                f"耗时: {result.get_duration():.1f}s")
        if ok:
            return True, f"数据库优化完成（耗时 {result.get_duration():.1f} 秒）"
        return False, "数据库优化失败"
    except Exception as e:
        return False, f"数据库优化失败: {str(e)}"


def get_runtime_logs(lines: int = 200) -> dict:
    """读取最近运行日志"""
    try:
        log_cfg = ConfigManager.get_logging_config()
        log_dir = log_cfg.get("log_dir", "logs")
        if not os.path.isabs(log_dir):
            base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            log_dir = os.path.join(base, log_dir)
        month = datetime.datetime.now().strftime("%Y%m")
        log_file = os.path.join(log_dir, f"app_{month}.log")
        if not os.path.exists(log_file):
            return {"file": log_file, "content": "（暂无日志文件）"}
        with open(log_file, "r", encoding="utf-8", errors="replace") as f:
            content_lines = f.readlines()
        return {"file": log_file, "content": "".join(content_lines[-lines:])}
    except Exception as e:
        return {"file": "", "content": f"读取日志失败: {str(e)}"}


def _runtime_log_file() -> str:
    """定位当前运行日志文件（logs/app_YYYYMM.log）"""
    log_cfg = ConfigManager.get_logging_config()
    log_dir = log_cfg.get("log_dir", "logs")
    if not os.path.isabs(log_dir):
        base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        log_dir = os.path.join(base, log_dir)
    month = datetime.datetime.now().strftime("%Y%m")
    return os.path.join(log_dir, f"app_{month}.log")


def clear_runtime_logs() -> dict:
    """清空当前运行日志文件（服务继续写入，新日志从空文件开始累积）"""
    try:
        log_file = _runtime_log_file()
        if os.path.exists(log_file):
            with open(log_file, "w", encoding="utf-8") as f:
                f.write("")
        return {"ok": True, "file": log_file, "message": "运行日志已清除"}
    except Exception as e:
        return {"ok": False, "file": "", "message": f"清除运行日志失败: {str(e)}"}


def clear_operation_logs() -> dict:
    """清空操作日志表（operation_logs）"""
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if conn is None:
            return {"ok": False, "message": "数据库连接失败"}
        conn.execute("DELETE FROM operation_logs")
        conn.commit()
        return {"ok": True, "message": "操作日志已清除"}
    except Exception as e:
        return {"ok": False, "message": f"清除操作日志失败: {str(e)}"}
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


# ================================================================ 提醒
def generate_reminders() -> dict:
    """生成并记录提醒（对齐原版 main.py checkContractExpirationReminders / checkRentDueReminders /
    checkOverdueReminders）：按提醒类型写入 reminder_logs 去重，返回本次新增提醒列表。
    返回 {'reminders': [...], 'count': N}
    """
    result = {"reminders": [], "count": 0}
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return result
        cursor = conn.cursor()
        today = datetime.date.today()
        # 确保 reminder_logs 表存在（正式库已有；新库/测试副本缺失时自动创建，与 scripts/insert_test_data.py 结构一致）
        try:
            cursor.execute("""CREATE TABLE IF NOT EXISTS reminder_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                reminder_type TEXT,
                related_info TEXT,
                reminder_date TEXT,
                is_read INTEGER DEFAULT 0,
                urgency_level TEXT DEFAULT 'normal',
                dismissed INTEGER DEFAULT 0,
                created_at TEXT DEFAULT (datetime('now','localtime')))""")
            conn.commit()
        except Exception:
            pass
        # 读取提醒设置（直接复用本连接查询；DashboardService.get_reminder_settings 依赖独立连接
        # 且 dashboard_services 未在模块级导入，原实现 NameError 被吞 → 永远用默认 30/7）
        cdays, rdays = 30, 7
        try:
            cursor.execute("SELECT contract_reminder_days, rent_reminder_days FROM reminder_settings LIMIT 1")
            _rrow = cursor.fetchone()
            if _rrow:
                cdays = int(_rrow[0]) if _rrow[0] is not None else 30
                rdays = int(_rrow[1]) if _rrow[1] is not None else 7
        except Exception:
            pass

        def _already_logged(rtype, contract_no):
            cursor.execute(
                "SELECT COUNT(*) FROM reminder_logs WHERE reminder_type=? AND related_info LIKE ? AND reminder_date=?",
                (rtype, f"%{contract_no}%", today.strftime("%Y-%m-%d")))
            return cursor.fetchone()[0] > 0

        def _insert_log(rtype, info):
            cursor.execute(
                "INSERT INTO reminder_logs (reminder_type, related_info, reminder_date) VALUES (?, ?, ?)",
                (rtype, info, today.strftime("%Y-%m-%d")))

        # 1) 合同到期提醒（执行中，0 <= 剩余天数 <= 提醒天数）
        try:
            cur = DatabaseUtils.execute_query(conn,
                "SELECT contract_no, lessee, end_date, monthly_rent FROM contracts WHERE status='执行中'")
            for r in (_rows(cur) if cur else []):
                try:
                    end = datetime.datetime.strptime(str(r[2]), "%Y-%m-%d").date()
                    days_left = (end - today).days
                    if 0 <= days_left <= cdays and not _already_logged("合同到期", r[0]):
                        _insert_log("合同到期", f"合同编号:{r[0]},承租方:{r[1]},将在{days_left}天后到期")
                        result["reminders"].append({"type": "合同到期", "contract_no": r[0], "lessee": r[1],
                                                    "days_left": days_left, "end_date": str(r[2]),
                                                    "monthly_rent": r[3] if r[3] is not None else 0})
                except Exception:
                    pass
        except Exception:
            pass

        # 2) 租金到期提醒（执行中合同的租金记录，period_end <= 今天+提醒天数）
        try:
            future = today + datetime.timedelta(days=rdays)
            cur = DatabaseUtils.execute_query(conn, """SELECT r.contract_no, r.period_end, c.house_no, c.lessee
                FROM rent_records r JOIN contracts c ON r.contract_no = c.contract_no
                WHERE c.status='执行中' AND r.period_end <= ?""", (future.isoformat(),))
            for r in (_rows(cur) if cur else []):
                try:
                    pend = datetime.datetime.strptime(str(r[1]), "%Y-%m-%d").date()
                    days_left = (pend - today).days
                    if not _already_logged("租金到期", r[0]):
                        _insert_log("租金到期", f"合同编号:{r[0]},承租方:{r[3]},租金将在{days_left}天后到期")
                        result["reminders"].append({"type": "租金到期", "contract_no": r[0], "lessee": r[3],
                                                    "days_left": days_left, "period_end": str(r[1]),
                                                    "house_no": r[2]})
                except Exception:
                    pass
        except Exception:
            pass

        # 3) 合同逾期提醒（status=已逾期）
        try:
            cur = DatabaseUtils.execute_query(conn,
                "SELECT contract_no, lessee, end_date FROM contracts WHERE status='已逾期'")
            for r in (_rows(cur) if cur else []):
                try:
                    end = datetime.datetime.strptime(str(r[2]), "%Y-%m-%d").date()
                    days_overdue = (today - end).days
                    if not _already_logged("合同逾期", r[0]):
                        _insert_log("合同逾期", f"合同编号:{r[0]},承租方:{r[1]},已逾期{days_overdue}天")
                        result["reminders"].append({"type": "合同逾期", "contract_no": r[0], "lessee": r[1],
                                                    "days_overdue": days_overdue, "end_date": str(r[2])})
                except Exception:
                    pass
        except Exception:
            pass

        conn.commit()
        result["count"] = len(result["reminders"])
        return result
    except Exception:
        try:
            if conn:
                conn.rollback()
        except Exception:
            pass
        return result
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def get_reminders() -> dict:
    """聚合提醒：合同到期/租金到期/合同逾期"""
    from dashboard_services import DashboardService
    try:
        contract_reminder_days, rent_reminder_days = DashboardService.get_reminder_settings()
    except Exception:
        contract_reminder_days, rent_reminder_days = 30, 7
    today = datetime.date.today()
    conn = None
    result = {"today": today.isoformat(), "contract_expiry": [], "rent_due": [], "overdue": [],
              "contract_reminder_days": contract_reminder_days, "rent_reminder_days": rent_reminder_days}
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return result
        future = today + datetime.timedelta(days=contract_reminder_days)
        cursor = DatabaseUtils.execute_query(conn,
            "SELECT contract_no, end_date, house_no, lessee, monthly_rent FROM contracts WHERE status IN ('执行中','已逾期') AND end_date <= ? ORDER BY end_date", (future.isoformat(),))
        for r in _rows(cursor):
            end = datetime.date.fromisoformat(str(r[1])) if r[1] else today
            result["contract_expiry"].append({
                "contract_no": r[0], "end_date": r[1], "house_no": r[2], "lessee": r[3],
                "monthly_rent": r[4], "days_left": (end - today).days})
        # 租金到期提醒：最新收款期间已过且未结清
        cursor = DatabaseUtils.execute_query(conn, """SELECT r.contract_no, r.period_end, c.house_no, c.lessee, r.payment_status
            FROM rent_records r LEFT JOIN contracts c ON r.contract_no = c.contract_no
            WHERE r.period_end <= ? AND r.payment_status != '已结清'
            ORDER BY r.period_end""", (today.isoformat(),))
        seen = set()
        for r in _rows(cursor):
            if r[0] in seen:
                continue
            seen.add(r[0])
            result["rent_due"].append({"contract_no": r[0], "period_end": r[1], "house_no": r[2],
                                       "lessee": r[3], "payment_status": r[4]})
        # 已逾期合同
        cursor = DatabaseUtils.execute_query(conn,
            "SELECT contract_no, end_date, house_no, lessee FROM contracts WHERE status = '已逾期' ORDER BY end_date")
        for r in _rows(cursor):
            result["overdue"].append({"contract_no": r[0], "end_date": r[1], "house_no": r[2], "lessee": r[3]})
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)
    return result


# ================================================================ 自动备份调度
_AUTO_BACKUP_CHECK_INTERVAL = 60  # 检查周期（秒）


def _auto_backup_marker_file() -> str:
    """上次自动备份执行标记文件（放项目根 auto_backup 目录，与备份保存路径无关）"""
    backup_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "auto_backup")
    os.makedirs(backup_dir, exist_ok=True)
    return os.path.join(backup_dir, ".last_run.txt")


def _load_last_auto_backup():
    """读取上次自动备份执行时间（ISO 字符串）"""
    try:
        with open(_auto_backup_marker_file(), "r", encoding="utf-8") as f:
            return datetime.datetime.fromisoformat(f.read().strip())
    except Exception:
        return None


def _save_last_auto_backup(dt: datetime.datetime) -> None:
    try:
        with open(_auto_backup_marker_file(), "w", encoding="utf-8") as f:
            f.write(dt.isoformat())
    except Exception:
        pass


def _auto_backup_due(st: dict, last, now: datetime.datetime) -> bool:
    """判断当前是否到自动备份时间点"""
    if not st.get("enabled"):
        return False
    if last is None:
        return True  # 首次启用立即备份一次
    freq = st.get("frequency") or "每天"
    if freq == "每天":
        bt = st.get("backup_time") or "00:00"
        try:
            hh, mm = int(bt[:2]), int(bt[3:5])
        except Exception:
            hh, mm = 0, 0
        today_due = now.hour > hh or (now.hour == hh and now.minute >= mm)
        return today_due and (last.strftime("%Y%m%d") != now.strftime("%Y%m%d"))
    if freq == "每周":
        return (now - last).total_seconds() >= 7 * 86400
    if freq == "每月":
        return (now - last).total_seconds() >= 30 * 86400
    return False


def auto_backup_worker():
    """后台自动备份线程：每 60 秒检查设置，到点调用 backup_database（main.py startup 启动）"""
    while True:
        try:
            st = get_auto_backup_settings()
            now = datetime.datetime.now()
            if _auto_backup_due(st, _load_last_auto_backup(), now):
                target = (st.get("backup_path") or "").strip()
                if not target:
                    # 自动备份默认仍用 auto_backup/（手动备份默认 backup/，两者独立）
                    target = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "auto_backup")
                ok, msg, path = backup_database(target_dir=target, username="auto")
                if ok:
                    _save_last_auto_backup(datetime.datetime.now())
                    print(f"[auto_backup] 自动备份成功: {path}")
                else:
                    print(f"[auto_backup] 自动备份失败: {msg}")
        except Exception as e:
            print(f"[auto_backup] 检查异常: {e}")
        time.sleep(_AUTO_BACKUP_CHECK_INTERVAL)


# ================================================================ 数据库切换
def switch_database(db_path: str) -> Tuple[bool, str]:
    """切换数据库文件（系统设置-选择数据库）"""
    try:
        if not db_path or not os.path.exists(db_path):
            return False, "数据库文件不存在"
        ConfigManager.set_database_path(db_path)
        DatabaseUtils.set_db_path(db_path)
        DatabaseUtils._money_migrated = None
        return True, "数据库切换成功"
    except Exception as e:
        return False, f"切换失败: {str(e)}"


def _read_all_accounts() -> List[tuple]:
    """读当前库全部账号（原始行：(id, username, password_hash, role)）。

    必须在切库**之前**调用，切库后读到的就是新库了。
    """
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return []
        cur = DatabaseUtils.execute_query(
            conn, "SELECT id, username, password, role FROM users")
        return list(cur.fetchall()) if cur else []
    except Exception as e:
        log_warning(f"_read_all_accounts: 读取账号失败: {e}")
        return []
    finally:
        if conn:
            try:
                DatabaseUtils.close_connection(conn)
            except Exception:
                pass


def _write_accounts_into(target_db_path: str, accounts: List[tuple]) -> int:
    """把账号原样写入目标库（先清空 users，保留原 id 与密码哈希）。

    ⚠️ 不能用 INSERT OR IGNORE：新库由 create_empty_database 播种了一个默认 admin，
    它与原库 admin 的 id 和密码哈希都不同，UNIQUE(username) 冲突会让原库记录被跳过，
    于是 token 里的 sub=user_id 和 pwd 签名都对不上 → 依旧 401。
    实测证据：源 admin id=7/hash 87 字符被新库 id=1/hash 83 字符顶掉，
    只因两者恰好都是 admin/admin 才没暴露问题。

    Args:
        target_db_path: 目标库路径（可直接用 sqlite3 连，不必先是当前库）
        accounts: _read_all_accounts() 的返回值

    Returns:
        实际写入的账号数（0 表示未做修改，调用方应据此保留默认 admin）
    """
    if not accounts:
        return 0
    dst_conn = None
    try:
        dst_conn = sqlite3.connect(target_db_path, timeout=10)
        dst_conn.execute(
            "CREATE TABLE IF NOT EXISTS users ("
            " id INTEGER PRIMARY KEY AUTOINCREMENT,"
            " username TEXT NOT NULL UNIQUE,"
            " password TEXT NOT NULL,"
            " role TEXT NOT NULL)")
        dst_conn.execute("DELETE FROM users")
        n = 0
        for r in accounts:
            dst_conn.execute(
                "INSERT INTO users (id, username, password, role) VALUES (?, ?, ?, ?)",
                (int(r[0]), str(r[1]), str(r[2]), str(r[3])))
            n += 1
        dst_conn.commit()
        return n
    except Exception as e:
        try:
            if dst_conn:
                dst_conn.rollback()
        except Exception:
            pass
        log_warning(f"_write_accounts_into: 账号写入失败: {e}")
        return 0
    finally:
        if dst_conn:
            try:
                dst_conn.close()
            except Exception:
                pass


def carry_over_user_accounts(target_db_path: str) -> Tuple[bool, str]:
    """把当前库账号搬到指定库（供「创建数据库」成功路径调用）。

    背景（2026-09-18 修复）：「创建数据库」成功后会自动切到新库，而新库只有默认
    admin/admin。当前登录账号（自定义管理员或操作员）在新库中不存在，于是
    auth.get_current_user 立即抛 401「账号不存在或已被删除，请重新登录」——
    用户被强制登出，且旧 token 失效后连切回原库都做不到，等于把用户锁在新空库里。

    注意：本函数读的是**当前**库，因此必须在切库动作之前或紧随其后由调用方
    自行把握顺序。实际使用中 create_database 会先 _read_all_accounts() 缓存，
    再建库，最后 _write_accounts_into()，避免切换后读到空库。

    Args:
        target_db_path: 目标库路径

    Returns:
        (ok, 说明)
    """
    accounts = _read_all_accounts()
    if not accounts:
        return False, "当前库中没有可同步的账号"
    n = _write_accounts_into(target_db_path, accounts)
    if n <= 0:
        return False, "账号写入目标库失败"
    names = ", ".join(str(r[1]) for r in accounts)
    return True, f"已同步当前库账号 {n} 个：{names}"


def create_database(db_path: str, current_user: Optional[dict] = None) -> Tuple[bool, str]:
    """创建新的空白数据库并切换

    ⚠️ 已存在守卫（2026-09-18 加固）：本函数是「系统设置 → 创建数据库」的落地实现，
    语义是**新建**，绝不允许覆盖已有库 —— 底层 create_empty_database 对已存在库会
    DROP 重建 contracts/rent_records/tenants，是销毁性操作。历史缺陷：对已有库误点
    本按钮会静默清空合同/租金/承租人数据，且因默认数据已存在而报出「初始化存在问题」
    的误导性错误。现在前置拦截，已存在即返回明确提示，不做任何修改。

    ⚠️ 账号延续（2026-09-18 修复）：成功路径中会把当前库账号复制进新库，
    避免切换后当前登录用户在新库不存在而被 401 踢出（详见 carry_over_user_accounts）。
    """
    try:
        target = os.path.abspath((db_path or "").strip())
        if os.path.exists(target):
            return False, (f"数据库创建失败: 目标文件已存在（{target}）。"
                           "为避免覆盖已有数据，本次未做任何修改。"
                           "如需使用该库请点「选择数据库」；如需新建请换一个未被占用的文件名。")
        # 切换前先抓出当前账号：切换后 get_connection 读到的就是空库了
        accounts_note = ""
        saved_accounts = _read_all_accounts()

        # allow_existing 保持默认 False：即便上面判断后被并发抢先创建，底层也会再拦一次
        ok, results = DatabaseUtils.create_empty_database(db_path=db_path)
        if not ok:
            # 只挑真正有价值的行（跳过表结构明细等噪声），避免把无意义内容拼进用户提示
            detail = [str(r).strip() for r in results
                      if str(r).strip().startswith(("❌", "⚠️"))]
            msg = "；".join((detail or [str(r) for r in results[-3:]])[-3:])
            return False, f"数据库创建失败: {msg}"

        # 新库已落盘：把原库账号整体搬迁进来（保留原 id 与密码哈希，详见 _write_accounts_into）
        if saved_accounts:
            n = _write_accounts_into(target, saved_accounts)
            if n > 0:
                accounts_note = f"，已同步 {n} 个账号（含当前登录账号）"
            else:
                log_warning("create_database: 账号同步未生效，新库仅保留默认 admin/admin")

        ConfigManager.set_database_path(db_path)
        DatabaseUtils.set_db_path(db_path)
        DatabaseUtils._money_migrated = None
        return True, f"数据库创建成功并已切换: {target}{accounts_note}（默认账号 admin/admin）"
    except Exception as e:
        return False, f"创建数据库失败: {str(e)}"


# ================================================================ 租金调整
# 合同期内租金调整：申请 → 审批 → 落地（拆分租金分段 + 更新当前租金）→ 历史可追溯
# 金额单位约定：services 层一律以「元」工作，execute_query 自动完成元↔分转换。

def _get_adjust_param(conn, key: str, default: float) -> float:
    """读 system_params 阈值（返回 float）。缺省/解析失败回退 default。"""
    try:
        cur = conn.cursor()
        cur.execute("SELECT value FROM system_params WHERE key=?", (key,))
        row = cur.fetchone()
        if row and row[0] not in (None, ""):
            return float(row[0])
    except Exception:
        pass
    return default


def _segment_month_count(start_date: str, end_date: str) -> int:
    """精确整月数（含首尾月）：月差 + (end.day >= start.day)。

    同日型合同（03-05~03-04）与月初~月末型（01-01~12-31）均正确返回 12，
    修正了旧 _calc_rents 对「月初~月末型」少算 1 个月的口径偏差。
    切分点对齐起租日「日」时满足分段可加性（各段月数之和 == 整段月数）。
    """
    try:
        s = datetime.datetime.strptime(start_date, "%Y-%m-%d")
        e = datetime.datetime.strptime(end_date, "%Y-%m-%d")
        months = (e.year - s.year) * 12 + (e.month - s.month)
        if e.day >= s.day:
            months += 1
        return months
    except Exception:
        return 0


def _align_effective_day(contract_start_date: str, effective_date: str) -> str:
    """将生效日对齐到合同起租日的「日」，保证分段可加性。

    例：起租 03-05，用户选 09-01 → 对齐为 09-05。若该月无对应日（2 月无 30/31），取该月最后一天。
    """
    try:
        s = datetime.datetime.strptime(contract_start_date, "%Y-%m-%d")
        e = datetime.datetime.strptime(effective_date, "%Y-%m-%d")
        day = s.day
        last = (datetime.date(e.year, e.month + 1, 1) - datetime.timedelta(days=1)).day \
            if e.month < 12 else 31
        day = min(day, last)
        return f"{e.year:04d}-{e.month:02d}-{day:02d}"
    except Exception:
        return effective_date


def _calc_schedule_total_rent(conn, contract_no: str) -> float:
    """按 rent_schedule 分段累加全租期总租金（元）。execute_query 已把 monthly_rent 转元。"""
    cursor = DatabaseUtils.execute_query(
        conn,
        "SELECT start_date, end_date, monthly_rent FROM rent_schedule WHERE contract_no=? ORDER BY segment_no",
        (contract_no,)
    )
    total = 0.0
    for sd, ed, mr in _rows(cursor):
        total += float(mr or 0) * _segment_month_count(sd, ed)
    return round(total, 2)


def _init_contract_schedule(conn, contract_no: str) -> bool:
    """幂等初始化合同分段（首段 = 全租期当前月租）。返回是否新增。

    兜底用途：老数据若因故缺分段，后续审批/重算前先补齐。
    """
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM rent_schedule WHERE contract_no=?", (contract_no,))
    if cur.fetchone()[0] > 0:
        return False
    cur.execute("SELECT start_date, end_date, monthly_rent FROM contracts WHERE contract_no=?", (contract_no,))
    row = cur.fetchone()
    if not row:
        return False
    start_date, end_date, monthly_rent = row
    if not start_date or not end_date:
        return False
    # 裸读 monthly_rent 是「分」，裸写回 rent_schedule 保持分单位，避免 execute_query 元→分二次换算
    cur.execute(
        "INSERT INTO rent_schedule (contract_no, segment_no, start_date, end_date, monthly_rent, source, created_at) "
        "VALUES (?, 1, ?, ?, ?, 'initial', ?)",
        (contract_no, start_date, end_date, monthly_rent, _now_str())
    )
    conn.commit()
    return True


def _split_schedule(conn, contract_no: str, effective_date: str, new_rent: float, adjust_id: int) -> bool:
    """在 effective_date 处拆分租金分段：找到包含生效日的段，拆为两段，后半段用新价。

    增量式（保历史）：支持同一合同多次调整。旧段 end 截到 effective-1，插入新段 [effective, 原end]。
    """
    cursor = DatabaseUtils.execute_query(
        conn,
        "SELECT id, segment_no, start_date, end_date, monthly_rent FROM rent_schedule "
        "WHERE contract_no=? ORDER BY segment_no",
        (contract_no,)
    )
    segs = _rows(cursor)
    if not segs:
        # 无分段则先初始化
        _init_contract_schedule(conn, contract_no)
        return _split_schedule(conn, contract_no, effective_date, new_rent, adjust_id)
    target = None
    for s in segs:
        seg_id, seg_no, sd, ed, mr = s
        if sd <= effective_date <= ed:
            target = s
            break
    if not target:
        # 分段与合同不符（孤儿残留/错段）：自愈重建后再拆，避免静默算错总租
        if _repair_schedule(conn, contract_no):
            return _split_schedule(conn, contract_no, effective_date, new_rent, adjust_id)
        return False
    seg_id, seg_no, sd, ed, old_rent = target
    if effective_date == sd:
        # 生效日恰为段首：整段换新价
        DatabaseUtils.execute_query(
            conn, "UPDATE rent_schedule SET monthly_rent=?, source='adjustment', adjust_id=? WHERE id=?",
            (new_rent, adjust_id, seg_id)
        )
    else:
        eff = datetime.datetime.strptime(effective_date, "%Y-%m-%d")
        seg_a_end = (eff - datetime.timedelta(days=1)).strftime("%Y-%m-%d")
        # 旧段截到 effective-1
        DatabaseUtils.execute_query(conn, "UPDATE rent_schedule SET end_date=? WHERE id=?", (seg_a_end, seg_id))
        # 后续段 segment_no 后移，为新段让位
        conn.cursor().execute(
            "UPDATE rent_schedule SET segment_no = segment_no + 1 WHERE contract_no=? AND segment_no > ?",
            (contract_no, seg_no)
        )
        # 插入新段 [effective, 原end] 新价
        DatabaseUtils.execute_query(
            conn,
            "INSERT INTO rent_schedule (contract_no, segment_no, start_date, end_date, monthly_rent, source, adjust_id, created_at) "
            "VALUES (?, ?, ?, ?, ?, 'adjustment', ?, ?)",
            (contract_no, seg_no + 1, effective_date, ed, new_rent, adjust_id, _now_str())
        )
    return True


def _apply_adjustment(conn, adjust: dict):
    """调整通过后落地：拆分分段 + 更新 contracts 当前租金字段（monthly/quarterly/annual/total）。"""
    contract_no = adjust["contract_no"]
    new_rent = adjust["new_monthly_rent"]  # 元
    effective = adjust["effective_date"]   # 已对齐起租日
    if not _split_schedule(conn, contract_no, effective, new_rent, adjust["id"]):
        raise ValueError(f"租金分段拆分失败（合同 {contract_no} 分段数据异常），审批已中止")
    # 重算全租期总租金（分段累加，元）
    total_rent = _calc_schedule_total_rent(conn, contract_no)
    quarterly = round(new_rent * 3, 2)
    annual = round(new_rent * 12, 2)
    DatabaseUtils.execute_query(
        conn,
        "UPDATE contracts SET monthly_rent=?, quarterly_rent=?, annual_rent=?, total_rent=? WHERE contract_no=?",
        (new_rent, quarterly, annual, total_rent, contract_no)
    )


def _repair_schedule(conn, contract_no: str) -> bool:
    """分段数据与合同不符（孤儿残留/错段）时自愈重建。

    初始月租优先取该合同第一条「已通过」调整的 old_monthly_rent（裸读=分，反映合同初始租金），
    兜底取 contracts.monthly_rent（分）。清空现有分段后按 contracts 起止插入初始段，
    再按 effective_date 升序重放全部已通过调整（金额分→元走 _apply_adjustment）。
    """
    cur = conn.cursor()
    row = cur.execute(
        "SELECT start_date, end_date FROM contracts WHERE contract_no=?", (contract_no,)
    ).fetchone()
    if not row or not row[0] or not row[1]:
        return False
    start_date, end_date = row
    r = cur.execute(
        "SELECT old_monthly_rent FROM rent_adjustments WHERE contract_no=? AND status='已通过' "
        "ORDER BY effective_date ASC LIMIT 1",
        (contract_no,)
    ).fetchone()
    if r and r[0]:
        init_fen = float(r[0])
    else:
        crow = cur.execute(
            "SELECT monthly_rent FROM contracts WHERE contract_no=?", (contract_no,)
        ).fetchone()
        init_fen = float(crow[0]) if crow and crow[0] else 0
    if init_fen <= 0:
        return False
    cur.execute("DELETE FROM rent_schedule WHERE contract_no=?", (contract_no,))
    cur.execute(
        "INSERT INTO rent_schedule (contract_no, segment_no, start_date, end_date, monthly_rent, source, created_at) "
        "VALUES (?, 1, ?, ?, ?, 'initial', ?)",
        (contract_no, start_date, end_date, init_fen, _now_str())
    )
    adjs = cur.execute(
        "SELECT * FROM rent_adjustments WHERE contract_no=? AND status='已通过' ORDER BY effective_date ASC",
        (contract_no,)
    ).fetchall()
    if adjs:
        cols = [d[0] for d in cur.description]
        for ar in adjs:
            adj = dict(zip(cols, ar))
            adj["old_monthly_rent"] = float(adj["old_monthly_rent"] or 0) / 100.0
            adj["new_monthly_rent"] = float(adj["new_monthly_rent"] or 0) / 100.0
            _apply_adjustment(conn, adj)
    else:
        init_yuan = init_fen / 100.0
        total_rent = _calc_schedule_total_rent(conn, contract_no)
        DatabaseUtils.execute_query(
            conn,
            "UPDATE contracts SET monthly_rent=?, quarterly_rent=?, annual_rent=?, total_rent=? WHERE contract_no=?",
            (init_yuan, round(init_yuan * 3, 2), round(init_yuan * 12, 2), total_rent, contract_no)
        )
    return True


def _rebuild_schedule_after_delete(conn, contract_no: str, exclude_adjust_id: int):
    """删除已通过调整后重建该合同租金分段（从初始段重放剩余已通过调整）。

    返回 (ok, err_msg)。金额单位：初始月租从 rent_schedule 裸读为分；
    重放时与 approve 一致，把每条调整的 old/new 月租分→元后再走 _apply_adjustment。
    """
    cur = conn.cursor()
    cur.execute(
        "SELECT monthly_rent FROM rent_schedule WHERE contract_no=? AND segment_no=1 AND source='initial'",
        (contract_no,)
    )
    row = cur.fetchone()
    if not row:
        return False, "无法确定该合同初始月租，已中止删除（请检查租金分段数据）"
    init_rent_fen = row[0]
    crow = cur.execute(
        "SELECT start_date, end_date FROM contracts WHERE contract_no=?", (contract_no,)
    ).fetchone()
    if not crow or not crow[0] or not crow[1]:
        return False, "合同缺少起止日期，无法重建租金分段"
    start_date, end_date = crow[0], crow[1]
    # 清空并重建：初始段 = 初始月租
    cur.execute("DELETE FROM rent_schedule WHERE contract_no=?", (contract_no,))
    cur.execute(
        "INSERT INTO rent_schedule (contract_no, segment_no, start_date, end_date, monthly_rent, source, created_at) "
        "VALUES (?, 1, ?, ?, ?, 'initial', ?)",
        (contract_no, start_date, end_date, init_rent_fen, _now_str())
    )
    # 重放剩余已通过调整（按生效日升序）
    cur.execute(
        "SELECT * FROM rent_adjustments WHERE contract_no=? AND status='已通过' AND id != ? "
        "ORDER BY effective_date ASC",
        (contract_no, exclude_adjust_id)
    )
    cols = [d[0] for d in cur.description]
    remaining = cur.fetchall()
    for r in remaining:
        adj = dict(zip(cols, r))
        adj["old_monthly_rent"] = float(adj["old_monthly_rent"] or 0) / 100.0
        adj["new_monthly_rent"] = float(adj["new_monthly_rent"] or 0) / 100.0
        _apply_adjustment(conn, adj)
    if not remaining:
        # 无剩余已通过调整：contracts 租金字段恢复初始值（初始月租元）
        init_yuan = float(init_rent_fen) / 100.0
        total_rent = _calc_schedule_total_rent(conn, contract_no)
        DatabaseUtils.execute_query(
            conn,
            "UPDATE contracts SET monthly_rent=?, quarterly_rent=?, annual_rent=?, total_rent=? WHERE contract_no=?",
            (init_yuan, round(init_yuan * 3, 2), round(init_yuan * 12, 2), total_rent, contract_no)
        )
    return True, ""


def _validate_adjustment(conn, contract_no: str, new_rent: float, effective_date: str, exclude_id=None):
    """校验调整合法性。返回 (ok, err_msg)。"""
    if new_rent is None or float(new_rent) <= 0:
        return False, "调整后月租必须大于 0"
    new_rent = float(new_rent)
    cur = conn.cursor()
    cur.execute("SELECT monthly_rent, start_date, end_date, status FROM contracts WHERE contract_no=?", (contract_no,))
    row = cur.fetchone()
    if not row:
        return False, "合同不存在"
    old_rent, start_date, end_date, status = row
    if status not in ("执行中", "已逾期"):
        return False, f"仅「执行中/已逾期」合同可调整，当前状态：{status}"
    if not start_date or not end_date:
        return False, "合同缺少起止日期，无法调整"
    # 生效日对齐起租日
    effective = _align_effective_day(start_date, effective_date)
    if not (start_date < effective < end_date):
        return False, f"生效日期须在租期内（{start_date} ~ {end_date}），且晚于起租日"
    # 统一为元比较（old_rent 裸读为分，转元）
    old_rent_yuan = float(old_rent or 0) / 100.0
    if abs(new_rent - old_rent_yuan) < 0.01:
        return False, "调整后月租与原月租相同，无需调整"
    # 幅度校验（2026-09-01 改：仅提示，不限制——超 ±30% 放行但附带提示；须继续执行下方频率/在途校验）
    hint = ""
    max_ratio = _get_adjust_param(conn, "rent_adjust_max_ratio", 30.0)
    if old_rent_yuan > 0:
        ratio = (new_rent - old_rent_yuan) / old_rent_yuan * 100  # 百分比
        if abs(ratio) > max_ratio:
            hint = f"调整幅度 {ratio:.1f}% 超过 ±{max_ratio:.0f}%（仅提示，不限制）"
    # 频率校验：距上次「已通过」调整生效日 ≥ min_interval_months
    min_interval = _get_adjust_param(conn, "rent_adjust_min_interval_months", 12.0)
    cur.execute(
        "SELECT MAX(effective_date) FROM rent_adjustments WHERE contract_no=? AND status='已通过'",
        (contract_no,)
    )
    last = cur.fetchone()[0]
    if last:
        if last >= effective:
            return False, f"生效日期不能早于上次调整生效日 {last}"
        ly, lm = int(last[:4]), int(last[5:7])
        ey, em = int(effective[:4]), int(effective[5:7])
        diff = (ey - ly) * 12 + (em - lm)
        if diff < min_interval:
            return False, f"距上次调整（{last}）不足 {int(min_interval)} 个月"
    # 无在途申请（同一合同不允许重复发起未决申请）
    cur.execute(
        "SELECT COUNT(*) FROM rent_adjustments WHERE contract_no=? AND status='待审批' "
        + (" AND id != ?" if exclude_id else ""),
        (contract_no, exclude_id) if exclude_id else (contract_no,)
    )
    if cur.fetchone()[0] > 0:
        return False, "该合同已有待审批的调整申请"
    return True, hint


def create_rent_adjustment(data: dict, username: str) -> Tuple[bool, str]:
    """发起租金调整申请（状态=待审批）。old 价取自库（不信任前端）。"""
    contract_no = (data.get("contract_no") or "").strip()
    if not contract_no:
        return False, "合同编号不能为空"
    new_rent = float(data.get("new_monthly_rent") or 0)
    effective_date = (data.get("effective_date") or "").strip()
    if not effective_date:
        return False, "生效日期不能为空"
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return False, "无法获取数据库连接"
        # 读旧月租（分，裸读用于幅度计算）+ 起止日（对齐）
        cur = conn.cursor()
        cur.execute("SELECT monthly_rent, start_date, end_date, status FROM contracts WHERE contract_no=?", (contract_no,))
        row = cur.fetchone()
        if not row:
            return False, "合同不存在"
        old_rent_fen, start_date, end_date, status = row
        effective = _align_effective_day(start_date, effective_date)
        ok, err = _validate_adjustment(conn, contract_no, new_rent, effective_date)
        if not ok:
            return False, err
        old_rent = float(old_rent_fen or 0) / 100.0  # 分→元
        ratio = round((new_rent - old_rent) / old_rent * 100, 2) if old_rent else 0
        adjust_type = "上调" if new_rent > old_rent else "下调"
        adjust_no = "TZ" + datetime.datetime.now().strftime("%Y%m%d%H%M%S%f")[:17]
        cursor = DatabaseUtils.execute_query(
            conn,
            "INSERT INTO rent_adjustments (adjust_no, contract_no, adjust_type, old_monthly_rent, new_monthly_rent, "
            "adjust_ratio, effective_date, reason, clause_basis, attachment_path, status, applicant, apply_time, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '待审批', ?, ?, ?)",
            (adjust_no, contract_no, adjust_type, old_rent, new_rent, ratio, effective,
             data.get("reason") or "", data.get("clause_basis") or "", data.get("attachment_path") or "",
             username, _now_str(), _now_str())
        )
        if cursor is None:
            return False, "调整申请写入失败"
        conn.commit()
        _log_op(username, "租金调整", "发起调整申请", "成功",
                f"合同 {contract_no}：{old_rent:.2f} → {new_rent:.2f} 元/月（{adjust_type} {ratio}%），生效 {effective}")
        notify_rent_adjustment(
            conn, "提交",
            f"【租金调整待审批】合同 {contract_no}：月租 {old_rent:.2f} → {new_rent:.2f} 元/月（{adjust_type} {ratio}%），生效 {effective}。申请人 {username}，请及时审批。",
            f"租金调整待审批：合同 {contract_no}，月租 {old_rent:.2f}→{new_rent:.2f} 元/月，生效 {effective}",
        )
        return True, err if err else "调整申请已提交，待审批"
    except Exception as e:
        return False, f"发起调整申请失败: {str(e)}"
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def approve_rent_adjustment(adjust_id: int, action: str, data: dict, username: str) -> Tuple[bool, str]:
    """审批调整申请。action=approve 通过落地 / reject 驳回。"""
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return False, "无法获取数据库连接"
        cur = conn.cursor()
        cur.execute("SELECT * FROM rent_adjustments WHERE id=?", (adjust_id,))
        row = cur.fetchone()
        if not row:
            return False, "调整申请不存在"
        cols = [d[0] for d in cur.description]
        adjust = dict(zip(cols, row))
        if adjust["status"] != "待审批":
            return False, f"该申请当前状态为「{adjust['status']}」，不可审批"
        # 金额列裸读是分，转元
        old_rent = float(adjust["old_monthly_rent"] or 0) / 100.0
        new_rent = float(adjust["new_monthly_rent"] or 0) / 100.0
        adjust["old_monthly_rent"] = old_rent
        adjust["new_monthly_rent"] = new_rent
        contract_no = adjust["contract_no"]

        if action == "approve":
            ok, err = _validate_adjustment(conn, contract_no, new_rent, adjust["effective_date"], exclude_id=adjust_id)
            if not ok:
                return False, err
            _apply_adjustment(conn, adjust)
            cur.execute(
                "UPDATE rent_adjustments SET status='已通过', approver=?, approve_time=? WHERE id=?",
                (username, _now_str(), adjust_id)
            )
            conn.commit()
            _log_op(username, "租金调整", "审批通过", "成功",
                    f"合同 {contract_no}：月租调整为 {new_rent:.2f} 元/月，生效 {adjust['effective_date']}")
            notify_rent_adjustment(
                conn, "通过",
                f"【租金调整已通过】合同 {contract_no}：月租已调整为 {new_rent:.2f} 元/月，生效 {adjust['effective_date']}。审批人 {username}。",
                f"租金调整已通过：合同 {contract_no}，月租 {new_rent:.2f} 元/月，生效 {adjust['effective_date']}",
            )
            return True, "调整已通过并生效"
        elif action == "reject":
            reject_reason = (data.get("reject_reason") or "").strip()
            if not reject_reason:
                return False, "驳回须填写原因"
            cur.execute(
                "UPDATE rent_adjustments SET status='已驳回', approver=?, reject_reason=?, approve_time=? WHERE id=?",
                (username, reject_reason, _now_str(), adjust_id)
            )
            conn.commit()
            _log_op(username, "租金调整", "审批驳回", "成功",
                    f"合同 {contract_no}：驳回，原因 {reject_reason}")
            notify_rent_adjustment(
                conn, "驳回",
                f"【租金调整已驳回】合同 {contract_no}：调整申请被驳回，原因：{reject_reason}。审批人 {username}。",
                f"租金调整已驳回：合同 {contract_no}，原因 {reject_reason}",
            )
            return True, "已驳回该调整申请"
        else:
            return False, "无效的审批动作"
    except Exception as e:
        return False, f"审批失败: {str(e)}"
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def cancel_rent_adjustment(adjust_id: int, username: str) -> Tuple[bool, str]:
    """作废调整申请（仅待审批可作废）。"""
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return False, "无法获取数据库连接"
        cur = conn.cursor()
        cur.execute("SELECT status, contract_no FROM rent_adjustments WHERE id=?", (adjust_id,))
        row = cur.fetchone()
        if not row:
            return False, "调整申请不存在"
        status, contract_no = row
        if status != "待审批":
            return False, f"仅「待审批」申请可作废，当前状态：{status}"
        cur.execute("UPDATE rent_adjustments SET status='已作废', approve_time=? WHERE id=?", (_now_str(), adjust_id))
        conn.commit()
        _log_op(username, "租金调整", "作废申请", "成功", f"合同 {contract_no}，申请单 #{adjust_id}")
        notify_rent_adjustment(
            conn, "作废",
            f"【租金调整已作废】合同 {contract_no}：申请单 #{adjust_id} 已被 {username} 作废。",
            f"租金调整已作废：合同 {contract_no}，申请单 #{adjust_id}",
        )
        return True, "已作废该调整申请"
    except Exception as e:
        return False, f"作废失败: {str(e)}"
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def delete_rent_adjustment(adjust_id: int, username: str) -> Tuple[bool, str]:
    """删除租金调整明细记录（仅管理员，路由层 require_admin 鉴权）。

    - 已通过：删除后重建该合同租金分段（从初始段重放剩余已通过调整），
      重算 total_rent / monthly_rent / quarterly_rent / annual_rent 并同步收款状态；
    - 待审批 / 已驳回 / 已作废：未产生分段，直接删除记录。
    删除前自动备份数据库（sqlite3 backup API，WAL 安全）。
    """
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return False, "无法获取数据库连接"
        cur = conn.cursor()
        cur.execute("SELECT * FROM rent_adjustments WHERE id=?", (adjust_id,))
        row = cur.fetchone()
        if not row:
            return False, "调整记录不存在"
        cols = [d[0] for d in cur.description]
        adjust = dict(zip(cols, row))
        status = adjust["status"]
        contract_no = adjust["contract_no"]
        # 删除前自动备份（WAL 安全；默认目录=项目根 backup/）
        try:
            backup_database()
        except Exception as be:
            return False, f"删除前备份失败，已中止: {str(be)}"
        conn.execute("BEGIN TRANSACTION")
        try:
            if status == "已通过":
                # 合同存在且起止日期完整 → 正常级联重建；否则（合同已删除/缺日期）跳过重建，
                # 仅清理该调整产生的分段残留，仍删除调整记录
                crow2 = cur.execute(
                    "SELECT start_date, end_date FROM contracts WHERE contract_no=?", (contract_no,)
                ).fetchone()
                if crow2 and crow2[0] and crow2[1]:
                    ok, err = _rebuild_schedule_after_delete(conn, contract_no, adjust_id)
                    if not ok:
                        raise ValueError(err)
                    # 同步收款状态：按「累计已收 vs 合同应收」统一重算（裸读分，分-分比较）
                    recalc_contract_payment_status(conn, contract_no)
                else:
                    # 合同不存在（孤儿残留）：清理该调整产生的分段，不重建
                    cur.execute(
                        "DELETE FROM rent_schedule WHERE contract_no=? AND adjust_id=?",
                        (contract_no, adjust_id)
                    )
            cur.execute("DELETE FROM rent_adjustments WHERE id=?", (adjust_id,))
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        _log_op(username, "租金调整", "删除记录", "成功",
                f"合同 {contract_no}，申请单 #{adjust_id}，原状态 {status}")
        notify_rent_adjustment(
            conn, "删除",
            f"【租金调整记录已删除】合同 {contract_no}：申请单 #{adjust_id}（{status}）已被管理员 {username} 删除，相关租金数据已同步更新。",
            f"租金调整记录已删除：合同 {contract_no}，申请单 #{adjust_id}",
        )
        return True, "删除成功，相关数据已同步更新"
    except Exception as e:
        return False, f"删除失败: {str(e)}"
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def list_rent_adjustments(statuses=None, search: str = "") -> dict:
    """租金调整列表（含合同承租方/房屋/当前月租）与状态统计。金额均为元。"""
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return {"items": [], "statistics": {}}
        sql = ("SELECT a.id, a.adjust_no, a.contract_no, a.adjust_type, a.old_monthly_rent, a.new_monthly_rent, "
               "a.adjust_ratio, a.effective_date, a.reason, a.clause_basis, a.attachment_path, a.status, "
               "a.applicant, a.approver, a.reject_reason, a.apply_time, a.approve_time, "
               "c.lessee, c.house_no, c.house_location, c.start_date, c.end_date, c.monthly_rent "
               "FROM rent_adjustments a LEFT JOIN contracts c ON c.contract_no = a.contract_no")
        conds, params = [], []
        if statuses:
            conds.append("a.status IN (" + ",".join("?" * len(statuses)) + ")")
            params.extend(statuses)
        if search:
            conds.append("(a.contract_no LIKE ? OR a.adjust_no LIKE ? OR c.lessee LIKE ? OR c.house_no LIKE ?)")
            like = f"%{search}%"
            params.extend([like, like, like, like])
        if conds:
            sql += " WHERE " + " AND ".join(conds)
        sql += " ORDER BY a.id DESC"
        cursor = DatabaseUtils.execute_query(conn, sql, params)
        rows = _rows(cursor)
        items = []
        for r in rows:
            items.append({
                "id": r[0], "adjust_no": r[1], "contract_no": r[2], "adjust_type": r[3],
                "old_monthly_rent": r[4], "new_monthly_rent": r[5], "adjust_ratio": r[6],
                "effective_date": r[7], "reason": r[8], "clause_basis": r[9], "attachment_path": r[10],
                "status": r[11], "applicant": r[12], "approver": r[13], "reject_reason": r[14],
                "apply_time": r[15], "approve_time": r[16],
                "lessee": r[17], "house_no": r[18], "house_location": r[19],
                "start_date": r[20], "end_date": r[21], "current_monthly_rent": r[22],
            })
        # 状态统计
        cur = conn.cursor()
        cur.execute("SELECT status, COUNT(*) FROM rent_adjustments GROUP BY status")
        status_rows = cur.fetchall()
        stat = {"total": sum(v for _, v in status_rows), "pending": 0, "approved": 0,
                "rejected": 0, "cancelled": 0}
        for s, v in status_rows:
            if s == "待审批":
                stat["pending"] = v
            elif s == "已通过":
                stat["approved"] = v
            elif s == "已驳回":
                stat["rejected"] = v
            elif s == "已作废":
                stat["cancelled"] = v
        return {"items": items, "statistics": stat}
    except Exception:
        return {"items": [], "statistics": {}}
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


def get_rent_schedule(contract_no: str) -> dict:
    """查某合同租金分段（元）与累加总租金。"""
    conn = None
    try:
        conn = DatabaseUtils.get_connection()
        if not conn:
            return {"segments": [], "total_rent": 0, "current_monthly_rent": 0}
        _init_contract_schedule(conn, contract_no)
        cursor = DatabaseUtils.execute_query(
            conn,
            "SELECT segment_no, start_date, end_date, monthly_rent, source, adjust_id FROM rent_schedule "
            "WHERE contract_no=? ORDER BY segment_no",
            (contract_no,)
        )
        segments = [{"segment_no": r[0], "start_date": r[1], "end_date": r[2], "monthly_rent": r[3],
                     "source": r[4], "adjust_id": r[5]} for r in _rows(cursor)]
        total_rent = _calc_schedule_total_rent(conn, contract_no)
        cur = conn.cursor()
        cur.execute("SELECT monthly_rent FROM contracts WHERE contract_no=?", (contract_no,))
        row = cur.fetchone()
        current = float(row[0] or 0) / 100.0 if row else 0
        return {"segments": segments, "total_rent": total_rent, "current_monthly_rent": current}
    except Exception:
        return {"segments": [], "total_rent": 0, "current_monthly_rent": 0}
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)
