/* ============================================================================
   check_report_flow.js —— 报表统计页「切换类型 / 生成报表」数据流无头回归
   ----------------------------------------------------------------------------
   覆盖点（对应民哥 2026-09-15 的需求）：
     ① 切换报表类型：清空图表与表格、只留占位提示，**不发任何请求**、不残留旧图表/旧数据
     ② 点击生成：加载中 / 加载失败 / 无数据 三种状态都有对应提示
     ③ 两条数据流互不干扰：切换类型时在途请求的返回值作废；加载中重复点击不会二次请求

   运行： cd backend && node check_report_flow.js
   退出码：0 = 全部通过；1 = 存在异常。
   ============================================================================ */
"use strict";
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const SRC = path.join(__dirname, "..", "static", "js", "reports.js");

/* ------------------------------------------------------------------ 假 DOM */
const els = {};
function makeEl(id) {
  return {
    id, innerHTML: "", value: "", disabled: false, dataset: {}, style: {}, _h: {},
    addEventListener(ev, fn) { (this._h[ev] = this._h[ev] || []).push(fn); },
    appendChild() {},
    fire(ev) { (this._h[ev] || []).forEach(f => f()); },
  };
}
function $(id) { const k = String(id).replace(/^#/, ""); return els[k] || (els[k] = makeEl(k)); }

const content = { innerHTML: "" };
const apiCalls = [];
let pending = null;          // 受控的 API.get：pending = {resolve, reject}

class ChartStub {
  constructor(canvas, cfg) { this.destroyed = false; this.cfg = cfg; ChartStub.instances.push(this); }
  destroy() { this.destroyed = true; }
}
ChartStub.instances = [];

const sandbox = {
  console,
  App: { charts: {} },
  $,
  esc: v => String(v),
  fmtMoney: v => Number(v).toLocaleString("zh-CN", { minimumFractionDigits: 2, maximumFractionDigits: 2 }),
  toast: () => {},
  setLoading: (btn, loading, text) => {
    if (!btn) return;
    if (loading) { btn.dataset.orig = btn.innerHTML; btn.disabled = true; btn.innerHTML = text || "处理中..."; }
    else { btn.disabled = false; if (btn.dataset.orig) btn.innerHTML = btn.dataset.orig; }
  },
  API: {
    get(url) {
      apiCalls.push(url);
      return new Promise((resolve, reject) => { pending = { resolve, reject }; });
    },
  },
  Chart: ChartStub,
  document: { createElement: () => makeEl("canvas") },
  lastYearStr: () => "2025-09-15",
  todayStr: () => "2026-09-15",
};
vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(SRC, "utf8"), sandbox, { filename: "reports.js" });

const App = sandbox.App;
const tick = () => new Promise(r => setImmediate(r));
const chart = () => els.repChart.innerHTML;
const tbody = () => els.repTbody.innerHTML;
const head = () => els.repHead.innerHTML;

// 最近一次创建的图表配置（ChartStub 保留入参，供「新图表是否按规范插入」类断言使用）
const lastChartCfg = () => {
  const inst = ChartStub.instances[ChartStub.instances.length - 1];
  return inst && inst.cfg;
};

/* -------------------------------------------------------------------- 断言 */
const bad = [];
function check(name, ok, extra) {
  console.log(`${ok ? "PASS" : "FAIL"}  ${name}`);
  if (!ok) bad.push(name + (extra ? `（${extra}）` : ""));
}

const PLACEHOLDER_CHART = "请点击「生成报表」按钮生成图表";
const PLACEHOLDER_TABLE = "请点击「生成报表」按钮查看数据";

const OK_DATA = {
  headers: ["合同编号", "承租方", "收款日期", "收款金额"],
  rows: [["HT001", "张三", "2026-01-05", 12000], ["HT002", "李四", "2026-02-08", 8000]],
  chart: { labels: ["已结清", "部分收款", "未结清"], counts: [1, 1, 0], amounts: [12000, 8000, 0], title: "收款状态分布" },
};

(async () => {
  // ── ① 首次进入页面：不应自动请求，只显示占位提示 ───────────────────────
  App.renderReports(content);
  check("进入页面不自动请求数据", apiCalls.length === 0, `实际请求 ${apiCalls.length} 次`);
  check("进入页面图表区为占位提示", chart().includes(PLACEHOLDER_CHART), chart());
  check("进入页面表格区为占位提示", tbody().includes(PLACEHOLDER_TABLE), tbody());

  // ── ② 切换报表类型：清空视图、不发请求 ────────────────────────────────
  els.repType.value = "收款状态报表";
  els.repType.fire("change");
  check("切换类型不发起请求", apiCalls.length === 0, `实际请求 ${apiCalls.length} 次`);
  check("切换类型后图表区为占位提示", chart().includes(PLACEHOLDER_CHART), chart());
  check("切换类型后表格区为占位提示", tbody().includes(PLACEHOLDER_TABLE), tbody());
  check("切换类型后表头已清空", head() === "", head());
  check("口径说明条随类型显隐", els.repNote.style.display === "", els.repNote.style.display);

  // ── ③ 点击生成：加载中状态 ────────────────────────────────────────────
  els.repStart.value = "2026-01-01";
  els.repEnd.value = "2026-12-31";
  els.repGen.fire("click");
  await tick();
  check("点击生成后才发请求", apiCalls.length === 1, `实际请求 ${apiCalls.length} 次`);
  const url0 = decodeURIComponent(apiCalls[0]);   // 报表类型走 encodeURIComponent，中文会被转义
  check("请求带上了当前类型与日期", url0.includes("收款状态报表") && url0.includes("start_date=2026-01-01"), url0);
  check("加载中：表格提示加载中", tbody().includes("加载中"), tbody());
  check("加载中：图表区提示正在生成", chart().includes("正在生成报表"), chart());
  check("加载中：生成按钮被禁用", els.repGen.disabled === true);

  // ── ④ 加载中重复点击：不产生第二次请求 ───────────────────────────────
  els.repGen.fire("click");
  els.repGen.fire("click");
  await tick();
  check("加载中重复点击不重复请求", apiCalls.length === 1, `实际请求 ${apiCalls.length} 次`);

  // ── ⑤ 加载成功：渲染数据与图表 ───────────────────────────────────────
  pending.resolve(OK_DATA);
  await tick();
  check("成功后渲染表头", head().includes("合同编号"), head());
  check("成功后渲染明细行", tbody().includes("HT001") && tbody().includes("12,000.00"), tbody().slice(0, 120));
  check("成功后创建图表实例", ChartStub.instances.length === 1);
  check("成功后按钮恢复可用", els.repGen.disabled === false);

  // ── ⑥ 切换类型：旧图表实例被销毁、旧数据不残留 ───────────────────────
  els.repType.value = "租金收入报表";
  els.repType.fire("change");
  check("切换类型销毁旧图表", ChartStub.instances[0].destroyed === true);
  check("切换类型清空表头", head() === "", head());
  check("切换类型后不残留旧明细", !tbody().includes("HT001"), tbody());
  check("切换类型后图表区回到占位", chart().includes(PLACEHOLDER_CHART), chart());
  check("切换类型本身仍不发请求", apiCalls.length === 1, `实际请求 ${apiCalls.length} 次`);

  // ── ⑦ 在途请求作废：生成过程中切换类型，返回的数据不得回写 ─────────────
  els.repGen.fire("click");
  await tick();
  const seqBefore = App._reportSeq;
  els.repType.value = "合同统计报表";
  els.repType.fire("change");          // 中途切换 → 请求在途
  pending.resolve(OK_DATA);            // 旧请求返回
  await tick();
  check("中途切换后旧数据不回写", !tbody().includes("HT001"), tbody().slice(0, 120));
  check("中途切换后仍是占位提示", tbody().includes(PLACEHOLDER_TABLE), tbody().slice(0, 120));
  check("切换类型递增了请求序号", App._reportSeq === seqBefore + 1);
  check("在途请求结束后按钮恢复可用", els.repGen.disabled === false);

  // ── ⑧ 无数据状态 ────────────────────────────────────────────────────
  els.repGen.fire("click");
  await tick();
  pending.resolve({ headers: ["合同编号"], rows: [], chart: {} });
  await tick();
  check("无数据：表格提示暂无数据", tbody().includes("暂无数据"), tbody());
  check("无数据：图表区提示暂无统计数据", chart().includes("暂无统计数据"), chart());

  // ── ⑨ 加载失败状态 ──────────────────────────────────────────────────
  els.repGen.fire("click");
  await tick();
  pending.reject(new Error("网络异常"));
  await tick();
  check("失败：表格区显示错误", tbody().includes("网络异常"), tbody());
  check("失败：图表区显示生成失败", chart().includes("生成失败"), chart());
  check("失败后按钮恢复可用", els.repGen.disabled === false);
  check("失败后仍可再次生成", App._reportBusy === false);

  // ── ⑩ 失败后重试：能正常发新请求并渲染 ────────────────────────────────
  const before = apiCalls.length;
  els.repGen.fire("click");
  await tick();
  check("失败后可再次发起请求", apiCalls.length === before + 1);
  pending.resolve(OK_DATA);
  await tick();
  check("重试后正常渲染", tbody().includes("HT001"), tbody().slice(0, 120));

  // ── ⑪ 合同统计报表：柱+折线双数据集、三态金额、非三态置 null 断点 ─────
  //     数据沿用同一接口（/api/reports），不新增页面、不新增请求。
  els.repType.value = "合同统计报表";
  els.repType.fire("change");
  els.repGen.fire("click");
  await tick();
  check("合同统计报表复用同一接口", apiCalls[apiCalls.length - 1].includes("/api/reports?"),
    apiCalls[apiCalls.length - 1]);
  pending.resolve({
    headers: ["合同编号", "合同状态"],
    rows: [["HT001", "执行中"]],
    chart: {
      labels: ["已完成", "已中止", "执行中", "已逾期"],
      values: [29, 1, 27, 0],                              // 柱：含不进折线的「已逾期」
      amount_statuses: ["已完成", "已中止", "执行中"],       // 折线范围
      amounts: [883788.36, 1800.0, 777625.92, 0],          // 已逾期有值但不在范围内
    },
  });
  await tick();
  const ccfg = lastChartCfg();
  check("合同统计报表创建了双系列图表", !!ccfg && ccfg.data.datasets.length === 2,
    ccfg ? `实际 ${ccfg.data.datasets.length} 个系列` : "无图表配置");
  check("柱系列 = 合同数量（整数，左轴）",
    ccfg.data.datasets[0].label === "合同数量" && ccfg.data.datasets[0].yAxisID === "y"
    && JSON.stringify(ccfg.data.datasets[0].data) === JSON.stringify([29, 1, 27, 0]),
    ccfg.data.datasets[0].label);
  check("柱系列带数值标签且格式为整数",
    ccfg.data.datasets[0].datalabels.display === true
    && ccfg.data.datasets[0].datalabels.formatter(1234) === "1,234"
    && ccfg.data.datasets[0].datalabels.formatter(0) === "0",
    String(ccfg.data.datasets[0].datalabels.formatter(1234)));
  check("柱标签启用防重叠（clamp + 白底衬垫）",
    ccfg.data.datasets[0].datalabels.clamp === true
    && ccfg.data.datasets[0].datalabels.backgroundColor.indexOf("255,255,255") >= 0);
  check("折线系列 = 合同总金额（元，右轴）",
    ccfg.data.datasets[1].label === "合同总金额（元）" && ccfg.data.datasets[1].type === "line"
    && ccfg.data.datasets[1].yAxisID === "y1",
    ccfg.data.datasets[1].label);
  check("折线仅取「已完成/已中止/执行中」三态，已逾期置 null 断点",
    JSON.stringify(ccfg.data.datasets[1].data)
    === JSON.stringify([883788.36, 1800, 777625.92, null]),
    JSON.stringify(ccfg.data.datasets[1].data));
  check("折线金额标签为千分位两位小数",
    ccfg.data.datasets[1].datalabels.formatter(883788.36) === "883,788.36"
    && ccfg.data.datasets[1].datalabels.formatter(null) === null,
    String(ccfg.data.datasets[1].datalabels.formatter(883788.36)));
  check("折线标签启用避让决策（align 为函数）",
    typeof ccfg.data.datasets[1].datalabels.align === "function");
  check("双轴配置：左轴计数、右轴金额",
    !!ccfg.options.scales.y && !!ccfg.options.scales.y1
    && ccfg.options.scales.y1.position === "right"
    && ccfg.options.scales.y1.grid.drawOnChartArea === false,
    JSON.stringify(Object.keys(ccfg.options.scales)));
  check("插入位置仍是既有图表容器（未新增页面）",
    !!els.repChart && App.charts.report !== null);
  check("响应式适配保持开启", ccfg.options.responsive === true && ccfg.options.maintainAspectRatio === false);

  // ── ⑫ 合同统计报表空结果：走统一空数据状态 ────────────────────────────
  els.repGen.fire("click");
  await tick();
  pending.resolve({ headers: ["合同编号"], rows: [], chart: { labels: [], values: [], amount_statuses: [], amounts: [] } });
  await tick();
  check("合同统计报表空结果：图表区统一空数据提示",
    chart().includes("暂无统计数据"), chart());
  check("合同统计报表空结果：表格区统一暂无数据提示",
    tbody().includes("暂无数据"), tbody());

  if (bad.length) {
    console.log("\n✗ 未通过项：\n  - " + bad.join("\n  - "));
    process.exit(1);
  }
  console.log(`\n✓ 全部通过（共发起 ${apiCalls.length} 次请求，均在点击「生成报表」后触发）`);
  process.exit(0);
})();
