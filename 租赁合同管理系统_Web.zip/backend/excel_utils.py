# -*- coding: utf-8 -*-
"""
租赁合同管理系统 Web 版 - Excel / PDF 导出工具
使用 openpyxl（Excel）与 reportlab（PDF），不依赖 pandas/matplotlib

安全说明（2026-09-11，R-01）：
  reportlab <= 3.6.12 的 Paragraph 会解析类 XML 标记，其 rl_safe_eval 存在
  代码注入漏洞（CVE-2023-33733），构造 <font color="..."> 一类内容可执行任意代码。
  本模块把「库中数据」直接送入 Paragraph（承租方/备注/Excel 导入单元格等均用户可控），
  故对全部单元格文本做 XML 转义（见 _pdf_text），从根源阻断标记解析。
  同时 requirements.lock 已将 reportlab 升级到已修复版本（纵深防御，双保险）。
"""
import io
import os
from decimal import Decimal
from xml.sax.saxutils import escape as _xml_escape

# reportlab 中文字体注册（模块加载时一次，避免每次导出重复解析大字体文件；
# reportlab 默认 Helvetica 无中文字形，不注册中文字体导出必乱码）
try:
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    _FONT_DIR = r"C:\Windows\Fonts"
    pdfmetrics.registerFont(TTFont("SimSun", os.path.join(_FONT_DIR, "simsun.ttc"), subfontIndex=0))
    pdfmetrics.registerFont(TTFont("SimHei", os.path.join(_FONT_DIR, "simhei.ttf")))
except Exception as _e:  # pragma: no cover - 字体缺失等环境异常
    _FONT_REGISTER_ERROR = _e
else:
    _FONT_REGISTER_ERROR = None

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter


HEADER_FILL = PatternFill(start_color="4F81BD", end_color="4F81BD", fill_type="solid")
HEADER_FONT = Font(bold=True, color="FFFFFF")
THIN_BORDER = Border(left=Side(style='thin'), right=Side(style='thin'),
                     top=Side(style='thin'), bottom=Side(style='thin'))
CENTER = Alignment(horizontal="center", vertical="center")


def _pdf_text(value) -> str:
    """PDF 单元格文本安全化（R-01 / CVE-2023-33733 防护）。

    reportlab 的 Paragraph 会解析一串类 XML 标记；<=3.6.12 版本的 rl_safe_eval
    可被 <font color="..."> 等标记注入执行任意代码。由于单元格内容来自数据库
    （用户可录入或 Excel 导入），必须先转义再交给 Paragraph。

    仅做 XML 转义（& < > → 实体），Paragraph 渲染时会还原为原字符，
    **不改变任何可见内容**；同时顺带修复数据含 < > & 时排版错乱的问题。
    """
    if value is None:
        return ""
    s = str(value)
    return _xml_escape(s) if s else ""


def _auto_width(ws, headers):
    for col_idx, col in enumerate(ws.columns, start=1):
        max_length = 0
        for cell in col:
            try:
                if cell.value is not None and len(str(cell.value)) > max_length:
                    max_length = len(str(cell.value))
            except Exception:
                pass
        ws.column_dimensions[get_column_letter(col_idx)].width = (max_length + 2) * 1.2


def build_xlsx(headers: list, rows: list, sheet_name: str = "数据", money_cols: list = None) -> bytes:
    """生成 xlsx 字节流（表头蓝色加粗 + 边框 + 自适应列宽）

    money_cols：金额列的列下标（0 基）。这些列写入数值并设置 '#,##0.00' 数字格式，
    使 Excel 中的显示与页面 fmtMoney（千分位 + 两位小数）一致，同时保留数值属性
    可直接求和、排序。不传则保持原有行为（纯文本写入），兼容既有调用方。

    注意：MoneyCursor 的「分 → 元」换算返回的是 Decimal，不是 float，
    故此处对 Decimal 一并识别并转成 float 写回（否则数字格式不会生效）。
    """
    wb = Workbook()
    ws = wb.active
    ws.title = sheet_name[:31]
    ws.append(headers)
    for cell in ws[1]:
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = CENTER
        cell.border = THIN_BORDER
    for row in rows:
        ws.append(list(row))
    money = set(money_cols or ())
    for row_cells in ws.iter_rows(min_row=2):
        for cell in row_cells:
            cell.border = THIN_BORDER
            val = cell.value
            if (cell.column - 1) in money and isinstance(val, (int, float, Decimal)) \
                    and not isinstance(val, bool):
                if isinstance(val, Decimal):
                    cell.value = float(val)
                cell.number_format = "#,##0.00"
    _auto_width(ws, headers)
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def build_pdf(headers: list, rows: list, title: str = "数据报表") -> bytes:
    """生成 PDF 字节流（横向 A4 铺满 + 中文字体 + 每页标题 + 页脚页码）

    布局约定：
    - 横向 A4；所有列按内容比例缩放铺满可用宽度，保证全部列在同一页内
    - 表头（黑体白字蓝底）跨页自动重复
    - 每页顶部绘制标题；页脚居中绘制“第X页/共X页”
    """
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib import colors
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.units import mm
    from reportlab.pdfgen import canvas as pdfcanvas

    # ---- 中文字体（模块加载时已注册 SimSun/SimHei，见文件头；此处仅引用）----
    body_font = "SimSun"   # 宋体
    head_font = "SimHei"   # 黑体
    if _FONT_REGISTER_ERROR:
        raise RuntimeError(f"中文字体注册失败，无法导出 PDF：{_FONT_REGISTER_ERROR}")

    page_w, page_h = landscape(A4)
    left_margin = right_margin = 8 * mm
    top_margin = 22 * mm
    bottom_margin = 14 * mm
    usable = page_w - left_margin - right_margin

    # ---- 字号随列数自适应（列多则小，保证一页放下全部列）----
    ncols = len(headers)
    if ncols >= 16:
        body_size, head_size = 6.5, 7
    elif ncols >= 10:
        body_size, head_size = 8, 8.5
    else:
        body_size, head_size = 9, 10

    # ---- 两级列宽分配：先保表头宽度（不换行），剩余空间按内容分给长列 ----
    def text_w_pt(s, size):
        return sum((size if ord(ch) > 0x2E7F else size * 0.52)
                   for ch in str(s if s is not None else ""))
    cell_pad = 3.0  # 左右内边距合计（与 TableStyle 的 LEFTPADDING/RIGHTPADDING 对应）
    header_nat = [text_w_pt(h, head_size) + cell_pad for h in headers]
    body_nat = []
    for ci in range(len(headers)):
        m = 0.0
        for row in rows:
            if ci < len(row):
                v = text_w_pt(row[ci], body_size) + cell_pad
                if v > m:
                    m = v
        body_nat.append(m)
    floors = [max(h, 24.0) for h in header_nat]                       # 下限：表头完整显示
    extras = [max(0.0, max(header_nat[i], body_nat[i]) - floors[i])   # 富余：长内容所需
              for i in range(len(headers))]
    extra_cap = usable * 0.18                                         # 单列内容上限，防备注类挤占整页
    extras = [min(e, extra_cap) for e in extras]
    base = sum(floors)
    extra_total = sum(extras)
    if base + extra_total <= usable:
        scale = usable / (base + extra_total)                         # 铺满：富余空间均匀放大
        col_widths = [(floors[i] + extras[i]) * scale for i in range(len(headers))]
    else:
        spare = usable - base                                         # 空间不足：只压缩内容列，表头不动
        factor = (spare / extra_total) if (extra_total > 0 and spare > 0) else 1.0
        col_widths = [floors[i] + extras[i] * factor for i in range(len(headers))]

    # ---- 表格内容（Paragraph 单元格，超长自动换行）----
    head_style = ParagraphStyle("head", fontName=head_font, fontSize=head_size,
                                leading=head_size * 1.3, alignment=1, textColor=colors.white)
    body_style = ParagraphStyle("body", fontName=body_font, fontSize=body_size,
                                leading=body_size * 1.25, alignment=1)

    def _split_header(h, w):
        """列宽放不下时在词边界断行（末两字成词，如 租赁开始/日期），避免 3+1 难看换行。

        注意：宽度测量用「未转义原文」（=实际可见字符），仅返回值做 XML 转义；
        其中 <br/> 为本模块自己插入的换行标记，需保留。
        """
        if text_w_pt(h, head_size) + cell_pad <= w:
            return _pdf_text(h)
        chars = list(str(h))
        n = len(chars)
        if n < 4:
            return _pdf_text(h)
        first = n - 2
        return '<br/>'.join([_pdf_text(''.join(chars[:first])),
                             _pdf_text(''.join(chars[first:]))])

    header_row = [Paragraph(_split_header(h, col_widths[i]), head_style)
                  for i, h in enumerate(headers)]
    # R-01：单元格内容全部经 _pdf_text 转义后再交给 Paragraph
    data_rows = [[Paragraph(_pdf_text(c), body_style) for c in row] for row in rows]
    data = [header_row] + data_rows

    table = Table(data, colWidths=col_widths, repeatRows=1)
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#4F81BD')),
        ('GRID', (0, 0), (-1, -1), 0.4, colors.HexColor('#B0B7C3')),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#EAF1F8')]),
        ('TOPPADDING', (0, 0), (-1, -1), 2),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 2),
        ('LEFTPADDING', (0, 0), (-1, -1), 1.5),
        ('RIGHTPADDING', (0, 0), (-1, -1), 1.5),
    ]))

    # ---- 画布：每页顶部标题 + 页脚页码（两遍法获取总页数）----
    class NumberedCanvas(pdfcanvas.Canvas):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._saved_page_states = []

        def showPage(self):
            self._saved_page_states.append(dict(self.__dict__))
            self._startPage()

        def save(self):
            num_pages = len(self._saved_page_states)
            for state in self._saved_page_states:
                self.__dict__.update(state)
                self._draw_header_footer(num_pages)
                super().showPage()
            super().save()

        def _draw_header_footer(self, num_pages):
            # 每页顶部标题
            self.setFont(head_font, 14)
            self.setFillColor(colors.black)
            self.drawCentredString(page_w / 2.0, page_h - 12 * mm, title)
            # 页脚页码
            self.setFont(body_font, 8)
            self.setFillColor(colors.HexColor('#555555'))
            self.drawCentredString(page_w / 2.0, 7 * mm, f"第{self._pageNumber}页/共{num_pages}页")

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=landscape(A4),
                            rightMargin=right_margin, leftMargin=left_margin,
                            topMargin=top_margin, bottomMargin=bottom_margin,
                            title=title, author="租赁合同管理系统")
    doc.build([table], canvasmaker=NumberedCanvas)
    return buf.getvalue()


def parse_excel_upload(raw: bytes) -> tuple:
    """解析上传的 xlsx，返回 (headers列表, rows列表)"""
    wb = load_workbook(io.BytesIO(raw), data_only=True)
    ws = wb.active
    rows_iter = ws.iter_rows(values_only=True)
    headers_row = next(rows_iter, None)
    if headers_row is None:
        return [], []
    headers = [str(h).strip() if h is not None else '' for h in headers_row]
    rows = []
    for r in rows_iter:
        rows.append(list(r))
    return headers, rows
