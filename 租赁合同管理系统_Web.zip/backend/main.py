# -*- coding: utf-8 -*-
"""
租赁合同管理系统 Web 版 - FastAPI 主入口

启动：uvicorn main:app --host 127.0.0.1 --port 8000
"""
import os
import re
import sys
import io
import threading
import datetime
from urllib.parse import quote
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Optional

BASE_DIR = Path(__file__).resolve().parent
PROJECT_DIR = BASE_DIR.parent
sys.path.insert(0, str(BASE_DIR))

# 配置文件指向 Web 项目根目录 config.json
os.environ.setdefault("LEASE_CONFIG_PATH", str(PROJECT_DIR / "config.json"))

from fastapi import FastAPI, Depends, HTTPException, UploadFile, File
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from config_utils import ConfigManager
from db_utils import DatabaseUtils
from dashboard_services import DashboardService
from operation_logger import get_operation_logs
from logger_module import log_error, log_warning, log_info
from version import APP_NAME, APP_VERSION
import auth
import services
import excel_utils


# 导入接口大小上限（P1-5，2026-09-11）：Excel 导入 50MB，与附件上传 100MB 对齐收紧
IMPORT_MAX_BYTES = 50 * 1024 * 1024


def _check_import_size(raw: bytes) -> None:
    """导入文件大小兜底，防止超大文件打满内存"""
    if raw and len(raw) > IMPORT_MAX_BYTES:
        raise HTTPException(status_code=400, detail="导入文件超过 50MB 上限，请拆分后再导入")


def _validate_new_db_path(path: str) -> Optional[str]:
    """新建数据库的落盘位置校验（2026-09-18 修正）。

    背景与教训：
      * 2026-09-17 原为「只允许写在 PROJECT_DIR 内」——实测拦住了误建到
        C:\\Windows\\System32\\evil.db（该目录存在时竟能建库成功并切走活动库）；
      * 但 2026-09-18 发现该限制**过严**：本项目是多副本部署（H 盘同时存在
        v2.3.3-20260918-0111 / v2.3.2-20260917-1234 / v2.3.2-20260915-2330，
        服务只挂其中一份），PROJECT_DIR 仅指服务自己那一份，导致
        「建到另一份副本」「建到 D:\\ 备份盘」这类合法操作被无差别拒绝，
        用户看到「创建失败: 新数据库只能创建在项目目录内」而无法自助解决。
      * 另需注意：旧判据用 `startswith(PROJECT_DIR)`，兄弟目录
        `...-0111-backup` 也会被误放行（字符串前缀不是路径包含）。

    新判据（只拦系统敏感位置，其余本地路径一律放行）：
      1. 必须在本地盘（拒绝 UNC 网络路径 \\\\server\\share，避免建库到网络盘
         引发 WAL/锁问题）；
      2. 目标目录（或最近的已存在祖先目录）不得落在系统目录内：
         C:\\Windows、C:\\Program Files( (x86))、C:\\ProgramData，也不允许落在
         任一磁盘的根目录（如 C:\\、D:\\ —— 根目录放 db 易被清理工具误删）；
      3. 目标目录与项目目录重叠（任一方包含另一方）时直接放行——覆盖
         项目内、项目父目录、兄弟副本等正常用法。
    返回错误消息；None 表示通过。
    """
    p = (path or "").strip()
    if not p:
        return "路径不能为空"
    try:
        abs_p = os.path.abspath(p)
    except Exception as e:
        return f"路径无效: {e}"

    # ① 拒绝 UNC / 网络路径
    if abs_p.startswith(("\\\\", "//")):
        return "不支持网络路径，请选择本机磁盘上的位置"

    proj = os.path.abspath(str(PROJECT_DIR))
    a_low, p_low = abs_p.lower(), proj.lower()

    # ③ 与项目目录重叠 → 直接放行（多副本部署的核心诉求）
    if a_low == p_low or a_low.startswith(p_low + os.sep) or p_low.startswith(a_low + os.sep):
        return None

    # ② 系统敏感目录黑名单：从目标目录向上找最近的「已存在」目录再判定，
    #    这样 C:\\Windows\\System32\\x.db 这种多级不存在的路径也拦得住
    try:
        probe = os.path.dirname(abs_p)
        while probe and not os.path.isdir(probe):
            parent = os.path.dirname(probe)
            if parent == probe:
                break
            probe = parent
        base = os.path.abspath(probe or os.path.dirname(abs_p) or ".")
        b_low = os.path.normcase(base)
        tgt_dir = os.path.abspath(os.path.dirname(abs_p) or ".")

        # 盘根判定只看**目标目录本身**是否为根，不能看「最近的已存在祖先」——
        # 否则 D:\新建目录\x.db（目录尚未创建）会因祖先回退到 D:\ 而被误拒。
        # 用 normcase 统一为「小写 + 反斜杠」再比对，避免手写转义踩坑：
        # 此前写 `drive_root in (r"c:\\", r"c:/")` 实际拼出 "c:\"（单个反斜杠），
        # 与两反斜杠字面量永不相等，导致 C:\ 根目录被漏放行（实测建库 200）。
        drive_t, tail_t = os.path.splitdrive(tgt_dir)
        is_drive_root = bool(drive_t) and os.path.normcase(tail_t) in ("\\", "/")

        blocked = []
        for env in ("SystemRoot", "windir", "ProgramFiles", "ProgramFiles(x86)", "ProgramData"):
            v = os.environ.get(env)
            if v:
                blocked.append(os.path.normcase(os.path.abspath(v)))

        hit_system = any(
            b_low == b or b_low.startswith(b.rstrip("\\/") + os.sep) for b in blocked)
        if hit_system or is_drive_root:
            where = tgt_dir if is_drive_root else base
            return (f"出于安全考虑，不允许在系统目录或磁盘根目录新建数据库（{where}）；"
                    "请改用项目目录或其它普通数据目录")
    except Exception as e:
        log_warning(f"新建库路径校验异常（按放行处理）: {e}")

    # 非系统目录的本地路径 → 放行，但留审计痕迹
    log_warning(f"[F-04 审计] 管理员在项目目录外新建数据库: {abs_p}")
    return None


def _validate_admin_db_path(path: str, must_exist: bool) -> Optional[str]:
    """F-04（2026-09-17 交付整改）：管理类路径接口（切换/创建/恢复数据库）的软校验。

    仅管理员可达，管理员是本机可信操作者，且「换机迁移/网盘库」属合法场景，
    故不做硬白名单（会破坏 11.7 迁移流程），只做最小约束 + 审计：
      1. 路径非空、扩展名必须为 .db（防止误选配置/日志等文件）；
      2. must_exist=True 时校验文件存在；
      3. 项目根之外的路径记 log_warning 留审计痕迹。

    注意：「新建」场景的位置限制见 _validate_new_db_path（切换/恢复读现有库，
    不做位置限制）。返回错误消息；None 表示通过。
    """
    p = (path or "").strip()
    if not p:
        return "路径不能为空"
    if os.path.splitext(p)[1].lower() != ".db":
        return "仅支持 .db 数据库文件"
    if must_exist and not os.path.isfile(p):
        return "数据库文件不存在"
    try:
        if not os.path.abspath(p).lower().startswith(str(PROJECT_DIR).lower()):
            log_warning(f"[F-04 审计] 管理员操作了项目根之外的数据库路径: {p}")
    except Exception:
        pass
    return None

# ---------------------------------------------------------------- FastAPI 应用
# R-03（2026-09-17 交付整改）：关闭 /docs、/redoc、/openapi.json —— 本系统为内网单机交付，
# 交互式 API 文档不应向所有能访问服务的人公开；接口清单见 README 与《操作手册》。
app = FastAPI(title=APP_NAME, version=APP_VERSION,
              docs_url=None, redoc_url=None, openapi_url=None)

# R-02（2026-09-17 交付整改）：CORS 收敛为同源白名单。
# 前端与 API 同源（http://127.0.0.1:8000），此中间件仅为防御性保留；
# 原 allow_origins=["*"] 与 allow_credentials=True 同时开启属错误配置，已修正。
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:8000", "http://localhost:8000"],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type"],
)

# R-07（2026-09-17 交付整改）：基础安全响应头（不含 CSP，避免破坏内联脚本的单页应用）
@app.middleware("http")
async def _security_headers(request, call_next):
    response = await call_next(request)
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
    response.headers.setdefault("Referrer-Policy", "same-origin")
    return response


# ---------------------------------------------------------------- 请求模型
class LoginRequest(BaseModel):
    username: str
    password: str


class ChangePasswordRequest(BaseModel):
    old_password: str
    new_password: str


class UserRequest(BaseModel):
    username: Optional[str] = None
    password: Optional[str] = None
    role: Optional[str] = None
    new_password: Optional[str] = None


class ContractRequest(BaseModel):
    data: dict


class RentRecordRequest(BaseModel):
    data: dict


class HouseRequest(BaseModel):
    data: dict


class TenantRequest(BaseModel):
    data: dict


class LandlordRequest(BaseModel):
    data: dict


class UtilityFeeRequest(BaseModel):
    data: dict


class NoteRequest(BaseModel):
    note_id: Optional[int] = None
    note_name: str
    content: str = ""


class SettingsRequest(BaseModel):
    data: dict


class RestoreRequest(BaseModel):
    backup_path: str


class SwitchDbRequest(BaseModel):
    db_path: str


class CreateDbRequest(BaseModel):
    db_path: str


class RentAdjustmentRequest(BaseModel):
    data: dict


class RentAdjustmentApproveRequest(BaseModel):
    action: str  # approve / reject
    reject_reason: Optional[str] = None


# ---------------------------------------------------------------- 认证 API
@app.post("/api/auth/login")
def api_login(req: LoginRequest):
    ok, result = auth.do_login(req.username, req.password)
    if not ok:
        raise HTTPException(status_code=401, detail=result.get("error", "登录失败"))
    return result


@app.get("/api/auth/usernames")
def api_usernames(user: dict = Depends(auth.get_current_user)):
    """用户名列表（P1-2，2026-09-11：加鉴权，防止未登录枚举账号定向爆破）"""
    return {"data": [u["username"] for u in auth.list_users()]}


@app.post("/api/auth/verify-password")
def api_verify_password(req: LoginRequest, user: dict = Depends(auth.get_current_user)):
    """系统设置访问密码验证（对齐原版 SystemSettingPasswordDialog / show_authentication_prompt）"""
    if not auth.verify_current_password(user["username"], req.password):
        raise HTTPException(status_code=401, detail="密码错误")
    return {"message": "验证通过"}


@app.post("/api/auth/logout")
def api_logout(user: dict = Depends(auth.get_current_user)):
    auth.do_logout(user)
    return {"message": "已退出登录"}


@app.get("/api/auth/me")
def api_me(user: dict = Depends(auth.get_current_user)):
    return {"user": user}


@app.post("/api/auth/change-password")
def api_change_password(req: ChangePasswordRequest, user: dict = Depends(auth.get_current_user)):
    ok, msg = auth.change_password(user["username"], req.old_password, req.new_password)
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"message": msg}


# ---------------------------------------------------------------- 系统信息
@app.get("/api/system/db-name")
def api_system_db_name():
    """登录页显示当前数据库名（公开接口；P1-3：只回文件名，不泄露绝对路径）"""
    try:
        full = str(services.get_db_path() or "")
        return {"database_path": os.path.basename(full.replace("\\", "/"))}
    except Exception:
        return {"database_path": ""}


@app.get("/api/system/info")
def api_system_info(user: dict = Depends(auth.get_current_user)):
    info = services.get_software_info()
    # R-09（2026-09-17 交付整改）：数据库绝对路径仅管理员可见，操作员不再回传
    if user.get("role") == "管理员":
        info["database_path"] = services.get_db_path()
    info["server_time"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return info


# ---------------------------------------------- 启动期数据库初始化（2026-09-11 加固）
# 背景：原 startup() 仅在配置能解析出路径时 set_db_path，库文件缺失/表结构不全会静默通过，
# 表现为「启动后连不上数据库 / 登录提示用户名或密码错误」。现改为：解析→自愈→实连校验→上报状态。
_startup_db_state = {
    "configured": False, "source": "", "path": "", "exists": False,
    "connected": False, "tables_ok": False, "detail": "尚未初始化",
}

# F-01（2026-09-17 交付整改）：关键表自检从 4 张扩充为 12 张核心业务表。
# 缺任何一张即 status=degraded 并在登录页红字提示，避免「部分功能静默不可用」。
# notes / reminder_logs / auto_backup_settings / schema_meta 为按需或元数据表，不列入。
_CRITICAL_TABLES = (
    "contracts", "rent_records", "rent_adjustments", "rent_schedule",
    "houses", "tenants", "landlords", "utility_fee",
    "users", "reminder_settings", "operation_logs", "system_params",
)


def _resolve_startup_db_path():
    """解析启动时应使用的数据库路径。

    1) 优先 config.json 的 database_path（相对路径按配置文件目录解析）
    2) 未配置 → 回退扫描项目 Data/*.db（优先 ZHMY_*）
    返回 (db_path 或 None, 来源说明)
    """
    try:
        p = ConfigManager.get_database_path()
    except Exception as e:
        log_error(f"启动数据库路径：读取配置失败: {e}")
        p = None
    if p:
        return p, "config.json/database_path"

    data_dir = PROJECT_DIR / "Data"
    try:
        cands = sorted([f for f in os.listdir(data_dir) if f.lower().endswith(".db")],
                       key=lambda n: (0 if n.upper().startswith("ZHMY") else 1, n))
        if cands:
            fallback = str(data_dir / cands[0])
            log_warning(f"启动数据库路径：config.json 未配置 database_path，回退使用 {fallback}")
            return fallback, f"回退扫描 Data/ → {cands[0]}"
    except Exception as e:
        log_error(f"启动数据库路径：回退扫描 Data/ 失败: {e}")
    return None, "config.json 未配置且 Data/ 下无候选库"


def _init_database_on_startup() -> dict:
    """启动时完成数据库「解析 → 自愈 → 绑定 → 实连校验」，返回状态字典（供 /api/health 展示）"""
    global _startup_db_state
    state = dict(_startup_db_state)
    db_path, source = _resolve_startup_db_path()
    state["source"] = source

    if not db_path:
        state.update({"configured": False, "path": "", "exists": False,
                      "connected": False, "tables_ok": False,
                      "detail": "未找到可用数据库路径，请检查 config.json 的 database_path"})
        log_error("启动数据库连接：FAIL —— " + state["detail"])
        _startup_db_state = state
        return state

    state.update({"configured": True, "path": db_path})

    # 自愈：库文件缺失时自动新建空库（含 admin/admin 与完整表结构），避免以空库裸跑
    if not os.path.isfile(db_path):
        log_warning(f"启动数据库连接：库文件不存在，自动新建空库 -> {db_path}")
        try:
            ok, results = DatabaseUtils.create_empty_database(db_path)
            log_info(f"启动数据库连接：新建空库{'成功' if ok else '失败'}"
                     f"{'，' + str(results[-1]) if results else ''}")
        except Exception as e:
            log_error(f"启动数据库连接：新建空库异常: {e}")
    state["exists"] = os.path.isfile(db_path)

    # 绑定路径 + 实连校验（含关键表检查）
    try:
        DatabaseUtils.set_db_path(db_path)
        DatabaseUtils._money_migrated = None
        conn = DatabaseUtils.get_connection()
        if conn is None:
            raise RuntimeError("get_connection 返回 None（无法建立数据库连接）")
        try:
            conn.execute("SELECT 1").fetchone()
            missing = []
            for t in _CRITICAL_TABLES:
                row = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?",
                                   (t,)).fetchone()
                if row is None:
                    missing.append(t)
        finally:
            DatabaseUtils.close_connection(conn)
        state["connected"] = True
        state["tables_ok"] = not missing
        if missing:
            state["detail"] = f"已连接，但缺少关键表: {missing}（请用「系统设置→初始化」或改选正确数据库）"
            log_error("启动数据库连接：WARN —— " + state["detail"])
        else:
            state["detail"] = "连接成功，关键表齐全"
            log_info(f"启动数据库连接：OK —— {db_path}（来源: {source}）")
    except Exception as e:
        state.update({"connected": False, "tables_ok": False, "detail": f"连接失败: {e}"})
        log_error(f"启动数据库连接：FAIL —— {e}")
    _startup_db_state = state
    return state


@app.get("/api/health")
def api_health():
    """健康检查（P2，2026-09-11；2026-09-11 加固：回报启动期数据库初始化结果）
    供守护脚本/监控探活，公开但不泄露路径等敏感信息"""
    st = dict(_startup_db_state)
    try:
        conn = DatabaseUtils.get_connection()
        if conn is None:
            return {"status": "degraded", "database": "unavailable",
                    "db_configured": bool(st.get("configured")), "db_tables_ok": False,
                    "pool_active": 0, "detail": st.get("detail", "")}
        try:
            conn.execute("SELECT 1").fetchone()
        finally:
            DatabaseUtils.close_connection(conn)
        pool_active = len(getattr(DatabaseUtils, "_active_connections", {}) or {})
        ok = bool(st.get("connected")) and bool(st.get("tables_ok"))
        return {"status": "ok" if ok else "degraded",
                "database": "ok" if ok else "incomplete",
                "db_configured": bool(st.get("configured")),
                "db_tables_ok": bool(st.get("tables_ok")),
                "pool_active": pool_active,
                "detail": st.get("detail", "")}
    except Exception as e:
        log_error(f"GET /api/health 失败: {e}")
        return {"status": "degraded", "database": "unavailable",
                "db_configured": bool(st.get("configured")), "db_tables_ok": False,
                "pool_active": 0, "detail": st.get("detail", "")}


# ---------------------------------------------------------------- 仪表盘
@app.get("/api/dashboard/stats")
def api_dashboard_stats(user: dict = Depends(auth.get_current_user)):
    try:
        stats = DashboardService.get_dashboard_stats()
    except Exception as e:
        log_error(f"GET /api/dashboard/stats 失败: {e}")
        stats = {"error": "服务器内部错误，详情见服务日志"}
    return stats


@app.get("/api/dashboard/rent-trend")
def api_rent_trend(user: dict = Depends(auth.get_current_user)):
    try:
        months, receivable, received = DashboardService.get_rent_trend_data()
        return {"months": months, "receivable": receivable, "received": received}
    except Exception as e:
        # P-03：异常细节只进服务日志，不回传前端（避免泄露路径/SQL 等内部信息）
        log_error(f"仪表盘接口异常: {e}")
        raise HTTPException(status_code=500, detail="服务器内部错误，详情见服务日志")


@app.get("/api/dashboard/expiry")
def api_contract_expiry(user: dict = Depends(auth.get_current_user)):
    try:
        return {"contract_expiry": DashboardService.get_contract_expiry_details()}
    except Exception as e:
        # P-03：异常细节只进服务日志，不回传前端（避免泄露路径/SQL 等内部信息）
        log_error(f"仪表盘接口异常: {e}")
        raise HTTPException(status_code=500, detail="服务器内部错误，详情见服务日志")


@app.get("/api/dashboard/rent-due")
def api_rent_due(user: dict = Depends(auth.get_current_user)):
    try:
        return {"rent_due": DashboardService.get_rent_due_reminders()}
    except Exception as e:
        # P-03：异常细节只进服务日志，不回传前端（避免泄露路径/SQL 等内部信息）
        log_error(f"仪表盘接口异常: {e}")
        raise HTTPException(status_code=500, detail="服务器内部错误，详情见服务日志")


@app.get("/api/dashboard/renewable")
def api_renewable(user: dict = Depends(auth.get_current_user)):
    try:
        return {"renewable": DashboardService.get_renewable_contracts()}
    except Exception as e:
        # P-03：异常细节只进服务日志，不回传前端（避免泄露路径/SQL 等内部信息）
        log_error(f"仪表盘接口异常: {e}")
        raise HTTPException(status_code=500, detail="服务器内部错误，详情见服务日志")


# ---------------------------------------------------------------- 提醒
@app.get("/api/reminders")
def api_reminders(user: dict = Depends(auth.get_current_user)):
    return services.get_reminders()


@app.post("/api/reminders/generate")
def api_generate_reminders(user: dict = Depends(auth.get_current_user)):
    """检查并记录新提醒（对齐原版 checkReminders 定时任务；去重写 reminder_logs）"""
    return services.generate_reminders()


# ---------------------------------------------------------------- 合同管理
@app.get("/api/contracts")
def api_list_contracts(search: str = "", statuses: str = "", payment_statuses: str = "",
                       start_date_from: str = "", end_date_to: str = "",
                       user: dict = Depends(auth.get_current_user)):
    status_list = [s for s in statuses.split(",") if s] if statuses else None
    pay_list = [s for s in payment_statuses.split(",") if s] if payment_statuses else None
    data = services.list_contracts(search=search, statuses=status_list, payment_statuses=pay_list,
                                   start_date_from=start_date_from, end_date_to=end_date_to)
    stats = services.contract_statistics(search=search, statuses=status_list, payment_statuses=pay_list,
                                         start_date_from=start_date_from, end_date_to=end_date_to)
    return {"data": data, "statistics": stats}


@app.post("/api/contracts/auto-update-status")
def api_auto_update_status(user: dict = Depends(auth.get_current_user)):
    """合同到期/逾期自动状态更新（对齐原版 checkAndUpdateExpiredContracts / checkAndUpdateOverdueContracts）"""
    result = services.auto_update_contract_statuses(username=user["username"])
    return result


@app.get("/api/contracts/next-no")
def api_next_contract_no(user: dict = Depends(auth.get_current_user)):
    """生成下一个合同编号: HT+年份+3位序号（对齐原版 generateContractNo）"""
    return {"data": services.next_contract_no()}


@app.get("/api/contracts/{contract_no}")
def api_get_contract(contract_no: str, user: dict = Depends(auth.get_current_user)):
    c = services.get_contract(contract_no)
    if c is None:
        raise HTTPException(status_code=404, detail="合同不存在")
    return c


@app.post("/api/contracts")
def api_add_contract(req: ContractRequest, user: dict = Depends(auth.get_current_user)):
    ok, msg = services.add_contract(req.data, user["username"])
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"message": msg}


@app.put("/api/contracts/{contract_no}")
def api_update_contract(contract_no: str, req: ContractRequest, user: dict = Depends(auth.get_current_user)):
    ok, msg = services.update_contract(contract_no, req.data, user["username"])
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"message": msg}


@app.delete("/api/contracts/{contract_no}")
def api_delete_contract(contract_no: str, user: dict = Depends(auth.get_current_user)):
    ok, msg, count = services.delete_contract(contract_no, user["username"])
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"message": msg}


@app.get("/api/contracts/{contract_no}/payments")
def api_contract_payments(contract_no: str, user: dict = Depends(auth.get_current_user)):
    return {"data": services.get_contract_payments(contract_no)}


@app.post("/api/contracts/{contract_no}/renew")
def api_renew_contract(contract_no: str, user: dict = Depends(auth.get_current_user)):
    ok, msg = services.renew_contract(contract_no, user["username"])
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"message": msg}


# ---------------------------------------------------------------- 合同文件（附件）
# 存储位置：<项目根>/Data/contract_files/<合同编号>/<原文件名>
# contracts.attachment_path 保存 JSON 数组（相对项目根目录的正斜杠路径），与桌面版格式一致
ATTACH_DIR_NAME = "contract_files"
ATTACH_ALLOWED_EXT = {
    ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".txt",
    ".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp",
}


def _attachment_root() -> Path:
    """合同文件存储根目录（不存在则创建）"""
    root = PROJECT_DIR / "Data" / ATTACH_DIR_NAME
    root.mkdir(parents=True, exist_ok=True)
    return root


def _safe_attach_name(name: str) -> str:
    """清洗文件名：剥离目录部分并替换路径分隔符/非法字符，避免路径穿越"""
    base = os.path.basename((name or "").replace("\\", "/")).strip()
    base = re.sub(r'[\\/:*?"<>|\r\n\t]', "_", base).strip(". ")
    return (base or "未命名文件")[:120]


def _unique_attach_path(folder: Path, filename: str) -> Path:
    """同名文件自动追加 (1)(2)… 后缀，避免覆盖既有文件"""
    stem, ext = os.path.splitext(filename)
    cand = folder / filename
    idx = 1
    while cand.exists():
        cand = folder / f"{stem}({idx}){ext}"
        idx += 1
    return cand


@app.post("/api/contracts/attachment/upload")
async def api_upload_contract_attachment(file: UploadFile = File(...), contract_no: str = "",
                                         user: dict = Depends(auth.get_current_user)):
    """上传合同文件（文档/图片），返回保存后的相对路径与文件名"""
    raw_name = _safe_attach_name(file.filename or "")
    ext = os.path.splitext(raw_name)[1].lower()
    if ext not in ATTACH_ALLOWED_EXT:
        raise HTTPException(status_code=400,
                            detail=f"不支持的文件类型「{ext or '未知'}」，仅支持：{'、'.join(sorted(ATTACH_ALLOWED_EXT))}")
    content = await file.read()
    if not content:
        raise HTTPException(status_code=400, detail="文件内容为空，上传失败")
    if len(content) > 100 * 1024 * 1024:
        raise HTTPException(status_code=400, detail="文件超过 100MB，请压缩后再上传")
    folder = _attachment_root() / (_safe_attach_name(contract_no) if (contract_no or "").strip() else "未指定合同")
    try:
        folder.mkdir(parents=True, exist_ok=True)
        target = _unique_attach_path(folder, raw_name)
        with open(target, "wb") as f:
            f.write(content)
    except Exception as e:
        log_error(f"合同文件保存失败: {e}")
        raise HTTPException(status_code=500, detail="文件保存失败，详情见服务日志")
    rel = target.relative_to(PROJECT_DIR).as_posix()
    try:
        services._log_op(user["username"], "合同管理", "上传合同文件", "成功",
                         f"合同编号: {contract_no or '未指定'}，文件: {target.name}，大小: {len(content)} 字节")
    except Exception:
        pass
    return {"message": "合同文件上传成功", "path": rel, "name": target.name}


@app.get("/api/contracts/attachment/file")
def api_view_contract_attachment(path: str, user: dict = Depends(auth.get_current_user)):
    """打开/下载合同文件（仅允许访问 Data/contract_files 目录内的文件，防路径穿越）"""
    root = _attachment_root().resolve()
    try:
        target = (PROJECT_DIR / path).resolve()
    except Exception:
        raise HTTPException(status_code=400, detail="文件路径不合法")
    if target != root and root not in target.parents:
        raise HTTPException(status_code=403, detail="仅允许访问合同文件目录内的文件")
    if not target.is_file():
        raise HTTPException(status_code=404, detail="文件不存在或已被移动")
    quoted = quote(target.name)
    return FileResponse(str(target), headers={
        "Content-Disposition": f"inline; filename*=UTF-8''{quoted}",
        "Cache-Control": "no-store",
    })


# ---- 合同管理页「导出 Excel」列定义 ----------------------------------------
# 与页面表格（static/js/contracts.js 表头）逐一对应：列顺序、表头名称、单元格
# 展示口径均跟随页面，「操作」列不导出。改页面表格列时请同步改这里。
#   text  = 原样输出（日期、状态、付款方式等后端返回值即页面展示值，不做编码导出）
#   money = 金额，写数值 + '#,##0.00' 格式，显示等同前端 fmtMoney（千分位两位小数）
CONTRACT_EXPORT_COLUMNS = [
    ("contract_no", "合同编号", "text"),
    ("sign_date", "签约日期", "text"),
    ("house_no", "房屋编号", "text"),
    ("house_type", "房屋类型", "text"),
    ("house_location", "房屋位置", "text"),
    ("lessee", "承租方", "text"),
    ("tenant", "承租人", "text"),
    ("start_date", "起租日期", "text"),
    ("end_date", "到期日期", "text"),
    ("payment_method", "付款方式", "text"),
    ("monthly_rent", "月租", "money"),
    ("quarterly_rent", "季租", "money"),
    ("annual_rent", "年租", "money"),
    ("deposit", "押金", "money"),
    ("received_rent", "已收", "money"),
    ("receivable_rent", "应收", "money"),
    ("payment_status", "收款情况", "text"),
    ("status", "状态", "text"),
    ("remarks", "备注", "text"),
]
# 可排序字段 = 导出列字段（与前端 contracts.js::sortContractList 的口径保持一致）
_CONTRACT_SORTABLE_KEYS = {f for f, _h, _k in CONTRACT_EXPORT_COLUMNS}
_CONTRACT_NUM_FIELDS = {"monthly_rent", "quarterly_rent", "annual_rent", "deposit",
                        "received_rent", "receivable_rent"}
_CONTRACT_DATE_FIELDS = {"sign_date", "start_date", "end_date"}


def _export_cell(d: dict, field: str, kind: str):
    """按列类型把字段值转成「页面展示值」

    text   —— 原样输出（日期、状态、付款方式等；None → 空串）
    money  —— 金额，输出数值（配 '#,##0.00'，等同前端 fmtMoney，且可求和）
    int    —— 整数列（如记录 ID），输出数值便于排序筛选
    period —— 页面把 period_start ~ period_end 显示在同一格，导出同样拼接
    """
    v = d.get(field)
    if kind == "money":
        try:
            return float(v) if v not in (None, "") else None
        except (TypeError, ValueError):
            return None
    if kind == "int":
        try:
            return int(v) if v not in (None, "") else None
        except (TypeError, ValueError):
            return None
    if kind == "period":
        s = "" if d.get("period_start") is None else str(d.get("period_start"))
        e = "" if d.get("period_end") is None else str(d.get("period_end"))
        return f"{s} ~ {e}"
    return "" if v is None else str(v)


def _build_export_rows(data: list, columns: list) -> list:
    """把记录列表转成导出行（列定义 = (字段, 表头, 类型)）"""
    return [[_export_cell(d, f, k) for f, _h, k in columns] for d in data]


def _sort_export_rows(data: list, key: str, sort_dir: str, num_fields: set,
                      date_fields: set, allowed_keys: set) -> list:
    """按页面当前排序状态排序（镜像前端 sort*.js 的口径）

    数值比大小、日期（YYYY-MM-DD）按字典序即时间序、其余按字符串；
    空值无论升序降序都排最后；字段不在允许集合内则保持原顺序。
    """
    if not key or key not in allowed_keys:
        return data

    def value(d):
        v = d.get(key)
        if v is None or v == "":
            return None
        if key in num_fields:
            try:
                return float(v)
            except (TypeError, ValueError):
                return None
        return str(v)  # date_fields 为 YYYY-MM-DD，字典序 == 时间序

    reverse = (sort_dir or "").lower() == "desc"
    valued = [d for d in data if value(d) is not None]
    empty = [d for d in data if value(d) is None]
    valued.sort(key=value, reverse=reverse)
    return valued + empty


def _sort_contracts(data: list, key: str, sort_dir: str) -> list:
    """合同列表按页面当前排序状态排序"""
    return _sort_export_rows(data, key, sort_dir, _CONTRACT_NUM_FIELDS,
                             _CONTRACT_DATE_FIELDS, _CONTRACT_SORTABLE_KEYS)


def build_contract_export_rows(data: list) -> list:
    """把合同记录转成导出行：金额转数值（配 '#,##0.00'），其余转页面展示文本"""
    return _build_export_rows(data, CONTRACT_EXPORT_COLUMNS)


@app.get("/api/contracts/export/excel")
def api_export_contracts_excel(search: str = "", statuses: str = "", payment_statuses: str = "",
                               start_date_from: str = "", end_date_to: str = "",
                               sort: str = "sign_date", sort_dir: str = "desc",
                               user: dict = Depends(auth.get_current_user)):
    """导出合同明细表 Excel：与页面当前展示保持一致
    - 同一筛选条件（关键字 + 合同状态 + 收款情况 + 起租/到期日期），不受分页影响，导出全部匹配记录
    - 列集合/顺序/表头与页面表格一致（不含「操作」列）
    - 单元格按页面展示值输出（金额为 fmtMoney 口径，状态/日期为显示文本）
    - 排序跟随页面当前排序（默认签约日期倒序）
    """
    status_list = [s for s in statuses.split(",") if s] if statuses else None
    pay_list = [s for s in payment_statuses.split(",") if s] if payment_statuses else None
    data = _sort_contracts(
        services.list_contracts(search=search, statuses=status_list, payment_statuses=pay_list,
                                start_date_from=start_date_from, end_date_to=end_date_to),
        sort, sort_dir)
    headers = [h for _f, h, _k in CONTRACT_EXPORT_COLUMNS]
    money_cols = [i for i, (_f, _h, k) in enumerate(CONTRACT_EXPORT_COLUMNS) if k == "money"]
    rows = build_contract_export_rows(data)
    content = excel_utils.build_xlsx(headers, rows, "合同数据", money_cols=money_cols)
    filename = f"合同数据_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    quoted = quote(filename)
    return StreamingResponse(io.BytesIO(content), media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                             headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quoted}"})


@app.get("/api/contracts/export/pdf")
def api_export_contracts_pdf(search: str = "", statuses: str = "", payment_statuses: str = "",
                             start_date_from: str = "", end_date_to: str = "",
                             user: dict = Depends(auth.get_current_user)):
    """合同 PDF 导出：与页面同一筛选条件（含起租/到期日期），列沿用既有 PDF 版式"""
    status_list = [s for s in statuses.split(",") if s] if statuses else None
    pay_list = [s for s in payment_statuses.split(",") if s] if payment_statuses else None
    data = services.list_contracts(search=search, statuses=status_list, payment_statuses=pay_list,
                                   start_date_from=start_date_from, end_date_to=end_date_to)
    headers = ["合同编号", "签约日期", "房屋编号", "房屋类型", "房屋位置", "承租方", "承租人",
               "租赁开始日期", "租赁截止日期", "最近收款期间", "合同状态", "付款方式",
               "月租金额", "季租金", "总租金", "年租金", "押金", "已收租金", "应收租金", "收款情况"]
    rows = [[d.get(h) for h in ["contract_no", "sign_date", "house_no", "house_type", "house_location",
                                "lessee", "tenant", "start_date", "end_date", "rent_period_end", "status",
                                "payment_method", "monthly_rent", "quarterly_rent", "total_rent",
                                "annual_rent", "deposit", "received_rent", "receivable_rent", "payment_status"]] for d in data]
    content = excel_utils.build_pdf(headers, rows, "合同数据")
    filename = f"合同数据_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    quoted = quote(filename)
    return StreamingResponse(io.BytesIO(content), media_type="application/pdf",
                             headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quoted}"})


@app.post("/api/contracts/import")
async def api_import_contracts(file: UploadFile = File(...), user: dict = Depends(auth.get_current_user)):
    raw = await file.read()
    _check_import_size(raw)  # P-02（2026-09-17 交付整改）：补齐导入大小校验
    try:
        headers, rows = excel_utils.parse_excel_upload(raw)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Excel 解析失败: {str(e)}")
    required = ["合同编号", "签约日期", "房屋编号", "房屋位置", "房屋面积", "出租方", "承租方",
                "承租人", "租赁开始日期", "租赁截止日期", "合同状态", "付款方式", "月租金额"]
    missing = [c for c in required if c not in headers]
    if missing:
        raise HTTPException(status_code=400, detail=f"Excel 缺少必要列: {', '.join(missing)}")
    hmap = {h: i for i, h in enumerate(headers)}
    success, failed = 0, []
    for idx, row in enumerate(rows, start=2):
        def cell(name):
            i = hmap.get(name)
            if i is None or i >= len(row):
                return ""
            v = row[i]
            return "" if v is None else str(v).strip()
        try:
            contract_no = cell("合同编号")
            monthly_rent = 0.0
            try:
                monthly_rent = float(str(cell("月租金额")).replace(",", ""))
            except ValueError:
                monthly_rent = 0.0
            house_area = 0.0
            try:
                house_area = float(str(cell("房屋面积")).replace(",", ""))
            except ValueError:
                house_area = 0.0
            deposit = 0.0
            try:
                deposit = float(str(cell("押金")).replace(",", "")) if cell("押金") else 0.0
            except ValueError:
                deposit = 0.0
            data = {
                "contract_no": contract_no,
                "sign_date": cell("签约日期"),
                "house_no": cell("房屋编号"),
                "house_location": cell("房屋位置"),
                "house_area": house_area,
                "lessor": cell("出租方"),
                "legal_representative": cell("法定代表人"),
                "person_in_charge": cell("分管负责人"),
                "contact_phone": cell("联系电话"),
                "lessee": cell("承租方"),
                "tenant": cell("承租人"),
                "tenant_id": cell("承租人身份证"),
                "tenant_phone": cell("承租人电话"),
                "start_date": cell("租赁开始日期"),
                "end_date": cell("租赁截止日期"),
                "status": cell("合同状态") or "执行中",
                "payment_method": cell("付款方式"),
                "monthly_rent": monthly_rent,
                "deposit": deposit,
                "usage": cell("用途"),
                "utility_method": cell("水电费计算方式"),
                "remarks": cell("备注"),
                "payment_status": "未结清",
            }
            ok, msg = services.add_contract(data, user["username"])
            if ok:
                success += 1
            else:
                failed.append((idx, msg))
        except Exception as e:
            failed.append((idx, str(e)))
    return {"message": f"导入完成：成功 {success} 条，失败 {len(failed)} 条", "success": success, "failed": failed}


# ---------------------------------------------------------------- 租金管理
@app.get("/api/rents")
def api_list_rents(statuses: str = "", search: str = "",
                   receipt_date_from: str = "", receipt_date_to: str = "",
                   user: dict = Depends(auth.get_current_user)):
    status_list = [s for s in statuses.split(",") if s] if statuses else None
    data = services.list_rent_records(statuses=status_list, search=search,
                                      receipt_date_from=receipt_date_from,
                                      receipt_date_to=receipt_date_to)
    stats = services.rent_statistics(statuses=status_list, search=search,
                                     receipt_date_from=receipt_date_from,
                                     receipt_date_to=receipt_date_to)
    return {"data": data, "statistics": stats}


@app.post("/api/rents")
def api_add_rent(req: RentRecordRequest, user: dict = Depends(auth.get_current_user)):
    ok, msg = services.add_rent_record(req.data, user["username"])
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"message": msg}


@app.put("/api/rents/{record_id}")
def api_update_rent(record_id: int, req: RentRecordRequest, user: dict = Depends(auth.get_current_user)):
    ok, msg = services.update_rent_record(record_id, req.data, user["username"])
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"message": msg}


@app.delete("/api/rents/{record_id}")
def api_delete_rent(record_id: int, user: dict = Depends(auth.get_current_user)):
    ok, msg = services.delete_rent_record(record_id, user["username"])
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"message": msg}


# ---- 租金管理页「导出 Excel」列定义 ----------------------------------------
# 与页面表格（static/js/rents.js 表头）逐一对应，规则同合同管理页：
#   列顺序 / 表头名称 / 单元格展示口径跟随页面，「操作」列不导出。
#   period 类型：页面把「所属期间」显示为 period_start ~ period_end，导出同样拼接。
RENT_EXPORT_COLUMNS = [
    ("id", "ID", "int"),
    ("contract_no", "合同编号", "text"),
    ("house_no", "房屋编号", "text"),
    ("lessee", "承租方", "text"),
    ("receipt_date", "收款日期", "text"),
    ("amount", "金额", "money"),
    ("period_start", "所属期间", "period"),
    ("payment_method", "租金支付方式", "text"),
    ("payment_status", "收款状态", "text"),
    ("description", "备注", "text"),
]
# 可排序字段：页面 data-key 里「所属期间」按 period_start 排，故一并纳入
_RENT_SORTABLE_KEYS = {f for f, _h, _k in RENT_EXPORT_COLUMNS} | {"period_start", "period_end"}
_RENT_NUM_FIELDS = {"id", "amount"}
_RENT_DATE_FIELDS = {"receipt_date", "period_start"}


def _sort_rents(data: list, key: str, sort_dir: str) -> list:
    """租金列表按页面当前排序状态排序"""
    return _sort_export_rows(data, key, sort_dir, _RENT_NUM_FIELDS,
                             _RENT_DATE_FIELDS, _RENT_SORTABLE_KEYS)


def build_rent_export_rows(data: list) -> list:
    """把租金记录转成导出行：金额为数值，所属期间按页面口径拼接"""
    return _build_export_rows(data, RENT_EXPORT_COLUMNS)


@app.get("/api/rents/export/excel")
def api_export_rents_excel(statuses: str = "", search: str = "",
                           receipt_date_from: str = "", receipt_date_to: str = "",
                           sort: str = "receipt_date", sort_dir: str = "desc",
                           user: dict = Depends(auth.get_current_user)):
    """导出租金明细表 Excel：与页面当前展示保持一致
    - 同一筛选条件（关键字 + 收款状态 + 收款日期区间），导出全部匹配记录（不受分页影响）
    - 列集合/顺序/表头与页面表格一致（不含「操作」列）
    - 单元格按页面展示值输出（金额 fmtMoney 口径、所属期间「起 ~ 止」、状态为显示文本）
    - 排序跟随页面当前排序（默认收款日期倒序）
    """
    status_list = [s for s in statuses.split(",") if s] if statuses else None
    data = _sort_rents(services.list_rent_records(statuses=status_list, search=search,
                                                  receipt_date_from=receipt_date_from,
                                                  receipt_date_to=receipt_date_to),
                       sort, sort_dir)
    headers = [h for _f, h, _k in RENT_EXPORT_COLUMNS]
    money_cols = [i for i, (_f, _h, k) in enumerate(RENT_EXPORT_COLUMNS) if k == "money"]
    rows = build_rent_export_rows(data)
    content = excel_utils.build_xlsx(headers, rows, "租金数据", money_cols=money_cols)
    filename = f"租金数据_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    quoted = quote(filename)
    return StreamingResponse(io.BytesIO(content), media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                             headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quoted}"})


@app.get("/api/rents/export/pdf")
def api_export_rents_pdf(statuses: str = "", search: str = "",
                         receipt_date_from: str = "", receipt_date_to: str = "",
                         user: dict = Depends(auth.get_current_user)):
    """租金 PDF 导出：与页面同一筛选条件（含收款日期区间），列沿用既有 PDF 版式"""
    status_list = [s for s in statuses.split(",") if s] if statuses else None
    data = services.list_rent_records(statuses=status_list, search=search,
                                      receipt_date_from=receipt_date_from,
                                      receipt_date_to=receipt_date_to)
    headers = ["记录ID", "合同编号", "房屋编号", "承租方", "承租人", "收款日期", "金额",
               "期间开始", "期间截止", "收款账户", "开票日期", "备注", "付款方式", "收款状态"]
    rows = [[d.get(h) for h in ["id", "contract_no", "house_no", "lessee", "tenant", "receipt_date",
                                "amount", "period_start", "period_end", "account", "invoice_date",
                                "description", "payment_method", "payment_status"]] for d in data]
    content = excel_utils.build_pdf(headers, rows, "租金数据")
    filename = f"租金数据_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    quoted = quote(filename)
    return StreamingResponse(io.BytesIO(content), media_type="application/pdf",
                             headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quoted}"})


# ---------------------------------------------------------------- 报表统计
REPORT_TYPES = ("合同统计报表", "租金收入报表", "收款状态报表")
# 「合同统计报表」金额折线纳入的状态（需求指定三态；其余状态只进柱状图）
CONTRACT_REPORT_AMOUNT_STATUS = ("已完成", "已中止", "执行中")


def _build_report(report_type: str, start_date: str, end_date: str) -> dict:
    conn = None
    try:
        if report_type not in REPORT_TYPES:
            raise HTTPException(status_code=400, detail=f"未知报表类型: {report_type}")
        if not start_date or not end_date:
            raise HTTPException(status_code=400, detail="请选择日期范围")
        if start_date > end_date:
            raise HTTPException(status_code=400, detail="开始日期不能晚于结束日期")
        conn = DatabaseUtils.get_connection()
        if not conn:
            raise HTTPException(status_code=500, detail="无法连接数据库")
        if report_type == "合同统计报表":
            # ── 口径（2026-09-18 扩容）──
            #   横轴 = 合同状态（原按状态分组，与既有柱状图一致，不新增统计维度）；
            #   柱值 = 该状态合同数（chart.values，旧字段保持兼容）；
            #   折线值 = 该状态合同总金额（chart.amounts），数据范围限定在
            #            「已完成 / 已中止 / 执行中」三种状态，其余状态（待审批等）
            #            不进折线但不影响柱状图；
            #   金额取 annual_rent（年租金总额），为空回退 monthly_rent × 12
            #   （与 services 合同金额口径一致）；金额列以「分」存储，除以 100 转元，
            #   全程 Decimal 累加后再一次性 round，避免 float 记账误差。
            cursor = DatabaseUtils.execute_query(conn,
                "SELECT contract_no, sign_date, lessee, start_date, end_date, status, monthly_rent, annual_rent FROM contracts WHERE sign_date BETWEEN ? AND ?",
                (start_date, end_date))
            rows = cursor.fetchall() if cursor else []
            cursor3 = DatabaseUtils.execute_query(conn,
                "SELECT status, COUNT(*), "
                "COALESCE(SUM(CASE WHEN annual_rent IS NOT NULL AND annual_rent <> 0 THEN annual_rent "
                "ELSE COALESCE(monthly_rent, 0) * 12 END), 0) "
                "FROM contracts WHERE sign_date BETWEEN ? AND ? GROUP BY status", (start_date, end_date))
            chart_rows = cursor3.fetchall() if cursor3 else []
            labels = [r[0] for r in chart_rows]
            chart = {"labels": labels,
                     "values": [r[1] for r in chart_rows],
                     # 前端按本清单决定哪些状态画折线点（其余给 null，折线断开，不伪造 0）
                     "amount_statuses": list(CONTRACT_REPORT_AMOUNT_STATUS),
                     "amounts": [float(round(Decimal(str(r[2] or 0)) / 100, 2)) for r in chart_rows]}
            headers = ["合同编号", "签约日期", "承租方", "租赁开始日期", "租赁截止日期", "合同状态", "月租金额", "年租金总额"]
            return {"headers": headers, "rows": rows, "chart": chart}
        elif report_type == "租金收入报表":
            cursor = DatabaseUtils.execute_query(conn,
                "SELECT contract_no, lessee, receipt_date, amount, period_start, period_end FROM rent_records WHERE receipt_date BETWEEN ? AND ?",
                (start_date, end_date))
            rows = cursor.fetchall() if cursor else []
            cursor2 = DatabaseUtils.execute_query(conn,
                "SELECT strftime('%Y-%m', receipt_date) as month, SUM(amount) FROM rent_records WHERE receipt_date BETWEEN ? AND ? GROUP BY month ORDER BY month",
                (start_date, end_date))
            chart_rows = cursor2.fetchall() if cursor2 else []
            chart = {"labels": [r[0] for r in chart_rows],
                     "values": [r[1] for r in chart_rows]}
            headers = ["合同编号", "承租方", "收款日期", "收款金额", "所属期间开始", "所属期间截止"]
            return {"headers": headers, "rows": rows, "chart": chart}
        else:  # 收款状态报表
            # ── 口径（2026-09-18 改为「合同口径」，修复未结清恒为 0 的缺陷）──
            #   旧版按「收款记录的 payment_status 快照」分组：未结清合同（累计已收=0）
            #   天然没有任何收款记录，导致「未结清」永远 0 份 0 元、图表份数合计
            #   小于执行中合同总数（2026-09-18 实测 22/27，5 份未结清合同不可见，
            #   而本报表的用途恰是「挑部分收款/未结清合同催收」）。
            #   现改为以合同的权威收款状态分组（唯一真源 contracts.payment_status，
            #   由 services.recalc_contract_payment_status 维护）：
            #   ① 合同份数 = 各状态的「执行中」合同数（与合同管理页筛选可直接对账，
            #      不依赖是否存在收款记录）；
            #   ② 金额合计 = 该状态合同在所选区间内的收款金额之和（Decimal 累加，
            #      输出两位小数，杜绝 float 记账）；
            #   ③ 明细行 = 区间内、执行中合同的收款记录；「收款状态」列显示合同
            #      权威状态（保证明细与图表分组一致，不受历史快照漂移影响）。
            cursor = DatabaseUtils.execute_query(
                conn, "SELECT contract_no, IFNULL(payment_status, '') FROM contracts WHERE status = ?",
                ("执行中",))
            status_of = {}
            for row in (cursor.fetchall() if cursor else []):
                if row and row[0]:
                    status_of[row[0]] = services.normalize_payment_status(row[1])

            stat_order = [services.PAYMENT_STATUS_SETTLED,
                          services.PAYMENT_STATUS_PARTIAL,
                          services.PAYMENT_STATUS_UNSETTLED]
            amount_agg = {k: Decimal("0") for k in stat_order}
            records = [r for r in (services.list_rent_records() or [])
                       if r.get("receipt_date")
                       and start_date <= str(r.get("receipt_date")) <= end_date
                       and r.get("contract_no") in status_of]
            for r in records:
                k = status_of.get(r.get("contract_no"), services.PAYMENT_STATUS_UNSETTLED)
                amt = r.get("amount")
                if amt is None:
                    continue
                try:
                    amount_agg[k] += Decimal(str(amt))
                except (InvalidOperation, ValueError, TypeError):
                    pass
            rows = [[r.get("contract_no"), r.get("lessee"), r.get("receipt_date"), r.get("amount"),
                     f'{r.get("period_start") or ""} ~ {r.get("period_end") or ""}',
                     status_of.get(r.get("contract_no"), services.PAYMENT_STATUS_UNSETTLED)]
                    for r in records]
            chart = {"title": "收款状态分布",
                     "labels": stat_order,
                     "counts": [sum(1 for s in status_of.values() if s == k) for k in stat_order],
                     "amounts": [float(round(amount_agg[k], 2)) for k in stat_order]}
            headers = ["合同编号", "承租方", "收款日期", "收款金额", "所属期间", "收款状态"]
            # 收款金额为数值列，导出时套 '#,##0.00'（与合同/租金导出一致）
            return {"headers": headers, "rows": rows, "chart": chart, "money_cols": [3]}
    finally:
        if conn:
            DatabaseUtils.close_connection(conn)


@app.get("/api/reports")
def api_reports(report_type: str, start_date: str, end_date: str,
                user: dict = Depends(auth.get_current_user)):
    return _build_report(report_type, start_date, end_date)


@app.get("/api/reports/export")
def api_reports_export(report_type: str, start_date: str, end_date: str, fmt: str = "excel",
                       user: dict = Depends(auth.get_current_user)):
    result = _build_report(report_type, start_date, end_date)
    headers = result["headers"]
    rows = result["rows"]
    money_cols = result.get("money_cols")  # 数值列（如收款金额），导出时套金额格式
    name_map = {"合同统计报表": "合同统计", "租金收入报表": "租金收入", "收款状态报表": "收款状态"}
    name = name_map.get(report_type, "报表")
    if fmt == "pdf":
        content = excel_utils.build_pdf(headers, rows, f"{name}（{start_date} ~ {end_date}）")
        filename = f"{name}_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
        quoted = quote(filename)
        return StreamingResponse(io.BytesIO(content), media_type="application/pdf",
                                 headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quoted}"})
    content = excel_utils.build_xlsx(headers, rows, name, money_cols=money_cols)
    filename = f"{name}_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    quoted = quote(filename)
    return StreamingResponse(io.BytesIO(content), media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                             headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quoted}"})


# ---------------------------------------------------------------- 基础资料
@app.get("/api/basic/houses")
def api_list_houses(search: str = "", user: dict = Depends(auth.get_current_user)):
    return {"data": services.list_houses(search=search)}


@app.post("/api/basic/houses")
def api_add_house(req: HouseRequest, user: dict = Depends(auth.get_current_user)):
    ok, msg = services.add_house(req.data, user["username"])
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"message": msg}


@app.put("/api/basic/houses/{house_id}")
def api_update_house(house_id: int, req: HouseRequest, user: dict = Depends(auth.get_current_user)):
    ok, msg = services.update_house(house_id, req.data, user["username"])
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"message": msg}


@app.delete("/api/basic/houses/{house_id}")
def api_delete_house(house_id: int, user: dict = Depends(auth.get_current_user)):
    ok, msg = services.delete_house(house_id, user["username"])
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"message": msg}


@app.get("/api/basic/houses/export/excel")
def api_export_houses_excel(search: str = "", user: dict = Depends(auth.get_current_user)):
    data = services.list_houses(search=search)
    headers = ["ID", "房屋编号", "房屋类型", "房屋位置", "房屋面积", "用途"]
    rows = [[d.get(h) for h in ["id", "house_no", "house_type", "house_location", "house_area", "usage"]] for d in data]
    content = excel_utils.build_xlsx(headers, rows, "房屋资料")
    filename = f"房屋资料_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    quoted = quote(filename)
    return StreamingResponse(io.BytesIO(content), media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                             headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quoted}"})


@app.post("/api/basic/houses/import")
async def api_import_houses(file: UploadFile = File(...), user: dict = Depends(auth.get_current_user)):
    """房屋资料 Excel 批量导入（对齐原版 HouseDataModule.importHouseFromExcel）"""
    raw = await file.read()
    _check_import_size(raw)  # P-02（2026-09-17 交付整改）：补齐导入大小校验
    try:
        headers, rows = excel_utils.parse_excel_upload(raw)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Excel 解析失败: {str(e)}")
    required = ["房屋编号", "房屋类型", "房屋位置"]
    missing = [c for c in required if c not in headers]
    if missing:
        raise HTTPException(status_code=400, detail=f"Excel 缺少必要列: {', '.join(missing)}")
    hmap = {h: i for i, h in enumerate(headers)}
    success, failed = 0, []
    for idx, row in enumerate(rows, start=2):
        def cell(name):
            i = hmap.get(name)
            if i is None or i >= len(row):
                return ""
            v = row[i]
            return "" if v is None else str(v).strip()
        try:
            house_area = None
            try:
                house_area = float(str(cell("房屋面积")).replace(",", "")) if cell("房屋面积") else None
            except ValueError:
                house_area = None
            ok, msg = services.add_house({
                "house_no": cell("房屋编号"),
                "house_type": cell("房屋类型"),
                "house_location": cell("房屋位置"),
                "house_area": house_area,
                "usage": cell("用途") or "商用",
            }, user["username"])
            if ok:
                success += 1
            else:
                failed.append((idx, msg))
        except Exception as e:
            failed.append((idx, str(e)))
    return {"message": f"导入完成：成功 {success} 条，失败 {len(failed)} 条", "success": success, "failed": failed}


@app.get("/api/basic/tenants")
def api_list_tenants(search: str = "", user: dict = Depends(auth.get_current_user)):
    return {"data": services.list_tenants(search=search)}


@app.post("/api/basic/tenants")
def api_add_tenant(req: TenantRequest, user: dict = Depends(auth.get_current_user)):
    ok, msg = services.add_tenant(req.data, user["username"])
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"message": msg}


@app.put("/api/basic/tenants/{tenant_id}")
def api_update_tenant(tenant_id: int, req: TenantRequest, user: dict = Depends(auth.get_current_user)):
    ok, msg = services.update_tenant(tenant_id, req.data, user["username"])
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"message": msg}


@app.delete("/api/basic/tenants/{tenant_id}")
def api_delete_tenant(tenant_id: int, user: dict = Depends(auth.get_current_user)):
    ok, msg = services.delete_tenant(tenant_id, user["username"])
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"message": msg}


@app.get("/api/basic/tenants/export/excel")
def api_export_tenants_excel(search: str = "", user: dict = Depends(auth.get_current_user)):
    data = services.list_tenants(search=search)
    headers = ["ID", "承租人名称", "联系人", "证件号", "联系电话"]
    rows = [[d.get(h) for h in ["id", "tenant_name", "contact_person", "contact_id", "contact_phone"]] for d in data]
    content = excel_utils.build_xlsx(headers, rows, "承租人资料")
    filename = f"承租人资料_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    quoted = quote(filename)
    return StreamingResponse(io.BytesIO(content), media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                             headers={"Content-Disposition": f"attachment; filename*=UTF-8''{quoted}"})


@app.post("/api/basic/tenants/import")
async def api_import_tenants(file: UploadFile = File(...), user: dict = Depends(auth.get_current_user)):
    """承租人资料 Excel 批量导入（对齐原版 TenantDataModule.importTenantFromExcel）"""
    raw = await file.read()
    _check_import_size(raw)
    try:
        headers, rows = excel_utils.parse_excel_upload(raw)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Excel 解析失败: {str(e)}")
    required = ["承租人名称"]
    missing = [c for c in required if c not in headers]
    if missing:
        raise HTTPException(status_code=400, detail=f"Excel 缺少必要列: {', '.join(missing)}")
    hmap = {h: i for i, h in enumerate(headers)}
    success, failed = 0, []
    for idx, row in enumerate(rows, start=2):
        def cell(name):
            i = hmap.get(name)
            if i is None or i >= len(row):
                return ""
            v = row[i]
            return "" if v is None else str(v).strip()
        try:
            ok, msg = services.add_tenant({
                "tenant_name": cell("承租人名称"),
                "contact_person": cell("联系人"),
                "contact_id": cell("证件号") or cell("身份证号"),
                "contact_phone": cell("联系电话") or cell("电话"),
            }, user["username"])
            if ok:
                success += 1
            else:
                failed.append((idx, msg))
        except Exception as e:
            failed.append((idx, str(e)))
    return {"message": f"导入完成：成功 {success} 条，失败 {len(failed)} 条", "success": success, "failed": failed}


@app.get("/api/basic/landlords")
def api_list_landlords(user: dict = Depends(auth.get_current_user)):
    return {"data": services.list_landlords()}


@app.post("/api/basic/landlords")
def api_add_landlord(req: LandlordRequest, user: dict = Depends(auth.get_current_user)):
    ok, msg = services.add_landlord(req.data, user["username"])
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"message": msg}


@app.put("/api/basic/landlords/{landlord_id}")
def api_update_landlord(landlord_id: int, req: LandlordRequest, user: dict = Depends(auth.get_current_user)):
    ok, msg = services.update_landlord(landlord_id, req.data, user["username"])
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"message": msg}


@app.delete("/api/basic/landlords/{landlord_id}")
def api_delete_landlord(landlord_id: int, user: dict = Depends(auth.get_current_user)):
    ok, msg = services.delete_landlord(landlord_id, user["username"])
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"message": msg}


@app.get("/api/basic/utility-fees")
def api_list_utility_fees(user: dict = Depends(auth.get_current_user)):
    return {"data": services.list_utility_fees()}


@app.post("/api/basic/utility-fees")
def api_add_utility_fee(req: UtilityFeeRequest, user: dict = Depends(auth.get_current_user)):
    ok, msg = services.add_utility_fee(req.data, user["username"])
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"message": msg}


@app.put("/api/basic/utility-fees/{fee_id}")
def api_update_utility_fee(fee_id: int, req: UtilityFeeRequest, user: dict = Depends(auth.get_current_user)):
    ok, msg = services.update_utility_fee(fee_id, req.data, user["username"])
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"message": msg}


@app.delete("/api/basic/utility-fees/{fee_id}")
def api_delete_utility_fee(fee_id: int, user: dict = Depends(auth.get_current_user)):
    ok, msg = services.delete_utility_fee(fee_id, user["username"])
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"message": msg}


@app.get("/api/basic/house-types")
def api_house_types(user: dict = Depends(auth.get_current_user)):
    return {"data": services.get_house_types()}


# ---------------------------------------------------------------- 系统设置（管理员）
@app.get("/api/settings/users")
def api_list_users(user: dict = Depends(auth.require_admin)):
    return {"data": auth.list_users()}


@app.post("/api/settings/users")
def api_add_user(req: UserRequest, user: dict = Depends(auth.require_admin)):
    ok, msg = auth.add_user(req.username, req.password or "", req.role or "操作员")
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"message": msg}


@app.put("/api/settings/users/{username}")
def api_update_user(username: str, req: UserRequest, user: dict = Depends(auth.require_admin)):
    ok, msg = auth.update_user(username, role=req.role, new_password=req.new_password)
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"message": msg}


@app.delete("/api/settings/users/{username}")
def api_delete_user(username: str, user: dict = Depends(auth.require_admin)):
    ok, msg = auth.delete_user(username, user["username"])
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"message": msg}


@app.get("/api/settings/software-info")
def api_get_software_info(user: dict = Depends(auth.get_current_user)):
    return services.get_software_info()


@app.post("/api/settings/software-info")
def api_save_software_info(req: SettingsRequest, user: dict = Depends(auth.require_admin)):
    ok, msg = services.save_software_info(req.data, user["username"])
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"message": msg}


@app.get("/api/settings/reminder-settings")
def api_get_reminder_settings(user: dict = Depends(auth.get_current_user)):
    return services.get_reminder_settings()


@app.post("/api/settings/reminder-settings")
def api_save_reminder_settings(req: SettingsRequest, user: dict = Depends(auth.require_admin)):
    ok, msg = services.save_reminder_settings(req.data, user["username"])
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"message": msg}


@app.get("/api/settings/auto-backup")
def api_get_auto_backup(user: dict = Depends(auth.get_current_user)):
    return services.get_auto_backup_settings()


@app.post("/api/settings/auto-backup")
def api_save_auto_backup(req: SettingsRequest, user: dict = Depends(auth.require_admin)):
    ok, msg = services.save_auto_backup_settings(req.data, user["username"])
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"message": msg}


@app.post("/api/settings/backup")
def api_backup(target_dir: str = "", user: dict = Depends(auth.require_admin)):
    ok, msg, path = services.backup_database(target_dir=target_dir or None, username=user["username"])
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"message": msg, "path": path}


@app.post("/api/settings/restore")
def api_restore(req: RestoreRequest, user: dict = Depends(auth.require_admin)):
    err = _validate_admin_db_path(req.backup_path, must_exist=True)
    if err:
        raise HTTPException(status_code=400, detail=f"恢复失败: {err}")
    ok, msg = services.restore_database(req.backup_path, user["username"])
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"message": msg}


@app.post("/api/settings/initialize")
def api_initialize(tables: str = "", user: dict = Depends(auth.require_admin)):
    """数据初始化：可选表清空（对齐原版 initData），未传 tables 时全量重建"""
    table_list = [t.strip() for t in tables.split(",") if t.strip()] if tables else None
    ok, msg = services.initialize_database(user["username"], tables=table_list)
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"message": msg}


@app.post("/api/settings/optimize")
def api_optimize(user: dict = Depends(auth.require_admin)):
    ok, msg = services.optimize_database(user["username"])
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"message": msg}


@app.post("/api/settings/recalc-payment-status")
def api_recalc_payment_status(user: dict = Depends(auth.require_admin)):
    """按「累计已收 vs 合同应收总租」全量重算收款状态，使合同管理与租金管理两页面口径一致"""
    ok, msg, detail = services.recalc_all_payment_statuses(user["username"])
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"message": msg, "changed": detail.get("changed", []), "contracts": detail.get("contracts", 0)}


@app.post("/api/settings/switch-database")
def api_switch_database(req: SwitchDbRequest, user: dict = Depends(auth.require_admin)):
    err = _validate_admin_db_path(req.db_path, must_exist=True)
    if err:
        raise HTTPException(status_code=400, detail=f"切换失败: {err}")
    ok, msg = services.switch_database(req.db_path)
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"message": msg}


@app.post("/api/settings/create-database")
def api_create_database(req: CreateDbRequest, user: dict = Depends(auth.require_admin)):
    """新建空库并切换。⚠️ 语义是「新建」：目标文件已存在时一律拒绝，不覆盖已有数据。

    历史缺陷（2026-09-18 修复）：本接口曾对已存在的库直接透传到 create_empty_database，
    而该函数会 DROP 重建 contracts/rent_records/tenants，导致用户数据被静默清空，
    且报出「数据库初始化存在问题: 默认提醒设置插入失败」这类与事实相反的提示。
    """
    err = _validate_admin_db_path(req.db_path, must_exist=False)
    if err:
        raise HTTPException(status_code=400, detail=f"创建失败: {err}")
    # 位置校验：只拦系统敏感目录 / 网络路径，不再要求「必须在项目目录内」
    # （2026-09-18 修正：多副本部署下 PROJECT_DIR 只是服务自己那一份，
    #  原限制会无差别拒绝「建到另一份副本」「建到 D:\ 备份盘」等合法操作）
    err = _validate_new_db_path(req.db_path)
    if err:
        raise HTTPException(status_code=400, detail=f"创建失败: {err}")
    abs_p = os.path.abspath(req.db_path)
    if not os.path.isdir(os.path.dirname(abs_p) or "."):
        raise HTTPException(status_code=400, detail="创建失败: 目标目录不存在")
    # 已存在守卫前置到接口层：让前端拿到明确的 400 语义，不进入销毁性的建库流程
    if os.path.exists(abs_p):
        raise HTTPException(status_code=400,
                            detail=f"创建失败: 目标数据库已存在（{abs_p}）。为避免覆盖已有数据未做任何修改；"
                                   "如需使用该库请点「选择数据库」，如需新建请换一个文件名。")
    ok, msg = services.create_database(req.db_path, current_user=user)
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    # 记审计：新建库是切库级操作，换库后 operation_logs 在新库里，故用旧库上下文记录会丢失，
    # 这里仅落运行时日志，便于事后追溯「谁在什么时候切到了哪个库」。
    log_warning(f"[创建数据库] 用户 {user.get('username')} 新建并切换到 {abs_p}")
    return {"message": msg, "path": abs_p}


@app.get("/api/settings/backup-settings")
def api_get_backup_settings(user: dict = Depends(auth.get_current_user)):
    """备份/数据库维护辅助信息（当前库路径、可用备份文件列表）"""
    db_path = services.get_db_path()
    backup_dir = os.path.join(PROJECT_DIR, "backup")
    backups = []
    if os.path.isdir(backup_dir):
        backups = sorted(
            [f for f in os.listdir(backup_dir) if f.endswith(".db")],
            key=lambda f: os.path.getmtime(os.path.join(backup_dir, f)), reverse=True)[:20]
    return {"db_path": db_path, "backup_dir": str(backup_dir), "backups": backups}


@app.get("/api/settings/logs")
def api_get_logs(kind: str = "operation", limit: int = 200,
                 user: dict = Depends(auth.require_admin)):
    if kind == "runtime":
        return services.get_runtime_logs(lines=limit)
    logs = get_operation_logs(limit=limit)
    return {"data": logs}


@app.post("/api/settings/clear-logs")
def api_clear_logs(kind: str = "runtime",
                   user: dict = Depends(auth.require_admin)):
    if kind == "runtime":
        return services.clear_runtime_logs()
    if kind == "operation":
        return services.clear_operation_logs()
    return {"ok": False, "message": f"未知日志类型: {kind}"}


# ---------------------------------------------------------------- 笔记
@app.get("/api/notes")
def api_list_notes(user: dict = Depends(auth.get_current_user)):
    return {"data": services.list_notes()}


@app.post("/api/notes")
def api_save_note(req: NoteRequest, user: dict = Depends(auth.get_current_user)):
    ok, msg, note_id = services.save_note(req.note_id, req.note_name, req.content, user["username"])
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"message": msg, "id": note_id}


@app.delete("/api/notes/{note_id}")
def api_delete_note(note_id: int, user: dict = Depends(auth.get_current_user)):
    ok, msg = services.delete_note(note_id, user["username"])
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"message": msg}


# ---------------------------------------------------------------- 租金调整
@app.get("/api/rent-adjustments")
def api_list_rent_adjustments(statuses: str = "", search: str = "",
                              user: dict = Depends(auth.get_current_user)):
    status_list = [s for s in statuses.split(",") if s] if statuses else None
    return services.list_rent_adjustments(statuses=status_list, search=search)


@app.post("/api/rent-adjustments")
def api_create_rent_adjustment(req: RentAdjustmentRequest, user: dict = Depends(auth.get_current_user)):
    ok, msg = services.create_rent_adjustment(req.data, user["username"])
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"message": msg}


@app.get("/api/rent-adjustments/schedule/{contract_no}")
def api_rent_schedule(contract_no: str, user: dict = Depends(auth.get_current_user)):
    return services.get_rent_schedule(contract_no)


@app.post("/api/rent-adjustments/{adjust_id}/approve")
def api_approve_rent_adjustment(adjust_id: int, req: RentAdjustmentApproveRequest,
                                user: dict = Depends(auth.require_admin)):
    ok, msg = services.approve_rent_adjustment(
        adjust_id, req.action, {"reject_reason": req.reject_reason}, user["username"])
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"message": msg}


@app.post("/api/rent-adjustments/{adjust_id}/cancel")
def api_cancel_rent_adjustment(adjust_id: int, user: dict = Depends(auth.get_current_user)):
    ok, msg = services.cancel_rent_adjustment(adjust_id, user["username"])
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"message": msg}


@app.delete("/api/rent-adjustments/{adjust_id}")
def api_delete_rent_adjustment(adjust_id: int, user: dict = Depends(auth.require_admin)):
    """删除租金调整明细记录（仅管理员）。已通过记录删除后级联重建分段并重算租金。"""
    ok, msg = services.delete_rent_adjustment(adjust_id, user["username"])
    if not ok:
        raise HTTPException(status_code=400, detail=msg)
    return {"message": msg}


# ---------------------------------------------------------------- 静态文件
@app.get("/")
def api_index():
    return FileResponse(str(PROJECT_DIR / "static" / "index.html"), headers={"Cache-Control": "no-store"})


app.mount("/static", StaticFiles(directory=str(PROJECT_DIR / "static")), name="static")


@app.middleware("http")
async def no_cache_static(request, call_next):
    """静态文件统一禁用缓存：客户端（含微信内置浏览器）任何刷新都拿到最新版，避免加载旧 JS/旧页面"""
    response = await call_next(request)
    if request.url.path.startswith("/static"):
        response.headers["Cache-Control"] = "no-store"
    return response


# 启动时初始化数据库路径 + 启动自动备份调度线程
@app.on_event("startup")
def startup():
    # 2026-09-11 加固：数据库「解析→自愈→实连校验」，任何失败都会写入服务日志
    st = _init_database_on_startup()
    log_info(f"[startup] 数据库状态: {st.get('detail')}（来源: {st.get('source')}）")
    print(f"[startup] 数据库状态: {st.get('detail')}（来源: {st.get('source')}）")
    # 自动备份调度：守护线程随进程退出，不阻塞主服务
    t = threading.Thread(target=services.auto_backup_worker, daemon=True, name="auto-backup-worker")
    t.start()
    log_info("[startup] 自动备份调度线程已启动")
    print("[startup] 自动备份调度线程已启动")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
