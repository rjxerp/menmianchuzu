# -*- coding: utf-8 -*-
"""配置管理工具模块，用于处理系统配置的保存和加载"""
import copy
import os
import json
# 避免循环导入，使用静默错误处理
try:
    from logger_module import log_info, log_error
except ImportError:
    # 如果无法导入日志模块，提供基本的日志函数
    def log_info(msg):
        print(f"INFO: {msg}")
    
    def log_error(msg):
        print(f"ERROR: {msg}")

class ConfigManager:
    """配置管理器，提供配置的保存和加载功能"""
    
    # 配置文件环境变量名
    _CONFIG_ENV_VAR = 'LEASE_CONFIG_PATH'
    
    # 默认配置文件名称
    _DEFAULT_CONFIG_FILENAME = 'config.json'
    
    # 当前使用的配置文件路径
    _current_config_path = None
    
    # 默认配置
    _default_config = {
        'database_path': None,  # 数据库路径将在首次运行时设置
        'app_settings': {
            'theme': 'default',
            'auto_backup': False,
            'backup_interval': 24  # 小时
        },
        'logging': {
            'log_dir': 'logs',
            'log_level': 'INFO',  # DEBUG, INFO, WARNING, ERROR, CRITICAL
            'max_log_size': 10 * 1024 * 1024,  # 默认10MB
            'backup_count': 5,  # 保留的备份文件数
            'enable_console': True  # 是否启用控制台日志
        },
        'operation_logging': {
            'batch_size': 10,  # 批量提交阈值
            'max_batch_age': 60,  # 最大批处理等待时间（秒）
            'async_processing': False  # 是否启用异步处理
        }
    }
    
    @classmethod
    def get_config_path(cls):
        """获取当前使用的配置文件路径
        
        优先级:
        1. 手动设置的路径 (通过set_config_path方法)
        2. 环境变量中指定的路径
        3. 程序目录下的默认配置文件
        
        Returns:
            str: 配置文件的绝对路径
        """
        # 如果已手动设置路径，优先使用
        if cls._current_config_path:
            return os.path.abspath(cls._current_config_path)
        
        # 检查环境变量
        env_path = os.environ.get(cls._CONFIG_ENV_VAR)
        if env_path:
            return os.path.abspath(env_path)
        
        # 默认路径：程序所在目录下的config.json
        default_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), cls._DEFAULT_CONFIG_FILENAME)
        return default_path
    
    @classmethod
    def set_config_path(cls, config_path):
        """动态设置配置文件路径
        
        Args:
            config_path (str): 新的配置文件路径，可以是相对路径或绝对路径
            
        Returns:
            bool: 设置是否成功
        """
        try:
            # 验证路径是否有效
            if config_path:
                # 确保目录存在
                config_dir = os.path.dirname(config_path)
                if config_dir and not os.path.exists(config_dir):
                    os.makedirs(config_dir, exist_ok=True)
                
                # 设置为绝对路径
                cls._current_config_path = os.path.abspath(config_path)
                log_info(f"配置文件路径已更改为: {cls._current_config_path}")
            else:
                # 清除手动设置的路径，恢复默认搜索逻辑
                cls._current_config_path = None
                log_info("配置文件路径已重置为默认值")
            return True
        except Exception as e:
            log_error(f"设置配置文件路径失败: {str(e)}")
            return False
    
    @classmethod
    def load_config(cls):
        """加载配置文件
        
        Returns:
            dict: 配置字典，如果文件不存在或读取失败则返回默认配置
        """
        config_path = cls.get_config_path()
        
        try:
            if os.path.exists(config_path):
                # 确保正确处理包含中文的文件路径
                with open(config_path, 'r', encoding='utf-8') as f:
                    config = json.load(f)
                    # 合并默认配置，确保所有必需的键都存在
                    return cls._merge_configs(cls._default_config, config)
            else:
                # 配置文件不存在，返回默认配置
                log_info(f"配置文件不存在，将使用默认配置: {config_path}")
                return copy.deepcopy(cls._default_config)  # Q-04：深拷贝，防调用方污染类默认值
        except Exception as e:
            log_error(f"加载配置文件失败: {str(e)}")
            # 出错时返回默认配置
            return copy.deepcopy(cls._default_config)  # Q-04：深拷贝，防调用方污染类默认值
    
    @classmethod
    def save_config(cls, config):
        """保存配置到文件
        
        Args:
            config (dict): 要保存的配置字典
            
        Returns:
            bool: 保存是否成功
        """
        config_path = cls.get_config_path()
        
        try:
            # 确保目录存在
            os.makedirs(os.path.dirname(config_path), exist_ok=True)
            
            # 合并配置，确保包含所有必需的键
            full_config = cls._merge_configs(cls._default_config, config)
            
            # 保存到文件，确保正确处理中文路径和内容
            with open(config_path, 'w', encoding='utf-8') as f:
                json.dump(full_config, f, ensure_ascii=False, indent=2)
            
            log_info(f"配置已成功保存到: {config_path}")
            return True
        except Exception as e:
            log_error(f"保存配置文件失败: {str(e)}")
            return False
    
    @classmethod
    def get_database_path(cls):
        """获取保存的数据库路径

        支持相对路径：以配置文件所在目录为基准解析为绝对路径，
        便于项目整体迁移（如 config.json 中写 "Data\\xxx.db"）。

        Returns:
            str: 数据库路径（绝对路径），如果未设置则返回None
        """
        config = cls.load_config()
        db_path = config.get('database_path')
        if not db_path:
            return None
        # 相对路径 → 基于配置文件所在目录解析为绝对路径
        if not os.path.isabs(db_path):
            config_dir = os.path.dirname(cls.get_config_path())
            db_path = os.path.abspath(os.path.join(config_dir, db_path))
        return db_path
    
    @classmethod
    def get_logging_config(cls):
        """获取日志配置
        
        Returns:
            dict: 日志配置字典
        """
        config = cls.load_config()
        return config.get('logging', {})
    
    @classmethod
    def set_database_path(cls, db_path):
        """设置并保存数据库路径
        
        Args:
            db_path (str): 数据库文件路径
            
        Returns:
            bool: 保存是否成功
        """
        config = cls.load_config()
        # 确保数据库路径为绝对路径，正确处理中文路径
        if db_path:
            config['database_path'] = os.path.abspath(db_path)
        else:
            config['database_path'] = None
        return cls.save_config(config)
    
    @classmethod
    def update_logging_config(cls, logging_config):
        """更新日志配置
        
        Args:
            logging_config (dict): 要更新的日志配置
            
        Returns:
            bool: 保存是否成功
        """
        config = cls.load_config()
        # 合并日志配置
        if 'logging' not in config:
            config['logging'] = {}
        config['logging'].update(logging_config)
        return cls.save_config(config)
    
    @staticmethod
    def _merge_configs(default, user):
        """深度合并两个配置字典
        
        Args:
            default (dict): 默认配置字典
            user (dict): 用户配置字典
            
        Returns:
            dict: 合并后的配置字典
        """
        result = default.copy()
        if not isinstance(user, dict):
            return result
            
        for key, value in user.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                # 递归合并嵌套字典
                result[key] = ConfigManager._merge_configs(result[key], value)
            else:
                # 直接覆盖
                result[key] = value
        return result

# 全局配置管理器实例
config_manager = ConfigManager()