# -*- coding: utf-8 -*-
"""统一测试入口 —— 一键跑全部回归（P1-11，2026-09-11）

用法：
  python run_tests.py            # 跑全部
  python run_tests.py schema     # 只跑名字含 schema 的用例
  python run_tests.py web money  # 只跑指定用例

包含用例：
  test_web_api.py             75 断言 API 回归（登录/合同/租金/权限/备份/报表等）
  test_schema_regression.py   新建库 schema 冒烟 + 幂等补列（P0-1）
  test_fix_regression.py      历史修复回归
  test_money_regression.py    金额 元/分 换算回归
  test_pdf_security.py        PDF 导出安全回归（R-01 / CVE-2023-33733 防护 + reportlab 版本护栏）
  test_payment_status.py      收款状态三态判定 + 仪表盘口径统一回归（2026-09-14）
  test_contract_export.py     合同导出 Excel 与页面表格一致性回归（2026-09-14）
  test_rent_export.py         租金导出 Excel 与页面表格一致性回归（2026-09-14）
  test_contract_date_filter.py  合同起租/到期日期筛选回归（2026-09-14）
  test_rent_date_filter.py      租金收款日期区间筛选回归（2026-09-14）
  test_report_payment_status.py 收款状态报表口径回归（仅两表 / 仅执行中 / 三态 / 份数去重，2026-09-15）
  test_report_contract_stats.py 合同统计报表口径回归（三态金额折线 / 分→元 / 回退口径，2026-09-18）
  test_create_database_safety.py 创建数据库安全性回归（已存在拒绝覆盖 / 不再误报初始化失败，2026-09-18）
  test_renew_delete_reset.py   删除续签新合同 → 复位原合同续签状态回归（2026-09-17）
  test_security_hardening.py   安全加固回归：docs 关闭/CORS/安全头/权限矩阵/路径校验（2026-09-17）
"""
import os
import sys
import time
import subprocess

BASE = os.path.dirname(os.path.abspath(__file__))
PYTHON = sys.executable

ALL_TESTS = [
    "test_web_api.py",
    "test_schema_regression.py",
    "test_fix_regression.py",
    "test_money_regression.py",
    "test_pdf_security.py",
    "test_payment_status.py",
    "test_contract_export.py",
    "test_rent_export.py",
    "test_contract_date_filter.py",
    "test_rent_date_filter.py",
    "test_report_payment_status.py",
    "test_report_contract_stats.py",
    "test_create_database_safety.py",
    "test_renew_delete_reset.py",
    "test_security_hardening.py",
]


def main():
    args = [a.lower() for a in sys.argv[1:]]
    selected = [t for t in ALL_TESTS
                if not args or any(a in t.lower() for a in args)]
    if not selected:
        print("没有匹配的测试用例。可用:", ", ".join(ALL_TESTS))
        return 2
    print("=" * 62)
    print(f"统一测试入口：共 {len(selected)} 个用例，Python: {PYTHON}")
    print("=" * 62)
    failed = []
    for t in selected:
        path = os.path.join(BASE, t)
        if not os.path.isfile(path):
            print(f"⚠️  {t}: 文件不存在，跳过")
            continue
        print(f"\n▶ 运行 {t} ...")
        start = time.time()
        proc = subprocess.run([PYTHON, path], cwd=BASE)
        cost = time.time() - start
        if proc.returncode == 0:
            print(f"✅ {t} 通过 ({cost:.1f}s)")
        else:
            print(f"❌ {t} 失败 (exit={proc.returncode}, {cost:.1f}s)")
            failed.append(t)
    print("\n" + "=" * 62)
    if failed:
        print(f"结果: {len(selected) - len(failed)}/{len(selected)} 通过；失败: {', '.join(failed)}")
        return 1
    print(f"结果: {len(selected)}/{len(selected)} 全部通过 🎉")
    return 0


if __name__ == "__main__":
    sys.exit(main())
