/* ============================================================================
   check_report_bar_labels.js —— 报表「数值标签」无头回归脚本
   ----------------------------------------------------------------------------
   用途：不开浏览器，验证报表图表的数值标签确实渲染出来、位置正确、互不压字。

   覆盖：① 租金收入报表（月度金额，12 根柱，柱顶金额标签）
         ② 收款状态报表-正常数据（3 柱 + 右轴折线：柱顶份数标签 + 折线金额标签；
            首状态同为两系列最大值 → 点位与柱顶同高，验证「翻到点下方」的避让）
         ③ 收款状态报表-空数据（三态全 0：柱标签与金额标签同在基线附近，验右侧避让）
         ④ 收款状态报表-高低错落（折线点远离柱顶 → 全部走「点上方」默认位）
         ⑤ 合同统计报表-正常数据（4 柱 + 右轴「合同总金额」折线：柱顶整数标签 +
            金额标签；已逾期状态无折线点 → 断点处不得出现标签）
         ⑥ 合同统计报表-空数据（柱值 0、折线点在基线 → 验同带避让）
         ⑦ 合同统计报表-高低错落（柱 28 与折线金额极差大 → 验默认位与顶部避让）

   校验：标签文本与千分位格式、柱标签高于柱顶、金额标签贴近数据点、
         全部标签在绘图区内，柱标签×金额标签、金额标签×金额标签矩形不相交。

   运行： cd backend && node check_report_bar_labels.js
   退出码：0 = 全部通过；1 = 存在异常。
   注意：改动 static/js/reports.js 的 App.barTopLabels()/App.linePointLabels()/
         App._reportLineAlign() 后，本脚本的等价实现要同步更新。
   ============================================================================ */
"use strict";
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const base = path.join(__dirname, "..", "static", "vendor");
const W = 1000, H = 300;   // 模拟画布尺寸（约等于桌面端报表面板宽度）

// ── 以浏览器方式加载两个 UMD（脚本内含 CommonJS 分支，直接 require 会去找包）──
vm.runInThisContext(fs.readFileSync(path.join(base, "chart.umd.js"), "utf8"), { filename: "chart.umd.js" });
vm.runInThisContext(fs.readFileSync(path.join(base, "chartjs-plugin-datalabels.min.js"), "utf8"), { filename: "chartjs-plugin-datalabels.js" });
const Chart = globalThis.Chart;
Chart.register(globalThis.ChartDataLabels);

const fmtMoney = v => Number(v).toLocaleString("zh-CN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const fmtCount = v => Number(v).toLocaleString("zh-CN");
const CHAR_W = 6;   // 11px 字号下数字/逗号的近似宽度（px/字符），用于估算标签宽度

/* App.barTopLabels() 的等价实现（reports.js 里的那份是唯一真源）*/
function barTopLabels(formatter, num) {
  return {
    display: true, anchor: "end", align: "end", offset: 5, clamp: true,
    color: "#2c3e50", backgroundColor: "rgba(255,255,255,.88)", borderWidth: 0, borderRadius: 3,
    padding: { top: 2, bottom: 2, left: 4, right: 4 },
    font: { size: num > 24 ? 9 : num > 14 ? 10 : 11, weight: "600" },
    formatter,
  };
}

/* App._reportLineAlign() 的等价实现（reports.js 里的那份是唯一真源）*/
function lineLabelAlign(ctx) {
  try {
    const chart = ctx.chart, i = ctx.dataIndex;
    const barMeta = chart.getDatasetMeta(0);
    const lineMeta = chart.getDatasetMeta(ctx.datasetIndex);
    const pt = lineMeta && lineMeta.data[i];
    const bar = barMeta && barMeta.data[i];
    const area = chart.chartArea;
    if (pt && area) {
      const upLo = pt.y - 29, upHi = pt.y - 5;
      const dnLo = pt.y + 5, dnHi = pt.y + 29;
      const bandLo = bar ? bar.y - 25 : null, bandHi = bar ? bar.y - 5 : null;
      const hits = (lo, hi) => bar ? (lo <= bandHi && hi >= bandLo) : false;
      const upRoom = upLo >= area.top;
      const dnRoom = dnHi <= area.bottom;
      if (upRoom && !hits(upLo, upHi)) return "top";
      if (dnRoom && !hits(dnLo, dnHi)) return "bottom";
      return "right";
    }
  } catch (e) { /* 同主实现：异常退回默认 */ }
  return "top";
}

/* App.linePointLabels() 的等价实现（reports.js 里的那份是唯一真源）*/
function linePointLabels(formatter) {
  return {
    display: true, anchor: "center",
    align: lineLabelAlign,
    offset: ctx => (lineLabelAlign(ctx) === "right" ? 16 : 8),
    clamp: true,
    color: "#c0392b", backgroundColor: "rgba(255,255,255,.88)", borderWidth: 0, borderRadius: 3,
    padding: { top: 2, bottom: 2, left: 4, right: 4 },
    font: { size: 10, weight: "600" },
    formatter,
  };
}

// ── 极简假画布：只记录 fillText 的最终坐标（canvas 变换栈需自行维护）──
function buildCanvas() {
  const texts = [];
  let tx = 0, ty = 0;
  const stack = [];
  const ctx = {
    save() { stack.push([tx, ty]); },
    restore() { const p = stack.pop(); if (p) { tx = p[0]; ty = p[1]; } },
    beginPath() {}, closePath() {}, rect() {}, clip() {},
    moveTo() {}, lineTo() {}, arc() {}, quadraticCurveTo() {}, bezierCurveTo() {},
    fill() {}, stroke() {}, fillRect() {}, clearRect() {}, strokeRect() {},
    translate(x, y) { tx += x; ty += y; },
    rotate() {}, scale() {}, transform() {},
    setTransform() { tx = 0; ty = 0; }, resetTransform() { tx = 0; ty = 0; },
    drawImage() {}, putImageData() {}, getImageData: () => ({ data: [] }),
    createLinearGradient: () => ({ addColorStop() {} }), createPattern: () => null,
    setLineDash() {}, getLineDash: () => [], isPointInPath: () => false, isPointInStroke: () => false,
    measureText(t) {
      const lines = String(t).split("\n");
      return { width: lines[0].length * CHAR_W, actualBoundingBoxAscent: 8, actualBoundingBoxDescent: 2 };
    },
    fillText(t, x, y) { texts.push({ text: String(t), x: tx + x, y: ty + y }); },
    strokeText() {},
    font: "", textAlign: "", textBaseline: "", direction: "ltr", fillStyle: "", strokeStyle: "",
    lineWidth: 1, globalAlpha: 1, shadowBlur: 0, shadowColor: "",
    shadowOffsetX: 0, shadowOffsetY: 0, lineCap: "butt", lineJoin: "miter", miterLimit: 10,
  };
  const canvas = {
    width: W, height: H, style: {}, clientWidth: W, clientHeight: H, offsetWidth: W, offsetHeight: H,
    parentNode: null, ownerDocument: null, attributes: [],
    getAttribute: () => null, setAttribute() {}, addEventListener() {}, removeEventListener() {},
    getBoundingClientRect: () => ({ width: W, height: H, top: 0, left: 0 }),
  };
  ctx.canvas = canvas;
  canvas.getContext = () => ctx;
  return { canvas, texts };
}

// 由 fillText 记录估算标签外框（左对齐文本；y 为基线，上下各留出字高余量）
function textBox(t) {
  const w = t.text.length * CHAR_W;
  return { text: t.text, x0: t.x - 4, x1: t.x + w + 4, y0: t.y - 12, y1: t.y + 4 };
}
// 两框相交判定：x/y 同时侵入超过 5px（吸收基线/字宽估算误差）才视为压字
function overlap(a, b) {
  const dx = Math.min(a.x1, b.x1) - Math.max(a.x0, b.x0);
  const dy = Math.min(a.y1, b.y1) - Math.max(a.y0, b.y0);
  return dx > 5 && dy > 5;
}

/* ---------------------------------------------------------------- 用例数据 */
// 计数轴（左轴）通用配置：与 reports.js 的 isPayment/isContract 分支保持一致
//   顶部余量 = grace 15% + suggestedMax(最大值+1)，保证柱顶标签落在绘图区内
const countYScale = maxVal => ({
  beginAtZero: true, grace: "15%", suggestedMax: (maxVal || 0) + 1,
  ticks: { precision: 0 },
});
const paymentScales = {
  x: { title: { display: true, text: "收款状态" } },
  y: { ...countYScale(17), title: { display: true, text: "合同份数（去重）" } },
  y1: {
    beginAtZero: true, position: "right", grid: { drawOnChartArea: false },
    title: { display: true, text: "收款金额（元）" }, ticks: { callback: v => fmtMoney(v) },
  },
};
const moneyLabels = v => (v === null || v === undefined ? null : fmtMoney(v));

// 合同统计报表的双轴配置（与 reports.js 中 isContract 分支一一对应）
const contractScales = {
  x: { title: { display: true, text: "合同状态" } },
  y: { ...countYScale(29), title: { display: true, text: "合同数量" } },
  y1: {
    beginAtZero: true, position: "right", grid: { drawOnChartArea: false },
    title: { display: true, text: "合同总金额（元）" }, ticks: { callback: v => fmtMoney(v) },
  },
};
const contractDataset = (values, c) => ({
  label: "合同数量", data: values, yAxisID: "y", backgroundColor: "rgba(79,129,189,.75)",
  datalabels: barTopLabels(fmtCount, values.length),
});
// 「合同总金额」折线：非三态状态（已逾期）给 null → 断点，不渲染标签
const contractLine = c => ([{
  label: "合同总金额（元）", data: c.amounts, type: "line",
  borderColor: "#c0392b", backgroundColor: "rgba(192,57,43,.15)", yAxisID: "y1",
  spanGaps: true,
  datalabels: linePointLabels(moneyLabels),
}]);

const CASES = [
  {
    name: "租金收入报表（月度金额）",
    labels: ["2025-10", "2025-11", "2025-12", "2026-01", "2026-02", "2026-03",
      "2026-04", "2026-05", "2026-06", "2026-07", "2026-08", "2026-09"],
    values: [68312, 21000, 8000, 164800, 105000, 187040, 30600, 69600, 84800, 36000, 18900, 20400],
    format: v => fmtMoney(v).replace(/\.00$/, ""),   // 整元数省略 .00
    dataset: values => ({
      label: "金额", data: values, backgroundColor: "rgba(79,129,189,.75)",
      datalabels: barTopLabels(v => fmtMoney(v).replace(/\.00$/, ""), values.length),
    }),
    scales: {
      y: { beginAtZero: true, grace: "12%", ticks: { callback: v => fmtMoney(v) } },
    },
  },
  {
    name: "收款状态报表-正常数据（柱顶份数 + 折线金额标签）",
    labels: ["已结清", "部分收款", "未结清"],
    values: [17, 4, 0],                       // 末位为 0 值柱：标签仍需显示在基线上方
    amounts: [568840, 90900, 0],              // 右轴折线：每点均须有金额标签（含 0.00）
    format: fmtCount,
    barColors: ["rgba(39,174,96,.75)", "rgba(79,129,189,.75)", "rgba(230,126,34,.75)"],
    title: "收款状态分布",
    dataset: (values, c) => ({
      label: "合同份数（按合同编号去重）", data: values, yAxisID: "y", backgroundColor: c.barColors,
      datalabels: barTopLabels(fmtCount, values.length),
    }),
    extraDatasets: c => ([{
      label: "收款金额合计（元）", data: c.amounts, type: "line",
      borderColor: "#c0392b", backgroundColor: "rgba(192,57,43,.15)", yAxisID: "y1",
      datalabels: linePointLabels(moneyLabels),
    }]),
    scales: paymentScales,
  },
  {
    name: "收款状态报表-空数据（三态全 0）",
    labels: ["已结清", "部分收款", "未结清"],
    values: [0, 0, 0],                        // 区间内无收款：柱与折线都趴在基线上
    amounts: [0, 0, 0],
    format: fmtCount,
    barColors: ["rgba(39,174,96,.75)", "rgba(79,129,189,.75)", "rgba(230,126,34,.75)"],
    title: "收款状态分布",
    dataset: (values, c) => ({
      label: "合同份数（按合同编号去重）", data: values, yAxisID: "y", backgroundColor: c.barColors,
      datalabels: barTopLabels(fmtCount, values.length),
    }),
    extraDatasets: c => ([{
      label: "收款金额合计（元）", data: c.amounts, type: "line",
      borderColor: "#c0392b", backgroundColor: "rgba(192,57,43,.15)", yAxisID: "y1",
      datalabels: linePointLabels(moneyLabels),
    }]),
    scales: paymentScales,
  },
  {
    name: "收款状态报表-高低错落（折线点远离柱顶）",
    labels: ["已结清", "部分收款", "未结清"],
    values: [5, 17, 2],
    amounts: [100000, 20000, 80000],          // 每个折线点都与柱顶错开 → 应全走「点上方」
    format: fmtCount,
    barColors: ["rgba(39,174,96,.75)", "rgba(79,129,189,.75)", "rgba(230,126,34,.75)"],
    title: "收款状态分布",
    dataset: (values, c) => ({
      label: "合同份数（按合同编号去重）", data: values, yAxisID: "y", backgroundColor: c.barColors,
      datalabels: barTopLabels(fmtCount, values.length),
    }),
    extraDatasets: c => ([{
      label: "收款金额合计（元）", data: c.amounts, type: "line",
      borderColor: "#c0392b", backgroundColor: "rgba(192,57,43,.15)", yAxisID: "y1",
      datalabels: linePointLabels(moneyLabels),
    }]),
    scales: paymentScales,
  },
  {
    // ⑤ 合同统计报表-正常数据：4 状态柱（含已逾期），折线只画三态，已逾期处为 null
    name: "合同统计报表-正常数据（柱顶整数 + 合同总金额折线，已逾期处断点）",
    labels: ["已完成", "已中止", "执行中", "已逾期"],
    values: [29, 1, 27, 0],
    amounts: [883788.36, 1800.00, 777625.92, null],   // 已逾期 null → 不得渲染金额标签
    format: fmtCount,
    title: "合同统计",
    dataset: contractDataset,
    extraDatasets: contractLine,
    scales: contractScales,
  },
  {
    // ⑥ 合同统计报表-空数据：柱与折线都趴在基线（金额 0.00 仍需标签）
    name: "合同统计报表-空数据（柱值与金额全 0）",
    labels: ["已完成", "已中止", "执行中"],
    values: [0, 0, 0],
    amounts: [0, 0, 0],
    format: fmtCount,
    title: "合同统计",
    dataset: contractDataset,
    extraDatasets: contractLine,
    scales: contractScales,
  },
  {
    // ⑦ 合同统计报表-高低错落：金额极差大（顶部点位需避让，其余走默认位）
    name: "合同统计报表-高低错落（金额极差大）",
    labels: ["已完成", "已中止", "执行中"],
    values: [2, 28, 5],
    amounts: [900000, 1800, 460000],
    format: fmtCount,
    title: "合同统计",
    dataset: contractDataset,
    extraDatasets: contractLine,
    scales: contractScales,
  },
];

/* ------------------------------------------------------------------ 校验执行 */
const failures = [];
let linesWithNull = 0;

CASES.forEach(c => {
  const { canvas, texts } = buildCanvas();
  const datasets = [c.dataset(c.values, c)].concat(c.extraDatasets ? c.extraDatasets(c) : []);
  const chart = new Chart(canvas, {
    type: "bar",
    data: { labels: c.labels, datasets },
    options: {
      responsive: false, maintainAspectRatio: false, animation: false,
      plugins: {
        legend: { position: "top" },
        datalabels: { display: false },
        title: { display: !!c.title, text: c.title || "" },
      },
      layout: { padding: { top: 26 } },
      scales: c.scales,
    },
  });

  const meta = chart.getDatasetMeta(0);
  const yScale = chart.scales.y;
  const area = chart.chartArea;
  texts.length = 0;
  chart.draw();

  console.log(`\n===== ${c.name} =====`);
  console.log(`绘图区 top=${area.top.toFixed(1)} bottom=${area.bottom.toFixed(1)}  柱数=${c.labels.length}`);

  const boxes = [];
  meta.data.forEach((bar, i) => {
    const top = yScale.getPixelForValue(c.values[i]);
    const want = c.format(c.values[i]);
    const expectX = bar.x - want.length * CHAR_W / 2;      // 文本左边缘（textAlign:left）
    // 同时匹配「文本」与「位置」，避免把坐标轴刻度误判成柱标签（0 值柱尤其容易撞）
    const t = texts.find(x => x.text === want && Math.abs(x.x - expectX) < 3);
    if (!t) { failures.push(`${c.name}/${c.labels[i]}: 未渲染出柱顶标签 "${want}"`); return; }
    const above = t.y < top, inArea = t.y >= area.top;
    console.log(`柱[${c.labels[i]}]  柱顶y=${top.toFixed(1)}  标签y=${t.y.toFixed(1)}  x=${t.x.toFixed(1)}  "${t.text}"  ${above ? "在柱上方" : "未高于柱顶"}${inArea ? "" : " / 越出顶部"}`);
    if (!above) failures.push(`${c.name}/${c.labels[i]}: 标签未高于柱顶`);
    if (!inArea) failures.push(`${c.name}/${c.labels[i]}: 标签越出绘图区顶部`);
    boxes.push(textBox(t));
  });

  // 折线数据集：区间内每个有效数据点都应有金额标签（千分位 + 两位小数），
  // 且贴近数据点、在绘图区内；null 断点（如「已逾期」不进折线）不得出现标签。
  if (c.amounts) {
    const lineMeta = chart.getDatasetMeta(1);
    linesWithNull = 0;
    lineMeta.data.forEach((pt, i) => {
      const raw = c.amounts[i];
      const area0 = chart.chartArea;
      if (raw === null || raw === undefined) {
        // 断点：不允许出现任何落在这个 x 位置附近的金额标签
        linesWithNull++;
        const near = texts.filter(t => t.x >= area0.left && t.x <= area0.right
          && /\d/.test(t.text) && t.text.indexOf(",") >= 0
          && Math.abs(t.x + t.text.length * CHAR_W / 2 - (pt.x || 0)) < 40);
        if (near.length) {
          failures.push(`${c.name}/折线[${c.labels[i]}]: 断点处不应渲染金额标签，却出现 "${near[0].text}"`);
        }
        console.log(`折线[${c.labels[i]}]  断点（null）→ 不渲染金额标签 ✓`);
        return;
      }
      const want = fmtMoney(raw);
      const candidates = texts.filter(t => t.text === want
        && t.x > area.left - 10 && t.x < area.right - 10
        && Math.abs(t.x + want.length * CHAR_W / 2 - pt.x) < 150);
      if (!candidates.length) {
        failures.push(`${c.name}/折线[${c.labels[i]}]: 未渲染出金额标签 "${want}"`);
        return;
      }
      const t = candidates[0];
      const box = textBox(t);
      const nearPt = Math.abs(t.x + want.length * CHAR_W / 2 - pt.x) < 150
        && (t.y < pt.y - 5 || t.y > pt.y + 5 || t.x > pt.x + 10);   // 不死压在数据点上
      const inArea = t.y >= area.top && t.y <= area.bottom + 6;
      console.log(`折线[${c.labels[i]}]  点y=${pt.y.toFixed(1)}  标签y=${t.y.toFixed(1)}  x=${t.x.toFixed(1)}  "${t.text}"  ${nearPt ? "贴点避让" : "位置异常"}${inArea ? "" : " / 越出绘图区"}`);
      if (!nearPt) failures.push(`${c.name}/折线[${c.labels[i]}]: 金额标签未贴近数据点`);
      if (!inArea) failures.push(`${c.name}/折线[${c.labels[i]}]: 金额标签越出绘图区`);
      boxes.push(box);
    });
  }

  // 两两重叠：任意两个标签外框同时侵入 x/y 超 5px → 压字（柱×柱、柱×金额、金额×金额全覆盖）
  for (let i = 1; i < boxes.length; i++) {
    for (let j = 0; j < i; j++) {
      if (overlap(boxes[i], boxes[j])) {
        failures.push(`${c.name}: 标签疑似重叠 "${boxes[j].text}" vs "${boxes[i].text}"`);
      }
    }
  }

  chart.destroy();
});

if (failures.length) {
  console.log("\n✗ 存在问题：\n  - " + failures.join("\n  - "));
  process.exit(1);
}
console.log("\n✓ 全部用例通过：柱顶标签高于柱顶、折线金额标签贴近数据点（千分位两位小数）、所有标签均在绘图区内且两两不压字");
process.exit(0);
