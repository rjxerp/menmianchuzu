# -*- coding: utf-8 -*-
"""版本号单一源（D-01 整改，2026-09-17）

此前版本号散落三处且互不一致（main.py=v2.2.6-web / README=v2.2.6-web / 操作手册=v2.3.2）。
现统一由本文件定义，main.py 的 FastAPI(version=...) 与文档均引用此处；
「关于」页显示的版本存于数据库 system_params.version，由用户在系统设置中维护。
"""
APP_NAME = "租赁合同管理系统 Web 版"
APP_VERSION = "v2.3.2-web"
RELEASE_DATE = "2026-09-17"
