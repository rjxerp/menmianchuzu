"""
dashboard_services.py

仪表盘服务模块，包含合同到期明细和租金到期明细的数据访问和业务逻辑

此模块负责分离并独立实现合同到期明细和租金到期明细的相关功能，
提供清晰的接口供主程序调用，避免功能模块间的耦合。
"""

import sqlite3
import time
from datetime import date, timedelta
import traceback
from typing import List, Dict, Any, Tuple, Optional, Set
from db_utils import DatabaseUtils

# 收款状态统一口径（2026-09-14）：仪表盘不再自造一套「按租赁天数折算年租 + 99.9% 阈值」
# 的算法，直接复用服务层的三态判定，保证与合同管理、租金管理完全一致。
from services import (  # noqa: E402
    compute_payment_status,
    PAYMENT_STATUS_SETTLED,
    PAYMENT_STATUS_UNSETTLED,
)

# 导入日志模块
try:
    from logger_module import log_info, log_error, log_debug
except ImportError:
    # 如果无法导入日志模块，提供默认实现
    def log_info(message, *args, **kwargs):
        print(f"INFO: {message}")
    
    def log_error(message, *args, **kwargs):
        print(f"ERROR: {message}")
        
    def log_debug(message, *args, **kwargs):
        print(f"DEBUG: {message}")

# 缓存相关常量
CACHE_EXPIRY_TIME = 300  # 缓存过期时间（秒）

# 简单的内存缓存类
class SimpleCache:
    """简单的内存缓存类，用于存储查询结果"""
    
    def __init__(self):
        self._cache = {}
        self._expiry = {}
    
    def get(self, key: str) -> Optional[Any]:
        """获取缓存值"""
        if key not in self._cache:
            return None
        
        # 检查缓存是否过期
        if key in self._expiry and time.time() > self._expiry[key]:
            del self._cache[key]
            del self._expiry[key]
            return None
        
        return self._cache[key]
    
    def set(self, key: str, value: Any, expiry: int = CACHE_EXPIRY_TIME) -> None:
        """设置缓存值"""
        self._cache[key] = value
        self._expiry[key] = time.time() + expiry
    
    def clear(self) -> None:
        """清空缓存"""
        self._cache.clear()
        self._expiry.clear()

# 创建全局缓存实例
cache = SimpleCache()


class DashboardService:
    """
    仪表盘服务类，提供合同到期明细和租金到期明细的服务接口
    """
    
    @staticmethod
    def validate_contract_data(contract_data: Tuple) -> Tuple[bool, Optional[str]]:
        """
        验证合同数据的有效性
        
        参数:
            contract_data: 合同数据元组
        
        返回:
            Tuple[bool, Optional[str]]: (是否有效, 错误信息)
        """
        # 检查数据长度
        if len(contract_data) < 5:
            return False, f"合同数据不完整，只有{len(contract_data)}个字段"
        
        # 检查必填字段
        contract_no = contract_data[0]
        end_date = contract_data[1]
        
        if not contract_no:
            return False, "合同编号为空"
        
        if not end_date:
            return False, "到期日期为空"
        
        # 验证日期格式
        try:
            if end_date != '未知':
                date.fromisoformat(end_date)
        except ValueError:
            return False, f"日期格式无效: {end_date}"
        
        return True, None
    
    @staticmethod
    def get_reminder_settings() -> Tuple[int, int]:
        """
        从数据库获取提醒设置
        
        返回:
            tuple: (contract_reminder_days, rent_reminder_days)
        """
        contract_reminder_days = 30  # 默认值
        rent_reminder_days = 7      # 默认值
        
        conn = None
        cursor = None
        try:
            conn = DatabaseUtils.get_connection()
            if not conn:
                log_error("获取数据库连接失败")
                return contract_reminder_days, rent_reminder_days
                
            cursor = conn.cursor()
            
            # 查询提醒设置（与saveReminderSettings保存的数据结构一致）
            cursor.execute("SELECT contract_reminder_days, rent_reminder_days FROM reminder_settings LIMIT 1")
            result = cursor.fetchone()
            if result:
                contract_reminder_days = int(result[0]) if result[0] is not None else contract_reminder_days
                rent_reminder_days = int(result[1]) if result[1] is not None else rent_reminder_days
                
        except sqlite3.Error as e:
            log_error(f"获取提醒设置时出错: {str(e)}")
        finally:
            if conn:
                DatabaseUtils.close_connection(conn)
                cursor = None
                conn = None
                
        return contract_reminder_days, rent_reminder_days
    
    @staticmethod
    def get_contract_payment_status(cursor: sqlite3.Cursor, contract_no: str) -> str:
        """
        判定合同收款状态：已结清 / 部分收款 / 未结清。

        口径统一（2026-09-14）：与合同管理、租金管理完全一致 ——
        以「合同应收总租 contracts.total_rent（为 0/空时回退 annual_rent）」为基准，
        与「累计已收 SUM(rent_records.amount)」比较，判据复用 services.compute_payment_status。
        不再使用旧版「按租赁天数比例折算年租 + 99.9% 比例阈值」的独立算法。

        参数:
            cursor: 数据库游标（裸游标，金额单位为「分」）
            contract_no: 合同编号

        返回:
            str: 已结清 / 部分收款 / 未结清
        """
        if not contract_no:
            log_error("合同编号为空")
            return PAYMENT_STATUS_UNSETTLED

        cache_key = f"contract_payment_status_{contract_no}"
        cached_result = cache.get(cache_key)
        if cached_result is not None:
            log_debug(f"从缓存获取合同 {contract_no} 收款状态")
            return cached_result

        try:
            cursor.execute(
                "SELECT total_rent, annual_rent FROM contracts WHERE contract_no = ?", (contract_no,))
            row = cursor.fetchone()
            if not row:
                # 沿用原「取不到租金信息 → 视为已结清」的行为，避免历史提醒口径跳变
                log_info(f"合同 {contract_no} 无租金信息，视为已结清")
                cache.set(cache_key, PAYMENT_STATUS_SETTLED, expiry=120)
                return PAYMENT_STATUS_SETTLED

            total_rent = row[0]
            if total_rent is None or float(total_rent or 0) == 0:
                total_rent = row[1]

            try:
                cursor.execute(
                    "SELECT COALESCE(SUM(amount), 0) FROM rent_records WHERE contract_no = ?", (contract_no,))
                received_row = cursor.fetchone()
                received = received_row[0] if received_row and received_row[0] is not None else 0
            except sqlite3.OperationalError as db_error:
                log_error(f"查询合同 {contract_no} 已收租金时数据库错误: {str(db_error)}")
                received = 0

            status = compute_payment_status(received, total_rent)

            log_info(
                f"合同 {contract_no} 收款情况: 应收总租 {float(total_rent or 0) / 100.0:.2f} 元, "
                f"累计已收 {float(received) / 100.0:.2f} 元, 状态: {status}"
            )

            # 缓存时间较短，避免收款登记后仪表盘长时间显示旧状态
            cache.set(cache_key, status, expiry=120)

            return status

        except Exception as e:
            log_error(f"计算合同 {contract_no} 收款情况时出错: {str(e)}")
            log_error(traceback.format_exc())
            # 出错时返回未结清，确保合同不会被错误地标记为已结清
            return PAYMENT_STATUS_UNSETTLED

    @staticmethod
    def is_contract_paid_up(cursor: sqlite3.Cursor, contract_no: str) -> bool:
        """
        判断合同是否已结清（累计已收 >= 合同应收总租）。

        口径与合同管理 / 租金管理一致；等价于 get_contract_payment_status(...) == 已结清。

        参数:
            cursor: 数据库游标
            contract_no: 合同编号

        返回:
            bool: 是否已结清
        """
        return DashboardService.get_contract_payment_status(cursor, contract_no) == PAYMENT_STATUS_SETTLED

    @staticmethod
    def get_contract_expiry_details() -> List[Dict[str, Any]]:
        """
        获取合同到期明细数据
        
        返回:
            list: 合同到期明细列表，每项包含contract_no、end_date、house_no、lessee、annual_rent等字段
        """
        start_time = time.time()
        contract_expiry_details = []
        conn = None
        cursor = None
        
        try:
            # 获取提醒设置
            contract_reminder_days, _ = DashboardService.get_reminder_settings()
            
            # 生成缓存键
            cache_key = f"contract_expiry_details_{contract_reminder_days}_{date.today()}"
            
            # 尝试从缓存获取数据
            cached_result = cache.get(cache_key)
            if cached_result is not None:
                log_info(f"从缓存获取合同到期明细数据，共 {len(cached_result)} 条记录")
                return cached_result
            
            conn = DatabaseUtils.get_connection()
            if not conn:
                log_error("获取数据库连接失败")
                return contract_expiry_details
                
            cursor = conn.cursor()
            
            # 获取当前日期和提醒天数
            today = date.today()
            today_str = today.isoformat()
            future_date = today + timedelta(days=contract_reminder_days)
            future_date_str = future_date.isoformat()
            
            log_info(f"查询合同到期明细: 日期范围 {today_str} 到 {future_date_str}, 提前提醒天数: {contract_reminder_days}")
            
            # 优化SQL查询，添加索引提示和查询超时控制（execute_query 自动金额 分→元）
            # 修复：去掉 end_date >= today 下限，已逾期合同（end_date < today）也显示
            #（此前统计卡"逾期合同数"含已过期合同，但明细被日期条件排除——口径不一致）
            query_start_time = time.time()
            cursor = DatabaseUtils.execute_query(conn, """
                SELECT contract_no, end_date, house_no, lessee, annual_rent, status
                FROM contracts 
                WHERE (status = '执行中' OR status = '已逾期') AND (end_date <= ?)
                ORDER BY end_date ASC
            """, (future_date_str,))
            query_time = time.time() - query_start_time
            
            contracts = cursor.fetchall() if cursor else []
            log_info(f"查询到 {len(contracts)} 条符合条件的合同记录，查询耗时: {query_time:.3f}秒")
            
            processed_contracts: Set[str] = set()  # 用于去重
            
            for contract in contracts:
                try:
                    # 数据验证
                    is_valid, error_msg = DashboardService.validate_contract_data(contract)
                    if not is_valid:
                        log_info(f"跳过无效合同数据: {error_msg} - 数据: {contract}")
                        continue
                    
                    # 安全解包数据
                    contract_no = contract[0] if contract[0] else '未知'
                    
                    # 去重检查
                    if contract_no in processed_contracts:
                        log_debug(f"跳过重复合同: {contract_no}")
                        continue
                    processed_contracts.add(contract_no)
                    
                    end_date = contract[1] if contract[1] else '未知'
                    house_no = contract[2] if contract[2] else '未知'
                    lessee = contract[3] if contract[3] else '未知'
                    annual_rent = contract[4] if contract[4] is not None else 0.0
                    status = contract[5] if len(contract) > 5 else '未知'
                    
                    # 计算合同状态和到期天数
                    days_until_expiry = 0
                    end_date_obj = None
                    try:
                        if end_date != '未知':
                            end_date_obj = date.fromisoformat(end_date)
                            days_until_expiry = (end_date_obj - today).days
                    except ValueError:
                        log_error(f"日期格式异常: {end_date}")
                        days_until_expiry = 0
                    
                    # 收款状态：直接取统一口径的三态结果（与合同管理/租金管理一致）
                    payment_status = DashboardService.get_contract_payment_status(cursor, contract_no)
                    
                    # 修复：所有到期/逾期合同都显示（不再只包含未结清）
                    # 合同到期提醒与收款状态无关——已结清但即将到期的合同同样需要提醒续签/终止
                    contract_expiry_details.append({
                        'contract_no': contract_no,
                        'end_date': end_date,
                        'house_no': house_no,
                        'lessee': lessee,
                        'annual_rent': str(annual_rent) if annual_rent is not None else '0.00',
                        'status': status,
                        'payment_status': payment_status,
                        'days_until_expiry': days_until_expiry,
                        'end_date_obj': end_date_obj,
                        'retrieved_at': time.time()
                    })
                except Exception as item_error:
                    log_error(f"处理合同记录时出错: {str(item_error)} - 合同数据: {contract}")
                    log_error(traceback.format_exc())
            
            # 确保结果按到期天数排序
            contract_expiry_details.sort(key=lambda x: x.get('days_until_expiry', float('inf')))
            
            # 缓存结果
            cache.set(cache_key, contract_expiry_details)
                    
        except Exception as e:
            log_error(f"获取合同到期明细时出错: {str(e)}")
            log_error(traceback.format_exc())
        finally:
            if conn:
                DatabaseUtils.close_connection(conn)
                cursor = None
                conn = None
                
        total_time = time.time() - start_time
        log_info(f"最终返回 {len(contract_expiry_details)} 条未结清的合同到期明细记录，总耗时: {total_time:.3f}秒")
        return contract_expiry_details
    
    @staticmethod
    def get_rent_due_reminders() -> List[Dict[str, str]]:
        """
        获取租金到期提醒数据
        
        返回:
            List[Dict]: 租金到期提醒数据列表
        """
        rent_reminders = []
        conn = None
        cursor = None
        
        try:
            conn = DatabaseUtils.get_connection()
            if not conn:
                log_error("获取数据库连接失败")
                return rent_reminders
                
            cursor = conn.cursor()
            
            # 获取当前日期
            today = date.today()
            
            # 修复：租金到期提醒范围与"租金提前提醒天数"设置联动（period_end <= today + rent_reminder_days）
            # 此前固定只显示已到期（period_end <= today），与系统设置脱节
            _, rent_reminder_days = DashboardService.get_reminder_settings()
            future_date = today + timedelta(days=rent_reminder_days)
            future_date_str = future_date.isoformat()
            
            # 查询1: 获取每个合同的最晚一次租金记录
            # 重点：只获取每个合同的最晚一次租金记录，然后检查该记录的租金截止日期是否<=当前日期+提醒天数
            # 优化：在子查询中也筛选合同状态为'执行中'的合同，减少不必要的数据处理
            cursor.execute("""
                SELECT r.contract_no, r.period_end, c.house_no, c.lessee 
                FROM (
                    -- 子查询获取每个执行中合同的最晚租金记录
                    SELECT r.contract_no, MAX(r.period_end) as latest_period_end
                    FROM rent_records r
                    JOIN contracts c ON r.contract_no = c.contract_no
                    WHERE c.status = '执行中'
                    GROUP BY r.contract_no
                ) AS latest_rent
                JOIN rent_records r ON latest_rent.contract_no = r.contract_no AND latest_rent.latest_period_end = r.period_end
                JOIN contracts c ON r.contract_no = c.contract_no
                WHERE r.period_end <= ?
                ORDER BY r.period_end ASC
            """, (future_date_str,))
            
            rent_record_results = cursor.fetchall()
            for row in rent_record_results:
                rent_reminders.append({
                    'contract_no': row[0],
                    'due_date': row[1],
                    'house_no': row[2],
                    'lessee': row[3]
                })
            
            # 查询2: 查找合同表中存在但租金记录表中无对应记录的执行中合同
            # 移除合同到期日期限制，返回所有执行中且无租金记录的合同
            cursor.execute("""
                SELECT c.contract_no, c.house_no, c.lessee, c.start_date 
                FROM contracts c 
                LEFT JOIN rent_records r ON c.contract_no = r.contract_no
                WHERE c.status = '执行中' AND r.contract_no IS NULL
                ORDER BY c.contract_no ASC
            """)
            
            missing_rent_results = cursor.fetchall()
            for row in missing_rent_results:
                # 当租金截止日期为空时，使用租赁开始日期作为到期日期
                start_date = row[3] if row[3] else "未知"
                rent_reminders.append({
                    'contract_no': row[0],
                    'due_date': start_date,  # 使用租赁开始日期替代"未设置租金记录"
                    'house_no': row[1],
                    'lessee': row[2],
                    'start_date': start_date,  # 添加start_date字段
                    'no_rent_record': True  # 修复：标记"从未录入租金记录"，UI 显示"未录租金"
                })
            
            # 处理重复合同编号,只保留到期日期最晚的记录
            unique_reminders = {}
            for reminder in rent_reminders:
                contract_no = reminder['contract_no']
                due_date = reminder['due_date']
                
                # 如果合同编号不存在或当前记录的到期日期更晚
                if contract_no not in unique_reminders:
                    unique_reminders[contract_no] = reminder
                else:
                    # 比较两个记录的到期日期，保留更晚的
                    existing_due_date = unique_reminders[contract_no]['due_date']
                    
                    # 处理日期比较，考虑可能的"未知"值
                    try:
                        # 尝试将两个日期转换为日期对象进行比较
                        if due_date != "未知" and existing_due_date != "未知":
                            current_date = date.fromisoformat(due_date)
                            existing_date = date.fromisoformat(existing_due_date)
                            
                            if current_date > existing_date:
                                unique_reminders[contract_no] = reminder
                        elif due_date != "未知" and existing_due_date == "未知":
                            # 当前记录有有效日期，保留当前记录
                            unique_reminders[contract_no] = reminder
                        # 如果当前记录是"未知"而现有记录有有效日期，则保留现有记录
                    except (ValueError, TypeError):
                        # 日期格式异常，优先保留非"未知"的记录
                        if due_date != "未知" and existing_due_date == "未知":
                            unique_reminders[contract_no] = reminder
            
            # 将去重后的记录转换回列表
            rent_reminders = list(unique_reminders.values())
            
            # 过滤只保留收款情况为"未结清"的记录
            filtered_reminders = []
            for reminder in rent_reminders:
                contract_no = reminder['contract_no']
                due_date = reminder['due_date']
                
                # 检查合同是否未结清
                is_unpaid = not DashboardService.is_contract_paid_up(cursor, contract_no)
                
                # 检查是否为有效的租金到期记录
                is_valid_record = False
                
                if due_date == "未知":
                    # 对于没有租赁开始日期的合同，直接视为有效记录
                    is_valid_record = True
                else:
                    # 对于有日期的合同，检查租金截止日期是否<=当前日期+租金提醒天数
                    # 修复：此前硬编码 today，与查询1范围（today+rent_reminder_days）不一致，
                    # 导致"即将到期"的租金记录在过滤层被误删（问题6修复不完整）
                    try:
                        due_date_obj = date.fromisoformat(due_date)
                        is_valid_record = due_date_obj <= future_date
                    except (ValueError, TypeError):
                        # 日期格式异常，跳过此记录
                        log_debug(f"合同 {contract_no} 的租金截止日期格式异常: {due_date}")
                        continue
                
                # 只添加未结清且有效的记录
                if is_unpaid and is_valid_record:
                    filtered_reminders.append(reminder)
            
            # 更新为过滤后的结果
            rent_reminders = filtered_reminders
            
            # 按到期日期排序（特殊处理"未知"的条目,将其放在最后）
            rent_reminders.sort(key=lambda x: x['due_date'] if x['due_date'] != "未知" else "9999-12-31")
            
        except Exception as e:
            log_error(f"获取租金到期明细时出错: {str(e)}")
        finally:
            if conn:
                DatabaseUtils.close_connection(conn)
                
        return rent_reminders
        
    @staticmethod
    def get_rent_trend_data():
        """
        获取租金收入趋势数据
        
        返回:
            tuple: (months, receivable, received),分别为月份列表,应收租金列表,已收租金列表
        """
        
        conn = None
        cursor = None
        
        try:
            # 初始化数据结构
            months = []
            receivable = []
            received = []
            
            # 获取数据库连接
            conn = DatabaseUtils.get_connection()
            if not conn:
                log_error("无法获取数据库连接")
                return [], [], []
            cursor = conn.cursor()
            
            # 获取最近12个月的月份列表
            try:
                today = date.today()
                for i in range(12):
                    # 计算前i个月的日期
                    year = today.year
                    month = today.month - i
                    if month <= 0:
                        year -= 1
                        month += 12
                    months.append(f"{year}-{month:02d}")
                
                # 反转顺序,从最早的月份开始
                months.reverse()
            except Exception as e:
                log_error(f"生成月份列表时出错: {str(e)}")
                # 设置默认的月份列表以确保后续操作能够进行
                months = [f"{date.today().year - (i//12)}-{(date.today().month - i%12 -1) % 12 + 1:02d}" for i in range(12)]
            
            # 为每个月计算应收金额和已收金额
            if months:
                for month in months:
                    # 计算该月应收租金总额（execute_query 自动金额 分→元）
                    # 口径：凡合同期覆盖该月的合同（start_date<=月末 且 end_date>=月初），该月应收其月租。
                    # 不能按 status='执行中' 筛选——历史月份的应收会漏掉"当时执行中、现已结束"的合同。
                    try:
                        # 获取合同期覆盖该月的所有合同的月租金总和
                        cursor = DatabaseUtils.execute_query(conn, """
                            SELECT SUM(monthly_rent) 
                            FROM contracts 
                            WHERE start_date <= ? || '-01' 
                            AND end_date >= ? || '-01'
                        """, (month, month))
                        result = cursor.fetchone() if cursor else None
                        month_receivable = result[0] if result and result[0] is not None else 0
                    except Exception as e:
                        month_receivable = 0
                        log_error(f"计算{month}应收金额出错: {str(e)}")
                    
                    # 统计该月实际收款金额
                    try:
                        # 从rent_records表中统计该月的收款总额
                        cursor = DatabaseUtils.execute_query(conn, """
                            SELECT SUM(amount) 
                            FROM rent_records 
                            WHERE receipt_date LIKE ? || '%'
                        """, (month,))
                        result = cursor.fetchone() if cursor else None
                        month_received = result[0] if result and result[0] is not None else 0
                    except Exception as e:
                        month_received = 0
                        log_error(f"统计{month}收款金额出错: {str(e)}")
                    
                    receivable.append(month_receivable)
                    received.append(month_received)
            
            return months, receivable, received
            
        except Exception as e:
            log_error(f"获取租金收入趋势数据时出错: {str(e)}")
            return [], [], []
        finally:
            if conn:
                DatabaseUtils.close_connection(conn)
                cursor = None
                conn = None
    
    @staticmethod
    def get_dashboard_stats() -> Dict[str, Any]:
        """
        获取仪表盘统计数据
        
        返回:
            dict: 包含各类统计数据的字典
        """
        stats = {
            'total_contracts': 0,
            'active_contracts': 0,
            'completed_contracts': 0,
            'terminated_contracts': 0,
            'overdue_contracts': 0,
            'annual_rent': 0,
            'received_rent': 0,
            'receivable_rent': 0,
            'total_deposit': 0
        }
        
        conn = None
        cursor = None
        
        try:
            conn = DatabaseUtils.get_connection()
            if not conn:
                log_error("获取数据库连接失败")
                return stats
                
            cursor = conn.cursor()
            
            # 总合同数
            cursor.execute("SELECT COUNT(*) FROM contracts")
            stats['total_contracts'] = cursor.fetchone()[0]
            
            # 活跃合同数
            cursor.execute("SELECT COUNT(*) FROM contracts WHERE status = '执行中'")
            stats['active_contracts'] = cursor.fetchone()[0]
            
            # 已完成合同数
            cursor.execute("SELECT COUNT(*) FROM contracts WHERE status = '已完成'")
            stats['completed_contracts'] = cursor.fetchone()[0]
            
            # 已中止合同数
            cursor.execute("SELECT COUNT(*) FROM contracts WHERE status = '已中止'")
            stats['terminated_contracts'] = cursor.fetchone()[0]
            
            # 已逾期合同数
            today = date.today().isoformat()
            cursor.execute("SELECT COUNT(*) FROM contracts WHERE status = '已逾期' OR (status = '执行中' AND end_date < ?)", (today,))
            stats['overdue_contracts'] = cursor.fetchone()[0]
            
            # 年度租金总额（仅统计执行中合同；execute_query 自动金额 分→元）
            cursor = DatabaseUtils.execute_query(conn, "SELECT SUM(annual_rent) FROM contracts WHERE status = '执行中'")
            result = cursor.fetchone() if cursor else None
            stats['annual_rent'] = result[0] if result and result[0] is not None else 0
            
            # 已收租金总额（仅统计执行中合同的租金记录，通过 contract_no 关联 contracts 过滤状态）
            cursor = DatabaseUtils.execute_query(
                conn,
                "SELECT SUM(amount) FROM rent_records r "
                "JOIN contracts c ON r.contract_no = c.contract_no "
                "WHERE c.status = '执行中'"
            )
            result = cursor.fetchone() if cursor else None
            stats['received_rent'] = result[0] if result and result[0] is not None else 0
            
            # 合同总租总额（仅统计执行中合同；total_rent 为含首尾分段累加口径，与租金调整一致）
            cursor = DatabaseUtils.execute_query(conn, "SELECT SUM(total_rent) FROM contracts WHERE status = '执行中'")
            result = cursor.fetchone() if cursor else None
            total_rent_sum = result[0] if result and result[0] is not None else 0
            
            # 应收租金总额（执行中合同总租 - 已收租金）
            stats['receivable_rent'] = max(0, total_rent_sum - stats['received_rent'])
            
            # 押金总金额（仅统计执行中合同）
            cursor = DatabaseUtils.execute_query(conn, "SELECT SUM(deposit) FROM contracts WHERE status = '执行中'")
            result = cursor.fetchone() if cursor else None
            stats['total_deposit'] = result[0] if result and result[0] is not None else 0
            
        except Exception as e:
            log_error(f"获取仪表盘统计数据时出错: {str(e)}")
        finally:
            if conn:
                DatabaseUtils.close_connection(conn)
                
        return stats
        
    @staticmethod
    def get_renewable_contracts():
        """
        获取待续签合同数据
        
        返回: 待续签合同列表，包含房屋编号、乙方名称、原合同到期日期、合同状态等信息
        待续签合同定义：状态为'已完成'或'已中止'、且对应房屋后续没有继续租出的合同
        筛选条件（2026-09-01 优化）：
        1) 合同状态为'已中止'或'已完成'的记录，对应房屋后续没有继续租出（不存在签约日期更晚的同房屋合同）
        2) 该房屋当前不存在执行中/已逾期的合同（未被占用）
        修复：符合测试脚本要求，返回需要续签的历史合同
        """
        conn = None
        cursor = None
        renewable_contracts = []
        
        try:
            # 使用DatabaseUtils获取数据库连接
            conn = DatabaseUtils.get_connection()
            if not conn:
                log_error("无法获取数据库连接")
                return []
            
            cursor = conn.cursor()
            
            # SQL查询：使用NOT EXISTS替代NOT IN以提高性能
            # 返回状态为'已完成'或'已中止'、且对应房屋后续没有继续租出的合同
            # 条件1：不存在签约日期晚于本合同的同房屋合同（后续没有继续租出）
            # 条件2：该房屋当前不存在执行中/已逾期的合同（未被占用）
            # 明确列出所需字段，确保contract_no被正确返回
            query = """
            SELECT c.contract_no, c.house_no, c.lessee, c.end_date, c.status
            FROM contracts c
            WHERE c.status IN ('已完成', '已中止')
            AND NOT EXISTS (
                SELECT 1 FROM contracts later 
                WHERE later.house_no = c.house_no 
                AND later.sign_date > c.sign_date
            )
            AND NOT EXISTS (
                SELECT 1 FROM contracts active 
                WHERE active.house_no = c.house_no 
                AND active.status IN ('执行中', '已逾期')
            )
            ORDER BY c.end_date DESC
            """
            
            cursor.execute(query)
            
            # 获取列名并转换为字典列表
            columns = [desc[0] for desc in cursor.description]
            for row in cursor.fetchall():
                renewable_contracts.append(dict(zip(columns, row)))
            
            log_info(f"成功获取{len(renewable_contracts)}个待续签合同")
            return renewable_contracts
            
        except Exception as e:
            # 记录详细错误信息
            log_error(f"获取待续签合同数据时出错: {str(e)}")
            log_error(f"错误详情: {traceback.format_exc()}")
            return []
        finally:
            # 确保资源释放
            if cursor:
                cursor.close()
            if conn:
                try:
                    DatabaseUtils.close_connection(conn)
                    log_info("数据库连接已关闭")
                except Exception as close_error:
                    log_error(f"关闭数据库连接时出错: {str(close_error)}")
