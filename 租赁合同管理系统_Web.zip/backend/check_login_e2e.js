/* ============================================================
   登录链路端到端自检（真实浏览器）
   ------------------------------------------------------------
   用途：验证「登录页 → 数据库状态显示 → admin 登录 → 跳转主界面」全链路。
   背景：2026-09-11 出现「总是显示 正在检查数据库连接」，根因是
         app.js 中 Store 对象方法名写错（Store.getItem / 自引用），
         导致脚本顶层抛错、initLogin 从未执行。本脚本用于回归验证。

   运行（Windows，项目根目录）：
     set NODE_PATH=C:\Users\Administrator\AppData\Roaming\npm\node_modules\openclaw\node_modules
     node backend\check_login_e2e.js
   依赖：playwright-core（随 openclaw 附带）+ 本机 Chrome。
   输出：一段 JSON；关键字段 dbStatus / navigated / tokenAfterLogin / pageErrors。
   ============================================================ */
const fs = require("fs");
const path = require("path");
const os = require("os");

function firstExisting(paths) {
  for (const p of paths) { try { if (p && fs.existsSync(p)) return p; } catch (e) {} }
  return null;
}

function findChrome() {
  const candidates = [];
  // agent-browser 自带 chrome
  const abHome = path.join(os.homedir(), ".agent-browser", "browsers");
  try {
    for (const d of fs.readdirSync(abHome)) {
      candidates.push(path.join(abHome, d, "chrome.exe"));
    }
  } catch (e) {}
  candidates.push(
    "C:/Program Files/Google/Chrome/Application/chrome.exe",
    "C:/Program Files (x86)/Google/Chrome/Application/chrome.exe",
    "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe",
    "C:/Program Files/Microsoft/Edge/Application/msedge.exe"
  );
  return firstExisting(candidates);
}

let chromium;
try {
  ({ chromium } = require("playwright-core"));
} catch (e) {
  try {
    ({ chromium } = require(path.join(
      os.homedir(),
      "AppData/Roaming/npm/node_modules/openclaw/node_modules/playwright-core"
    )));
  } catch (e2) {
    console.error("未找到 playwright-core，请设置 NODE_PATH 指向 openclaw/node_modules");
    process.exit(2);
  }
}

const BASE = process.env.LEASE_BASE_URL || "http://127.0.0.1:8000/";
const USER = process.env.LEASE_USER || "admin";
const PASS = process.env.LEASE_PASS || "admin";

(async () => {
  const out = { steps: [] };
  let browser;
  try {
    const chrome = findChrome();
    if (!chrome) { console.error("未找到可用的 Chrome/Edge"); process.exit(2); }
    out.chrome = chrome;

    browser = await chromium.launch({
      executablePath: chrome,
      headless: true,
      args: ["--no-sandbox", "--disable-dev-shm-usage"],
    });
    const page = await (await browser.newContext()).newPage();
    const errors = [];
    page.on("pageerror", (e) => errors.push("pageerror: " + e.message));
    page.on("console", (m) => { if (m.type() === "error") errors.push("console.error: " + m.text()); });

    await page.goto(BASE, { waitUntil: "domcontentloaded", timeout: 20000 });

    // 数据库状态：等待从"正在检查"变为结果
    try {
      await page.waitForFunction(() => {
        const el = document.getElementById("login-db");
        return el && el.textContent && !el.textContent.includes("正在检查");
      }, { timeout: 8000 });
    } catch (e) { out.steps.push("db-status wait TIMEOUT"); }
    out.dbStatus = await page.$eval("#login-db", (el) => el.textContent.trim()).catch(() => "NO_ELEM");
    out.dbColor = await page.$eval("#login-db", (el) => getComputedStyle(el).color).catch(() => "N/A");
    out.initLoginDefined = await page.evaluate(() => typeof window.initLogin === "function");

    // 登录
    await page.fill("#username", USER);
    await page.fill("#password", PASS);
    await page.click("#login-btn");

    let navigated = false;
    try { await page.waitForURL(/app\.html/, { timeout: 8000 }); navigated = true; } catch (e) {}
    out.navigated = navigated;
    out.afterLoginUrl = page.url();
    out.tokenAfterLogin = await page.evaluate(() => (localStorage.getItem("lease_token") || "").slice(0, 20)).catch(() => "ERR");
    out.loginError = await page.$eval("#login-error", (el) => (el.hidden ? "" : el.textContent.trim())).catch(() => "N/A");

    if (navigated) {
      await page.waitForTimeout(1500);
      out.appHidden = await page.$eval("#app", (el) => el.hidden).catch(() => "N/A");
      out.userName = await page.$eval("#userName", (el) => el.textContent.trim()).catch(() => "N/A");
    }
    out.pageErrors = errors.slice(0, 10);
    out.PASS = navigated && /^ey|^[A-Za-z0-9_-]{10}/.test(out.tokenAfterLogin) && errors.length === 0;

    console.log(JSON.stringify(out, null, 2));
    process.exit(out.PASS ? 0 : 1);
  } catch (e) {
    out.fatal = e.message;
    console.log(JSON.stringify(out, null, 2));
    process.exit(1);
  } finally {
    if (browser) await browser.close().catch(() => {});
  }
})();
