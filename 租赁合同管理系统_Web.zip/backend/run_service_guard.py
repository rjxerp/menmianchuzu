# -*- coding: utf-8 -*-
"""服务守护脚本（2026-09-11）

职责：拉起 uvicorn 并守护它 —— 进程退出自动重启；每 60 秒探活 /api/health，
连续 3 次失败则强杀该进程并重启。只操作自己拉起的那个 PID，不影响其他 Python 进程。

用法：
  python run_service_guard.py            # 前台守护（可放 shell:startup，窗口最小化）
  python run_service_guard.py --once     # 只启动一次，不守护（等价于手动启动）

日志：logs/service_guard.log
"""
import os
import sys
import time
import json
import subprocess
import urllib.request
from datetime import datetime

BASE = os.path.dirname(os.path.abspath(__file__))
PROJECT = os.path.dirname(BASE)
PORT = 8000
HEALTH_URL = f"http://127.0.0.1:{PORT}/api/health"
LOGDIR = os.path.join(PROJECT, "logs")
GUARD_LOG = os.path.join(LOGDIR, "service_guard.log")
SERVICE_LOG = os.path.join(LOGDIR, "web_service.log")
MARKER = os.path.join(BASE, ".python_exe.txt")

FULL_DEPS = "import uvicorn,fastapi,pydantic,multipart,jwt,openpyxl,reportlab"
PROBE_INTERVAL = 60      # 秒
PROBE_FAIL_LIMIT = 3
RESTART_DELAY = 5        # 秒


def log(msg: str) -> None:
    os.makedirs(LOGDIR, exist_ok=True)
    line = f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {msg}"
    print(line, flush=True)
    try:
        with open(GUARD_LOG, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


def _ok(cmd: list, code: str) -> bool:
    try:
        return subprocess.run(cmd + ["-c", code], capture_output=True, timeout=60).returncode == 0
    except Exception:
        return False


SKIP_DIRS = ("hermes", ".workbuddy", ".local\\bin", "uv\\python", "\\binaries\\")


def _candidate_list() -> list:
    """候选解释器清单（与 backend\\pick_python.bat 保持一致）。

    2026-09-11 修正：原候选过窄（只认 Store 3.11 / py -3.11 / PATH 前几个），
    在 Store 版 Python 被卸载后只能落到 uv 托管的 shim（无依赖、PEP668 拒绝安装），
    导致服务起不来。现改为全量枚举 + 全量依赖判定。
    """
    cands = []

    def push(cmd, label):
        if cmd and cmd not in [c for _, c in cands]:
            cands.append((label, cmd))

    local = os.environ.get("LOCALAPPDATA", "")

    # 1) 项目虚拟环境
    venv = os.path.join(PROJECT, ".venv", "Scripts", "python.exe")
    push([venv], f"项目虚拟环境 {venv}")

    # 2) 记忆文件
    if os.path.isfile(MARKER):
        try:
            with open(MARKER, "r", encoding="utf-8", errors="ignore") as f:
                saved = f.read().strip().strip('"')
            if saved and os.path.isfile(saved):
                push([saved], f"记忆文件 {saved}")
        except Exception:
            pass

    # 3) Store 版 Python
    for v in ("3.13", "3.12", "3.11", "3.10"):
        p = os.path.join(local, "Microsoft", "WindowsApps", f"python{v}.exe")
        if os.path.isfile(p):
            push([p], f"Store {v} {p}")

    # 4) py 启动器注册的各版本
    for v in ("3.13", "3.12", "3.11", "3.10"):
        push(["py", f"-{v}"], f"py -{v}")

    # 5) PATH（跳过 uv / Hermes / WorkBuddy 等隔离环境）
    for name in ("python3.13", "python3.12", "python3.11", "python3.10", "python3", "python"):
        for p in os.environ.get("PATH", "").split(os.pathsep):
            exe = os.path.join(p, name + ".exe")
            if not os.path.isfile(exe):
                continue
            low = exe.lower()
            if any(k in low for k in SKIP_DIRS):
                continue
            push([exe], f"PATH {exe}")
            break

    # 6) 常见安装目录
    for base in ("C:\\", "D:\\", os.path.join(local, "Programs", "Python")):
        for v in ("313", "312", "311", "310"):
            exe = os.path.join(base, f"Python{v}", "python.exe")
            if os.path.isfile(exe):
                push([exe], f"系统安装 {exe}")

    return cands


def resolve_interpreter() -> list:
    """选出第一个能导入全部依赖的解释器。"""
    for label, cmd in _candidate_list():
        if _ok(cmd, FULL_DEPS):
            log(f"使用解释器: {cmd[0]} ({label})")
            return cmd
    log("未找到具备完整依赖的 Python 解释器，请先执行: pip install -r requirements.txt")
    sys.exit(1)


def probe_health(timeout=5) -> bool:
    try:
        with urllib.request.urlopen(HEALTH_URL, timeout=timeout) as r:
            if r.status != 200:
                return False
            data = json.loads(r.read().decode("utf-8"))
            return data.get("status") == "ok"
    except Exception:
        return False


def start_service(py_cmd: list):
    os.makedirs(LOGDIR, exist_ok=True)
    logf = open(SERVICE_LOG, "ab")
    p = subprocess.Popen(
        py_cmd + ["-m", "uvicorn", "main:app", "--host", "127.0.0.1", "--port", str(PORT), "--app-dir", "backend"],
        cwd=PROJECT, stdout=logf, stderr=logf, stdin=subprocess.DEVNULL)
    log(f"服务已启动 PID={p.pid}")
    return p


def wait_ready(proc, seconds=60) -> bool:
    for _ in range(max(1, seconds // 2)):
        if proc.poll() is not None:
            return False
        if probe_health():
            return True
        time.sleep(2)
    return False


def main():
    once = "--once" in sys.argv
    py_cmd = resolve_interpreter()
    while True:
        proc = start_service(py_cmd)
        if not wait_ready(proc):
            rc = proc.poll()
            log(f"服务 60 秒内未就绪（进程状态: {rc}）—— 重启。排查: python backend/check_startup.py")
        else:
            log("服务就绪，进入守护轮询（每 60 秒探活一次）")
            fails = 0
            while True:
                time.sleep(PROBE_INTERVAL)
                if proc.poll() is not None:
                    log(f"检测到服务进程已退出（exit={proc.returncode}），准备重启")
                    break
                if probe_health():
                    fails = 0
                    continue
                fails += 1
                log(f"健康检查失败 {fails}/{PROBE_FAIL_LIMIT}")
                if fails >= PROBE_FAIL_LIMIT:
                    log("连续探活失败，强制结束当前进程并重启")
                    try:
                        proc.terminate()
                        try:
                            proc.wait(timeout=10)
                        except Exception:
                            proc.kill()
                    except Exception as e:
                        log(f"结束进程异常: {e}")
                    break
        if once:
            log("--once 模式，退出守护")
            return
        time.sleep(RESTART_DELAY)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        log("守护被手动中断（Ctrl+C），服务进程可能仍在运行，可用 stop_web.bat 停止")
