@echo off
rem ================================================================
rem  pick_python.bat -- project interpreter selector
rem  (ASCII only on purpose: it is called by launchers whose console code
rem   page differs, so it must never contain non-ASCII text.)
rem
rem  Shared by: start_web.bat / the diagnostic launcher / start_web_daemon.bat
rem
rem  Candidate order:
rem    1. project virtualenv .venv\Scripts\python.exe
rem    2. last known good value in backend\.python_exe.txt
rem    3. Store Python in %LOCALAPPDATA%\Microsoft\WindowsApps\python3.1x.exe
rem    4. py launcher: py -3.10 .. -3.13
rem    5. PATH: python3.13 / 3.12 / 3.11 / 3.10 / python3 / python
rem       (uv, Hermes, WorkBuddy and .local\bin shims are skipped)
rem    6. common install dirs: C:\Python3*  D:\Python3*  %LOCALAPPDATA%\Programs\Python\Python3*
rem
rem  Decision rule: a candidate is accepted only if it can import ALL
rem  runtime dependencies (see DEP_PROBE). Importing sys alone is NOT
rem  enough -- that mistake picked a dependency-less uv-managed Python
rem  on 2026-09-11 and broke startup.
rem
rem  If nothing qualifies, deps are installed (Tencent PyPI mirror) into the
rem  first non-isolated interpreter; if that fails, a project virtualenv
rem  .venv is created and used instead.
rem
rem  Usage : call "%~dp0pick_python.bat" [verbose]
rem  Result: PY_RUN is set to the chosen interpreter, e.g. "C:\Python310\python.exe"
rem          If nothing is found PY_RUN stays undefined and ERRORLEVEL is 1.
rem ================================================================
setlocal EnableDelayedExpansion
for %%I in ("%~dp0..") do set "PROJ=%%~fI"
set "VERBOSE=%~1"
set "CAND=%TEMP%\lease_py_candidates.tmp"
set "DEP_PROBE=import uvicorn,fastapi,pydantic,multipart,jwt,openpyxl,reportlab"
set "PIP_MIRROR=-i https://mirrors.tencent.com/pypi/simple/ --trusted-host mirrors.tencent.com"
set "SKIPRE=/i /c:hermes /c:.workbuddy /c:.local\bin /c:uv\python /c:binaries"
set "PY_RUN="
type nul > "%CAND%"

rem ---------------- collect candidates ----------------
if exist "%PROJ%\.venv\Scripts\python.exe" >>"%CAND%" echo "%PROJ%\.venv\Scripts\python.exe"

if exist "%~dp0.python_exe.txt" (
  set /p PY_LAST=<"%~dp0.python_exe.txt"
  if defined PY_LAST >>"%CAND%" echo !PY_LAST!
)

for %%V in (3.13 3.12 3.11 3.10) do (
  if exist "!LOCALAPPDATA!\Microsoft\WindowsApps\python%%V.exe" >>"%CAND%" echo "!LOCALAPPDATA!\Microsoft\WindowsApps\python%%V.exe"
)

for %%V in (3.13 3.12 3.11 3.10) do (
  for /f "usebackq delims=" %%P in (`py -%%V -c "import sys;print(sys.executable)" 2^>nul`) do >>"%CAND%" echo "%%P"
)

for %%N in (python3.13 python3.12 python3.11 python3.10 python3 python) do (
  for /f "delims=" %%P in ('where %%N 2^>nul') do (
    echo %%P|findstr %SKIPRE% >nul
    if errorlevel 1 >>"%CAND%" echo "%%P"
  )
)

for /d %%D in ("C:\Python3*" "D:\Python3*" "!LOCALAPPDATA!\Programs\Python\Python3*") do (
  if exist "%%~D\python.exe" >>"%CAND%" echo "%%~D\python.exe"
)

rem ---------------- probe each candidate for the full dependency set ----------------
set /a N=0
for /f "usebackq delims=" %%P in ("%CAND%") do (
  if not "%%P"=="" (
    echo %%P|findstr /i /c:".exe" >nul
    if not errorlevel 1 (
      if exist %%P (
        set /a N+=1
        if not defined PY_RUN (
          %%P -c "%DEP_PROBE%" >nul 2>nul
          if not errorlevel 1 (
            set "PY_RUN=%%P"
            if "!VERBOSE!"=="verbose" echo         [ok  ] candidate !N! %%P
          ) else (
            if "!VERBOSE!"=="verbose" echo         [miss] candidate !N! %%P
          )
        )
      )
    )
  )
)

rem ---------------- fallback 1: install deps in place ----------------
if not defined PY_RUN (
  set "PIP_TARGET="
  for /f "usebackq delims=" %%P in ("%CAND%") do (
    if not defined PIP_TARGET (
      echo %%P|findstr %SKIPRE% >nul
      if errorlevel 1 (
        echo %%P|findstr /i /c:".exe" >nul
        if not errorlevel 1 (
          if exist %%P set "PIP_TARGET=%%P"
        )
      )
    )
  )
  if defined PIP_TARGET (
    if "!VERBOSE!"=="verbose" echo         [info] no usable interpreter, installing deps into !PIP_TARGET!
    !PIP_TARGET! -m pip install --upgrade pip >nul 2>nul
    !PIP_TARGET! -m pip install -r "%PROJ%\requirements.lock" !PIP_MIRROR!
    if errorlevel 1 !PIP_TARGET! -m pip install -r "%PROJ%\requirements.txt" !PIP_MIRROR!
    !PIP_TARGET! -c "%DEP_PROBE%" >nul 2>nul
    if not errorlevel 1 set "PY_RUN=!PIP_TARGET!"
  )
)

rem ---------------- fallback 2: create project virtualenv .venv ----------------
if not defined PY_RUN (
  if defined PIP_TARGET (
    if "!VERBOSE!"=="verbose" echo         [info] creating project virtualenv .venv
    !PIP_TARGET! -m venv "%PROJ%\.venv" >nul 2>nul
    set "VENVPY=%PROJ%\.venv\Scripts\python.exe"
    if exist "!VENVPY!" (
      "!VENVPY!" -m pip install -r "%PROJ%\requirements.lock" !PIP_MIRROR!
      "!VENVPY!" -c "%DEP_PROBE%" >nul 2>nul
      if not errorlevel 1 set PY_RUN="!VENVPY!"
    )
  )
)

rem ---------------- remember and return ----------------
if defined PY_RUN (
  > "%~dp0.python_exe.txt" echo !PY_RUN!
)
endlocal & set "PY_RUN=%PY_RUN%" & if not defined PY_RUN exit /b 1
