/* ============================================================
   租赁合同管理系统 Web 版 - 前端应用
   ============================================================ */
"use strict";

/* localStorage 安全访问（P1-7，2026-09-11：隐私模式/禁用存储时避免整页白屏） */
const Store = {
  get(k) { try { return window.localStorage.getItem(k); } catch (e) { return null; } },
  set(k, v) { try { window.localStorage.setItem(k, v); } catch (e) {} },
  remove(k) { try { window.localStorage.removeItem(k); } catch (e) {} },
};

/* ---------------- API 封装 ---------------- */
const API = {
  token: Store.get("lease_token") || "",

  async request(method, url, body, isForm, opts = {}) {
    const headers = {};
    if (this.token) headers["Authorization"] = "Bearer " + this.token;
    let payload = body;
    if (body && !isForm) {
      headers["Content-Type"] = "application/json";
      payload = JSON.stringify(body);
    }
    const resp = await fetch(url, { method, headers, body: payload, cache: "no-store" });
    if (resp.status === 401 && !opts.noRedirect) {
      // token 失效
      Store.remove("lease_token");
      if (!location.pathname.endsWith("index.html") && location.pathname !== "/") {
        location.href = "/";
      }
      throw new Error("登录已过期，请重新登录");
    }
    const ct = resp.headers.get("content-type") || "";
    if (ct.includes("application/json")) {
      const data = await resp.json();
      if (!resp.ok) throw new Error(data.detail || "请求失败");
      return data;
    }
    if (!resp.ok) throw new Error("请求失败(" + resp.status + ")");
    return resp;
  },

  get(url) { return this.request("GET", url); },
  post(url, body, opts) { return this.request("POST", url, body, false, opts); },
  put(url, body) { return this.request("PUT", url, body); },
  del(url) { return this.request("DELETE", url); },

  /* 下载文件流（导出用）
     timeoutMs：超时毫秒数，不传则不限时。导出行数多时服务端生成需要时间，
     超时按失败提示，避免按钮一直卡在 loading。 */
  async download(url, fallbackName, timeoutMs) {
    const headers = {};
    if (this.token) headers["Authorization"] = "Bearer " + this.token;
    const ctrl = timeoutMs ? new AbortController() : null;
    const timer = ctrl ? setTimeout(() => ctrl.abort(), timeoutMs) : null;
    let resp;
    try {
      resp = await fetch(url, { headers, signal: ctrl ? ctrl.signal : undefined });
    } catch (e) {
      if (e && e.name === "AbortError") throw new Error("导出超时，请缩小筛选范围后重试");
      throw e;
    } finally {
      if (timer) clearTimeout(timer);
    }
    if (resp.status === 401) { location.href = "/"; throw new Error("登录已过期"); }
    if (!resp.ok) {
      const data = await resp.json().catch(() => null);
      throw new Error((data && data.detail) || "导出失败");
    }
    const blob = await resp.blob();
    const disp = resp.headers.get("content-disposition") || "";
    let filename = fallbackName;
    const m = disp.match(/filename\*=UTF-8''([^;]+)/);
    if (m) filename = decodeURIComponent(m[1]);
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 300);
  },
};

/* ---------------- 通用工具 ---------------- */
function $(sel, root) { return (root || document).querySelector(sel); }
function $all(sel, root) { return Array.from((root || document).querySelectorAll(sel)); }
function esc(s) {
  if (s === null || s === undefined) return "";
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}
function fmtMoney(v) {
  if (v === null || v === undefined || v === "") return "";
  const n = Number(v);
  if (isNaN(n)) return String(v);
  return n.toLocaleString("zh-CN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
function fmtDate(d) { return d || ""; }
function todayStr() {
  const d = new Date();
  return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
}
function lastYearStr() {
  const d = new Date();
  d.setFullYear(d.getFullYear() - 1);
  return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
}
/* 当前年度第一天 / 最后一天（YYYY-MM-DD，按系统日期动态计算，不写死年份） */
function yearStartStr() {
  return new Date().getFullYear() + "-01-01";
}
function yearEndStr() {
  return new Date().getFullYear() + "-12-31";
}
/* 日期合法性校验：空串视为「不限制」返回 true；否则必须是 YYYY-MM-DD 且真实存在 */
function isValidDateStr(s) {
  if (!s) return true;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const [y, m, d] = s.split("-").map(Number);
  const dt = new Date(y, m - 1, d);
  return dt.getFullYear() === y && dt.getMonth() === m - 1 && dt.getDate() === d;
}

let toastTimer = null;
function toast(msg, type) {
  let t = $("#toast");
  if (!t) return;
  t.textContent = msg;
  t.className = "toast " + (type || "");
  t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { t.hidden = true; }, 2600);
}

function confirmDlg(msg) { return window.confirm(msg); }

function openModal(title, bodyHtml, opts) {
  opts = opts || {};
  $("#modalTitle").textContent = title;
  $("#modalBody").innerHTML = bodyHtml;
  const box = $("#modalBox");
  box.className = "modal" + (opts.wide ? " wide" : "") + (opts.narrow ? " narrow" : "") + (opts.detail ? " detail" : "");
  $("#modalMask").hidden = false;
}
function closeModal() { $("#modalMask").hidden = true; }

function setLoading(btn, loading, text) {
  if (!btn) return;
  if (loading) { btn.dataset.orig = btn.innerHTML; btn.disabled = true; btn.innerHTML = text || "处理中..."; }
  else { btn.disabled = false; if (btn.dataset.orig) btn.innerHTML = btn.dataset.orig; }
}


/* ---------------- 状态标签 ---------------- */
function statusTag(status) {
  const map = {
    "执行中": "tag-green", "已完成": "tag-blue", "已逾期": "tag-red", "已中止": "tag-gray",
    "已结清": "tag-green", "部分收款": "tag-blue", "未结清": "tag-orange",
  };
  return `<span class="tag ${map[status] || "tag-gray"}">${esc(status)}</span>`;
}

/* ============================================================
   登录页逻辑
   ============================================================ */
function initLogin() {
  const form = $("#login-form");
  if (!form) return;
  if (API.token) {
    // 已有 token，直接尝试进入主界面
    API.get("/api/auth/me").then(() => {
      location.href = "/static/app.html";
    }).catch(() => {
      Store.remove("lease_token");
      API.token = "";
    });
  }
  // 数据库连通状态（P1-2：用户名下拉已改为自由输入，不再拉取用户名列表）
  // 2026-09-11：直接展示"连没连上库"，避免把"登录失败"误判成"连不上数据库"
  (async () => {
    const el = $("#login-db"), hint = $("#login-db-hint");
    const show = (text, color, tip) => {
      if (el) { el.textContent = text; el.style.color = color; }
      if (hint) { hint.textContent = tip || ""; hint.style.display = tip ? "" : "none"; }
    };
    try {
      const r = await fetch("/api/system/db-name", { cache: "no-store" });
      if (!r.ok) throw new Error("HTTP " + r.status);
      const info = await r.json();
      const dbName = (info.database_path || "").split(/[\\/]/).pop();
      if (dbName) {
        show("✔ 数据库已连接: " + dbName, "#27ae60");
      } else {
        show("✖ 未检测到数据库", "#e74c3c",
          "服务端未配置数据库：请运行项目根目录的「诊断启动.bat」查看原因与修复建议。");
      }
    } catch (e) {
      show("✖ 无法连接服务/数据库", "#e74c3c",
        "请确认服务已启动（可双击 start_web.bat），或运行「诊断启动.bat」排查。");
    }
  })();
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const errBox = $("#login-error");
    errBox.hidden = true;
    const btn = $("#login-btn");
    setLoading(btn, true, "登录中...");
    try {
      const data = await API.post("/api/auth/login", {
        username: $("#username").value,
        password: $("#password").value,
      });
      API.token = data.token;
      Store.set("lease_token", data.token);
      Store.set("lease_user", JSON.stringify(data.user));
      location.href = "/static/app.html";
    } catch (err) {
      errBox.textContent = err.message;
      errBox.hidden = false;
    } finally {
      setLoading(btn, false);
    }
  });
}

/* ============================================================
   主应用逻辑
   ============================================================ */
const App = {
  user: null,
  page: "dashboard",
  charts: {},

  /* 导出通用流程（合同管理 / 租金管理等列表页共用，保证行为一致）
     ① 空数据不发请求；② 加载中禁用按钮 + 全局锁，防止重复点击重复导出；
     ③ 超时按失败提示；④ 成功/失败统一 toast。
     用法：App.exportFile({ btn, url, fallbackName, count, name, timeoutMs }) */
  async exportFile(opt) {
    const btn = opt.btn;
    const name = opt.name || "数据";
    if (this._exporting) { toast("已有导出任务在进行中，请稍候"); return; }
    if (!opt.count) { toast(`当前筛选条件下没有可导出的${name}`); return; }
    this._exporting = true;
    setLoading(btn, true, "导出中...");
    try {
      await API.download(opt.url, opt.fallbackName, opt.timeoutMs || 60000);
      toast(`已导出 ${opt.count} 条${name}`, "success");
    } catch (e) {
      toast("导出失败：" + (e.message || "请稍后重试"), "error");
    } finally {
      setLoading(btn, false);
      this._exporting = false;
    }
  },

  async init() {
    if (!API.token) { location.href = "/"; return; }
    try {
      const me = await API.get("/api/auth/me");
      this.user = me.user;
      Store.set("lease_user", JSON.stringify(me.user));
    } catch (e) {
      if (e.message.includes("登录已过期")) return;
      toast("认证失败: " + e.message, "error");
      return;
    }
    $("#app").hidden = false;
    $("#userName").textContent = this.user.username;
    const roleEl = $("#userRole");
    roleEl.textContent = this.user.role;
    roleEl.className = "role-badge" + (this.user.role === "操作员" ? " op" : "");
    if (this.user.role !== "管理员") {
      const navSettings = $("#navSettings");
      if (navSettings) navSettings.style.display = "none";
    }
    this.bindEvents();
    this.loadSystemInfo();
    this.startClock();
    const page = location.hash.replace("#", "") || "dashboard";
    this.showPage(page);
  },

  bindEvents() {
    $all(".nav-item").forEach(el => {
      el.addEventListener("click", (e) => {
        e.preventDefault();
        this.showPage(el.dataset.page);
        $("#sidebar").classList.remove("open");
      });
    });
    $("#hamburger").addEventListener("click", () => $("#sidebar").classList.toggle("open"));
    $("#logoutBtn").addEventListener("click", () => this.logout());
    $("#changePwdBtn").addEventListener("click", () => this.showChangePwd());
    $("#modalClose").addEventListener("click", closeModal);
    $("#modalMask").addEventListener("click", (e) => { if (e.target === $("#modalMask")) closeModal(); });
    // 主题切换（对齐原版 showThemeSelection / applyModernTheme，4 主题）
    const themeSel = $("#themeSelect");
    if (themeSel) {
      const saved = Store.get("lease_theme") || "default";
      themeSel.value = saved;
      document.documentElement.setAttribute("data-theme", saved);
      themeSel.addEventListener("change", () => {
        const t = themeSel.value;
        document.documentElement.setAttribute("data-theme", t);
        Store.set("lease_theme", t);
      });
    }
    this.startReminderTimer();
    this.startIdleTimer();
  },

  /* 提醒定时器（对齐原版 initReminder QTimer：按 reminder_frequency 分钟检查一次，首次立即检查） */
  startReminderTimer() {
    if (this._reminderStarted) return;
    this._reminderStarted = true;
    const check = async () => {
      try {
        // 首次（或未缓存）时从后端同步提醒频率，保证修改过的设置生效
        if (!Store.get("lease_reminder_freq")) {
          try {
            const rs = await API.get("/api/settings/reminder-settings");
            Store.set("lease_reminder_freq", String(rs.reminder_frequency || 60));
          } catch (e) {}
        }
        const r = await API.post("/api/reminders/generate");
        const list = (r && r.reminders) || [];
        if (list.length) this.showReminderPopup(list);
      } catch (e) {}
      // 每次检查后按最新提醒频率调度下一次（系统设置保存时同步到 localStorage）
      const freqMin = parseInt(Store.get("lease_reminder_freq") || "60", 10) || 60;
      setTimeout(check, Math.max(freqMin, 1) * 60 * 1000);
    };
    check();
  },

  /* 屏幕超时自动退出（对齐原版 screen_timeout_minutes：无操作 N 分钟自动退出登录；0=禁用） */
  startIdleTimer() {
    if (this._idleStarted) return;
    this._idleStarted = true;
    let lastActivity = Date.now();
    const bump = () => { lastActivity = Date.now(); };
    ["mousemove", "mousedown", "keydown", "scroll", "touchstart"].forEach(ev =>
      document.addEventListener(ev, bump, { passive: true }));
    // 首次从后端同步屏幕超时设置（系统设置保存时也会同步到 localStorage）
    if (!Store.get("lease_screen_timeout")) {
      API.get("/api/settings/reminder-settings").then(rs => {
        Store.set("lease_screen_timeout", String(rs.screen_timeout_minutes || 30));
      }).catch(() => {});
    }
    // 每 30 秒检查一次
    setInterval(() => {
      const t = parseInt(Store.get("lease_screen_timeout") || "30", 10) || 0;
      if (t <= 0) return; // 0 = 不限制
      if (Date.now() - lastActivity > t * 60 * 1000) {
        try { toast("长时间未操作，系统已自动退出登录", "info"); } catch (e) {}
        this.logout();
      }
    }, 30 * 1000);
  },

  /* 合并提醒弹窗（对齐原版 showCombinedReminders：逾期 > 合同到期 > 租金到期） */
  showReminderPopup(list) {
    if (!list || !list.length || document.hidden) return;
    const overdue = list.filter(x => x.type === "合同逾期").sort((a, b) => (b.days_overdue || 0) - (a.days_overdue || 0));
    const expiry = list.filter(x => x.type === "合同到期").sort((a, b) => (a.days_left || 0) - (b.days_left || 0));
    const rent = list.filter(x => x.type === "租金到期").sort((a, b) => (a.days_left || 0) - (b.days_left || 0));
    let msg = "有新的提醒需要您处理：\n\n";
    if (overdue.length) {
      msg += "⚠️ 合同逾期提醒\n";
      overdue.forEach(x => { msg += `  - 合同编号:${x.contract_no},承租方:${x.lessee},已逾期${x.days_overdue}天\n`; });
      msg += "\n";
    }
    if (expiry.length) {
      msg += "📅 合同到期提醒\n";
      expiry.forEach(x => { msg += `  - 合同编号:${x.contract_no},承租方:${x.lessee},将在${x.days_left}天后到期\n`; });
      msg += "\n";
    }
    if (rent.length) {
      msg += "💸 租金到期提醒\n";
      rent.forEach(x => { msg += `  - 合同编号:${x.contract_no},承租方:${x.lessee},租金将在${x.days_left}天后到期\n`; });
    }
    openModal("系统提醒", `<div style="white-space:pre-wrap;font-size:13px;line-height:1.7">${esc(msg)}</div>
      <div class="form-actions"><button class="btn" onclick="closeModal()">确定</button></div>`, {});
  },

  async logout() {
    try { await API.post("/api/auth/logout"); } catch (e) {}
    Store.remove("lease_token");
    Store.remove("lease_user");
    location.href = "/";
  },

  async loadSystemInfo() {
    try {
      const info = await API.get("/api/system/info");
      $("#brand").textContent = info.brand || "综合贸易";
      $("#appName").textContent = info.software_name || "门面租赁管理系统";
      const dbName = (info.database_path || "").split(/[\\/]/).pop();
      $("#dbBadge").textContent = dbName || "";
      App._dbPath = info.database_path || "";
    } catch (e) {}
  },

  // 取当前库所在目录（用于「创建数据库」输入框的路径提示）。
  // App._dbPath 由 loadSystemInfo 填充；未就绪时回退空串，不阻塞弹窗渲染。
  getDbDirHint() {
    const p = App._dbPath || "";
    const i = Math.max(p.lastIndexOf("\\"), p.lastIndexOf("/"));
    return i > 0 ? p.slice(0, i + 1) : "";
  },

  startClock() {
    const tick = () => {
      const now = new Date();
      const pad = n => String(n).padStart(2, "0");
      $("#datetime").textContent =
        `${now.getFullYear()}-${pad(now.getMonth()+1)}-${pad(now.getDate())} ${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
    };
    tick();
    setInterval(tick, 1000);
  },

  showPage(page) {
    this.page = page;
    location.hash = page;
    $all(".nav-item").forEach(el => el.classList.toggle("active", el.dataset.page === page));
    const content = $("#content");
    // 销毁旧图表
    Object.values(this.charts).forEach(c => { try { c.destroy(); } catch (e) {} });
    this.charts = {};
    switch (page) {
      case "dashboard": this.renderDashboard(content); break;
      case "contracts": this.renderContracts(content); break;
      case "rents": this.renderRents(content); break;
      case "adjustments": this.renderAdjustments(content); break;
      case "reports": this.renderReports(content); break;
      case "basic": this.renderBasic(content); break;
      case "settings": this.renderSettings(content); break;
      case "notes": this.renderNotes(content); break;
      case "about": this.renderAbout(content); break;
      default: this.renderDashboard(content);
    }
  },

  /* ---------------- 修改密码 ---------------- */
  showChangePwd() {
    openModal("修改密码", `
      <div class="form-grid">
        <div class="form-group full"><label class="required">原密码</label>
          <input type="password" id="cpOld" placeholder="请输入原密码"></div>
        <div class="form-group full"><label class="required">新密码</label>
          <input type="password" id="cpNew" placeholder="新密码至少8位，须包含字母和数字"></div>
        <div class="form-group full"><label class="required">确认新密码</label>
          <input type="password" id="cpNew2" placeholder="再次输入新密码"></div>
      </div>
      <div class="form-actions">
        <button class="btn" onclick="closeModal()">取消</button>
        <button class="btn btn-primary" id="cpBtn">确认修改</button>
      </div>`, { narrow: true });
    $("#cpBtn").addEventListener("click", async () => {
      const oldP = $("#cpOld").value, newP = $("#cpNew").value, new2 = $("#cpNew2").value;
      if (!oldP || !newP) return toast("请填写完整", "error");
      if (newP !== new2) return toast("两次输入的新密码不一致", "error");
      if (newP.length < 8) return toast("新密码长度至少为8个字符！", "error");
      if (!/[A-Za-z]/.test(newP) || !/[0-9]/.test(newP)) return toast("新密码必须包含字母和数字！", "error");
      const btn = $("#cpBtn");
      setLoading(btn, true);
      try {
        const r = await API.post("/api/auth/change-password", { old_password: oldP, new_password: newP });
        toast(r.message, "success");
        closeModal();
      } catch (e) { toast(e.message, "error"); }
      finally { setLoading(btn, false); }
    });
  },
};

/* ============================================================
   仪表盘
   ============================================================ */
App.renderDashboard = async function (content) {
  content.innerHTML = `<div class="panel"><div class="panel-title">经营统计</div>
    <div class="stats-grid" id="dashStats"></div>
    <div class="dash-grid">
      <div class="panel" style="margin-bottom:0"><div class="panel-title">租金到期明细</div>
        <div class="cond-label" id="rentDueCond"></div>
        <div class="table-wrap" style="max-height:280px;overflow-y:auto" id="rentDueTable"></div></div>
      <div class="panel" style="margin-bottom:0"><div class="panel-title">合同到期明细</div>
        <div class="cond-label" id="expiryCond"></div>
        <div class="table-wrap" style="max-height:280px;overflow-y:auto" id="expiryTable"></div></div>
      <div class="panel" style="margin-bottom:0"><div class="panel-title">待续签（空置）合同明细</div>
        <div class="cond-label" id="renewableCond"></div>
        <div class="table-wrap" style="max-height:280px;overflow-y:auto" id="renewableTable"></div></div>
      <div class="panel full" style="margin-bottom:0"><div class="panel-title">租金收入趋势（近12个月应收/实收）</div>
        <div class="chart-box" id="rentTrendChart"></div></div>
    </div></div>`;
  try {
    // 先执行自动状态更新（对齐原版 loadAllData 中 checkAndUpdateExpiredContracts/OverdueContracts）
    try { await API.post("/api/contracts/auto-update-status"); } catch (e) {}
    const [stats, trend, expiry, rentDue, renewable, reminders] = await Promise.all([
      API.get("/api/dashboard/stats"),
      API.get("/api/dashboard/rent-trend"),
      API.get("/api/dashboard/expiry"),
      API.get("/api/dashboard/rent-due"),
      API.get("/api/dashboard/renewable"),
      API.get("/api/reminders").catch(() => ({ contract_reminder_days: 30, rent_reminder_days: 7 })),
    ]);
    // 三表说明标签（随提醒设置动态，对齐原版 updateReminders 文案）
    const cd = (reminders && reminders.contract_reminder_days) ?? 30;
    const rd = (reminders && reminders.rent_reminder_days) ?? 7;
    const cExpiry = document.getElementById("expiryCond");
    const cRent = document.getElementById("rentDueCond");
    const cRenew = document.getElementById("renewableCond");
    if (cExpiry) cExpiry.textContent = `说明：到期日在未来 ${cd} 天内（含已逾期）合同`;
    if (cRent) cRent.textContent = `说明：到期日在未来 ${rd} 天内（含已到期/未结清）合同`;
    if (cRenew) cRenew.textContent = `说明：已中止/已完成且房屋后续未再租出的空置合同`;
    this.renderDashStats($("#dashStats"), stats);
    this.renderRentTrendChart($("#rentTrendChart"), trend);
    this.renderExpiryTable($("#expiryTable"), expiry.contract_expiry || []);
    this.renderRenewableTable($("#renewableTable"), renewable.renewable || []);
    this.renderRentDueTable($("#rentDueTable"), rentDue.rent_due || []);
  } catch (e) {
    toast("仪表盘加载失败: " + e.message, "error");
  }
};

/* 双击行 → 合同详情弹窗（对齐原版 showContractDetails 字段分组） */
App.openContractDetail = async function (contractNo) {
  try {
    const c = await API.get(`/api/contracts/${encodeURIComponent(contractNo)}`);
    if (!c || !c.contract_no) return toast("未找到该合同", "error");
    const F = {
      contract_no: "合同编号", sign_date: "签约日期", sign_year_month: "签约年月", status: "状态",
      lessor: "出租人", legal_representative: "法定代表人", person_in_charge: "负责人", contact_phone: "联系电话",
      lessee: "承租人", tenant: "租户", tenant_id: "租户身份证", tenant_phone: "租户电话",
      start_date: "起租日期", end_date: "到期日期",
      monthly_rent: "月租金", annual_rent: "年租金", total_rent: "总租金", deposit: "押金", payment_method: "付款方式",
      house_no: "房屋编号", house_location: "房屋位置", house_area: "房屋面积", usage: "用途",
      utility_method: "水电费结算方式", water_fee: "水费", electricity_fee: "电费", remarks: "备注",
    };
    const moneyFields = { monthly_rent: 1, annual_rent: 1, total_rent: 1, deposit: 1, water_fee: 1, electricity_fee: 1, house_area: 1 };
    const groups = [
      ["基本信息", ["contract_no", "sign_date", "sign_year_month", "status"]],
      ["出租人信息", ["lessor", "legal_representative", "person_in_charge", "contact_phone"]],
      ["承租人信息", ["lessee", "tenant", "tenant_id", "tenant_phone"]],
      ["合同期限", ["start_date", "end_date"]],
      ["租金与费用", ["monthly_rent", "annual_rent", "total_rent", "deposit", "payment_method"]],
      ["附加信息", ["house_no", "house_location", "house_area", "usage", "utility_method", "water_fee", "electricity_fee", "remarks"]],
    ];
    const rowHtml = (key) => {
      const v = c[key];
      const label = F[key] || key;
      let text = (v === null || v === undefined || v === "") ? "—" : String(v);
      if (key === "status") return `<div class="detail-row"><span class="k">${label}</span><span class="v">${statusTag(c.status)}</span></div>`;
      if (moneyFields[key] && text !== "—") text = fmtMoney(v);
      return `<div class="detail-row"><span class="k">${label}</span><span class="v">${esc(text)}</span></div>`;
    };
    const body = `<div class="detail-grid">${groups.map(([title, keys]) =>
      `<div class="detail-group"><h4>${title}</h4>${keys.map(rowHtml).join("")}</div>`).join("")}</div>`;
    openModal(`合同详情 - ${esc(contractNo)}`, body + `<div class="form-actions" style="margin-top:12px"><button class="btn" onclick="closeModal()">关闭</button></div>`, { detail: true });
  } catch (e) { toast(e.message, "error"); }
};

App.renderDashStats = function (el, stats) {
  const s = stats || {};
  const cards = [
    { label: "合同总数", value: s.total_contracts ?? "--" },
    { label: "执行中合同", value: s.active_contracts ?? "--", cls: "green" },
    { label: "已完成合同", value: s.completed_contracts ?? "--", cls: "blue" },
    { label: "已中止合同", value: s.terminated_contracts ?? "--", cls: "orange" },
    { label: "已逾期合同", value: s.overdue_contracts ?? "--", cls: "red" },
    { label: "年度租金总额", value: fmtMoney(s.annual_rent), cls: "orange", sm: true },
    { label: "已收租金总额", value: fmtMoney(s.received_rent), cls: "green", sm: true },
    { label: "应收租金总额", value: fmtMoney(s.receivable_rent), cls: "blue", sm: true },
    { label: "押金总金额", value: fmtMoney(s.total_deposit), sm: true },
  ];
  el.innerHTML = cards.map(c => `
    <div class="stat-card">
      <div class="label">${c.label}</div>
      <div class="value ${c.cls || ""} ${c.sm ? "sm" : ""}">${esc(c.value)}</div>
    </div>`).join("");
};

App.renderRentTrendChart = function (el, trend) {
  const months = (trend && trend.months) || [];
  const receivable = (trend && trend.receivable) || [];
  const received = (trend && trend.received) || [];
  el.innerHTML = "";
  if (!months.length) { el.innerHTML = '<p class="hint" style="color:#999;text-align:center;padding-top:80px">暂无趋势数据</p>'; return; }
  const canvas = document.createElement("canvas");
  el.appendChild(canvas);
  this.charts.rentTrend = new Chart(canvas, {
    type: "line",
    data: {
      labels: months,
      datasets: [
        { label: "应收租金", data: receivable, borderColor: "rgba(79,129,189,1)", backgroundColor: "rgba(79,129,189,.15)", borderWidth: 2, tension: 0.3, pointRadius: 4, pointBackgroundColor: "rgba(79,129,189,1)", fill: true },
        { label: "实际收款", data: received, borderColor: "rgba(39,174,96,1)", backgroundColor: "rgba(39,174,96,.15)", borderWidth: 2, tension: 0.3, pointRadius: 4, pointBackgroundColor: "rgba(39,174,96,1)", fill: true },
      ],
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: {
        legend: { position: "top" },
        datalabels: {
          color: "#333",
          font: { size: 10, weight: "600" },
          formatter: v => (v === null || v === undefined ? "" : Number(v).toLocaleString("zh-CN")),
          anchor: "end",
          align: "top",
          clamp: true,
          display: "auto",
        },
      },
      scales: {
        y: { beginAtZero: true, ticks: { callback: v => fmtMoney(v) } },
      },
    },
  });
};

App.renderExpiryTable = function (el, list) {
  if (!list.length) { el.innerHTML = '<p class="hint" style="color:#999;padding:16px">暂无记录</p>'; return; }
  el.innerHTML = `<table class="data-table"><thead><tr>
    <th>序号</th><th>合同编号</th><th>到期日期</th><th>房屋编号</th><th>承租方</th><th>年租金</th><th>状态</th><th>剩余天数</th>
  </tr></thead><tbody>
    ${list.map((x, i) => `<tr data-no="${esc(x.contract_no)}">
      <td class="num">${i + 1}</td><td>${esc(x.contract_no)}</td><td>${esc(x.end_date)}</td><td>${esc(x.house_no)}</td>
      <td>${esc(x.lessee)}</td><td class="num">${fmtMoney(x.annual_rent)}</td>
      <td>${statusTag(x.status)}</td>
      <td>${x.days_until_expiry !== undefined && x.days_until_expiry !== null ?
        (x.days_until_expiry < 0 ? `<span class="tag tag-red">已逾期${-x.days_until_expiry}天</span>`
          : x.days_until_expiry === 0 ? `<span class="tag tag-orange">今天到期</span>`
          : `<span class="tag tag-blue">${x.days_until_expiry}天</span>`) : "--"}</td>
    </tr>`).join("")}
  </tbody></table>`;
};

App.renderRentDueTable = function (el, list) {
  if (!list.length) { el.innerHTML = '<p class="hint" style="color:#999;padding:16px">暂无记录</p>'; return; }
  el.innerHTML = `<table class="data-table"><thead><tr>
    <th>序号</th><th>合同编号</th><th>房屋编号</th><th>承租方</th><th>最近收款期间截止</th>
  </tr></thead><tbody>
    ${list.map((x, i) => {
      const dueDate = x.due_date || x.period_end || x.end_date;
      let dateLabel = dueDate;
      if (x.no_rent_record) dateLabel = `${dueDate} (未录租金)`;
      else if (x.start_date && dueDate === x.start_date) dateLabel = `${dueDate} (租赁开始)`;
      return `<tr data-no="${esc(x.contract_no)}">
      <td class="num">${i + 1}</td><td>${esc(x.contract_no)}</td><td>${esc(x.house_no)}</td><td>${esc(x.lessee)}</td>
      <td>${esc(dateLabel)}</td>
    </tr>`;
    }).join("")}
  </tbody></table>`;
};

/* 待续签（空置）合同明细（对齐原版 ui_dashboard_tab 待续签模块） */
App.renderRenewableTable = function (el, list) {
  if (!list.length) { el.innerHTML = '<p class="hint" style="color:#999;padding:16px">暂无记录</p>'; return; }
  el.innerHTML = `<table class="data-table"><thead><tr>
    <th>序号</th><th>合同编号</th><th>房屋编号</th><th>承租方</th><th>原合同到期日期</th><th>合同状态</th>
  </tr></thead><tbody>
    ${list.map((x, i) => `<tr data-no="${esc(x.contract_no)}">
      <td class="num">${i + 1}</td><td>${esc(x.contract_no)}</td><td>${esc(x.house_no)}</td><td>${esc(x.lessee)}</td>
      <td>${esc(x.end_date)}</td><td>${statusTag(x.status)}</td>
    </tr>`).join("")}
  </tbody></table>`;
};

/* ============================================================
   启动
   ============================================================ */
document.addEventListener("DOMContentLoaded", () => {
  // 登录页
  if (document.getElementById("login-form")) {
    initLogin();
    return;
  }
  // 主应用（各功能模块在 contracts.js/rents.js/reports.js/basic.js/settings.js/notes.js 中挂载）
  if (document.getElementById("app")) {
    App.init();
    // 三表明细行双击 → 合同详情弹窗（事件委托，避免每次渲染重复绑定）
    // 注意：合同管理页主表 #contractTbody 的双击已由 contracts.js 改为打开“编辑合同”，此处排除
    document.getElementById("content").addEventListener("dblclick", (e) => {
      const tr = e.target.closest("tr[data-no]");
      if (tr && tr.dataset.no && !tr.closest("#contractTbody")) App.openContractDetail(tr.dataset.no);
    });
    // 数据变更自动刷新：合同/租金/笔记保存后广播；仪表盘当前页时防抖重渲染（对齐原版 data_updated 信号）
    window.addEventListener("lease-data-updated", () => {
      if (App.page === "dashboard") {
        clearTimeout(App._dashTimer);
        App._dashTimer = setTimeout(() => {
          Object.values(App.charts).forEach((c) => { try { c.destroy(); } catch (e) {} });
          App.charts = {};
          App.renderDashboard($("#content"));
        }, 800);
      }
    });
  }
});
