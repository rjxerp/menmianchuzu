/* ============================================================
   合同管理模块
   ============================================================ */
"use strict";

App.renderContracts = function (content) {
  content.innerHTML = `
  <div class="panel">
    <div class="toolbar">
      <input type="search" id="cSearch" placeholder="搜索合同编号/承租方/房屋位置等" style="width:240px">
      <label class="check-inline"><input type="checkbox" id="cSt1" value="执行中" checked> 执行中</label>
      <label class="check-inline"><input type="checkbox" id="cSt2" value="已完成"> 已完成</label>
      <label class="check-inline"><input type="checkbox" id="cSt4" value="已中止"> 已中止</label>
      <label class="check-inline"><input type="checkbox" id="cSt3" value="已逾期"> 已逾期</label>
      <label class="check-inline"><input type="checkbox" id="cPay1" value="已结清"> 已结清</label>
      <label class="check-inline"><input type="checkbox" id="cPay3" value="部分收款"> 部分收款</label>
      <label class="check-inline"><input type="checkbox" id="cPay2" value="未结清"> 未结清</label>
      <label>起租日期: <input type="date" id="cStartDateFrom" value="${yearStartStr()}"></label>
      <label>到期日期: <input type="date" id="cEndDateTo" value="${yearEndStr()}"></label>
      <span class="spacer"></span>
      <button class="btn" id="cReset">重置</button>
      <button class="btn" id="cSearchBtn">搜索</button>
      <button class="btn btn-primary" id="cAdd">+ 添加合同</button>
      <button class="btn btn-success" id="cImport">导入 Excel</button>
      <button class="btn" id="cExport">导出 Excel</button>
      <button class="btn" id="cExportPdf">导出 PDF</button>
    </div>
    <div class="table-wrap" style="max-height:73.3vh;overflow-y:auto">
      <table class="data-table" id="contractTable">
        <thead><tr>
          <th data-key="contract_no" class="sortable">合同编号<span class="sort-ic"></span></th>
          <th data-key="sign_date" class="sortable">签约日期<span class="sort-ic"></span></th>
          <th data-key="house_no" class="sortable">房屋编号<span class="sort-ic"></span></th>
          <th data-key="house_type" class="sortable">房屋类型<span class="sort-ic"></span></th>
          <th data-key="house_location" class="sortable">房屋位置<span class="sort-ic"></span></th>
          <th data-key="lessee" class="sortable">承租方<span class="sort-ic"></span></th>
          <th data-key="tenant" class="sortable">承租人<span class="sort-ic"></span></th>
          <th data-key="start_date" class="sortable">起租日期<span class="sort-ic"></span></th>
          <th data-key="end_date" class="sortable">到期日期<span class="sort-ic"></span></th>
          <th data-key="payment_method" class="sortable">付款方式<span class="sort-ic"></span></th>
          <th data-key="monthly_rent" class="sortable num">月租<span class="sort-ic"></span></th>
          <th data-key="quarterly_rent" class="sortable num">季租<span class="sort-ic"></span></th>
          <th data-key="annual_rent" class="sortable num">年租<span class="sort-ic"></span></th>
          <th data-key="deposit" class="sortable num">押金<span class="sort-ic"></span></th>
          <th data-key="received_rent" class="sortable num">已收<span class="sort-ic"></span></th>
          <th data-key="receivable_rent" class="sortable num">应收<span class="sort-ic"></span></th>
          <th data-key="payment_status" class="sortable">收款情况<span class="sort-ic"></span></th>
          <th data-key="status" class="sortable">状态<span class="sort-ic"></span></th>
          <th data-key="remarks" style="width:112px;max-width:112px">备注<span class="sort-ic"></span></th>
          <th>操作</th>
        </tr></thead>
        <tbody id="contractTbody"><tr><td colspan="20" style="text-align:center;color:#999">加载中...</td></tr></tbody>
      </table>
    </div>
    <div id="contractStats" style="margin-top:10px;font-size:12px;color:#666"></div>
  </div>`;
  const sel = {
    search: $("#cSearch"), st1: $("#cSt1"), st2: $("#cSt2"), st3: $("#cSt3"), st4: $("#cSt4"),
    pay1: $("#cPay1"), pay2: $("#cPay2"), pay3: $("#cPay3"),
    // 日期条件：对应后端 start_date_from / end_date_to（语义：合同租期与查询区间有交集）
    startDate: $("#cStartDateFrom"), endDate: $("#cEndDateTo"),
    btn: $("#cSearchBtn"), reset: $("#cReset"), add: $("#cAdd"),
    imp: $("#cImport"), exp: $("#cExport"), expPdf: $("#cExportPdf"),
    table: $("#contractTable"), tbody: $("#contractTbody"), stats: $("#contractStats"),
  };
  // 合同明细表排序状态：默认按签约日期倒序（降序）
  App._contractSort = { key: "sign_date", dir: "desc" };
  // 表头点击三态排序：首次升序 → 再次降序 → 第三次恢复默认（签约日期倒序）
  $all("th.sortable", sel.table).forEach(th => {
    th.addEventListener("click", () => {
      const key = th.dataset.key;
      const s = App._contractSort;
      if (s.key === key && s.dir === "asc") s.dir = "desc";
      else if (s.key === key && s.dir === "desc") { s.key = "sign_date"; s.dir = "desc"; }
      else { s.key = key; s.dir = "asc"; }
      App.applyContractSort(sel);
    });
  });
  sel.btn.addEventListener("click", () => App.searchContracts(sel));
  sel.reset.addEventListener("click", () => {
    sel.search.value = ""; sel.st1.checked = true; sel.st2.checked = false; sel.st3.checked = false; sel.st4.checked = false;
    sel.pay1.checked = false; sel.pay2.checked = false; sel.pay3.checked = false;
    // 日期条件恢复为当前年度首日 / 末日
    sel.startDate.value = yearStartStr(); sel.endDate.value = yearEndStr();
    App.loadContracts(sel);
  });
  sel.search.addEventListener("keydown", e => { if (e.key === "Enter") App.searchContracts(sel); });
  [sel.startDate, sel.endDate].forEach(el => {
    el.addEventListener("keydown", e => { if (e.key === "Enter") App.searchContracts(sel); });
    el.addEventListener("change", () => App.searchContracts(sel));
  });
  sel.add.addEventListener("click", () => App.showContractForm(sel, null));
  sel.imp.addEventListener("click", () => App.importContracts(sel));
  sel.exp.addEventListener("click", () => {
    const s = App._contractSort || { key: "sign_date", dir: "desc" };
    const q = App.contractQuery(sel);
    const qs = `search=${encodeURIComponent(q.search)}`
      + `&statuses=${encodeURIComponent(q.statuses)}`
      + `&payment_statuses=${encodeURIComponent(q.payment_statuses)}`
      + `&start_date_from=${encodeURIComponent(q.start_date_from)}`
      + `&end_date_to=${encodeURIComponent(q.end_date_to)}`
      + `&sort=${encodeURIComponent(s.key)}&sort_dir=${encodeURIComponent(s.dir)}`;
    App.exportFile({
      btn: sel.exp, name: "合同数据", count: (App._contractList || []).length,
      url: `/api/contracts/export/excel?${qs}`, fallbackName: "合同数据.xlsx",
    });
  });
  sel.expPdf.addEventListener("click", () => {
    const q = App.contractQuery(sel);
    const qs = `search=${encodeURIComponent(q.search)}`
      + `&statuses=${encodeURIComponent(q.statuses)}`
      + `&payment_statuses=${encodeURIComponent(q.payment_statuses)}`
      + `&start_date_from=${encodeURIComponent(q.start_date_from)}`
      + `&end_date_to=${encodeURIComponent(q.end_date_to)}`;
    App.exportFile({
      btn: sel.expPdf, name: "合同数据", count: (App._contractList || []).length,
      url: `/api/contracts/export/pdf?${qs}`, fallbackName: "合同数据.pdf",
    });
  });
  App.loadContracts(sel);
};

App.checkedStatuses = function (sel) {
  return [sel.st1, sel.st2, sel.st3, sel.st4].filter(c => c.checked).map(c => c.value).join(",");
};

App.checkedPayStatuses = function (sel) {
  return [sel.pay1, sel.pay2, sel.pay3].filter(c => c && c.checked).map(c => c.value).join(",");
};

/* 搜索：收集全部条件（含起租/到期日期）→ 校验 → 重置分页 → 重新请求列表
   校验规则：日期必须为 YYYY-MM-DD 合法日期；起租日期不得晚于到期日期 */
App.searchContracts = function (sel) {
  const start = (sel.startDate && sel.startDate.value || "").trim();
  const end = (sel.endDate && sel.endDate.value || "").trim();
  if (!isValidDateStr(start)) {
    toast("起租日期格式不正确，应为 YYYY-MM-DD", "error");
    if (sel.startDate) sel.startDate.focus();
    return;
  }
  if (!isValidDateStr(end)) {
    toast("到期日期格式不正确，应为 YYYY-MM-DD", "error");
    if (sel.endDate) sel.endDate.focus();
    return;
  }
  if (start && end && start > end) {
    toast("起租日期不能晚于到期日期", "error");
    if (sel.startDate) sel.startDate.focus();
    return;
  }
  App._contractPage = 1; // 重置分页至第一页（当前列表不分页，为后续分页预留）
  App.loadContracts(sel);
};

/* 当前生效的查询条件（列表与导出共用，保证两边口径一致） */
App.contractQuery = function (sel) {
  const start = (sel.startDate && sel.startDate.value || "").trim();
  const end = (sel.endDate && sel.endDate.value || "").trim();
  return {
    search: sel.search.value.trim(),
    statuses: App.checkedStatuses(sel),
    payment_statuses: App.checkedPayStatuses(sel),
    start_date_from: start,
    end_date_to: end,
  };
};

App.loadContracts = async function (sel) {
  sel.tbody.innerHTML = '<tr><td colspan="20" style="text-align:center;color:#999">加载中...</td></tr>';
  setLoading(sel.btn, true, "查询中...");
  try {
    const q = App.contractQuery(sel);
    const r = await API.get(`/api/contracts?search=${encodeURIComponent(q.search)}`
      + `&statuses=${encodeURIComponent(q.statuses)}`
      + `&payment_statuses=${encodeURIComponent(q.payment_statuses)}`
      + `&start_date_from=${encodeURIComponent(q.start_date_from)}`
      + `&end_date_to=${encodeURIComponent(q.end_date_to)}`);
    const list = r.data || [];
    App._contractList = list;
    App.applyContractSort(sel);
    if (!list.length) toast("没有符合当前条件的合同");
    const s = r.statistics || {};
    sel.stats.innerHTML = `合同总数: <b>${esc(s.total || 0)}</b>&nbsp;|&nbsp;
      执行中: <b>${(s.status_counts && s.status_counts["执行中"]) || 0}</b>&nbsp;|&nbsp;
      已完成: <b>${(s.status_counts && s.status_counts["已完成"]) || 0}</b>&nbsp;|&nbsp;
      已中止: <b>${(s.status_counts && s.status_counts["已中止"]) || 0}</b>&nbsp;|&nbsp;
      已逾期: <b>${(s.status_counts && s.status_counts["已逾期"]) || 0}</b>&nbsp;|&nbsp;
      已结清: <b>${s.settled_count || 0}</b>&nbsp;|&nbsp;
      部分收款: <b>${s.partial_count || 0}</b>&nbsp;|&nbsp;
      未结清: <b>${s.unsettled_count || 0}</b>&nbsp;|&nbsp;
      月租合计: <b>${fmtMoney(s.monthly_rent_total)}</b>&nbsp;|&nbsp;
      季租合计: <b>${fmtMoney(s.quarterly_rent_total)}</b>&nbsp;|&nbsp;
      年租合计: <b>${fmtMoney(s.annual_rent_total)}</b>&nbsp;|&nbsp;
      已收租金: <b>${fmtMoney(s.received_rent)}</b>&nbsp;|&nbsp;
      应收租金: <b>${fmtMoney(s.receivable_rent)}</b>&nbsp;|&nbsp;
      押金合计: <b>${fmtMoney(s.deposit_total)}</b>`;
  } catch (e) {
    sel.tbody.innerHTML = `<tr><td colspan="20" style="text-align:center;color:#e74c3c">${esc(e.message)}</td></tr>`;
  } finally {
    setLoading(sel.btn, false);
  }
};

/* ============================================================
   合同明细表排序：默认签约日期倒序；表头三态切换（升序→降序→默认）
   纯前端本地排序（不产生后端请求），500 条量级毫秒级完成
   ============================================================ */
App.sortContractList = function (list, key, dir) {
  const NUM = ["monthly_rent", "quarterly_rent", "annual_rent", "deposit", "received_rent", "receivable_rent"];
  const DATE = ["sign_date", "start_date", "end_date"];
  const arr = list.slice();
  arr.sort(function (a, b) {
    const va = a[key], vb = b[key];
    const ae = va === null || va === undefined || va === "";
    const be = vb === null || vb === undefined || vb === "";
    if (ae && be) return 0;
    if (ae) return 1; // 空值始终排最后
    if (be) return -1;
    let r;
    if (NUM.indexOf(key) >= 0) {
      r = Number(va) - Number(vb);
    } else if (DATE.indexOf(key) >= 0) {
      const ta = Date.parse(va), tb = Date.parse(vb);
      r = (!isNaN(ta) && !isNaN(tb)) ? ta - tb : String(va).localeCompare(String(vb));
    } else {
      r = String(va).localeCompare(String(vb), "zh-Hans-CN");
    }
    return dir === "asc" ? r : -r;
  });
  return arr;
};

App.applyContractSort = function (sel) {
  const s = App._contractSort;
  const sorted = App.sortContractList(App._contractList || [], s.key, s.dir);
  if (!sorted.length) {
    sel.tbody.innerHTML = '<tr><td colspan="20" style="text-align:center;color:#999">暂无记录</td></tr>';
  } else {
    sel.tbody.innerHTML = sorted.map(c => `<tr data-no="${esc(c.contract_no)}" title="双击编辑该合同" style="cursor:pointer">
      <td>${esc(c.contract_no)}</td><td>${esc(c.sign_date)}</td><td>${esc(c.house_no)}</td>
      <td>${esc(c.house_type || "")}</td><td>${esc(c.house_location)}</td>
      <td>${esc(c.lessee)}</td><td>${esc(c.tenant)}</td>
      <td>${esc(c.start_date)}</td><td>${esc(c.end_date)}</td>
      <td>${esc(c.payment_method)}</td>
      <td class="num">${fmtMoney(c.monthly_rent)}</td><td class="num">${fmtMoney(c.quarterly_rent)}</td>
      <td class="num">${fmtMoney(c.annual_rent)}</td>
      <td class="num">${fmtMoney(c.deposit)}</td><td class="num">${fmtMoney(c.received_rent)}</td>
      <td class="num">${fmtMoney(c.receivable_rent)}</td>
      <td>${statusTag(c.payment_status)}</td>
      <td>${statusTag(c.status)}</td>
      <td title="${esc(c.remarks || "")}" style="max-width:112px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(c.remarks || "")}</td>
      <td><div class="row-actions">
        <button class="btn btn-sm" data-act="edit">编辑</button>
        <button class="btn btn-sm btn-success" data-act="renew">续签</button>
        <button class="btn btn-sm" data-act="pay">收款明细</button>
        <button class="btn btn-sm btn-danger" data-act="del">删除</button>
      </div></td>
    </tr>`).join("");
    $all("tr[data-no]", sel.tbody).forEach(tr => {
      const no = tr.dataset.no;
      $all("button", tr).forEach(btn => {
        btn.addEventListener("click", () => {
          const act = btn.dataset.act;
          if (act === "edit") App.showContractForm(sel, no);
          else if (act === "renew") App.renewContract(sel, no);
          else if (act === "pay") App.showPayments(no);
          else if (act === "del") App.deleteContract(sel, no);
        });
      });
      // 双击整行 → 打开当前合同的“编辑合同”窗口（双击操作按钮除外）
      tr.addEventListener("dblclick", (e) => {
        if (e.target.closest("button")) return;
        App.showContractForm(sel, no);
      });
    });
  }
  // 更新表头排序指示（箭头 ▲ 升序 / ▼ 降序）
  $all("th.sortable", sel.table).forEach(th => {
    th.classList.remove("sort-asc", "sort-desc");
    const ic = th.querySelector(".sort-ic");
    if (ic) ic.textContent = "";
  });
  const cur = sel.table.querySelector('th[data-key="' + s.key + '"]');
  if (cur) {
    cur.classList.add(s.dir === "asc" ? "sort-asc" : "sort-desc");
    const ic = cur.querySelector(".sort-ic");
    if (ic) ic.textContent = s.dir === "asc" ? "▲" : "▼";
  }
};

/* 合同表单（添加/编辑；prefillData 用于续签自动预填原合同数据） */
App.showContractForm = async function (sel, contractNo, prefillData) {
  let data = prefillData || null;
  if (contractNo && !data) {
    try { data = await API.get(`/api/contracts/${encodeURIComponent(contractNo)}`); }
    catch (e) { toast(e.message, "error"); return; }
  }
  // 续签预填时清空合同编号，作为新合同（对齐原版 handleRenewContract 打开新窗口逻辑）
  const isRenewPrefill = !!prefillData;
  const isEdit = !!contractNo && !isRenewPrefill;
  const payLocked = !isRenewPrefill && data && data.payment_status === "已结清";
  const [houses, tenants, landlords, types, utilityFees] = await Promise.all([
    API.get("/api/basic/houses").catch(() => ({ data: [] })),
    API.get("/api/basic/tenants").catch(() => ({ data: [] })),
    API.get("/api/basic/landlords").catch(() => ({ data: [] })),
    API.get("/api/basic/house-types").catch(() => ({ data: [] })),
    API.get("/api/basic/utility-fees").catch(() => ({ data: [] })),
  ]);
  const v = (k) => (data ? (data[k] !== null && data[k] !== undefined ? data[k] : "") : "");
  // 续签预填：日期不沿用原合同，按新合同默认（对齐原版 handleRenewContract 新窗口默认日期）
  const dateV = (k) => (isRenewPrefill ? "" : v(k));
  // 房屋类型：优先合同记录值；为空时按房屋编号从房屋资料回查（对齐原版 onHouseInfoChanged）
  let initialHouseType = v("house_type");
  if (!initialHouseType && v("house_no")) {
    const matchedHouse = houses.data.find(h => h.house_no === v("house_no"));
    if (matchedHouse && matchedHouse.house_type) initialHouseType = matchedHouse.house_type;
  }
  // 房屋：默认空白（新增/续签时不预选任何房屋，需用户自行选择；编辑时回显原值）
  const houseOptions = `<option value="" ${v("house_no") ? "" : "selected"}>请选择房屋</option>` +
    houses.data.map(h => `<option value="${esc(h.house_no)}" ${v("house_no") === h.house_no ? "selected" : ""}>${esc(h.house_no)} - ${esc(h.house_location)}</option>`).join("");
  // 承租方（乙方）下拉：选项显示承租方名称，值=联系人姓名（对齐原版 select_tenant 填充 tenant=contact_person）
  const tenantOptions = `<option value="" ${v("tenant") ? "" : "selected"}>请选择承租人</option>` +
    tenants.data.map(t => `<option value="${esc(t.contact_person || "")}" ${v("tenant") === t.contact_person ? "selected" : ""}>${esc(t.tenant_name)}</option>`).join("");
  const tenantExtra = (v("tenant") && !tenants.data.some(t => t.contact_person === v("tenant")))
    ? `<option value="${esc(v("tenant"))}" selected>${esc(v("tenant"))}</option>` : "";
  // 出租方下拉：添加/续签模式默认选中 is_default=1 的出租人（对齐原版 fillDefaultLandlordInfo）
  const defaultLandlord = (!isEdit) ? (landlords.data.find(l => l.is_default === 1) || null) : null;
  const landlordOptions = landlords.data.map(l => `<option value="${esc(l.landlord_name)}" ${(v("lessor") === l.landlord_name) || (!v("lessor") && defaultLandlord && defaultLandlord.landlord_name === l.landlord_name) ? "selected" : ""}>${esc(l.landlord_name)}</option>`).join("");
  const typeOptions = types.data.map(t => `<option value="${esc(t)}" ${initialHouseType === t ? "selected" : ""}>${esc(t)}</option>`).join("");
  // 保证当前合同/回查的房屋类型在下拉中可见（对齐原版 house_type_edit 只读文本框直接显示合同值：
  // 若合同类型不在房屋资料类型列表中，也应显示，不能显示为空）
  const typeList = (types.data || []).map(String);
  const typeOptionsExtra = (initialHouseType && !typeList.includes(String(initialHouseType)))
    ? `<option value="${esc(initialHouseType)}" selected>${esc(initialHouseType)}</option>` : "";
  // 下拉兜底：值不在标准选项内时显示原值（对齐原版 findText 找不到时保持原值显示）
  const optExtra = (standard, cur) => (cur && !standard.includes(cur)) ? `<option value="${esc(cur)}" selected>${esc(cur)}</option>` : "";
  // 付款方式：对齐原版 ['年','季','月']（Web 旧版曾多出 年付/半年付/一次性，历史值兜底显示）
  const payMethodOptions = ["年", "季", "月"].map(m => `<option value="${m}" ${v("payment_method") === m ? "selected" : ""}>${m}</option>`).join("") +
    optExtra(["年", "季", "月"], v("payment_method"));
  // 用途：对齐原版 ['商用','住宅']，并置空默认值（新增时默认"请选择"，编辑时回显原值）
  const usageOptions = `<option value="" ${v("usage") ? "" : "selected"}>请选择</option>` +
    ["商用", "住宅"].map(m => `<option value="${m}" ${v("usage") === m ? "selected" : ""}>${m}</option>`).join("") +
    optExtra(["商用", "住宅"], v("usage"));
  // 水电费收取方式：对齐原版 ['按标准收取','其它']
  const utilityOptions = ["按标准收取", "其它"].map(m => `<option value="${m}" ${v("utility_method") === m ? "selected" : ""}>${m}</option>`).join("") +
    optExtra(["按标准收取", "其它"], v("utility_method"));
  // 合同期倒推（对齐原版 fillContractData: daysTo//365，1-3 才设置，否则默认1年）
  let periodYears = 1;
  if (data && !isRenewPrefill && v("start_date") && v("end_date")) {
    const days = Math.floor((new Date(v("end_date") + "T00:00:00") - new Date(v("start_date") + "T00:00:00")) / 86400000);
    const y = Math.floor(days / 365);
    if (y >= 1 && y <= 3) periodYears = y;
  }
  const periodOptions = [1, 2, 3].map(p => `<option value="${p}" ${periodYears === p ? "selected" : ""}>${p}年</option>`).join("");
  // 合同状态：续签预填视为新合同，默认"执行中"（对齐原版 handleRenewContract 新窗口默认状态）
  const statusVal = isRenewPrefill ? "" : v("status");

  openModal(contractNo ? `合同详情 - ${esc(contractNo)}` : "添加合同", `
  <div class="form-grid">
    <div class="form-row">
      <div class="form-group"><label class="required bold">签约日期</label>
        <input type="date" id="fSignDate" value="${esc(dateV("sign_date"))}"></div>
      <div class="form-group"><label class="required">合同编号</label>
        <input type="text" id="fContractNo" value="${esc(isRenewPrefill ? "" : v("contract_no"))}" readonly></div>
      <div class="form-group"><label>合同状态</label>
        <select id="fStatus" disabled>
          <option value="执行中" ${statusVal === "执行中" || !statusVal ? "selected" : ""}>执行中</option>
          <option value="已完成" ${statusVal === "已完成" ? "selected" : ""}>已完成</option>
          <option value="已中止" ${statusVal === "已中止" ? "selected" : ""}>已中止</option>
          <option value="已逾期" ${statusVal === "已逾期" ? "selected" : ""}>已逾期</option>
        </select></div>
      <div class="form-group"><label>收款情况</label>
        <div style="display:flex;gap:6px;align-items:center">
          <input type="text" id="fPayStatus" value="${isRenewPrefill ? "未结清" : payLocked ? "已结清" : v("payment_status") || "未结清"}" readonly style="color:#c62828;font-weight:bold;border:1px solid #c62828;text-align:center;flex:1;min-width:0">
          ${isEdit ? '<button type="button" class="btn btn-sm" id="fPayDetailBtn" style="white-space:nowrap;flex-shrink:0">详情</button>' : ""}
        </div></div>
      ${data && !isRenewPrefill && v("status") === "已完成" ? `<div class="form-group"><label>续签状态</label><input type="text" value="${esc(v("is_renewed") || "未续签")}" readonly></div>` : ""}
    </div>
    <div class="form-row">
      <div class="form-group"><label class="required bold">房屋</label>
        <select id="fHouseNo">${houseOptions}</select></div>
      <div class="form-group"><label>房屋类型</label>
        <select id="fHouseType" disabled><option value="">请选择</option>${typeOptionsExtra}${typeOptions}</select></div>
      <div class="form-group"><label>用途</label>
        <select id="fUsage">${usageOptions}</select></div>
      <div class="form-group"><label>房屋面积</label>
        <input type="number" id="fHouseArea" step="0.01" value="${esc(v("house_area"))}"></div>
    </div>
    <div class="form-group full"><label>房屋位置</label>
      <input type="text" id="fHouseLocation" value="${esc(v("house_location"))}"></div>
    <div class="form-row">
      <div class="form-group"><label class="required bold">出租方（甲方）</label>
        <select id="fLessor">${landlordOptions}</select></div>
      <div class="form-group"><label>法定代表人</label>
        <input type="text" id="fLegalRep" value="${esc(v("legal_representative"))}"></div>
      <div class="form-group"><label>分管负责人</label>
        <input type="text" id="fPersonCharge" value="${esc(v("person_in_charge"))}"></div>
      <div class="form-group"><label>联系电话</label>
        <input type="text" id="fContactPhone" value="${esc(v("contact_phone"))}"></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label class="required bold">承租人(乙方)</label>
        <select id="fTenant">${tenantOptions}${tenantExtra}</select></div>
      <div class="form-group"><label class="required">承租方</label>
        <input type="text" id="fLessee" value="${esc(v("lessee"))}"></div>
      <div class="form-group"><label>承租人身份证</label>
        <input type="text" id="fTenantId" value="${esc(v("tenant_id"))}"></div>
      <div class="form-group"><label>承租人电话</label>
        <input type="text" id="fTenantPhone" value="${esc(v("tenant_phone"))}"></div>
    </div>
    <div class="form-group full"><label class="required bold">租赁起止日期</label>
      <div class="date-range">
        <div class="date-field">
          <span class="date-label">开始日期</span>
          <input type="date" id="fStartDate" value="${esc(dateV("start_date"))}">
        </div>
        <div class="date-field">
          <span class="date-label">合同期</span>
          <select id="fContractPeriod">${periodOptions}</select>
        </div>
        <div class="date-field right">
          <span class="date-label">截止日期</span>
          <input type="date" id="fEndDate" value="${esc(dateV("end_date"))}">
        </div>
      </div>
    </div>
    <div class="form-row">
      <div class="form-group"><label class="bold">付款方式</label>
        <select id="fPayMethod">${payMethodOptions}</select></div>
      <div class="form-group"><label class="required">月租金额（元）</label>
        <input type="number" id="fMonthlyRent" step="0.01" min="0" value="${esc(v("monthly_rent"))}"></div>
      <div class="form-group"><label>季度租金（自动）</label>
        <input type="text" id="fQuarterlyRent" readonly></div>
      <div class="form-group"><label>年度租金（自动）</label>
        <input type="text" id="fAnnualRent" readonly></div>
      <div class="form-group"><label>押金（元）</label>
        <input type="number" id="fDeposit" step="0.01" min="0" value="${esc(v("deposit"))}"></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label class="bold">水电费收取方式</label>
        <select id="fUtilityMethod">${utilityOptions}</select></div>
      <div class="form-group"><label>水费标准</label>
        <input type="number" id="fWaterFee" step="0.01" min="0" value="${esc(v("water_fee"))}"></div>
      <div class="form-group"><label>电费标准</label>
        <input type="number" id="fElecFee" step="0.01" min="0" value="${esc(v("electricity_fee"))}"></div>
    </div>
    <div class="form-group full"><label class="bold">备注</label>
      <textarea id="fRemarks">${esc(v("remarks"))}</textarea></div>
    <div class="form-group full"><label class="bold">合同文件</label>
      <div class="attach-box">
        <div class="attach-bar">
          <button type="button" class="btn btn-sm" id="fAttachAdd">+ 上传文件</button>
          <button type="button" class="btn btn-sm" id="fAttachClear">清空</button>
          <span class="attach-tip">支持 PDF / Word / Excel / 图片；双击文件名可打开浏览</span>
        </div>
        <ul class="attach-list" id="fAttachList"></ul>
        <input type="file" id="fAttachInput" multiple hidden
               accept=".pdf,.doc,.docx,.xls,.xlsx,.txt,.jpg,.jpeg,.png,.gif,.bmp,.webp">
      </div></div>
  </div>
  ${payLocked ? '<div class="hint" style="color:#e67e22;margin-top:8px">⚠ 该合同收款情况为「已结清」，字段已锁定，仅可查看（对齐原版 lockAllFields 行为）</div>' : ""}
  <div class="form-actions">
    ${isEdit ? '<label class="check-inline" style="margin-right:auto;color:#e67e22;font-weight:bold"><input type="checkbox" id="fSuspend"' + (statusVal === "已中止" ? " checked" : "") + '> 中止</label>' : ""}
    <button class="btn" id="fCancelBtn" onclick="closeModal()">取消</button>
    <button class="btn btn-primary" id="fSaveBtn" ${payLocked ? "disabled" : ""}>保存</button>
  </div>`, { wide: true });

  if (payLocked) {
    // 对齐原版 lockAllFields：收款已结清的合同编辑时锁定全部表单字段
    $all("input, select, textarea, button", $("#modalBody")).forEach(el => {
      // 中止勾选（fSuspend）、保存按钮、取消按钮与收款情况「详情」按钮保持可操作
      //（取消须始终可点击关闭弹窗；详情为只读查看入口，已结清时也应可查看收款明细）
      if (el.id !== "fSaveBtn" && el.id !== "fSuspend" && el.id !== "fCancelBtn" && el.id !== "fPayDetailBtn") el.disabled = true;
    });
  }

  // 收款情况「详情」按钮：与列表操作列「收款明细」按钮行为完全一致（打开收款明细弹窗）
  const payDetailBtn = $("#fPayDetailBtn");
  if (payDetailBtn) payDetailBtn.addEventListener("click", () => App.showPayments(contractNo));

  /* ------------------------------------------------------------
     合同文件（附件）字段
     存储：contracts.attachment_path 保存 JSON 路径数组（与桌面版格式一致），
     兼容旧版「单个路径字符串」数据；续签预填视为新合同，不沿用原合同附件。
     ------------------------------------------------------------ */
  let attachPaths = [];
  if (!isRenewPrefill && v("attachment_path")) {
    const raw = v("attachment_path");
    try {
      const arr = JSON.parse(raw);
      attachPaths = Array.isArray(arr) ? arr.filter(Boolean).map(String) : [String(raw)];
    } catch (e) {
      attachPaths = [String(raw)];  // 旧版单文件路径
    }
  }
  const attachNameOf = (p) => String(p).replace(/\\/g, "/").split("/").pop() || String(p);
  const renderAttachList = () => {
    const ul = $("#fAttachList");
    if (!ul) return;
    if (!attachPaths.length) {
      ul.innerHTML = '<li class="attach-empty">暂无文件，点击「+ 上传文件」添加</li>';
      return;
    }
    ul.innerHTML = attachPaths.map((p, i) => `<li class="attach-item" data-idx="${i}">
        <span class="attach-name" title="双击打开：${esc(p)}">${esc(attachNameOf(p))}</span>
        <button type="button" class="attach-del" data-del="${i}" title="从列表移除（保存后生效）">×</button>
      </li>`).join("");
    $all(".attach-name", ul).forEach(el => {
      el.addEventListener("dblclick", () => {
        App.openContractAttachment(attachPaths[Number(el.closest("li").dataset.idx)]);
      });
    });
    $all("button[data-del]", ul).forEach(btn => {
      btn.addEventListener("click", () => {
        attachPaths.splice(Number(btn.dataset.del), 1);
        renderAttachList();
      });
    });
  };
  renderAttachList();

  const attachInput = $("#fAttachInput");
  const attachAddBtn = $("#fAttachAdd");
  if (attachAddBtn) attachAddBtn.addEventListener("click", () => attachInput.click());
  const attachClearBtn = $("#fAttachClear");
  if (attachClearBtn) {
    attachClearBtn.addEventListener("click", () => {
      if (!attachPaths.length) return toast("当前没有已上传的合同文件", "error");
      if (!confirmDlg("确定清空合同文件列表吗？（保存合同后生效，磁盘上的源文件不会被删除）")) return;
      attachPaths = [];
      renderAttachList();
    });
  }
  if (attachInput) {
    attachInput.addEventListener("change", async () => {
      const files = Array.from(attachInput.files || []);
      if (!files.length) return;
      setLoading(attachAddBtn, true);
      try {
        for (const f of files) {
          const fd = new FormData();
          fd.append("file", f);
          const no = ($("#fContractNo").value || "").trim();
          const r = await API.request("POST",
            `/api/contracts/attachment/upload?contract_no=${encodeURIComponent(no)}`, fd, true);
          if (r && r.path && attachPaths.indexOf(r.path) < 0) attachPaths.push(r.path);
        }
        renderAttachList();
        toast("合同文件上传成功", "success");
      } catch (e) { toast(e.message, "error"); }
      finally { setLoading(attachAddBtn, false); attachInput.value = ""; }
    });
  }

  // 房屋编号/房屋类型联动（对齐原版 onHouseInfoChanged + fillUtilityFeesByHouseType）
  const fillHouseTypeByNo = () => {
    const no = $("#fHouseNo").value.trim();
    if (!no) return;
    const h = houses.data.find(x => x.house_no === no);
    if (h) {
      if (h.house_type) $("#fHouseType").value = h.house_type;
      if (h.house_location) $("#fHouseLocation").value = h.house_location;
      if (h.house_area !== null && h.house_area !== undefined && h.house_area !== "") $("#fHouseArea").value = h.house_area;
      fillUtilityByType();
    }
  };
  const fillUtilityByType = () => {
    const t = $("#fHouseType").value.trim();
    if (!t) return;
    const u = utilityFees.data.find(x => x.house_type === t);
    if (u) {
      $("#fWaterFee").value = u.water_fee;
      $("#fElecFee").value = u.electricity_fee;
    }
  };
  $("#fHouseNo").addEventListener("change", fillHouseTypeByNo);
  // 注：房屋类型只读（disabled，对齐原版 house_type_edit 只读），类型变更只能通过重选房屋触发；
  // 编辑模式加载时不自动填充水电费标准，直接使用合同记录值（对齐原版 fillContractData 注释行为）

  // 出租方联动：切换出租人后自动填充法定代表人/分管负责人/联系电话（对齐原版 select_landlord 双击填充）
  const fillLandlordInfo = (force) => {
    const name = $("#fLessor").value;
    const l = landlords.data.find(x => x.landlord_name === name);
    if (!l) return;
    if (force || !$("#fLegalRep").value.trim()) $("#fLegalRep").value = l.legal_representative || "";
    if (force || !$("#fPersonCharge").value.trim()) $("#fPersonCharge").value = l.person_in_charge || "";
    if (force || !$("#fContactPhone").value.trim()) $("#fContactPhone").value = l.contact_phone || "";
  };
  $("#fLessor").addEventListener("change", () => fillLandlordInfo(true));

  // 承租方联动：选择承租人记录后自动填充乙方名称/身份证/电话（对齐原版 select_tenant 双击填充）
  const fillTenantInfo = () => {
    const cp = $("#fTenant").value;
    if (!cp) return;
    const t = tenants.data.find(x => x.contact_person === cp);
    if (!t) return;
    $("#fLessee").value = t.tenant_name;
    $("#fTenantId").value = t.contact_id || "";
    $("#fTenantPhone").value = t.contact_phone || "";
  };
  $("#fTenant").addEventListener("change", fillTenantInfo);

  // 合同期联动：开始日期/合同期变化 → 自动计算截止日期（开始 + N年 - 1天；对齐原版 updateEndDate）
  const fmtDate = (d) => {
    const p = (n) => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
  };
  const updateEndDate = () => {
    const s = $("#fStartDate").value;
    const years = parseInt($("#fContractPeriod").value, 10) || 1;
    if (!s) return;
    const d = new Date(s + "T00:00:00");
    d.setFullYear(d.getFullYear() + years);
    d.setDate(d.getDate() - 1);
    $("#fEndDate").value = fmtDate(d);
  };
  $("#fStartDate").addEventListener("change", updateEndDate);
  $("#fContractPeriod").addEventListener("change", updateEndDate);

  // 季度/年度租金自动计算（对齐原版 calculateRents：round(月租×3)、round(月租×12)）
  const calcRents = () => {
    const m = parseFloat($("#fMonthlyRent").value) || 0;
    $("#fQuarterlyRent").value = String(Math.round(m * 3));
    $("#fAnnualRent").value = String(Math.round(m * 12));
  };
  $("#fMonthlyRent").addEventListener("input", calcRents);
  calcRents();

  // 添加/续签预填模式：默认日期（签约=今天、开始=今天、截止=今天+1年-1天；对齐原版构造默认值）
  if (!data || isRenewPrefill) {
    const today = new Date();
    $("#fSignDate").value = fmtDate(today);
    $("#fStartDate").value = fmtDate(today);
    updateEndDate();
  }

  // 添加/续签预填模式：自动填充默认出租人信息（对齐原版 fillDefaultLandlordInfo：仅填空项，保留已有值）
  if (defaultLandlord && !data) fillLandlordInfo(false);

  // 合同编号自动生成（对齐原版 generateContractNo：添加/续签预填自动生成新号且只读）
  if (!isEdit) {
    API.get("/api/contracts/next-no").then(r => {
      const el = $("#fContractNo");
      if (el && !el.value) el.value = (r && r.data) || "";
    }).catch(() => {});
  }

  // 中止勾选：勾选后合同状态自动置为"已中止"，并解锁截止日期/保存按钮/备注（允许对已结清/锁定合同执行中止并补充备注）
  const suspendEl = $("#fSuspend");
  if (suspendEl) {
    suspendEl.addEventListener("change", () => {
      const statusSel = $("#fStatus");
      const endDateEl = $("#fEndDate");
      const saveBtn = $("#fSaveBtn");
      const remarksEl = $("#fRemarks");
      if (suspendEl.checked) {
        statusSel.value = "已中止";
        endDateEl.disabled = false;
        saveBtn.disabled = false;
        if (remarksEl) remarksEl.disabled = false;   // 勾选中止后备注恢复可编辑
      } else {
        statusSel.value = statusVal;
        if (payLocked) {
          endDateEl.disabled = true;
          saveBtn.disabled = true;
          if (remarksEl) remarksEl.disabled = true;  // 取消中止且已结清时备注恢复锁定
        }
      }
    });
  }

  $("#fSaveBtn").addEventListener("click", async () => {
    // 收款状态以表单字段 #fPayStatus 为准（该字段只读、恒有值）：
    // 新增/续签预填默认"未结清"，已结清锁定显示"已结清"；
    // 修复点：续签预填时不能取 v("payment_status")（那是原合同的旧状态，原合同已结清会被误存成已结清）
    const payStatusRaw = $("#fPayStatus") ? $("#fPayStatus").value : "";
    const formPayStatus = ["已结清", "部分收款", "未结清"].includes(payStatusRaw) ? payStatusRaw : "未结清";
    const d = {
      contract_no: $("#fContractNo").value.trim(),
      sign_date: $("#fSignDate").value,
      house_no: $("#fHouseNo").value,
      house_type: $("#fHouseType").value,
      house_location: $("#fHouseLocation").value.trim(),
      house_area: parseFloat($("#fHouseArea").value) || 0,
      lessor: $("#fLessor").value,
      legal_representative: $("#fLegalRep").value.trim(),
      person_in_charge: $("#fPersonCharge").value.trim(),
      contact_phone: $("#fContactPhone").value.trim(),
      lessee: $("#fLessee").value.trim(),
      tenant: $("#fTenant").value,
      tenant_id: $("#fTenantId").value.trim(),
      tenant_phone: $("#fTenantPhone").value.trim(),
      start_date: $("#fStartDate").value,
      end_date: $("#fEndDate").value,
      status: $("#fStatus").value,
      payment_method: $("#fPayMethod").value,
      monthly_rent: parseFloat($("#fMonthlyRent").value) || 0,
      quarterly_rent: Math.round((parseFloat($("#fMonthlyRent").value) || 0) * 3),
      deposit: parseFloat($("#fDeposit").value) || 0,
      usage: $("#fUsage").value.trim(),
      utility_method: $("#fUtilityMethod").value.trim(),
      water_fee: parseFloat($("#fWaterFee").value) || null,
      electricity_fee: parseFloat($("#fElecFee").value) || null,
      remarks: $("#fRemarks").value,
      // 合同文件：JSON 路径数组（无附件时存空数组字符串，保持与桌面版一致的存储格式）
      attachment_path: JSON.stringify(attachPaths),
      payment_status: formPayStatus,
      // 续签预填：记录来源合同编号；后端删除本合同时据此复位原合同的「续签状态」为未续签
      renewed_from: (isRenewPrefill && data && data.contract_no) ? data.contract_no : null,
    };
    if (!d.contract_no) return toast("合同编号不能为空", "error");
    if (!d.sign_date) return toast("签约日期不能为空", "error");
    if (!d.start_date || !d.end_date) return toast("租赁起止日期不能为空", "error");
    if (!d.lessee) return toast("承租方不能为空", "error");
    // 对齐原版 accept：开始日期不能晚于截止日期
    if (d.start_date > d.end_date) return toast("租赁开始日期不能晚于租赁截止日期", "error");
    const btn = $("#fSaveBtn");
    setLoading(btn, true);
    try {
      const r = contractNo
        ? await API.put(`/api/contracts/${encodeURIComponent(contractNo)}`, { data: d })
        : await API.post("/api/contracts", { data: d });
      toast(r.message, "success");
      window.dispatchEvent(new CustomEvent("lease-data-updated"));
      closeModal();
      // 仅合同管理页打开时重载合同列表；从租金调整页双击打开的编辑窗口保存后不重载（sel 非合同页对象）
      if (App.page === "contracts" && sel) App.loadContracts(sel);
    } catch (e) { toast(e.message, "error"); }
    finally { setLoading(btn, false); }
  });
};

/* 续签（对齐原版 ui_contract_tab.handleRenewContract）：
   1) 更新旧合同状态为已完成、标记已续签
   2) 自动打开新合同窗口并预填原合同数据（房屋/承租/租金等信息） */
App.renewContract = async function (sel, contractNo) {
  if (!confirmDlg(`确定将合同 ${contractNo} 标记为已完成并续签吗？\n（原合同将标记为"已续签"，随后自动打开新合同窗口）`)) return;
  try {
    const r = await API.post(`/api/contracts/${encodeURIComponent(contractNo)}/renew`);
    toast(r.message, "success");
    window.dispatchEvent(new CustomEvent("lease-data-updated"));
    // 加载原合同数据 → 预填新合同表单
    try {
      const old = await API.get(`/api/contracts/${encodeURIComponent(contractNo)}`);
      await App.showContractForm(sel, null, old);
    } catch (e2) {
      App.loadContracts(sel);
    }
  } catch (e) { toast(e.message, "error"); }
};

/* 打开合同附件（双击文件名触发）：
   图片 / PDF / 文本 → 浏览器新标签页直接预览；
   Word / Excel 等浏览器无法渲染的类型 → 自动下载到本机，并用本地软件打开 */
App.openContractAttachment = async function (path) {
  if (!path) return;
  try {
    const headers = {};
    if (API.token) headers["Authorization"] = "Bearer " + API.token;
    const resp = await fetch(`/api/contracts/attachment/file?path=${encodeURIComponent(path)}`, { headers, cache: "no-store" });
    if (resp.status === 401) { location.href = "/"; throw new Error("登录已过期，请重新登录"); }
    if (!resp.ok) {
      const d = await resp.json().catch(() => null);
      throw new Error((d && d.detail) || "打开文件失败");
    }
    const blob = await resp.blob();
    const url = URL.createObjectURL(blob);
    const ct = (blob.type || "").toLowerCase();
    const name = String(path).replace(/\\/g, "/").split("/").pop() || "合同文件";
    const previewable = ct.startsWith("image/") || ct.indexOf("pdf") >= 0 || ct.startsWith("text/");
    if (previewable) {
      const w = window.open(url, "_blank");
      if (!w) {
        const a = document.createElement("a");
        a.href = url; a.target = "_blank"; a.rel = "noopener";
        document.body.appendChild(a); a.click(); a.remove();
      }
      setTimeout(() => URL.revokeObjectURL(url), 300000);
    } else {
      const a = document.createElement("a");
      a.href = url; a.download = name;
      document.body.appendChild(a); a.click();
      setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 1000);
      toast("该类型文件浏览器无法直接预览，已下载到本机，请用 Word/Excel 打开", "success");
    }
  } catch (e) { toast(e.message, "error"); }
};

/* 收款明细 */
App.showPayments = async function (contractNo) {
  try {
    const r = await API.get(`/api/contracts/${encodeURIComponent(contractNo)}/payments`);
    const list = r.data || [];
    openModal(`合同 ${esc(contractNo)} 收款明细`, `
      <div class="table-wrap">
        <table class="data-table">
          <thead><tr><th>收款日期</th><th>金额</th><th>所属期间</th><th>收款方式</th><th>收款状态</th><th>备注</th></tr></thead>
          <tbody>${list.length ? list.map(x => `<tr>
            <td>${esc(x.receipt_date)}</td><td class="num">${fmtMoney(x.amount)}</td>
            <td>${esc(x.period_start)} ~ ${esc(x.period_end)}</td>
            <td>${esc(x.payment_method)}</td><td>${statusTag(x.payment_status)}</td>
            <td>${esc(x.description)}</td></tr>`).join("")
            : '<tr><td colspan="6" style="text-align:center;color:#999">暂无收款记录</td></tr>'}</tbody>
        </table>
      </div>
      <div class="form-actions"><button class="btn" onclick="closeModal()">关闭</button></div>`, { wide: true });
  } catch (e) { toast(e.message, "error"); }
};

/* 删除合同 */
App.deleteContract = async function (sel, contractNo) {
  if (!confirmDlg(`确定要删除合同编号为 ${contractNo} 的合同吗？删除后将无法恢复！`)) return;
  try {
    const r = await API.del(`/api/contracts/${encodeURIComponent(contractNo)}`);
    toast(r.message, "success");
    window.dispatchEvent(new CustomEvent("lease-data-updated"));
    App.loadContracts(sel);
  } catch (e) { toast(e.message, "error"); }
};

/* 导入合同 */
App.importContracts = function (sel) {
  const input = document.createElement("input");
  input.type = "file";
  input.accept = ".xlsx";
  input.addEventListener("change", async () => {
    if (!input.files.length) return;
    const fd = new FormData();
    fd.append("file", input.files[0]);
    const btn = $("#cImport");
    setLoading(btn, true);
    try {
      const r = await API.request("POST", "/api/contracts/import", fd, true);
      toast(r.message, "success");
      window.dispatchEvent(new CustomEvent("lease-data-updated"));
      App.loadContracts(sel);
    } catch (e) { toast(e.message, "error"); }
    finally { setLoading(btn, false); }
  });
  input.click();
};
