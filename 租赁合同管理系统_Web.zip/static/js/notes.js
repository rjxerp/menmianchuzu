/* ============================================================
   笔记 + 关于模块
   ============================================================ */
"use strict";

/* ---------------- 笔记 ---------------- */
App.renderNotes = function (content) {
  content.innerHTML = `
  <div class="panel">
    <div class="toolbar">
      <button class="btn btn-primary" id="nNew">+ 新建笔记</button>
      <button class="btn" id="nRename">重命名</button>
      <button class="btn" id="nExport">导出笔记</button>
      <button class="btn btn-danger" id="nDelete">删除笔记</button>
    </div>
    <div class="notes-layout">
      <div class="notes-list" id="nList"></div>
      <div class="note-editor">
        <input type="text" id="nName" placeholder="笔记名称" style="margin-bottom:8px;font-size:15px;font-weight:600">
        <textarea id="nContent" placeholder="在此输入笔记内容..."></textarea>
        <div class="form-actions">
          <button class="btn btn-primary" id="nSave">保存笔记</button>
          <span class="hint" id="nStatus" style="color:#999;font-size:12px;align-self:center"></span>
        </div>
      </div>
    </div>
  </div>`;

  let currentId = null;
  let notes = [];

  const loadList = async () => {
    try {
      const r = await API.get("/api/notes");
      notes = r.data || [];
      const listEl = $("#nList");
      if (!notes.length) {
        listEl.innerHTML = '<p style="color:#999;font-size:13px;padding:8px">暂无笔记</p>';
        $("#nName").value = ""; $("#nContent").value = ""; currentId = null;
      } else {
        listEl.innerHTML = notes.map(n => `<div class="note-item ${n.id === currentId ? "active" : ""}" data-id="${esc(n.id)}">${esc(n.note_name)}</div>`).join("");
        $all(".note-item", listEl).forEach(el => el.addEventListener("click", () => {
          currentId = Number(el.dataset.id);
          $all(".note-item", listEl).forEach(x => x.classList.toggle("active", x === el));
          const n = notes.find(x => x.id === currentId);
          if (n) { $("#nName").value = n.note_name; $("#nContent").value = n.content; }
        }));
      }
    } catch (e) { toast(e.message, "error"); }
  };

  const save = async () => {
    const name = $("#nName").value.trim();
    const content = $("#nContent").value;
    if (!name) return toast("笔记名称不能为空", "error");
    const btn = $("#nSave");
    setLoading(btn, true);
    try {
      const r = await API.post("/api/notes", { note_id: currentId, note_name: name, content });
      toast(r.message, "success");
      window.dispatchEvent(new CustomEvent("lease-data-updated"));
      currentId = r.id || currentId;
      $("#nStatus").textContent = "已保存 " + new Date().toLocaleTimeString();
      await loadList();
    } catch (e) { toast(e.message, "error"); }
    finally { setLoading(btn, false); }
  };

  $("#nNew").addEventListener("click", () => {
    currentId = null;
    $("#nName").value = "";
    $("#nContent").value = "";
    $("#nStatus").textContent = "";
    $("#nName").focus();
    $all(".note-item").forEach(x => x.classList.remove("active"));
  });
  $("#nSave").addEventListener("click", save);
  $("#nDelete").addEventListener("click", async () => {
    if (!currentId) return toast("请先选择要删除的笔记", "error");
    if (!confirmDlg("确定删除这条笔记吗？")) return;
    try {
      const r = await API.del(`/api/notes/${currentId}`);
      toast(r.message, "success");
      window.dispatchEvent(new CustomEvent("lease-data-updated"));
      currentId = null;
      $("#nName").value = ""; $("#nContent").value = "";
      await loadList();
    } catch (e) { toast(e.message, "error"); }
  });
  $("#nRename").addEventListener("click", () => { if (currentId) $("#nName").focus(); else toast("请先选择笔记", "error"); });
  // 导出笔记为 txt（对齐原版 notepad_tab.export_note）
  $("#nExport").addEventListener("click", () => {
    const name = $("#nName").value.trim();
    const content = $("#nContent").value;
    if (!name) return toast("请先选择或命名笔记", "error");
    const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = name + ".txt";
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 300);
    toast("笔记已导出", "success");
  });

  loadList();
};

/* ---------------- 关于 ---------------- */
App.renderAbout = function (content) {
  content.innerHTML = `
  <div class="panel" style="max-width:560px;margin:0 auto;text-align:center;padding:40px 24px">
    <img class="login-logo" src="/static/logo.png" alt="综合贸易 Logo" style="margin:0 auto 16px;width:64px">
    <h2 style="color:var(--primary);margin-bottom:6px" id="aboutName">门面租赁管理系统</h2>
    <p style="color:var(--gray);margin-bottom:6px" id="aboutBrand">综合贸易</p>
    <p style="font-size:15px;margin-bottom:20px" id="aboutVersion">版本: -</p>
    <div class="info-list" style="align-items:center">
      <div class="info-item"><span class="k">开发时间</span><span class="v" id="aboutDevTime">-</span></div>
      <div class="info-item"><span class="k">当前用户</span><span class="v">${esc(App.user.username)}（${esc(App.user.role)}）</span></div>
      <div class="info-item"><span class="k">数据库</span><span class="v" id="aboutDb">-</span></div>
    </div>
    <p style="color:#999;font-size:12px;margin-top:24px">邵阳市综合贸易总公司 · 商业房产（门面）租赁管理</p>
    <div style="margin-top:16px">
      <a class="btn" href="/static/操作手册_Web版.html" target="_blank" rel="noopener">打开帮助手册</a>
    </div>
  </div>`;
  API.get("/api/system/info").then(info => {
    $("#aboutName").textContent = info.software_name || "门面租赁管理系统";
    $("#aboutBrand").textContent = info.brand || "综合贸易";
    $("#aboutVersion").textContent = "版本: " + (info.version || "-");
    $("#aboutDevTime").textContent = info.dev_time || "-";
    $("#aboutDb").textContent = info.database_path || "-";
  }).catch(() => {});
};

/* ============================================================
   启动（统一入口：见 app.js 末尾 DOMContentLoaded）
   ============================================================ */
