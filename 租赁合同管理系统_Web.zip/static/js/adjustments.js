/* ============================================================
   租金调整模块
   合同期内租金调整：发起申请 → 审批（通过/驳回）→ 落地
   状态：待审批 / 已通过 / 已驳回 / 已作废
   ============================================================ */
"use strict";

/* 本地状态标签（复用全局 tag 样式，覆盖调整状态） */
function adjustStatusTag(status) {
  const map = {
    "待审批": "tag-orange", "已通过": "tag-green",
    "已驳回": "tag-red", "已作废": "tag-gray",
  };
  return `<span class="tag ${map[status] || "tag-gray"}">${esc(status)}</span>`;
}

/* 调整类型标签：上调=红，下调=绿 */
function adjustTypeTag(t) {
  if (t === "上调") return `<span style="color:#e74c3c;font-weight:bold">上调</span>`;
  if (t === "下调") return `<span style="color:#27ae60;font-weight:bold">下调</span>`;
  return esc(t || "");
}

/* 幅度显示：带符号 + 颜色 */
function adjustRatioHtml(ratio) {
  const n = Number(ratio);
  if (isNaN(n)) return "";
  const color = n > 0 ? "#e74c3c" : (n < 0 ? "#27ae60" : "#666");
  const sign = n > 0 ? "+" : "";
  return `<span style="color:${color};font-weight:bold">${sign}${n.toFixed(2)}%</span>`;
}

App.renderAdjustments = function (content) {
  const isAdmin = App.user && App.user.role === "管理员";
  content.innerHTML = `
  <div class="panel">
    <div class="toolbar">
      <input type="search" id="aSearch" placeholder="搜索合同编号/调整单号/承租方/房屋" style="width:260px">
      <label class="check-inline"><input type="checkbox" id="aSt1" value="待审批" checked> 待审批</label>
      <label class="check-inline"><input type="checkbox" id="aSt2" value="已通过" checked> 已通过</label>
      <label class="check-inline"><input type="checkbox" id="aSt3" value="已驳回" checked> 已驳回</label>
      <label class="check-inline"><input type="checkbox" id="aSt4" value="已作废" checked> 已作废</label>
      <span class="spacer"></span>
      <button class="btn" id="aReset">重置</button>
      <button class="btn" id="aSearchBtn">搜索</button>
      <button class="btn btn-primary" id="aAdd">+ 发起租金调整</button>
    </div>
    <div class="table-wrap" style="max-height:72vh;overflow-y:auto">
      <table class="data-table" id="adjustTable">
        <thead><tr>
          <th>调整单号</th>
          <th>合同编号</th>
          <th>承租方</th>
          <th>房屋</th>
          <th>类型</th>
          <th class="num">原月租</th>
          <th class="num">新月租</th>
          <th>幅度</th>
          <th>生效日期</th>
          <th>原因</th>
          <th>状态</th>
          <th>申请人</th>
          <th>审批人</th>
          <th>申请时间</th>
          <th>操作</th>
        </tr></thead>
        <tbody id="adjustTbody"><tr><td colspan="15" style="text-align:center;color:#999">加载中...</td></tr></tbody>
      </table>
    </div>
    <div id="adjustStats" style="margin-top:10px;font-size:12px;color:#666"></div>
  </div>`;
  const sel = {
    search: $("#aSearch"), st1: $("#aSt1"), st2: $("#aSt2"), st3: $("#aSt3"), st4: $("#aSt4"),
    btn: $("#aSearchBtn"), reset: $("#aReset"), add: $("#aAdd"),
    tbody: $("#adjustTbody"), stats: $("#adjustStats"),
  };
  sel.btn.addEventListener("click", () => App.loadAdjustments(sel));
  sel.reset.addEventListener("click", () => {
    sel.search.value = ""; sel.st1.checked = sel.st2.checked = sel.st3.checked = sel.st4.checked = true;
    App.loadAdjustments(sel);
  });
  sel.search.addEventListener("keydown", e => { if (e.key === "Enter") App.loadAdjustments(sel); });
  sel.add.addEventListener("click", () => App.showAdjustForm(sel));
  App.loadAdjustments(sel);
};

App.checkedAdjustStatuses = function (sel) {
  return [sel.st1, sel.st2, sel.st3, sel.st4].filter(c => c.checked).map(c => c.value).join(",");
};

App.loadAdjustments = async function (sel) {
  sel.tbody.innerHTML = '<tr><td colspan="15" style="text-align:center;color:#999">加载中...</td></tr>';
  try {
    const sts = App.checkedAdjustStatuses(sel);
    const search = sel.search.value.trim();
    const r = await API.get(`/api/rent-adjustments?statuses=${encodeURIComponent(sts)}&search=${encodeURIComponent(search)}`);
    const list = r.items || [];
    const s = r.statistics || {};
    sel.stats.innerHTML = `调整总数: <b>${esc(s.total || 0)}</b>&nbsp;|&nbsp;
      待审批: <b style="color:#e67e22">${s.pending || 0}</b>&nbsp;|&nbsp;
      已通过: <b style="color:#27ae60">${s.approved || 0}</b>&nbsp;|&nbsp;
      已驳回: <b style="color:#e74c3c">${s.rejected || 0}</b>&nbsp;|&nbsp;
      已作废: <b style="color:#999">${s.cancelled || 0}</b>`;
    if (!list.length) {
      sel.tbody.innerHTML = '<tr><td colspan="15" style="text-align:center;color:#999">暂无调整记录</td></tr>';
      return;
    }
    const isAdmin = App.user && App.user.role === "管理员";
    sel.tbody.innerHTML = list.map(x => {
      const ops = [];
      if (x.status === "待审批") {
        if (isAdmin) {
          ops.push(`<button class="btn btn-sm btn-primary" data-act="approve">通过</button>`);
          ops.push(`<button class="btn btn-sm btn-danger" data-act="reject">驳回</button>`);
        }
        ops.push(`<button class="btn btn-sm" data-act="cancel">作废</button>`);
      } else if (x.status === "已驳回" && x.reject_reason) {
        ops.push(`<span title="${esc(x.reject_reason)}" style="color:#e74c3c;font-size:12px">驳回:${esc(x.reject_reason)}</span>`);
      }
      // 删除明细记录（仅管理员；已通过记录删除后级联重建分段并重算租金）
      if (isAdmin) {
        ops.push(`<button class="btn btn-sm btn-danger" data-act="del" title="删除该记录；已通过记录将级联重建分段并重算租金">删除</button>`);
      }
      return `<tr data-id="${x.id}" data-contract-no="${esc(x.contract_no)}" title="双击查看/编辑该合同" style="cursor:pointer">
        <td>${esc(x.adjust_no)}</td>
        <td>${esc(x.contract_no)}</td>
        <td>${esc(x.lessee || "")}</td>
        <td>${esc(x.house_no || "")}</td>
        <td>${adjustTypeTag(x.adjust_type)}</td>
        <td class="num">${fmtMoney(x.old_monthly_rent)}</td>
        <td class="num">${fmtMoney(x.new_monthly_rent)}</td>
        <td>${adjustRatioHtml(x.adjust_ratio)}</td>
        <td>${esc(x.effective_date)}</td>
        <td title="${esc(x.reason || "")}" style="max-width:120px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(x.reason || "")}</td>
        <td>${adjustStatusTag(x.status)}</td>
        <td>${esc(x.applicant || "")}</td>
        <td>${esc(x.approver || "")}</td>
        <td>${esc((x.apply_time || "").slice(0, 16))}</td>
        <td><div class="row-actions">${ops.join("")}</div></td>
      </tr>`;
    }).join("");
    $all("tr[data-id]", sel.tbody).forEach(tr => {
      const id = Number(tr.dataset.id);
      $all("button", tr).forEach(btn => {
        btn.addEventListener("click", () => {
          const act = btn.dataset.act;
          if (act === "approve") App.approveAdjustment(sel, id, "approve");
          else if (act === "reject") App.approveAdjustment(sel, id, "reject");
          else if (act === "cancel") App.cancelAdjustment(sel, id);
          else if (act === "del") App.deleteAdjustment(sel, id);
        });
      });
      // 双击整行 → 按该记录“合同编号”打开“编辑合同”窗口（双击操作按钮除外）
      tr.addEventListener("dblclick", (e) => {
        if (e.target.closest("button")) return;
        const no = tr.dataset.contractNo;
        if (no) App.showContractForm(sel, no);
      });
    });
  } catch (e) {
    sel.tbody.innerHTML = `<tr><td colspan="15" style="text-align:center;color:#e74c3c">${esc(e.message)}</td></tr>`;
  }
};

/* 发起租金调整申请 */
App.showAdjustForm = async function (sel) {
  let contracts = [];
  try { contracts = (await API.get("/api/contracts")).data || []; } catch (e) {}
  const adjustables = contracts.filter(c => c.status === "执行中" || c.status === "已逾期");
  if (!adjustables.length) {
    toast("暂无可调整的合同（仅执行中/已逾期）", "error");
    return;
  }
  const contractOptions = adjustables.map(c =>
    `<option value="${esc(c.contract_no)}">${esc(c.contract_no)} - ${esc(c.lessee)}（月租 ${fmtMoney(c.monthly_rent)}）</option>`
  ).join("");

  // 默认生效日期：下个月 1 号
  const d = new Date();
  const nextMonth = new Date(d.getFullYear(), d.getMonth() + 1, 1);
  const defEff = nextMonth.getFullYear() + "-" + String(nextMonth.getMonth() + 1).padStart(2, "0") + "-01";

  openModal("发起租金调整", `
  <div class="form-grid">
    <div class="form-row">
      <div class="form-group full"><label class="required">合同</label>
        <select id="aContractNo">${contractOptions}</select></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>当前月租（元）</label>
        <input type="text" id="aOldRent" readonly></div>
      <div class="form-group"><label>起租日</label>
        <input type="text" id="aStartDate" readonly></div>
      <div class="form-group"><label>到期日</label>
        <input type="text" id="aEndDate" readonly></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label class="required">调整后月租（元）</label>
        <input type="number" id="aNewRent" step="0.01" min="0" max="999999.99" placeholder="输入新租金"></div>
      <div class="form-group"><label>调整幅度（自动）</label>
        <input type="text" id="aRatio" readonly></div>
      <div class="form-group"><label class="required">生效日期</label>
        <input type="date" id="aEffective" value="${defEff}"></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>调整原因</label>
        <input type="text" id="aReason" placeholder="如：市场行情变化、双方协商一致"></div>
      <div class="form-group"><label>条款依据</label>
        <input type="text" id="aClauseBasis" placeholder="如：补充协议 / 合同第X条"></div>
    </div>
    <div class="form-group full" style="font-size:12px;color:#999;line-height:1.6">
      说明：① 生效日期将自动对齐到该合同<b>起租日对应的「日」</b>（如起租日为 5 号，生效日期按某月 5 号计），保证租金按整月分段精确计算；
      ② 仅「执行中 / 已逾期」合同可调整；③ 单次调整幅度超过 ±30% 仅提示、不限制（系统自动给出提示）；两次调整间隔默认不少于 12 个月。
    </div>
  </div>
  <div class="form-actions">
    <button class="btn" onclick="closeModal()">取消</button>
    <button class="btn btn-primary" id="aSaveBtn">提交申请</button>
  </div>`, { wide: true });

  const $n = (id) => $("#" + id);
  let curContract = adjustables[0];

  const refreshContract = () => {
    curContract = adjustables.find(c => c.contract_no === $n("aContractNo").value) || null;
    if (curContract) {
      $n("aOldRent").value = curContract.monthly_rent !== null && curContract.monthly_rent !== undefined
        ? Number(curContract.monthly_rent).toFixed(2) : "";
      $n("aStartDate").value = curContract.start_date || "";
      $n("aEndDate").value = curContract.end_date || "";
    } else {
      $n("aOldRent").value = ""; $n("aStartDate").value = ""; $n("aEndDate").value = "";
    }
    calcRatio();
  };
  const calcRatio = () => {
    const oldR = parseFloat($n("aOldRent").value) || 0;
    const newR = parseFloat($n("aNewRent").value) || 0;
    if (oldR > 0 && newR > 0) {
      const ratio = (newR - oldR) / oldR * 100;
      $n("aRatio").value = (ratio > 0 ? "+" : "") + ratio.toFixed(2) + "%";
    } else {
      $n("aRatio").value = "";
    }
  };
  $n("aContractNo").addEventListener("change", refreshContract);
  $n("aNewRent").addEventListener("input", calcRatio);
  refreshContract();

  $n("aSaveBtn").addEventListener("click", async () => {
    const d = {
      contract_no: $n("aContractNo").value,
      new_monthly_rent: parseFloat($n("aNewRent").value) || 0,
      effective_date: $n("aEffective").value,
      reason: $n("aReason").value.trim(),
      clause_basis: $n("aClauseBasis").value.trim(),
    };
    if (!d.contract_no) return toast("请选择合同", "error");
    if (d.new_monthly_rent <= 0) return toast("调整后月租必须大于 0", "error");
    if (!d.effective_date) return toast("生效日期不能为空", "error");
    // 幅度超 ±30%：仅提示，不限制
    const oldR = parseFloat($n("aOldRent").value) || 0;
    if (oldR > 0) {
      const r = (d.new_monthly_rent - oldR) / oldR * 100;
      if (Math.abs(r) > 30) {
        if (!confirmDlg(`调整幅度 ${r > 0 ? "+" : ""}${r.toFixed(2)}% 超过 ±30%，系统仅提示不限制，确定继续提交？`)) return;
      }
    }
    const btn = $n("aSaveBtn");
    setLoading(btn, true);
    try {
      const r = await API.post("/api/rent-adjustments", { data: d });
      toast(r.message, "success");
      closeModal();
      window.dispatchEvent(new CustomEvent("lease-data-updated"));
      App.loadAdjustments(sel);
    } catch (e) { toast(e.message, "error"); }
    finally { setLoading(btn, false); }
  });
};

/* 审批：通过 / 驳回 */
App.approveAdjustment = async function (sel, id, action) {
  let rejectReason = "";
  if (action === "reject") {
    rejectReason = window.prompt("请输入驳回原因：");
    if (rejectReason === null) return;
    if (!rejectReason.trim()) return toast("驳回须填写原因", "error");
  } else if (action === "approve") {
    if (!confirmDlg("确认通过该租金调整申请？通过后将立即更新合同租金并拆分租金分段。")) return;
  }
  try {
    const r = await API.post(`/api/rent-adjustments/${id}/approve`,
      { action, reject_reason: rejectReason.trim() });
    toast(r.message, "success");
    window.dispatchEvent(new CustomEvent("lease-data-updated"));
    App.loadAdjustments(sel);
  } catch (e) { toast(e.message, "error"); }
};

/* 作废申请 */
App.cancelAdjustment = async function (sel, id) {
  if (!confirmDlg("确定作废该调整申请吗？")) return;
  try {
    const r = await API.post(`/api/rent-adjustments/${id}/cancel`);
    toast(r.message, "success");
    window.dispatchEvent(new CustomEvent("lease-data-updated"));
    App.loadAdjustments(sel);
  } catch (e) { toast(e.message, "error"); }
};

/* 删除明细记录（仅管理员） */
App.deleteAdjustment = async function (sel, id) {
  if (!confirmDlg("确定删除该租金调整记录吗？\n若为「已通过」记录，删除后将自动重建该合同租金分段并重算租金、同步收款状态。")) return;
  try {
    const r = await API.del(`/api/rent-adjustments/${id}`);
    toast(r.message, "success");
    window.dispatchEvent(new CustomEvent("lease-data-updated"));
    App.loadAdjustments(sel);
  } catch (e) { toast(e.message, "error"); }
};
