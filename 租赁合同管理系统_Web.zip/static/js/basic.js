/* ============================================================
   基础资料模块（房屋/承租人/出租人/水电费标准）
   ============================================================ */
"use strict";

App.renderBasic = function (content) {
  content.innerHTML = `
  <div class="panel">
    <div class="tabs" id="basicTabs">
      <button class="tab-btn active" data-tab="houses">房屋资料</button>
      <button class="tab-btn" data-tab="tenants">承租人资料</button>
      <button class="tab-btn" data-tab="landlords">出租人资料</button>
      <button class="tab-btn" data-tab="utility">水电费标准</button>
    </div>
    <div id="basicBody"></div>
  </div>`;
  const body = $("#basicBody");
  const showTab = (tab) => {
    $all(".tab-btn").forEach(b => b.classList.toggle("active", b.dataset.tab === tab));
    if (tab === "houses") App.renderHouses(body);
    else if (tab === "tenants") App.renderTenants(body);
    else if (tab === "landlords") App.renderLandlords(body);
    else App.renderUtility(body);
  };
  $all(".tab-btn").forEach(b => b.addEventListener("click", () => showTab(b.dataset.tab)));
  showTab("houses");
};

/* ---------------- 房屋 ---------------- */
App.renderHouses = function (body) {
  body.innerHTML = `
  <div class="toolbar" style="margin-top:12px">
    <input type="search" id="hSearch" placeholder="搜索编号/类型/位置" style="width:220px">
    <button class="btn" id="hSearchBtn">搜索</button>
    <span class="spacer"></span>
    <button class="btn btn-primary" id="hAdd">+ 添加房屋</button>
    <button class="btn btn-success" id="hImport">导入 Excel</button>
    <button class="btn" id="hExport">导出 Excel</button>
  </div>
  <div class="table-wrap">
    <table class="data-table">
      <thead><tr><th>ID</th><th>房屋编号</th><th>房屋类型</th><th>房屋位置</th><th class="num">面积(㎡)</th><th>用途</th><th>操作</th></tr></thead>
      <tbody id="hTbody"><tr><td colspan="7" style="text-align:center;color:#999">加载中...</td></tr></tbody>
    </table>
  </div>`;
  const tbody = $("#hTbody");
  const load = async () => {
    const search = $("#hSearch").value.trim();
    try {
      const r = await API.get(`/api/basic/houses?search=${encodeURIComponent(search)}`);
      const list = r.data || [];
      if (!list.length) tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;color:#999">暂无记录</td></tr>';
      else {
        tbody.innerHTML = list.map(x => `<tr data-id="${esc(x.id)}">
          <td>${esc(x.id)}</td><td>${esc(x.house_no)}</td><td>${esc(x.house_type || "")}</td>
          <td>${esc(x.house_location || "")}</td><td class="num">${esc(x.house_area)}</td>
          <td>${esc(x.usage || "")}</td>
          <td><div class="row-actions">
            <button class="btn btn-sm" data-act="edit">编辑</button>
            <button class="btn btn-sm btn-danger" data-act="del">删除</button>
          </div></td></tr>`).join("");
        $all("tr[data-id]", tbody).forEach(tr => {
          $all("button", tr).forEach(b => b.addEventListener("click", () => {
            const x = list.find(i => i.id === Number(tr.dataset.id));
            if (b.dataset.act === "edit") App.showHouseForm(load, x);
            else App.deleteBasic(load, "/api/basic/houses", tr.dataset.id, "房屋");
          }));
        });
      }
    } catch (e) { tbody.innerHTML = `<tr><td colspan="7" style="text-align:center;color:#e74c3c">${esc(e.message)}</td></tr>`; }
  };
  $("#hSearchBtn").addEventListener("click", load);
  $("#hSearch").addEventListener("keydown", e => { if (e.key === "Enter") load(); });
  $("#hAdd").addEventListener("click", () => App.showHouseForm(load, null));
  $("#hImport").addEventListener("click", () => App.importBasicExcel(load, "/api/basic/houses/import", "房屋资料", ["房屋编号", "房屋类型", "房屋位置"]));
  $("#hExport").addEventListener("click", () => {
    API.download("/api/basic/houses/export/excel", "房屋资料.xlsx").then(() => toast("已导出", "success")).catch(e => toast(e.message, "error"));
  });
  load();
};

App.showHouseForm = function (reload, data) {
  const v = (k) => (data ? (data[k] !== null && data[k] !== undefined ? data[k] : "") : "");
  openModal(data ? `编辑房屋 - ${esc(data.house_no)}` : "添加房屋", `
  <div class="form-grid">
    <div class="form-group"><label class="required">房屋编号</label>
      <input type="text" id="hNo" value="${esc(v("house_no"))}"></div>
    <div class="form-group"><label class="required">房屋类型</label>
      <input type="text" id="hType" list="houseTypeList" value="${esc(v("house_type"))}">
      <datalist id="houseTypeList"><option>门面</option><option>办公室</option><option>仓库</option><option>住房</option></datalist></div>
    <div class="form-group"><label class="required">房屋位置</label>
      <input type="text" id="hLoc" value="${esc(v("house_location"))}"></div>
    <div class="form-group"><label>面积(㎡)</label>
      <input type="number" id="hArea" step="0.01" min="0" value="${esc(v("house_area"))}"></div>
    <div class="form-group"><label>用途</label>
      <input type="text" id="hUsage" value="${esc(v("usage"))}"></div>
  </div>
  <div class="form-actions">
    <button class="btn" onclick="closeModal()">取消</button>
    <button class="btn btn-primary" id="hSave">保存</button>
  </div>`, {});
  $("#hSave").addEventListener("click", async () => {
    const d = {
      house_no: $("#hNo").value.trim(), house_type: $("#hType").value.trim(),
      house_location: $("#hLoc").value.trim(),
      house_area: parseFloat($("#hArea").value) || null,
      usage: $("#hUsage").value.trim(),
    };
    if (!d.house_no) return toast("房屋编号不能为空", "error");
    if (!d.house_type) return toast("房屋类型不能为空", "error");
    if (!d.house_location) return toast("房屋位置不能为空", "error");
    const btn = $("#hSave");
    setLoading(btn, true);
    try {
      const r = data
        ? await API.put(`/api/basic/houses/${data.id}`, { data: d })
        : await API.post("/api/basic/houses", { data: d });
      toast(r.message, "success"); closeModal(); reload();
    } catch (e) { toast(e.message, "error"); }
    finally { setLoading(btn, false); }
  });
};

/* ---------------- 承租人 ---------------- */
App.renderTenants = function (body) {
  body.innerHTML = `
  <div class="toolbar" style="margin-top:12px">
    <input type="search" id="tSearch" placeholder="搜索名称/联系人/电话" style="width:220px">
    <button class="btn" id="tSearchBtn">搜索</button>
    <span class="spacer"></span>
    <button class="btn btn-primary" id="tAdd">+ 添加承租人</button>
    <button class="btn btn-success" id="tImport">导入 Excel</button>
    <button class="btn" id="tExport">导出 Excel</button>
  </div>
  <div class="table-wrap">
    <table class="data-table">
      <thead><tr><th>ID</th><th>承租人名称</th><th>联系人</th><th>证件号</th><th>联系电话</th><th>操作</th></tr></thead>
      <tbody id="tTbody"><tr><td colspan="6" style="text-align:center;color:#999">加载中...</td></tr></tbody>
    </table>
  </div>`;
  const tbody = $("#tTbody");
  const load = async () => {
    const search = $("#tSearch").value.trim();
    try {
      const r = await API.get(`/api/basic/tenants?search=${encodeURIComponent(search)}`);
      const list = r.data || [];
      if (!list.length) tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:#999">暂无记录</td></tr>';
      else {
        tbody.innerHTML = list.map(x => `<tr data-id="${esc(x.id)}">
          <td>${esc(x.id)}</td><td>${esc(x.tenant_name)}</td><td>${esc(x.contact_person || "")}</td>
          <td>${esc(x.contact_id || "")}</td><td>${esc(x.contact_phone || "")}</td>
          <td><div class="row-actions">
            <button class="btn btn-sm" data-act="edit">编辑</button>
            <button class="btn btn-sm btn-danger" data-act="del">删除</button>
          </div></td></tr>`).join("");
        $all("tr[data-id]", tbody).forEach(tr => {
          $all("button", tr).forEach(b => b.addEventListener("click", () => {
            const x = list.find(i => i.id === Number(tr.dataset.id));
            if (b.dataset.act === "edit") App.showTenantForm(load, x);
            else App.deleteBasic(load, "/api/basic/tenants", tr.dataset.id, "承租人");
          }));
        });
      }
    } catch (e) { tbody.innerHTML = `<tr><td colspan="6" style="text-align:center;color:#e74c3c">${esc(e.message)}</td></tr>`; }
  };
  $("#tSearchBtn").addEventListener("click", load);
  $("#tSearch").addEventListener("keydown", e => { if (e.key === "Enter") load(); });
  $("#tAdd").addEventListener("click", () => App.showTenantForm(load, null));
  $("#tImport").addEventListener("click", () => App.importBasicExcel(load, "/api/basic/tenants/import", "承租人资料", ["承租人名称"]));
  $("#tExport").addEventListener("click", () => {
    API.download("/api/basic/tenants/export/excel", "承租人资料.xlsx").then(() => toast("已导出", "success")).catch(e => toast(e.message, "error"));
  });
  load();
};

App.showTenantForm = function (reload, data) {
  const v = (k) => (data ? (data[k] !== null && data[k] !== undefined ? data[k] : "") : "");
  openModal(data ? `编辑承租人 - ${esc(data.tenant_name)}` : "添加承租人", `
  <div class="form-grid">
    <div class="form-group"><label class="required">承租人名称</label>
      <input type="text" id="tName" value="${esc(v("tenant_name"))}"></div>
    <div class="form-group"><label>联系人</label>
      <input type="text" id="tContact" value="${esc(v("contact_person"))}"></div>
    <div class="form-group"><label>证件号</label>
      <input type="text" id="tId" value="${esc(v("contact_id"))}"></div>
    <div class="form-group"><label>联系电话</label>
      <input type="text" id="tPhone" value="${esc(v("contact_phone"))}"></div>
  </div>
  <div class="form-actions">
    <button class="btn" onclick="closeModal()">取消</button>
    <button class="btn btn-primary" id="tSave">保存</button>
  </div>`, {});
  $("#tSave").addEventListener("click", async () => {
    const d = {
      tenant_name: $("#tName").value.trim(), contact_person: $("#tContact").value.trim(),
      contact_id: $("#tId").value.trim(), contact_phone: $("#tPhone").value.trim(),
    };
    if (!d.tenant_name) return toast("承租人名称不能为空", "error");
    const btn = $("#tSave");
    setLoading(btn, true);
    try {
      const r = data
        ? await API.put(`/api/basic/tenants/${data.id}`, { data: d })
        : await API.post("/api/basic/tenants", { data: d });
      toast(r.message, "success"); closeModal(); reload();
    } catch (e) { toast(e.message, "error"); }
    finally { setLoading(btn, false); }
  });
};

/* ---------------- 出租人 ---------------- */
App.renderLandlords = function (body) {
  body.innerHTML = `
  <div class="toolbar" style="margin-top:12px">
    <span class="spacer"></span>
    <button class="btn btn-primary" id="lAdd">+ 添加出租人</button>
  </div>
  <div class="table-wrap">
    <table class="data-table">
      <thead><tr><th>ID</th><th>出租方（甲方）</th><th>法定代表人</th><th>分管负责人</th><th>联系电话</th><th>默认</th><th>操作</th></tr></thead>
      <tbody id="lTbody"><tr><td colspan="7" style="text-align:center;color:#999">加载中...</td></tr></tbody>
    </table>
  </div>`;
  const tbody = $("#lTbody");
  const load = async () => {
    try {
      const r = await API.get("/api/basic/landlords");
      const list = r.data || [];
      if (!list.length) tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;color:#999">暂无记录</td></tr>';
      else {
        tbody.innerHTML = list.map(x => `<tr data-id="${esc(x.id)}">
          <td>${esc(x.id)}</td><td>${esc(x.landlord_name)}</td><td>${esc(x.legal_representative || "")}</td>
          <td>${esc(x.person_in_charge || "")}</td><td>${esc(x.contact_phone || "")}</td>
          <td>${x.is_default ? '<span class="tag tag-green">默认</span>' : ""}</td>
          <td><div class="row-actions">
            <button class="btn btn-sm" data-act="edit">编辑</button>
            <button class="btn btn-sm btn-danger" data-act="del">删除</button>
          </div></td></tr>`).join("");
        $all("tr[data-id]", tbody).forEach(tr => {
          $all("button", tr).forEach(b => b.addEventListener("click", () => {
            const x = list.find(i => i.id === Number(tr.dataset.id));
            if (b.dataset.act === "edit") App.showLandlordForm(load, x);
            else App.deleteBasic(load, "/api/basic/landlords", tr.dataset.id, "出租人");
          }));
        });
      }
    } catch (e) { tbody.innerHTML = `<tr><td colspan="7" style="text-align:center;color:#e74c3c">${esc(e.message)}</td></tr>`; }
  };
  $("#lAdd").addEventListener("click", () => App.showLandlordForm(load, null));
  load();
};

App.showLandlordForm = function (reload, data) {
  const v = (k) => (data ? (data[k] !== null && data[k] !== undefined ? data[k] : "") : "");
  openModal(data ? `编辑出租人 - ${esc(data.landlord_name)}` : "添加出租人", `
  <div class="form-grid">
    <div class="form-group"><label class="required">出租方（甲方）</label>
      <input type="text" id="lName" value="${esc(v("landlord_name"))}"></div>
    <div class="form-group"><label>法定代表人</label>
      <input type="text" id="lLegal" value="${esc(v("legal_representative"))}"></div>
    <div class="form-group"><label>分管负责人</label>
      <input type="text" id="lPerson" value="${esc(v("person_in_charge"))}"></div>
    <div class="form-group"><label>联系电话</label>
      <input type="text" id="lPhone" value="${esc(v("contact_phone"))}"></div>
    <div class="form-group"><label>设为默认</label>
      <select id="lDefault"><option value="0" ${!v("is_default") ? "selected" : ""}>否</option>
        <option value="1" ${v("is_default") ? "selected" : ""}>是</option></select></div>
  </div>
  <div class="form-actions">
    <button class="btn" onclick="closeModal()">取消</button>
    <button class="btn btn-primary" id="lSave">保存</button>
  </div>`, {});
  $("#lSave").addEventListener("click", async () => {
    const d = {
      landlord_name: $("#lName").value.trim(),
      legal_representative: $("#lLegal").value.trim(),
      person_in_charge: $("#lPerson").value.trim(),
      contact_phone: $("#lPhone").value.trim(),
      is_default: $("#lDefault").value === "1",
    };
    if (!d.landlord_name) return toast("出租方名称不能为空", "error");
    const btn = $("#lSave");
    setLoading(btn, true);
    try {
      const r = data
        ? await API.put(`/api/basic/landlords/${data.id}`, { data: d })
        : await API.post("/api/basic/landlords", { data: d });
      toast(r.message, "success"); closeModal(); reload();
    } catch (e) { toast(e.message, "error"); }
    finally { setLoading(btn, false); }
  });
};

/* ---------------- 水电费标准 ---------------- */
App.renderUtility = function (body) {
  body.innerHTML = `
  <div class="toolbar" style="margin-top:12px">
    <span class="spacer"></span>
    <button class="btn btn-primary" id="uAdd">+ 添加标准</button>
  </div>
  <div class="table-wrap">
    <table class="data-table">
      <thead><tr><th>ID</th><th>房屋类型</th><th class="num">水费(元/吨)</th><th class="num">电费(元/度)</th><th>操作</th></tr></thead>
      <tbody id="uTbody"><tr><td colspan="5" style="text-align:center;color:#999">加载中...</td></tr></tbody>
    </table>
  </div>`;
  const tbody = $("#uTbody");
  const load = async () => {
    try {
      const r = await API.get("/api/basic/utility-fees");
      const list = r.data || [];
      if (!list.length) tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:#999">暂无记录</td></tr>';
      else {
        tbody.innerHTML = list.map(x => `<tr data-id="${esc(x.id)}">
          <td>${esc(x.id)}</td><td>${esc(x.house_type)}</td>
          <td class="num">${esc(x.water_fee)}</td><td class="num">${esc(x.electricity_fee)}</td>
          <td><div class="row-actions">
            <button class="btn btn-sm" data-act="edit">编辑</button>
            <button class="btn btn-sm btn-danger" data-act="del">删除</button>
          </div></td></tr>`).join("");
        $all("tr[data-id]", tbody).forEach(tr => {
          $all("button", tr).forEach(b => b.addEventListener("click", () => {
            const x = list.find(i => i.id === Number(tr.dataset.id));
            if (b.dataset.act === "edit") App.showUtilityForm(load, x);
            else App.deleteBasic(load, "/api/basic/utility-fees", tr.dataset.id, "水电费标准");
          }));
        });
      }
    } catch (e) { tbody.innerHTML = `<tr><td colspan="5" style="text-align:center;color:#e74c3c">${esc(e.message)}</td></tr>`; }
  };
  $("#uAdd").addEventListener("click", () => App.showUtilityForm(load, null));
  load();
};

App.showUtilityForm = function (reload, data) {
  const v = (k) => (data ? (data[k] !== null && data[k] !== undefined ? data[k] : "") : "");
  openModal(data ? `编辑水电费标准 - ${esc(data.house_type)}` : "添加水电费标准", `
  <div class="form-grid">
    <div class="form-group"><label class="required">房屋类型</label>
      <input type="text" id="uType" list="houseTypeList2" value="${esc(v("house_type"))}" ${data ? "readonly" : ""}>
      <datalist id="houseTypeList2"><option>门面</option><option>办公室</option><option>仓库</option><option>住房</option></datalist></div>
    <div class="form-group"><label class="required">水费(元/吨)</label>
      <input type="number" id="uWater" step="0.01" min="0" value="${esc(v("water_fee"))}"></div>
    <div class="form-group"><label class="required">电费(元/度)</label>
      <input type="number" id="uElec" step="0.01" min="0" value="${esc(v("electricity_fee"))}"></div>
  </div>
  <div class="form-actions">
    <button class="btn" onclick="closeModal()">取消</button>
    <button class="btn btn-primary" id="uSave">保存</button>
  </div>`, {});
  $("#uSave").addEventListener("click", async () => {
    const d = {
      house_type: $("#uType").value.trim(),
      water_fee: parseFloat($("#uWater").value) || 0,
      electricity_fee: parseFloat($("#uElec").value) || 0,
    };
    if (!d.house_type) return toast("房屋类型不能为空", "error");
    if (d.house_type === "全部") return toast("不能选择'全部'作为房屋类型", "error");
    if (d.water_fee < 0 || d.electricity_fee < 0) return toast("水费和电费标准不能为负数", "error");
    const btn = $("#uSave");
    setLoading(btn, true);
    try {
      const r = data
        ? await API.put(`/api/basic/utility-fees/${data.id}`, { data: d })
        : await API.post("/api/basic/utility-fees", { data: d });
      toast(r.message, "success"); closeModal(); reload();
    } catch (e) { toast(e.message, "error"); }
    finally { setLoading(btn, false); }
  });
};

/* 通用删除 */
App.deleteBasic = async function (reload, url, id, name) {
  if (!confirmDlg(`确定删除这条${name}记录吗？`)) return;
  try {
    const r = await API.del(`${url}/${id}`);
    toast(r.message, "success"); reload();
  } catch (e) { toast(e.message, "error"); }
};

/* 通用 Excel 导入（房屋/承租人，对齐原版 importHouseFromExcel / importTenantFromExcel） */
App.importBasicExcel = function (reload, url, name, requiredCols) {
  const input = document.createElement("input");
  input.type = "file";
  input.accept = ".xlsx";
  input.addEventListener("change", async () => {
    if (!input.files.length) return;
    const fd = new FormData();
    fd.append("file", input.files[0]);
    toast(`正在导入${name}...`);
    try {
      const r = await API.request("POST", url, fd, true);
      toast(r.message, "success");
      reload();
    } catch (e) { toast(e.message, "error"); }
  });
  input.click();
};
