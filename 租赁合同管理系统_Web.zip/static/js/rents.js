/* ============================================================
   租金管理模块
   ============================================================ */
"use strict";

App.renderRents = function (content) {
  content.innerHTML = `
  <div class="panel">
    <div class="toolbar">
      <input type="search" id="rSearch" placeholder="搜索合同编号/承租方/房屋编号" style="width:240px">
      <label class="check-inline"><input type="checkbox" id="rSt1" value="已结清" checked> 已结清</label>
      <label class="check-inline"><input type="checkbox" id="rSt3" value="部分收款" checked> 部分收款</label>
      <label class="check-inline"><input type="checkbox" id="rSt2" value="未结清" checked> 未结清</label>
      <label>收款开始日期: <input type="date" id="rDateFrom" value="${yearStartStr()}"></label>
      <label>收款结束日期: <input type="date" id="rDateTo" value="${yearEndStr()}"></label>
      <span class="spacer"></span>
      <button class="btn" id="rReset">重置</button>
      <button class="btn" id="rSearchBtn">搜索</button>
      <button class="btn btn-primary" id="rAdd">+ 添加租金记录</button>
      <button class="btn" id="rExport">导出 Excel</button>
      <button class="btn" id="rExportPdf">导出 PDF</button>
    </div>
    <div class="table-wrap" style="max-height:73.3vh;overflow-y:auto">
      <table class="data-table" id="rentTable">
        <thead><tr>
          <th data-key="id" class="sortable">ID<span class="sort-ic"></span></th>
          <th data-key="contract_no" class="sortable">合同编号<span class="sort-ic"></span></th>
          <th data-key="house_no" class="sortable">房屋编号<span class="sort-ic"></span></th>
          <th data-key="lessee" class="sortable">承租方<span class="sort-ic"></span></th>
          <th data-key="receipt_date" class="sortable">收款日期<span class="sort-ic"></span></th>
          <th data-key="amount" class="sortable num">金额<span class="sort-ic"></span></th>
          <th data-key="period_start" class="sortable">所属期间<span class="sort-ic"></span></th>
          <th data-key="payment_method" class="sortable">租金支付方式<span class="sort-ic"></span></th>
          <th data-key="payment_status" class="sortable">收款状态<span class="sort-ic"></span></th>
          <th data-key="description" class="sortable">备注<span class="sort-ic"></span></th>
          <th>操作</th>
        </tr></thead>
        <tbody id="rentTbody"><tr><td colspan="11" style="text-align:center;color:#999">加载中...</td></tr></tbody>
      </table>
    </div>
    <div id="rentStats" style="margin-top:10px;font-size:12px;color:#666"></div>
  </div>`;
  const sel = {
    search: $("#rSearch"), st1: $("#rSt1"), st2: $("#rSt2"), st3: $("#rSt3"),
    // 收款日期区间：对应后端 receipt_date_from / receipt_date_to
    dateFrom: $("#rDateFrom"), dateTo: $("#rDateTo"),
    btn: $("#rSearchBtn"), reset: $("#rReset"), add: $("#rAdd"), exp: $("#rExport"), expPdf: $("#rExportPdf"),
    tbody: $("#rentTbody"), stats: $("#rentStats"),
  };
  sel.table = $("#rentTable");
  App._rentSort = { key: "receipt_date", dir: "desc" };
  $all("th.sortable", sel.table).forEach(th => {
    th.addEventListener("click", () => {
      const key = th.dataset.key;
      const s = App._rentSort;
      if (s.key === key && s.dir === "asc") s.dir = "desc";
      else if (s.key === key && s.dir === "desc") { s.key = "receipt_date"; s.dir = "desc"; }
      else { s.key = key; s.dir = "asc"; }
      App.applyRentSort(sel);
    });
  });
  sel.btn.addEventListener("click", () => App.searchRents(sel));
  sel.reset.addEventListener("click", () => {
    sel.search.value = ""; sel.st1.checked = true; sel.st2.checked = true; sel.st3.checked = true;
    // 收款日期区间恢复为当前年度首日 / 末日
    sel.dateFrom.value = yearStartStr(); sel.dateTo.value = yearEndStr();
    App.loadRents(sel);
  });
  sel.search.addEventListener("keydown", e => { if (e.key === "Enter") App.searchRents(sel); });
  [sel.dateFrom, sel.dateTo].forEach(el => {
    el.addEventListener("keydown", e => { if (e.key === "Enter") App.searchRents(sel); });
    el.addEventListener("change", () => App.searchRents(sel));
  });
  sel.add.addEventListener("click", () => App.showRentForm(sel, null));
  sel.exp.addEventListener("click", () => {
    const s = App._rentSort || { key: "receipt_date", dir: "desc" };
    const q = App.rentQuery(sel);
    const qs = `statuses=${encodeURIComponent(q.statuses)}`
      + `&search=${encodeURIComponent(q.search)}`
      + `&receipt_date_from=${encodeURIComponent(q.receipt_date_from)}`
      + `&receipt_date_to=${encodeURIComponent(q.receipt_date_to)}`
      + `&sort=${encodeURIComponent(s.key)}&sort_dir=${encodeURIComponent(s.dir)}`;
    App.exportFile({
      btn: sel.exp, name: "租金数据", count: (App._rentList || []).length,
      url: `/api/rents/export/excel?${qs}`, fallbackName: "租金数据.xlsx",
    });
  });
  sel.expPdf.addEventListener("click", () => {
    const q = App.rentQuery(sel);
    const qs = `statuses=${encodeURIComponent(q.statuses)}`
      + `&search=${encodeURIComponent(q.search)}`
      + `&receipt_date_from=${encodeURIComponent(q.receipt_date_from)}`
      + `&receipt_date_to=${encodeURIComponent(q.receipt_date_to)}`;
    App.exportFile({
      btn: sel.expPdf, name: "租金数据", count: (App._rentList || []).length,
      url: `/api/rents/export/pdf?${qs}`, fallbackName: "租金数据.pdf",
    });
  });
  App.loadRents(sel);
};

App.checkedRentStatuses = function (sel) {
  return [sel.st1, sel.st2, sel.st3].filter(c => c && c.checked).map(c => c.value).join(",");
};

/* 搜索：收集全部条件（含收款日期区间）→ 校验 → 重置分页 → 重新请求列表
   校验规则：日期必须为 YYYY-MM-DD 合法日期；开始日期不得晚于结束日期 */
App.searchRents = function (sel) {
  const from = (sel.dateFrom && sel.dateFrom.value || "").trim();
  const to = (sel.dateTo && sel.dateTo.value || "").trim();
  if (!isValidDateStr(from)) {
    toast("收款开始日期格式不正确，应为 YYYY-MM-DD", "error");
    if (sel.dateFrom) sel.dateFrom.focus();
    return;
  }
  if (!isValidDateStr(to)) {
    toast("收款结束日期格式不正确，应为 YYYY-MM-DD", "error");
    if (sel.dateTo) sel.dateTo.focus();
    return;
  }
  if (from && to && from > to) {
    toast("收款开始日期不能晚于结束日期", "error");
    if (sel.dateFrom) sel.dateFrom.focus();
    return;
  }
  App._rentPage = 1; // 重置分页至第一页（当前列表不分页，为后续分页预留）
  App.loadRents(sel);
};

/* 当前生效的查询条件（列表与导出共用，保证两边口径一致） */
App.rentQuery = function (sel) {
  const from = (sel.dateFrom && sel.dateFrom.value || "").trim();
  const to = (sel.dateTo && sel.dateTo.value || "").trim();
  return {
    statuses: App.checkedRentStatuses(sel),
    search: sel.search.value.trim(),
    receipt_date_from: from,
    receipt_date_to: to,
  };
};

App.loadRents = async function (sel) {
  sel.tbody.innerHTML = '<tr><td colspan="11" style="text-align:center;color:#999">加载中...</td></tr>';
  setLoading(sel.btn, true, "查询中...");
  try {
    const q = App.rentQuery(sel);
    const r = await API.get(`/api/rents?statuses=${encodeURIComponent(q.statuses)}`
      + `&search=${encodeURIComponent(q.search)}`
      + `&receipt_date_from=${encodeURIComponent(q.receipt_date_from)}`
      + `&receipt_date_to=${encodeURIComponent(q.receipt_date_to)}`);
    const list = r.data || [];
    App._rentList = list;
    App.applyRentSort(sel);
    if (!list.length) toast("没有符合当前条件的租金记录");
    const s = r.statistics || {};
    sel.stats.innerHTML = `记录总数: <b>${esc(s.count || 0)}</b>&nbsp;|&nbsp;
      已结清: <b>${s.settled_count || 0}</b>&nbsp;|&nbsp;
      部分收款: <b>${s.partial_count || 0}</b>&nbsp;|&nbsp;
      未结清: <b>${s.unsettled_count || 0}</b>&nbsp;|&nbsp;
      收款金额合计: <b>${fmtMoney(s.total_amount)}</b>`;
  } catch (e) {
    sel.tbody.innerHTML = `<tr><td colspan="11" style="text-align:center;color:#e74c3c">${esc(e.message)}</td></tr>`;
  } finally {
    setLoading(sel.btn, false);
  }
};

/* ============================================================
   租金明细表排序：默认收款日期倒序；表头三态切换（升/降/默认）
   前端本地排序（不产生后端请求），500 条量级毫秒完成
   ============================================================ */
App.sortRentList = function (list, key, dir) {
  const NUM = ["id", "amount"];
  const DATE = ["receipt_date", "period_start"];
  const arr = list.slice();
  arr.sort(function (a, b) {
    const va = a[key], vb = b[key];
    const ae = va === null || va === undefined || va === "";
    const be = vb === null || vb === undefined || vb === "";
    if (ae && be) return 0;
    if (ae) return 1; // 空值始终排最后
    if (be) return -1;
    let r;
    if (NUM.indexOf(key) >= 0) {
      r = Number(va) - Number(vb);
    } else if (DATE.indexOf(key) >= 0) {
      const ta = Date.parse(va), tb = Date.parse(vb);
      r = (!isNaN(ta) && !isNaN(tb)) ? ta - tb : String(va).localeCompare(String(vb));
    } else {
      r = String(va).localeCompare(String(vb), "zh-Hans-CN");
    }
    return dir === "asc" ? r : -r;
  });
  return arr;
};

App.applyRentSort = function (sel) {
  const s = App._rentSort;
  const sorted = App.sortRentList(App._rentList || [], s.key, s.dir);
  if (!sorted.length) {
    sel.tbody.innerHTML = '<tr><td colspan="11" style="text-align:center;color:#999">暂无记录</td></tr>';
  } else {
    sel.tbody.innerHTML = sorted.map(x => `<tr data-id="${esc(x.id)}" title="双击编辑该记录" style="cursor:pointer">
      <td>${esc(x.id)}</td><td>${esc(x.contract_no)}</td><td>${esc(x.house_no || "")}</td>
      <td>${esc(x.lessee)}</td><td>${esc(x.receipt_date)}</td>
      <td class="num">${fmtMoney(x.amount)}</td>
      <td>${esc(x.period_start)} ~ ${esc(x.period_end)}</td>
      <td>${esc(x.payment_method || "")}</td>
      <td>${statusTag(x.payment_status)}</td><td>${esc(x.description || "")}</td>
      <td><div class="row-actions">
        <button class="btn btn-sm" data-act="edit">编辑</button>
        <button class="btn btn-sm btn-danger" data-act="del">删除</button>
      </div></td>
    </tr>`).join("");
    $all("tr[data-id]", sel.tbody).forEach(tr => {
      const id = tr.dataset.id;
      $all("button", tr).forEach(btn => {
        btn.addEventListener("click", () => {
          if (btn.dataset.act === "edit") App.showRentForm(sel, Number(id));
          else App.deleteRent(sel, Number(id));
        });
      });
      // 双击整行 → 打开当前记录的“编辑租金记录”窗口（双击操作按钮除外）
      tr.addEventListener("dblclick", (e) => {
        if (e.target.closest("button")) return;
        App.showRentForm(sel, Number(id));
      });
    });
  }
  // 更新表头排序指示（箭头）
  $all("th.sortable", sel.table).forEach(th => {
    th.classList.remove("sort-asc", "sort-desc");
    const ic = th.querySelector(".sort-ic");
    if (ic) ic.textContent = "";
  });
  const cur = sel.table.querySelector('th[data-key="' + s.key + '"]');
  if (cur) {
    cur.classList.add(s.dir === "asc" ? "sort-asc" : "sort-desc");
    const ic = cur.querySelector(".sort-ic");
    if (ic) ic.textContent = s.dir === "asc" ? "▲" : "▼";
  }
};

/* 租金表单（添加/编辑）
   对齐原版 ui_rent_tab.py RentRecordDialog 逻辑规则：
   - 选合同联动填充：房屋编号/承租方(乙方)/承租人/租金支付方式/月季年租金/应收总租金/合同起止期间/最近收款所属期间/收款情况
   - 收取第(全年/1-12) + 月/季 下拉 → 说明自动生成（全年租金 / 第N{月|季}租金）
   - 所属期间自动计算：全年→合同起止；无最近记录→合同开始+N月-1天；有最近记录→上次截止+1天+N月-1天
   - 收款情况自动维护：按「累计已收 vs 合同应收」判定 已结清/部分收款/未结清；编辑模式已结清→锁定可编辑字段
   - 保存校验顺序：合同→承租方→收款日期→期间非空→金额>0→期间起止顺序 */
App.showRentForm = async function (sel, recordId) {
  let data = null;
  if (recordId) {
    try {
      const r = await API.get("/api/rents");
      data = (r.data || []).find(x => x.id === recordId) || null;
    } catch (e) {
      // P1-6（2026-09-11）：编辑模式加载失败必须显式报错，不允许静默退化为空白新增表单
      toast("加载收款记录失败，无法编辑：" + (e.message || e), "error");
      return;
    }
    if (!data) {
      toast("未找到 id=" + recordId + " 的收款记录（可能已被删除）", "error");
      return;
    }
  }
  const v = (k) => (data ? (data[k] !== null && data[k] !== undefined ? data[k] : "") : "");
  let contracts = [];
  let rents = [];
  try { contracts = (await API.get("/api/contracts")).data || []; } catch (e) {}
  try { rents = (await API.get("/api/rents")).data || []; } catch (e) {}
  const findContract = (no) => contracts.find(x => x.contract_no === no) || null;
  // 该合同最新一条收款记录（对齐原版 ORDER BY receipt_date DESC LIMIT 1；同日取 id 大者）
  const lastRentOf = (contractNo) => {
    const list = rents.filter(x => x.contract_no === contractNo)
      .sort((a, b) => (a.receipt_date < b.receipt_date ? 1 : a.receipt_date > b.receipt_date ? -1 : (a.id || 0) < (b.id || 0) ? 1 : -1));
    return list[0] || null;
  };

  // 日期工具（对齐原版 addMonths/月末-1天）
  const fmtD = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  const addDaysStr = (s, n) => {
    if (!s) return "";
    const d = new Date(s + "T00:00:00");
    d.setDate(d.getDate() + n);
    return fmtD(d);
  };
  const addMonthsMinusDay = (s, months) => {
    if (!s) return "";
    const d = new Date(s + "T00:00:00");
    d.setMonth(d.getMonth() + months);
    d.setDate(d.getDate() - 1);
    return fmtD(d);
  };

  // 对齐原版选合同对话框：只列出尚未结清的合同（未结清 + 部分收款）
  const openContracts = contracts.filter(c => c.payment_status !== "已结清");
  const contractOptions = openContracts.map(c => `<option value="${esc(c.contract_no)}" ${v("contract_no") === c.contract_no ? "selected" : ""}>${esc(c.contract_no)} - ${esc(c.lessee)}</option>`).join("");
  // 编辑模式且原合同不在未结清列表（已结清/已删除）：追加兜底选项，保证下拉显示记录原合同
  const origC = recordId ? contracts.find(c => c.contract_no === v("contract_no")) : null;
  const extraContractOpt = (recordId && v("contract_no") && !openContracts.some(c => c.contract_no === v("contract_no")))
    ? `<option value="${esc(v("contract_no"))}" selected>${esc(v("contract_no"))} - ${origC ? esc(origC.lessee) : "已删除"}（${origC ? "已结清" : "已删除"}）</option>` : "";
  const pnOptions = ['全年','1','2','3','4','5','6','7','8','9','10','11','12']
    .map(p => `<option value="${p}">${p}</option>`).join("");
  const periodTypes = ['月','季'].map(t => `<option value="${t}" ${t === "季" ? "selected" : ""}>${t}</option>`).join("");
  const ACC_OPTS = ['基本账户','微信','现金','支付宝','其它'];
  const extraAcc = v("account") && !ACC_OPTS.includes(v("account"))
    ? `<option value="${esc(v("account"))}" selected>${esc(v("account"))}</option>` : "";
  const accountOptions = extraAcc + ACC_OPTS.map(a => `<option value="${esc(a)}" ${v("account") === a ? "selected" : ""}>${esc(a)}</option>`).join("");

  const selContract = findContract(v("contract_no"));

  openModal(recordId ? `编辑租金记录 #${recordId}` : "添加租金记录", `
  <div class="form-grid">
    <div class="form-row">
      <div class="form-group"><label class="required">合同</label>
        <select id="rContractNo">${extraContractOpt}${contractOptions}</select></div>
      <div class="form-group"><label>房屋编号</label>
        <input type="text" id="rHouseNo" readonly value="${esc(v("house_no"))}"></div>
      <div class="form-group"><label>收款情况</label>
        <input type="text" id="rPayStatusNote" readonly value="未选择" style="color:#c62828;font-weight:bold;border:1px solid #c62828;text-align:center"></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label class="required">承租方(乙方)</label>
        <input type="text" id="rLessee" readonly value="${esc(v("lessee"))}"></div>
      <div class="form-group"><label>承租人</label>
        <input type="text" id="rTenant" readonly value="${esc(v("tenant"))}"></div>
      <div class="form-group"><label>租金支付方式</label>
        <input type="text" id="rPayMethodInfo" readonly value="${esc(selContract ? selContract.payment_method : "")}"></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>月租金（元）</label>
        <input type="text" id="rMonthlyRent" readonly></div>
      <div class="form-group"><label>季租金（自动）</label>
        <input type="text" id="rQuarterlyRent" readonly></div>
      <div class="form-group"><label>年租金（自动）</label>
        <input type="text" id="rAnnualRent" readonly></div>
      <div class="form-group"><label>应收总租金（元）</label>
        <input type="text" id="rReceivable" readonly></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>合同起止期间</label>
        <input type="text" id="rContractPeriod" readonly></div>
      <div class="form-group"><label>最近收款所属期间</label>
        <input type="text" id="rLastPeriod" readonly></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label class="required">收款日期</label>
        <input type="date" id="rReceiptDate" value="${esc(v("receipt_date") || todayStr())}"></div>
      <div class="form-group"><label>收取第</label>
        <select id="rPeriodNumber">${pnOptions}</select></div>
      <div class="form-group"><label>月/季</label>
        <select id="rPeriodType">${periodTypes}</select></div>
      <div class="form-group"><label class="required">金额（元）</label>
        <input type="number" id="rAmount" step="0.01" min="0" max="999999.99" value="${esc(v("amount"))}"></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label class="required">所属期间开始</label>
        <input type="date" id="rPeriodStart" value="${esc(v("period_start"))}"></div>
      <div class="form-group"><label class="required">所属期间截止</label>
        <input type="date" id="rPeriodEnd" value="${esc(v("period_end"))}"></div>
      <div class="form-group"><label>收款账户</label>
        <select id="rAccount">${accountOptions}</select></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>发票收据开具日期</label>
        <input type="date" id="rInvoiceDate" value="${esc(v("invoice_date") || todayStr())}"></div>
    </div>
    <div class="form-group full"><label>备注</label>
      <textarea id="rDescription">${esc(v("description"))}</textarea></div>
  </div>
  <div class="form-actions">
    <button class="btn" onclick="closeModal()">取消</button>
    <button class="btn btn-primary" id="rSaveBtn">保存</button>
  </div>`, { wide: true });

  const $n = (id) => $("#" + id);
  let curContract = selContract;

  // 收款状态三态判定（2026-09-14 缺陷修复）
  // 原判据「本次金额 >= 当前欠款余额」是错的：编辑模式下合同的 received_rent 已包含本笔，
  // 于是「本次金额 == 余额」会被误判为已结清 —— 经典场景：应收 48000、已收 36000、
  // 本次再收 12000，余额正好 12000，状态却被写成「已结清」。
  // 现改为累计口径：不含本笔的已收基数 + 本次金额，与合同应收总额比较。
  const PAY_TOLERANCE = 0.5; // 分→元换算尾差容忍（元）
  const calcPaymentStatus = (amt) => {
    if (!curContract) return "";
    const total = Number(curContract.total_rent) || 0;
    // 编辑模式：合同的 received_rent 已含本笔，先扣掉原金额才是「不含本次」的已收基数
    const base = (Number(curContract.received_rent) || 0) - (recordId ? (parseFloat(v("amount")) || 0) : 0);
    const cumulative = base + (parseFloat(amt) || 0);
    if (total <= 0) return "已结清";
    if (cumulative <= 0) return "未结清";
    if (cumulative >= total - PAY_TOLERANCE) return "已结清";
    return "部分收款";
  };
  // 收款情况 = f(合同应收总额, 累计已收)；编辑模式已结清→锁定
  const updatePaymentStatus = (isEdit) => {
    const note = $n("rPayStatusNote");
    const c = curContract;
    if (!c) { note.value = $n("rContractNo").value ? "合同不存在" : "未选择"; return; }
    const status = calcPaymentStatus($n("rAmount").value);
    note.value = status;
    note.style.color = "#c62828";
    if (isEdit && status === "已结清") {
      // 对齐原版 setFieldsEditable(False) 8 项：收款日期/金额/期间起止/账户/发票日期/说明/保存按钮
      ["rReceiptDate","rAmount","rPeriodStart","rPeriodEnd","rAccount","rInvoiceDate","rDescription","rSaveBtn"].forEach(id => {
        const el = $n(id); if (el) el.disabled = true;
      });
    }
    return status;
  };
  // 金额变化时按累计口径重算收款状态（更新只读红字；无合同不覆盖）
  const autoUpdatePaymentStatus = () => {
    const note = $n("rPayStatusNote");
    if (!note || !curContract) return;
    note.value = calcPaymentStatus($n("rAmount").value);
  };
  // 对齐原版 updateDescription：全年租金 / 第N{月|季}租金
  const updateDescription = () => {
    const n = $n("rPeriodNumber").value;
    const t = $n("rPeriodType").value;
    return n === "全年" ? "全年租金" : `第${n}${t}租金`;
  };
  // 对齐原版 updatePeriodDates：所属期间自动计算
  const updatePeriodDates = () => {
    const c = curContract;
    if (!c || !c.start_date || !c.end_date) return;
    const pn = $n("rPeriodNumber").value;
    if (pn === "全年") {
      $n("rPeriodStart").value = c.start_date;
      $n("rPeriodEnd").value = c.end_date;
      return;
    }
    const months = $n("rPeriodType").value === "月" ? 1 : 3;
    const last = lastRentOf(c.contract_no);
    if (last && last.period_end) {
      const start = addDaysStr(last.period_end, 1);
      $n("rPeriodStart").value = start;
      $n("rPeriodEnd").value = addMonthsMinusDay(start, months);
    } else {
      $n("rPeriodStart").value = c.start_date;
      $n("rPeriodEnd").value = addMonthsMinusDay(c.start_date, months);
    }
  };
  // 选合同联动（对齐原版 fill_contract_info）
  const fillContractInfo = (isEdit) => {
    const c = findContract($n("rContractNo").value);
    curContract = c;
    if (!c) {
      $n("rHouseNo").value = ""; $n("rPayMethodInfo").value = "";
      $n("rMonthlyRent").value = ""; $n("rQuarterlyRent").value = ""; $n("rAnnualRent").value = "";
      $n("rReceivable").value = ""; $n("rContractPeriod").value = ""; $n("rLastPeriod").value = "";
      updatePaymentStatus(isEdit);
      return;
    }
    $n("rHouseNo").value = c.house_no || "";
    $n("rLessee").value = c.lessee || "";
    $n("rTenant").value = c.tenant || "";
    $n("rPayMethodInfo").value = c.payment_method || "";
    $n("rMonthlyRent").value = c.monthly_rent !== null && c.monthly_rent !== undefined ? Number(c.monthly_rent).toFixed(2) : "";
    $n("rQuarterlyRent").value = c.quarterly_rent !== null && c.quarterly_rent !== undefined ? String(c.quarterly_rent) : (c.monthly_rent ? String(Math.round(Number(c.monthly_rent) * 3)) : "");
    $n("rAnnualRent").value = c.annual_rent !== null && c.annual_rent !== undefined ? String(c.annual_rent) : (c.monthly_rent ? String(Math.round(Number(c.monthly_rent) * 12)) : "");
    const receivable = (Number(c.total_rent) || 0) - (Number(c.received_rent) || 0);
    $n("rReceivable").value = String(Math.round(receivable));
    $n("rContractPeriod").value = c.start_date && c.end_date ? `${c.start_date} ~ ${c.end_date}` : "";
    const last = lastRentOf(c.contract_no);
    $n("rLastPeriod").value = last && last.period_start && last.period_end ? `${last.period_start} ~ ${last.period_end}` : "暂无收款记录";
    updatePaymentStatus(isEdit);
    updatePeriodDates();
    $n("rDescription").value = updateDescription();
  };

  $n("rContractNo").addEventListener("change", () => fillContractInfo(!!recordId));
  $n("rPeriodNumber").addEventListener("change", () => { updatePeriodDates(); $n("rDescription").value = updateDescription(); });
  $n("rPeriodType").addEventListener("change", () => { updatePeriodDates(); $n("rDescription").value = updateDescription(); });
  $n("rReceiptDate").addEventListener("change", () => { $n("rDescription").value = updateDescription(); });
  // 对齐原版：金额变化也重置说明 + 自动更新收款情况
  $n("rAmount").addEventListener("input", () => { autoUpdatePaymentStatus(); $n("rDescription").value = updateDescription(); });

  // 初始填充：添加模式默认选中第一个合同并联动；编辑模式保留记录自身期间/金额/说明
  if (selContract || $n("rContractNo").value) {
    fillContractInfo(!!recordId);
    if (recordId) {
      if (v("period_start")) $n("rPeriodStart").value = v("period_start");
      if (v("period_end")) $n("rPeriodEnd").value = v("period_end");
      if (v("description")) $n("rDescription").value = v("description");
      if (v("amount")) $n("rAmount").value = v("amount");
      if (v("receipt_date")) $n("rReceiptDate").value = v("receipt_date");
    }
  } else {
    // 未选合同：期间默认 今天 ~ 今天+1月-1天（对齐原版 QDateEdit 默认值）
    $n("rPeriodStart").value = todayStr();
    $n("rPeriodEnd").value = addMonthsMinusDay(todayStr(), 1);
  }

  $n("rSaveBtn").addEventListener("click", async () => {
    autoUpdatePaymentStatus(); // 保存前重算收款状态（对齐原版 getRentData 保存时重算）
    const noteVal = $n("rPayStatusNote").value;
    const d = {
      contract_no: $n("rContractNo").value,
      lessee: $n("rLessee").value.trim(),
      tenant: $n("rTenant").value.trim(),
      receipt_date: $n("rReceiptDate").value,
      amount: parseFloat($n("rAmount").value) || 0,
      period_start: $n("rPeriodStart").value,
      period_end: $n("rPeriodEnd").value,
      account: $n("rAccount").value,
      invoice_date: $n("rInvoiceDate").value,
      description: $n("rDescription").value.trim(), // 对齐原版 getRentData：保存说明框当前值（不兜底）
      payment_status: ["已结清", "部分收款", "未结清"].includes(noteVal) ? noteVal : "未结清", // 三态标准化（后端仍会按累计已收重算，此处仅作兜底）
      // 对齐原版 ui_rent_tab.py:3217：payment_method 保存的是「租金支付方式」（只读联动自合同的 payment_method），
      // 而非弹窗里可编辑的"收款方式"下拉；编辑模式合同已删除时回退原记录值
      payment_method: $n("rPayMethodInfo").value || v("payment_method") || "",
      house_no: curContract ? curContract.house_no : (data ? data.house_no : ""),
      monthly_rent: curContract ? curContract.monthly_rent : (data ? data.monthly_rent : ""),
    };
    // 校验顺序对齐原版 accept()
    if (!d.contract_no) return toast("请选择合同", "error");
    if (!d.lessee) return toast("承租方(乙方)不能为空", "error");
    if (!d.receipt_date) return toast("收款日期不能为空", "error");
    if (!d.period_start || !d.period_end) return toast("所属期间不能为空", "error");
    if (d.amount <= 0) return toast("金额必须大于0", "error");
    if (d.period_start > d.period_end) return toast("所属期间开始日期不能晚于截止日期", "error");
    const btn = $n("rSaveBtn");
    setLoading(btn, true);
    try {
      const r = recordId
        ? await API.put(`/api/rents/${recordId}`, { data: d })
        : await API.post("/api/rents", { data: d });
      toast(r.message, "success");
      window.dispatchEvent(new CustomEvent("lease-data-updated"));
      closeModal();
      App.loadRents(sel);
    } catch (e) { toast(e.message, "error"); }
    finally { setLoading(btn, false); }
  });
};

/* 删除租金记录 */
App.deleteRent = async function (sel, recordId) {
  if (!confirmDlg(`确定删除这条租金记录吗？`)) return;
  try {
    const r = await API.del(`/api/rents/${recordId}`);
    toast(r.message, "success");
    window.dispatchEvent(new CustomEvent("lease-data-updated"));
    App.loadRents(sel);
  } catch (e) { toast(e.message, "error"); }
};
