/* ============================================================
   报表统计模块
   ============================================================ */
"use strict";

App.renderReports = function (content) {
  content.innerHTML = `
  <div class="panel">
    <div class="toolbar">
      <label>报表类型:
        <select id="repType">
          <option value="合同统计报表">合同统计报表</option>
          <option value="租金收入报表">租金收入报表</option>
          <option value="收款状态报表">收款状态报表</option>
        </select>
      </label>
      <label>开始日期: <input type="date" id="repStart" value="${lastYearStr()}"></label>
      <label>结束日期: <input type="date" id="repEnd" value="${todayStr()}"></label>
      <button class="btn btn-primary" id="repGen">生成报表</button>
      <span class="spacer"></span>
      <button class="btn" id="repExpX">导出 Excel</button>
      <button class="btn" id="repExpP">导出 PDF</button>
    </div>
    <p class="report-note" id="repNote" style="display:none;margin:6px 0 0;font-size:12px;color:#7f8c8d">
      统计口径：仅取「合同管理」与「租金管理」两表数据；分组基准 = <b>合同</b>的收款状态（与合同管理页一致），仅统计 <b>执行中</b> 合同；
      <b>合同份数</b> = 该状态的执行中合同数（未结清等暂无收款的合同也计入）；<b>金额合计</b> = 该状态合同在所选区间内的收款金额之和（元）；
      明细仅列区间内的收款记录。
    </p>
    <div class="report-chart" id="repChart"><p style="color:#999;text-align:center;padding-top:100px">请点击「生成报表」按钮生成图表</p></div>
    <div class="table-wrap" style="max-height:45vh;overflow-y:auto">
      <table class="data-table" id="repTable">
        <thead><tr id="repHead"></tr></thead>
        <tbody id="repTbody"><tr><td style="text-align:center;color:#999">请点击「生成报表」按钮查看数据</td></tr></tbody>
      </table>
    </div>
  </div>`;
  const sel = {
    type: $("#repType"), start: $("#repStart"), end: $("#repEnd"),
    gen: $("#repGen"), expX: $("#repExpX"), expP: $("#repExpP"),
    chart: $("#repChart"), head: $("#repHead"), tbody: $("#repTbody"),
    note: $("#repNote"),
  };
  sel.gen.addEventListener("click", () => App.loadReport(sel));
  sel.expX.addEventListener("click", () => App.exportReport(sel, "excel"));
  sel.expP.addEventListener("click", () => App.exportReport(sel, "pdf"));
  // 切换报表类型：只清视图与口径提示，不发任何请求（数据一律等「生成报表」）
  sel.type.addEventListener("change", () => App.resetReportView(sel));
  App.resetReportView(sel);
};

// 「收款状态报表」口径较特殊（去重计数 + 双源数据），页面显式提示，避免误读
App.toggleReportNote = function (sel) {
  if (sel.note) sel.note.style.display = sel.type.value === "收款状态报表" ? "" : "none";
};

App.destroyReportChart = function () {
  if (App.charts && App.charts.report) {
    try { App.charts.report.destroy(); } catch (e) {}
    App.charts.report = null;
  }
};

// 清空图表与数据区，只留占位提示（切换报表类型 / 首次进入页面都走这里）
App.resetReportView = function (sel) {
  App._reportSeq++;            // 自增后，在途请求的返回值一律作废，避免旧数据盖回来
  App.destroyReportChart();
  sel.head.innerHTML = "";
  sel.tbody.innerHTML = '<tr><td style="text-align:center;color:#999">请点击「生成报表」按钮查看数据</td></tr>';
  sel.chart.innerHTML = '<p style="color:#999;text-align:center;padding-top:100px">请点击「生成报表」按钮生成图表</p>';
  App.toggleReportNote(sel);
};

// 请求序号：区分「切换类型」与「生成报表」两条数据流；同一时刻只允许一个请求在飞
App._reportSeq = 0;
App._reportBusy = false;

App.loadReport = async function (sel) {
  const type = sel.type.value, start = sel.start.value, end = sel.end.value;
  if (!start || !end) return toast("请选择日期范围", "error");
  if (start > end) return toast("开始日期不能晚于结束日期", "error");
  if (App._reportBusy) return;                  // 与 setLoading 的按钮禁用构成双保险
  App._reportBusy = true;
  const seq = ++App._reportSeq;
  const isStale = () => seq !== App._reportSeq; // 期间切换过报表类型 → 本次结果作废

  App.destroyReportChart();
  sel.head.innerHTML = "";
  sel.tbody.innerHTML = '<tr><td style="text-align:center;color:#999">加载中...</td></tr>';
  sel.chart.innerHTML = '<p style="color:#999;text-align:center;padding-top:100px">正在生成报表...</p>';
  setLoading(sel.gen, true, "生成中...");
  try {
    const r = await API.get(`/api/reports?report_type=${encodeURIComponent(type)}&start_date=${start}&end_date=${end}`);
    if (isStale()) return;                      // 已切类型，视图已重置，丢弃本次返回
    const headers = r.headers || [];
    const rows = r.rows || [];
    sel.head.innerHTML = headers.map(h => `<th>${esc(h)}</th>`).join("");
    // 金额列按页面既有格式（千分位两位小数）展示，数值与来源表一致
    const moneyIdx = headers.map((h, i) => (/金额|租金/.test(String(h)) ? i : -1)).filter(i => i >= 0);
    if (!rows.length) {
      sel.tbody.innerHTML = '<tr><td style="text-align:center;color:#999">暂无数据</td></tr>';
    } else {
      sel.tbody.innerHTML = rows.map(row => `<tr>${row.map((c, i) =>
        `<td>${esc(moneyIdx.indexOf(i) >= 0 ? fmtMoney(c) : c)}</td>`).join("")}</tr>`).join("");
    }
    // 图表
    App.renderReportChart(sel.chart, type, r.chart || {});
  } catch (e) {
    if (isStale()) return;
    const msg = esc(e.message || "生成报表失败");
    sel.head.innerHTML = "";
    sel.tbody.innerHTML = `<tr><td style="text-align:center;color:#e74c3c">${msg}</td></tr>`;
    sel.chart.innerHTML = `<p style="color:#e74c3c;text-align:center;padding-top:100px">生成失败：${msg}</p>`;
  } finally {
    App._reportBusy = false;
    setLoading(sel.gen, false);
  }
};

// 计数类标签：0 / null 一律显示 0 或空，整数加千分位
App.fmtCount = function (v) {
  if (v === null || v === undefined || v === "") return "";
  const n = Number(v);
  return isNaN(n) ? String(v) : n.toLocaleString("zh-CN");
};

// 柱顶数值标签的通用样式（租金收入报表 / 收款状态报表共用，避免两处配置走偏）
//   formatter  格式化函数；(num) 柱数，用于标签变多时自动缩字号
// 位置要点：竖直柱 anchor='end' 取柱顶端、align='end' 朝柱外侧，插件最终还会再减去
//           「半个标签高 + offset」，故标签外框底边正好在柱顶上方 offset 像素，绝不压柱体。
App.barTopLabels = function (formatter, num) {
  return {
    display: true,
    anchor: "end",
    align: "end",
    offset: 5,         // 标签底边距柱顶 5px
    clamp: true,       // 超出绘图区时贴边回收，不被顶边裁掉
    color: "#2c3e50",
    backgroundColor: "rgba(255,255,255,.88)", // 浅色底衬：跨网格线/折线也清晰
    borderWidth: 0,
    borderRadius: 3,
    padding: { top: 2, bottom: 2, left: 4, right: 4 },
    font: { size: num > 24 ? 9 : num > 14 ? 10 : 11, weight: "600" },
    formatter,
  };
};

// 折线数据点标签的避让决策（内部函数；backend/check_report_bar_labels.js 有等价实现，两处需同步）
// 返回 "top"（点上方）/ "bottom"（点下方）/ "right"（点右侧），优先级：上 → 右 → 下
//
// 避让对象 = 柱顶标签带。柱标签在柱顶上方：外框底边距柱顶 offset5、字高约 14（含衬垫 4），
// 故柱顶上方约 5~25px 为「柱标签带」；横向以柱心为基准左右各约「标签半宽 + 4」。
//
// 坐标系提醒：y 轴向下为正，所以 pt.y < bar.y 表示「折线点高于柱顶」，此时把标签放在
// 点上方反而正好落进柱标签带（合同统计报表实测：点 95.2、柱顶 119.3、柱标签 106）。
// 因此判据不能只看「点与柱顶是否等高」，而要算「候选落点区间」与「柱标签带」是否相交。
App._reportLineAlign = function (ctx) {
  try {
    const chart = ctx.chart, i = ctx.dataIndex;
    const barMeta = chart.getDatasetMeta(0);          // 本图数据集 0 恒为柱（合同数量/份数）
    const lineMeta = chart.getDatasetMeta(ctx.datasetIndex);
    const pt = lineMeta && lineMeta.data[i];
    const bar = barMeta && barMeta.data[i];
    const area = chart.chartArea;
    if (pt && area) {
      // 候选落点区间（y）：点上方 ≈ [pt.y-29, pt.y-5]；点下方 ≈ [pt.y+5, pt.y+29]
      // （offset 8 + 标签半高 ~7 + 衬垫 4 → 中心距点约 15，上下各留 2px 余量）
      const upLo = pt.y - 29, upHi = pt.y - 5;
      const dnLo = pt.y + 5, dnHi = pt.y + 29;
      // 柱标签带（y）：柱顶上方 5~25px
      const bandLo = bar ? bar.y - 25 : null, bandHi = bar ? bar.y - 5 : null;
      const hits = (lo, hi) => bar ? (lo <= bandHi && hi >= bandLo) : false;

      // 绘图区容纳判断
      const upRoom = upLo >= area.top;          // 上方放得下
      const dnRoom = dnHi <= area.bottom;       // 下方放得下

      if (upRoom && !hits(upLo, upHi)) return "top";   // 首选：点上方且不压柱标签
      if (dnRoom && !hits(dnLo, dnHi)) return "bottom"; // 次选：点下方且不压柱标签
      // 上/下都会压柱标签，或贴边放不下 → 横向错开到点右侧（右侧 offset 16，已避开柱心标签）
      return "right";
    }
  } catch (e) { /* 布局未就绪等异常一律退回默认位置 */ }
  return "top";                              // 极端布局兜底，交给 clamp
};

// 折线数据点金额标签（收款状态报表「收款金额合计」/ 合同统计报表「合同总金额」共用）
//   formatter  格式化函数；返回 null 的点（如断点/区间外状态）不渲染标签
// 位置要点：默认在数据点上方；按 App._reportLineAlign 在 上/下/右 之间自动择位——
//   与柱顶份数标签带重叠时翻到点下方，点贴近绘图区顶部/横轴时相应翻面或右移，
//   保证金额标签不压柱顶份数标签、不与相邻标签互相叠字、不越出绘图区；
//   白底衬垫保证标签短暂压住折线/柱体时依然可读。
App.linePointLabels = function (formatter) {
  return {
    display: true,
    anchor: "center",  // 锚定折线数据点本身
    align: App._reportLineAlign,
    offset: ctx => (App._reportLineAlign(ctx) === "right" ? 16 : 8),  // 右侧多留间距，横向让开柱顶标签
    clamp: true,       // 贴近绘图区边缘时回收，不被裁掉
    color: "#c0392b",  // 与折线同色，标签视觉归属该系列（柱标签为深灰 #2c3e50）
    backgroundColor: "rgba(255,255,255,.88)",
    borderWidth: 0,
    borderRadius: 3,
    padding: { top: 2, bottom: 2, left: 4, right: 4 },
    font: { size: 10, weight: "600" },  // 金额串比份数长，比柱标签（11px）小一号
    formatter,
  };
};

// 「合同总金额」折线：数据点标签（千分位 + 两位小数，单位元）
//   与收款状态报表共用 App.linePointLabels 的避让规则；null 点（不在三态内的
//   合同状态）不渲染标签，避免把「无数据」画成 0 的假读数。
App.contractAmountLabels = function () {
  return App.linePointLabels(v => (v === null || v === undefined ? null : fmtMoney(v)));
};


App.renderReportChart = function (el, type, chart) {
  el.innerHTML = "";
  App.destroyReportChart();
  const labels = chart.labels || [];
  if (!labels.length) {
    el.innerHTML = '<p style="color:#999;text-align:center;padding-top:100px">暂无统计数据</p>';
    return;
  }
  const isPayment = type === "收款状态报表";
  const isRentIncome = type === "租金收入报表";
  const isContract = type === "合同统计报表";
  let datasets = [];
  if (isPayment) {
    // X 轴 = 收款状态三态；柱=合同份数（左轴，按合同编号去重），折线=该状态收款金额合计（右轴）
    const barColors = {
      "已结清": "rgba(39,174,96,.75)",
      "部分收款": "rgba(79,129,189,.75)",
      "未结清": "rgba(230,126,34,.75)",
    };
    datasets = [
      {
        label: "合同份数（按合同编号去重）", data: chart.counts || [], yAxisID: "y",
        backgroundColor: labels.map(l => barColors[l] || "rgba(149,165,166,.75)"),
        // 柱顶显示合同份数（整数，见 App.barTopLabels）
        datalabels: App.barTopLabels(App.fmtCount, labels.length),
      },
      {
        label: "收款金额合计（元）", data: chart.amounts || [], type: "line",
        borderColor: "#c0392b", backgroundColor: "rgba(192,57,43,.15)", yAxisID: "y1",
        // 数据点旁标注金额：千分位 + 固定两位小数（单位元，见系列名/右轴标题）；
        // 与柱顶份数标签的避让规则见 App.linePointLabels
        datalabels: App.linePointLabels(v => (v === null || v === undefined ? null : fmtMoney(v))),
      },
    ];
  } else if (isContract) {
    // 合同统计报表：柱=合同数量（左轴），折线=合同总金额（右轴）
    //   折线只画「已完成 / 已中止 / 执行中」三态（chart.amount_statuses 由后端下发），
    //   其余状态（如已逾期）对应 null → 折线断开，不伪造 0 值读数。
    const amountStatuses = chart.amount_statuses || [];
    const totals = chart.amounts || [];
    const amountData = labels.map((l, i) =>
      amountStatuses.indexOf(l) >= 0 ? (totals[i] === undefined ? null : totals[i]) : null);
    datasets = [
      {
        label: "合同数量", data: chart.values || [], yAxisID: "y",
        backgroundColor: "rgba(79,129,189,.75)",
        // 柱顶显示合同数量：整数格式（App.fmtCount）并防重叠（白底衬垫 + clamp + 自动缩字号）
        datalabels: App.barTopLabels(App.fmtCount, labels.length),
      },
      {
        label: "合同总金额（元）", data: amountData, type: "line",
        borderColor: "#c0392b", backgroundColor: "rgba(192,57,43,.15)", yAxisID: "y1",
        spanGaps: true,   // 区间外状态给 null 断点，但折线仍连起来，避免视觉断裂
        datalabels: App.contractAmountLabels(),
      },
    ];
  } else {
    // 租金收入报表：显示金额
    const barDataset = {
      label: "金额",
      data: chart.values || [],
      backgroundColor: "rgba(79,129,189,.75)",
      // 数据集级配置优先于 plugins.datalabels，此处显式开关，避免被全局 display:false 覆盖
      datalabels: isRentIncome
        ? App.barTopLabels(v => fmtMoney(v).replace(/\.00$/, ""), labels.length)
        : { display: false },
    };
    datasets = [barDataset];
  }
  const canvas = document.createElement("canvas");
  el.appendChild(canvas);
  App.charts.report = new Chart(canvas, {
    type: "bar",
    data: { labels, datasets },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: {
        legend: { position: "top" },
        datalabels: { display: false },
        // 图表标题随报表类型联动（chart.title 由后端随数据一起下发）
        title: { display: !!chart.title, text: chart.title || "" },
      },
      // 顶部留白：出现过柱顶标签的报表都要留，保证最高那根柱的标签不与图例/边框相撞
      layout: (isRentIncome || isPayment || isContract) ? { padding: { top: 26 } } : {},
      scales: (isPayment || isContract) ? {
        x: { title: { display: true, text: isPayment ? "收款状态" : "合同状态" } },
        y: {
          beginAtZero: true,
          // 左侧（计数轴）留 { 顶部余量 }：柱顶标签必须落在绘图区内。
          // ticks.precision:0 会把 max 向上取整到整数，若柱最大值正好贴近轴顶，
          // 标签就会越出绘图区（实测：柱值 28、grace12% 时标签越顶）。
          // 用 suggestedMax 显式抬高一档，配合 grace 保证至少有 1 个标签高的空间。
          grace: "15%",
          suggestedMax: (Math.max.apply(null, (isContract ? chart.values : chart.counts) || [0]) || 0) + 1,
          ticks: { precision: 0 },
          title: { display: true, text: isPayment ? "合同份数（去重）" : "合同数量" },
        },
        y1: {
          beginAtZero: true, position: "right", grid: { drawOnChartArea: false },
          title: { display: true, text: isPayment ? "收款金额（元）" : "合同总金额（元）" },
          ticks: { callback: v => fmtMoney(v) },
        },
      } : {
        y: {
          beginAtZero: true,
          grace: isRentIncome ? "12%" : 0,
          ticks: { callback: v => fmtMoney(v) },
        },
      },
    },
  });
};

App.exportReport = function (sel, fmt) {
  const type = sel.type.value, start = sel.start.value, end = sel.end.value;
  if (!start || !end) return toast("请选择日期范围", "error");
  const name = type.replace("报表", "") + (fmt === "pdf" ? ".pdf" : ".xlsx");
  API.download(`/api/reports/export?report_type=${encodeURIComponent(type)}&start_date=${start}&end_date=${end}&fmt=${fmt}`, name)
    .then(() => toast("报表已导出", "success")).catch(e => toast(e.message, "error"));
};
