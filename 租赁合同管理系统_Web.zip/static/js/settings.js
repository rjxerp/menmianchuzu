/* ============================================================
   系统设置模块（仅管理员可见）
   ============================================================ */
"use strict";

App.renderSettings = function (content) {
  if (App.user.role !== "管理员") {
    content.innerHTML = '<div class="panel"><p>需要管理员权限访问系统设置</p></div>';
    return;
  }
  // 进入系统设置需输入当前用户密码（对齐原版 SystemSettingPasswordDialog / show_authentication_prompt）
  App.requireSettingsPassword(content);
};

App.requireSettingsPassword = function (content) {
  content.innerHTML = `
  <div class="panel" style="max-width:420px;margin:40px auto;text-align:center">
    <h3 style="color:var(--primary);margin-bottom:12px">系统设置访问验证</h3>
    <p style="color:var(--gray);margin-bottom:16px">请输入当前登录用户的密码以进入系统设置</p>
    <div class="form-group" style="margin-bottom:16px">
      <input type="password" id="spPwd" placeholder="请输入密码">
    </div>
    <div class="form-actions" style="justify-content:center">
      <button class="btn btn-primary" id="spBtn">验证进入</button>
    </div>
    <div class="hint" id="spErr" style="color:var(--red);margin-top:10px"></div>
  </div>`;
  const doVerify = async () => {
    const pwd = $("#spPwd").value;
    if (!pwd) { $("#spErr").textContent = "请输入密码"; return; }
    const btn = $("#spBtn");
    setLoading(btn, true);
    try {
      await API.post("/api/auth/verify-password", { username: App.user.username, password: pwd }, { noRedirect: true });
      App.renderSettingsMain(content);
    } catch (e) {
      $("#spErr").textContent = e.message || "密码错误";
    } finally { setLoading(btn, false); }
  };
  $("#spBtn").addEventListener("click", doVerify);
  $("#spPwd").addEventListener("keydown", e => { if (e.key === "Enter") doVerify(); });
  $("#spPwd").focus();
};

App.renderSettingsMain = function (content) {
  content.innerHTML = `
  <div class="settings-grid">
    <div class="settings-group">
      <h4>数据维护</h4>
      <div class="toolbar">
        <button class="btn" id="sCreateDb">创建数据库</button>
        <button class="btn" id="sSelectDb">选择数据库</button>
        <button class="btn btn-primary" id="sBackup">备份数据</button>
        <button class="btn btn-warning" id="sRestore">数据恢复</button>
        <button class="btn btn-danger" id="sInit">数据初始化</button>
        <button class="btn" id="sOptimize">数据库优化</button>
      </div>
      <div class="info-list" style="margin-top:10px">
        <div class="info-item"><span class="k">当前数据库</span><span class="v" id="sDbPath"></span></div>
        <div class="info-item"><span class="k">备份结果</span><span class="v" id="sBackupMsg" style="color:#666"></span></div>
      </div>
    </div>
    <div class="settings-group">
      <h4>用户管理</h4>
      <div class="toolbar">
        <button class="btn btn-primary" id="sAddUser">+ 添加用户</button>
      </div>
      <div class="table-wrap">
        <table class="data-table">
          <thead><tr><th>ID</th><th>用户名</th><th>角色</th><th>操作</th></tr></thead>
          <tbody id="sUserTbody"><tr><td colspan="4" style="text-align:center;color:#999">加载中...</td></tr></tbody>
        </table>
      </div>
    </div>
    <div class="settings-group">
      <h4>提醒设置</h4>
      <div class="form-grid">
        <div class="form-group"><label>合同提前提醒天数</label>
          <input type="number" id="sRemindContract" min="0" value="30"></div>
        <div class="form-group"><label>租金提前提醒天数</label>
          <input type="number" id="sRemindRent" min="0" value="7"></div>
        <div class="form-group"><label>屏幕超时(分钟)</label>
          <input type="number" id="sTimeout" min="0" value="30"></div>
        <div class="form-group"><label>提醒检查频率(分钟)</label>
          <input type="number" id="sFreq" min="0" value="60"></div>
      </div>
      <div class="form-actions"><button class="btn btn-primary" id="sSaveRemind">保存提醒设置</button></div>
    </div>
    <div class="settings-group">
      <h4>自动备份设置</h4>
      <div class="form-grid">
        <div class="form-group"><label>启用自动备份</label>
          <select id="sAutoBackup"><option value="0">否</option><option value="1">是</option></select></div>
        <div class="form-group"><label>频率</label>
          <select id="sAbFreq"><option>每天</option><option>每周</option><option>每月</option></select></div>
        <div class="form-group"><label>备份时间</label>
          <input type="time" id="sAbTime" value="00:00"></div>
        <div class="form-group"><label>备份路径</label>
          <input type="text" id="sAbPath" placeholder="留空则使用默认 auto_backup 目录"></div>
      </div>
      <div class="form-actions"><button class="btn btn-primary" id="sSaveAuto">保存自动备份设置</button></div>
    </div>
    <div class="settings-group">
      <h4>软件信息</h4>
      <div class="form-grid">
        <div class="form-group"><label>软件品牌</label><input type="text" id="sBrand"></div>
        <div class="form-group"><label>软件名称</label><input type="text" id="sName"></div>
        <div class="form-group"><label>版本</label><input type="text" id="sVersion"></div>
        <div class="form-group"><label>开发时间</label><input type="text" id="sDevTime"></div>
      </div>
      <div class="form-actions"><button class="btn btn-primary" id="sSaveInfo">保存软件信息</button></div>
    </div>
    <div class="settings-group log-span">
      <h4>日志查看</h4>
      <div class="toolbar">
        <button class="btn" id="sOpLog">操作日志</button>
        <button class="btn" id="sRunLog">运行日志</button>
        <button class="btn btn-danger" id="sClearLog">清除日志</button>
      </div>
      <pre id="sLogBox" style="background:#f5f7fa;border-radius:6px;padding:10px;max-height:260px;overflow:auto;font-size:12px;margin-top:10px;white-space:pre-wrap;word-break:break-all"></pre>
    </div>
  </div>`;

  // 加载系统信息/设置
  let logKind = "runtime";
  (async () => {
    try {
      const [sys, remind, ab] = await Promise.all([
        API.get("/api/system/info"),
        API.get("/api/settings/reminder-settings"),
        API.get("/api/settings/auto-backup"),
      ]);
      $("#sDbPath").textContent = sys.database_path || "";
      $("#sBrand").value = sys.brand || ""; $("#sName").value = sys.software_name || "";
      $("#sVersion").value = sys.version || ""; $("#sDevTime").value = sys.dev_time || "";
      $("#sRemindContract").value = remind.contract_reminder_days || 30;
      $("#sRemindRent").value = remind.rent_reminder_days || 7;
      $("#sTimeout").value = remind.screen_timeout_minutes || 30;
      $("#sFreq").value = remind.reminder_frequency || 60;
      $("#sAutoBackup").value = ab.enabled ? "1" : "0";
      $("#sAbFreq").value = ab.frequency || "每天";
      $("#sAbTime").value = ab.backup_time || "00:00";
      $("#sAbPath").value = ab.backup_path || "";
    } catch (e) { toast(e.message, "error"); }
    App.loadSettingsUsers();
  })();

  // 备份数据：弹窗自定义备份路径（留空则用默认 backup 目录）
  $("#sBackup").addEventListener("click", async () => {
    openModal("备份数据 - 选择备份路径", `
      <p style="color:#666;margin-bottom:10px">请选择备份文件保存的目录（目录不存在会自动创建），留空则使用默认 backup 目录。备份文件自动命名为「库名_backup_年月日_时分秒.db」。</p>
      <div class="form-grid">
        <div class="form-group full"><label>备份路径（目录）</label>
          <input type="text" id="sBackupPath" placeholder="如 D:\\backup，留空则使用默认目录"></div>
      </div>
      <div class="info-list" style="margin-top:10px">
        <div class="info-item"><span class="k">默认目录</span><span class="v" id="sDefaultBackupDir" style="color:#666">加载中...</span></div>
      </div>
      <div class="form-actions">
        <button class="btn" onclick="closeModal()">取消</button>
        <button class="btn btn-primary" id="sBackupConfirm">开始备份</button>
      </div>`, { wide: true });
    $("#sBackupPath").focus();
    try {
      const bs = await API.get("/api/settings/backup-settings");
      const d = $("#sDefaultBackupDir");
      if (d) { d.textContent = bs.backup_dir || ""; $("#sBackupPath").placeholder = bs.backup_dir ? "如 " + bs.backup_dir + "，留空则使用默认目录" : "留空则使用默认目录"; }
    } catch (e) { /* 拿默认目录失败不影响手动输入 */ }
    $("#sBackupConfirm").addEventListener("click", async () => {
      const btn = $("#sBackupConfirm");
      setLoading(btn, true);
      try {
        const dir = ($("#sBackupPath").value || "").trim();
        const q = dir ? "?target_dir=" + encodeURIComponent(dir) : "";
        const r = await API.post("/api/settings/backup" + q);
        closeModal();
        $("#sBackupMsg").textContent = r.message + (r.path ? " → " + r.path : "");
        toast(r.message, "success");
      } catch (e) { toast(e.message, "error"); }
      finally { setLoading(btn, false); }
    });
  });

  // 刷新「当前数据库」路径显示（reminder：成功后必须同步，否则页面仍显示旧库路径）
  const refreshDbPath = async () => {
    try {
      const info = await API.get("/api/system/info");
      const el = $("#sDbPath");
      if (el) el.textContent = info.database_path || "";
      return info;
    } catch (e) { return null; }
  };
  App.refreshSettingsDbPath = refreshDbPath;

  // 创建数据库（对齐原版 ui_system_settings_tab.createDatabase：输入路径创建空库并切换）
  // 2026-09-18 修复：① 走 openModal 替换裸 prompt（页面弹窗规范）；② 加 setLoading 防重复点击；
  // ③ 路径 trim + .db 后缀前端预校验（原来是等后端 400 才知道）；④ 成功后同时刷新
  //    #sDbPath（原实现只刷品牌栏，当前数据库一行仍显示旧路径）。
  // 后端语义已加固为「仅新建」：目标文件已存在会被拒绝，不会覆盖已有数据。
  $("#sCreateDb").addEventListener("click", () => {
    openModal("创建数据库", `
      <p style="color:#8B0000;font-weight:bold;margin-bottom:10px">说明：新建一个空白数据库并<strong>自动切换过去</strong>。新库初始账号 <code>admin</code> / <code>admin</code>，不含任何业务数据。</p>
      <div class="form-grid">
        <div class="form-group full"><label>新数据库文件完整路径</label>
          <input type="text" id="sCreateDbPath" placeholder="如 ${esc(App.getDbDirHint())}\\${esc("new_lease.db")}"></div>
      </div>
      <div class="info-list" style="margin-top:10px">
        <div class="info-item"><span class="k">目标文件已存在时</span><span class="v" style="color:#666">不会覆盖，操作会被拒绝（改用「选择数据库」）</span></div>
      </div>
      <div class="form-actions">
        <button class="btn" onclick="closeModal()">取消</button>
        <button class="btn btn-primary" id="sCreateDbConfirm">创建并切换</button>
      </div>`, { wide: true });
    const input = $("#sCreateDbPath");
    if (input) input.focus();
    $("#sCreateDbConfirm").addEventListener("click", async () => {
      const btn = $("#sCreateDbConfirm");
      const path = ($("#sCreateDbPath") && $("#sCreateDbPath").value || "").trim();
      if (!path) return toast("请输入新数据库文件完整路径", "error");
      if (!/\.db$/i.test(path)) return toast("路径必须以 .db 结尾（如 …\\new_lease.db）", "error");
      if (!confirmDlg("创建后会自动切换到新数据库（新库初始账号 admin/admin），是否继续？")) return;
      setLoading(btn, true);
      try {
        const r = await API.post("/api/settings/create-database", { db_path: path });
        closeModal();
        await refreshDbPath();
        App.loadSystemInfo();
        toast(r.message, "success");
      } catch (e) { toast(e.message, "error"); }
      finally { setLoading(btn, false); }
    });
  });

  // 选择数据库（对齐原版 selectDatabase：校验 SQLite 表后切换）
  $("#sSelectDb").addEventListener("click", async () => {
    const path = prompt("请输入要切换的数据库文件完整路径：");
    if (!path) return;
    if (!confirmDlg("切换数据库后将使用新数据库，是否继续？")) return;
    try {
      const r = await API.post("/api/settings/switch-database", { db_path: path });
      toast(r.message, "success");
      App.loadSystemInfo();
    } catch (e) { toast(e.message, "error"); }
  });

  $("#sRestore").addEventListener("click", async () => {
    const path = prompt("请输入备份文件的完整路径：");
    if (!path) return;
    if (!confirmDlg("恢复数据将覆盖当前所有数据，是否继续？")) return;
    try {
      const r = await API.post("/api/settings/restore", { backup_path: path });
      toast(r.message, "success");
    } catch (e) { toast(e.message, "error"); }
  });

  $("#sInit").addEventListener("click", async () => {
    // 数据初始化：可选表勾选（对齐原版 DataInitDialog），全选默认
    const tables = [
      ["contracts", "合同表"], ["rent_records", "租金记录表"], ["reminder_settings", "提醒设置表"],
      ["users", "用户表"], ["houses", "房屋资料"], ["landlords", "出租人资料"],
      ["tenants", "承租人资料"], ["notes", "笔记表"], ["operation_logs", "操作日志表"], ["utility_fee", "水电费记录表"],
    ];
    openModal("数据初始化", `
      <p style="color:#8B0000;font-weight:bold;margin-bottom:10px">说明：选择需要初始化的数据表。初始化操作将清空所选表中的所有数据！</p>
      <div class="form-grid">
        ${tables.map(([k, name], i) => `
          <div class="form-group"><label style="display:flex;align-items:center;gap:6px;cursor:pointer">
            <input type="checkbox" id="initT${i}" value="${k}" checked> ${name}（${k}）
          </label></div>`).join("")}
      </div>
      <div class="form-actions">
        <button class="btn" onclick="closeModal()">取消</button>
        <button class="btn btn-danger" id="initConfirm">确认初始化</button>
      </div>`, { wide: true });
    $("#initConfirm").addEventListener("click", async () => {
      const sel = tables.map((_, i) => $("#initT" + i)).filter(c => c && c.checked).map(c => c.value);
      if (!sel.length) return toast("请至少选择一张表", "error");
      if (!confirmDlg(`确定要初始化以下数据表吗？\n${sel.map(s => tables.find(t => t[0] === s)[1]).join("、")}\n\n此操作将清空所选表中的所有数据！`)) return;
      const btn = $("#initConfirm");
      setLoading(btn, true);
      try {
        const r = await API.post(`/api/settings/initialize?tables=${encodeURIComponent(sel.join(","))}`);
        toast(r.message, "success");
        closeModal();
      } catch (e) { toast(e.message, "error"); }
      finally { setLoading(btn, false); }
    });
  });

  $("#sOptimize").addEventListener("click", async () => {
    if (!confirmDlg("数据库优化将执行 VACUUM 与索引重建，是否继续？")) return;
    const btn = $("#sOptimize");
    setLoading(btn, true);
    try {
      const r = await API.post("/api/settings/optimize");
      toast(r.message, "success");
    } catch (e) { toast(e.message, "error"); }
    finally { setLoading(btn, false); }
  });

  $("#sAddUser").addEventListener("click", () => App.showUserForm());

  $("#sSaveRemind").addEventListener("click", async () => {
    try {
      const r = await API.post("/api/settings/reminder-settings", { data: {
        contract_reminder_days: Number($("#sRemindContract").value) || 30,
        rent_reminder_days: Number($("#sRemindRent").value) || 7,
        screen_timeout_minutes: Number($("#sTimeout").value) || 30,
        reminder_frequency: Number($("#sFreq").value) || 60,
      }});
      // 同步提醒频率/屏幕超时到 localStorage，供 app.js 提醒定时器与自动退出使用
      Store.set("lease_reminder_freq", String(Number($("#sFreq").value) || 60));
      Store.set("lease_screen_timeout", String(Number($("#sTimeout").value) || 0));
      toast(r.message, "success");
    } catch (e) { toast(e.message, "error"); }
  });

  $("#sSaveAuto").addEventListener("click", async () => {
    try {
      const r = await API.post("/api/settings/auto-backup", { data: {
        enabled: $("#sAutoBackup").value === "1",
        frequency: $("#sAbFreq").value,
        backup_time: $("#sAbTime").value,
        backup_path: $("#sAbPath").value.trim(),
      }});
      toast(r.message, "success");
    } catch (e) { toast(e.message, "error"); }
  });

  $("#sSaveInfo").addEventListener("click", async () => {
    try {
      const r = await API.post("/api/settings/software-info", { data: {
        brand: $("#sBrand").value.trim(), software_name: $("#sName").value.trim(),
        version: $("#sVersion").value.trim(), dev_time: $("#sDevTime").value.trim(),
      }});
      toast(r.message, "success");
      App.loadSystemInfo();
    } catch (e) { toast(e.message, "error"); }
  });

  $("#sOpLog").addEventListener("click", async () => {
    logKind = "operation";
    try {
      const r = await API.get("/api/settings/logs?kind=operation&limit=200");
      const logs = r.data || [];
      $("#sLogBox").textContent = logs.length ? logs.map(l =>
        `[${l.log_time}] ${l.username} | ${l.operation_module} | ${l.operation_content} | ${l.operation_result}${l.detail ? " | " + (typeof l.detail === "string" ? l.detail : JSON.stringify(l.detail)) : ""}`
      ).join("\n") : "暂无操作日志";
    } catch (e) { toast(e.message, "error"); }
  });

  $("#sRunLog").addEventListener("click", async () => {
    logKind = "runtime";
    try {
      const r = await API.get("/api/settings/logs?kind=runtime&limit=200");
      $("#sLogBox").textContent = r.content || "暂无运行日志";
    } catch (e) { toast(e.message, "error"); }
  });

  // 清除日志：清除当前查看类型的日志（运行日志=清空日志文件；操作日志=清空日志表）
  $("#sClearLog").addEventListener("click", async () => {
    const label = logKind === "operation" ? "操作日志" : "运行日志";
    if (!confirm(`确定要清除当前显示的【${label}】吗？此操作不可恢复！`)) return;
    try {
      const r = await API.post(`/api/settings/clear-logs?kind=${logKind}`);
      toast((r && r.message) || "日志已清除", "success");
      $("#sLogBox").textContent = logKind === "operation" ? "暂无操作日志" : "暂无运行日志";
    } catch (e) { toast(e.message, "error"); }
  });
};

/* 用户列表 */
App.loadSettingsUsers = async function () {
  const tbody = $("#sUserTbody");
  if (!tbody) return;
  try {
    const r = await API.get("/api/settings/users");
    const list = r.data || [];
    if (!list.length) tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;color:#999">暂无用户</td></tr>';
    else {
      tbody.innerHTML = list.map(u => `<tr data-u="${esc(u.username)}">
        <td>${u.id}</td><td>${esc(u.username)}</td>
        <td>${u.role === "管理员" ? '<span class="tag tag-blue">管理员</span>' : '<span class="tag tag-green">操作员</span>'}</td>
        <td><div class="row-actions">
          <button class="btn btn-sm" data-act="edit">更新</button>
          <button class="btn btn-sm btn-danger" data-act="del">删除</button>
        </div></td></tr>`).join("");
      $all("tr[data-u]", tbody).forEach(tr => {
        $all("button", tr).forEach(b => b.addEventListener("click", () => {
          const u = list.find(i => i.username === tr.dataset.u);
          if (b.dataset.act === "edit") App.showUserForm(u);
          else App.deleteUser(u);
        }));
      });
    }
  } catch (e) {
    tbody.innerHTML = `<tr><td colspan="4" style="text-align:center;color:#e74c3c">${esc(e.message)}</td></tr>`;
  }
};

/* 用户表单 */
App.showUserForm = function (user) {
  const editing = !!user;
  openModal(editing ? `更新用户 - ${esc(user.username)}` : "添加用户", `
  <div class="form-grid">
    <div class="form-group"><label class="required">用户名</label>
      <input type="text" id="uName" value="${editing ? esc(user.username) : ""}" ${editing ? "readonly" : ""}></div>
    <div class="form-group"><label class="required">${editing ? "新密码" : "密码"}</label>
      <input type="password" id="uPwd" placeholder="${editing ? "留空则不修改" : "请输入密码"}"></div>
    <div class="form-group"><label>角色</label>
      <select id="uRole">
        <option value="管理员" ${editing && user.role === "管理员" ? "selected" : ""}>管理员</option>
        <option value="操作员" ${editing && user.role === "操作员" ? "selected" : ""}>操作员</option>
      </select></div>
  </div>
  <div class="form-actions">
    <button class="btn" onclick="closeModal()">取消</button>
    <button class="btn btn-primary" id="uSave">保存</button>
  </div>`, { narrow: true });
  $("#uSave").addEventListener("click", async () => {
    const username = $("#uName").value.trim();
    const password = $("#uPwd").value;
    const role = $("#uRole").value;
    if (!username) return toast("用户名不能为空", "error");
    if (!editing && !password) return toast("密码不能为空", "error");
    if (password && password.length < 4) return toast("密码至少4位", "error");
    const btn = $("#uSave");
    setLoading(btn, true);
    try {
      const r = editing
        ? await API.put(`/api/settings/users/${encodeURIComponent(username)}`, { role, new_password: password || undefined })
        : await API.post("/api/settings/users", { username, password, role });
      toast(r.message, "success"); closeModal(); App.loadSettingsUsers();
    } catch (e) { toast(e.message, "error"); }
    finally { setLoading(btn, false); }
  });
};

/* 删除用户 */
App.deleteUser = async function (user) {
  if (!confirmDlg(`确定删除用户 ${user.username} 吗？`)) return;
  try {
    const r = await API.del(`/api/settings/users/${encodeURIComponent(user.username)}`);
    toast(r.message, "success"); App.loadSettingsUsers();
  } catch (e) { toast(e.message, "error"); }
};
